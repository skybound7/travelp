-- Create database and user
CREATE DATABASE IF NOT EXISTS luxury_travel;
USE luxury_travel;

-- Create tables
CREATE TABLE IF NOT EXISTS combo_itineraries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status ENUM('draft', 'confirmed', 'cancelled', 'completed') DEFAULT 'draft',
    total_price DECIMAL(10, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS itinerary_components (
    id INT AUTO_INCREMENT PRIMARY KEY,
    itinerary_id INT NOT NULL,
    component_type ENUM('flight', 'hotel', 'activity', 'transport') NOT NULL,
    start_datetime DATETIME NOT NULL,
    end_datetime DATETIME NOT NULL,
    location_from VARCHAR(100) NOT NULL,
    location_to VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    details JSON,
    status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
    <!-- In the head section -->
    <link href="/css/applications.css" rel="stylesheet">
    
    <!-- Before closing body tag -->
    <script src="/js/applications.js"></script><!-- Include the applications section -->
    <?php include 'templates/service-applications.html'; ?>created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (itinerary_id) REFERENCES combo_itineraries(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS itinerary_schedule (
    id INT AUTO_INCREMENT PRIMARY KEY,
    itinerary_id INT NOT NULL,
    day_number INT NOT NULL,
    time_slot TIME NOT NULL,
    activity_type VARCHAR(50) NOT NULL,
    description TEXT,
    location VARCHAR(100),
    duration INT, -- in minutes
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (itinerary_id) REFERENCES combo_itineraries(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    itinerary_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    transaction_id VARCHAR(100),
    status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (itinerary_id) REFERENCES combo_itineraries(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS payment_refunds (
    id INT AUTO_INCREMENT PRIMARY KEY,
    payment_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    reason TEXT,
    status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE CASCADE
);

-- Home Stay and Property Listings
CREATE TABLE property_owners (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    verification_status ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
    business_name VARCHAR(255),
    tax_id VARCHAR(50),
    contact_phone VARCHAR(20),
    contact_email VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE properties (
    id INT PRIMARY KEY AUTO_INCREMENT,
    owner_id INT NOT NULL,
    property_type ENUM('homestay', 'hotel', 'rental_car') NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    address TEXT NOT NULL,
    city VARCHAR(100) NOT NULL,
    country VARCHAR(100) NOT NULL,
    postal_code VARCHAR(20),
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    price_per_night DECIMAL(10, 2),
    capacity INT,
    bedrooms INT,
    bathrooms INT,
    amenities JSON,
    rules TEXT,
    availability_calendar JSON,
    status ENUM('draft', 'pending', 'active', 'inactive') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_id) REFERENCES property_owners(id)
);

CREATE TABLE property_photos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    property_id INT NOT NULL,
    photo_url VARCHAR(255) NOT NULL,
    is_primary BOOLEAN DEFAULT FALSE,
    display_order INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (property_id) REFERENCES properties(id)
);

CREATE TABLE rental_cars (
    id INT PRIMARY KEY AUTO_INCREMENT,
    property_id INT NOT NULL,
    make VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    year INT NOT NULL,
    transmission ENUM('automatic', 'manual') NOT NULL,
    fuel_type ENUM('petrol', 'diesel', 'electric', 'hybrid') NOT NULL,
    seats INT NOT NULL,
    price_per_day DECIMAL(10, 2) NOT NULL,
    insurance_details JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (property_id) REFERENCES properties(id)
);

-- Travel Insurance
CREATE TABLE insurance_plans (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    coverage_details JSON NOT NULL,
    price_calculation_formula TEXT,
    terms_conditions TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE itinerary_insurance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    itinerary_id INT NOT NULL,
    insurance_plan_id INT NOT NULL,
    coverage_start_date DATE NOT NULL,
    coverage_end_date DATE NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'active', 'cancelled', 'expired') DEFAULT 'pending',
    policy_number VARCHAR(50),
    insured_persons JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (itinerary_id) REFERENCES combo_itineraries(id),
    FOREIGN KEY (insurance_plan_id) REFERENCES insurance_plans(id)
);

CREATE TABLE insurance_claims (
    id INT PRIMARY KEY AUTO_INCREMENT,
    insurance_id INT NOT NULL,
    claim_type VARCHAR(100) NOT NULL,
    description TEXT,
    amount DECIMAL(10, 2),
    supporting_documents JSON,
    status ENUM('submitted', 'reviewing', 'approved', 'rejected') DEFAULT 'submitted',
    submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolution_date TIMESTAMP,
    resolution_notes TEXT,
    FOREIGN KEY (insurance_id) REFERENCES itinerary_insurance(id)
);

-- Service Applications
CREATE TABLE service_applications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    service_type ENUM('property_listing', 'car_rental', 'travel_insurance', 'homestay') NOT NULL,
    status ENUM('pending', 'approved', 'rejected', 'review_required') DEFAULT 'pending',
    application_data JSON NOT NULL,
    submitted_documents JSON,
    admin_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE application_reviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    application_id INT NOT NULL,
    reviewer_id INT NOT NULL,
    review_status ENUM('approved', 'rejected', 'needs_info') NOT NULL,
    comments TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (application_id) REFERENCES service_applications(id),
    FOREIGN KEY (reviewer_id) REFERENCES users(id)
);

-- Document Templates
CREATE TABLE document_templates (
    id INT PRIMARY KEY AUTO_INCREMENT,
    service_type ENUM('property_listing', 'car_rental', 'travel_insurance', 'homestay') NOT NULL,
    document_type VARCHAR(50) NOT NULL,
    template_name VARCHAR(100) NOT NULL,
    template_content TEXT NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample data
INSERT INTO combo_itineraries (user_id, title, start_date, end_date, status) VALUES
(1, 'Luxury California Tour', '2024-03-01', '2024-03-07', 'confirmed'),
(1, 'NYC Weekend Getaway', '2024-04-15', '2024-04-17', 'draft');

INSERT INTO itinerary_components (itinerary_id, component_type, start_datetime, end_datetime, location_from, location_to, price) VALUES
(1, 'flight', '2024-03-01 10:00:00', '2024-03-01 13:00:00', 'NYC', 'LAX', 550.00),
(1, 'hotel', '2024-03-01 15:00:00', '2024-03-07 11:00:00', 'LAX', 'LAX', 1200.00),
(1, 'activity', '2024-03-02 09:00:00', '2024-03-02 17:00:00', 'LAX', 'LAX', 299.99);

INSERT INTO itinerary_schedule (itinerary_id, day_number, time_slot, activity_type, description, location, duration) VALUES
(1, 1, '10:00:00', 'Flight', 'Flight to LAX', 'JFK Airport', 180),
(1, 1, '15:00:00', 'Check-in', 'Hotel Check-in', 'Luxury Hotel LAX', 60),
(1, 2, '09:00:00', 'Tour', 'City Tour', 'Los Angeles', 480);

INSERT INTO payments (itinerary_id, amount, payment_method, status) VALUES
(1, 2049.99, 'credit_card', 'completed');

-- Add sample data for insurance plans
INSERT INTO insurance_plans (name, description, coverage_details) VALUES
('Premium Travel Protection', 'Comprehensive coverage for luxury travelers', '{
    "medical_coverage": 1000000,
    "trip_cancellation": true,
    "lost_baggage": 10000,
    "emergency_evacuation": true,
    "24h_assistance": true,
    "luxury_vehicle_coverage": 50000
}'),
('Business Elite Coverage', 'Tailored for business travelers', '{
    "medical_coverage": 500000,
    "trip_cancellation": true,
    "lost_baggage": 5000,
    "emergency_evacuation": true,
    "24h_assistance": true,
    "business_equipment": 10000
}');
