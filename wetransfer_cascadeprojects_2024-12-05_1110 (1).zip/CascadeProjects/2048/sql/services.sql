-- Eurail Bookings
CREATE TABLE eurail_bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    pass_type ENUM('first-class', 'global', 'select') NOT NULL,
    duration INT NOT NULL,
    start_date DATE NOT NULL,
    passengers INT NOT NULL,
    countries JSON NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Excursion Bookings
CREATE TABLE excursion_bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    excursion_type ENUM('adventure', 'cultural', 'culinary') NOT NULL,
    destination VARCHAR(100) NOT NULL,
    excursion_date DATE NOT NULL,
    group_size INT NOT NULL,
    special_requests TEXT,
    total_price DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Payments for Services
CREATE TABLE payments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    booking_id INT NOT NULL,
    booking_type ENUM('eurail', 'excursion') NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    transaction_id VARCHAR(100),
    payment_method VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Service Reviews
CREATE TABLE service_reviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    booking_id INT NOT NULL,
    booking_type ENUM('eurail', 'excursion') NOT NULL,
    user_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    review_text TEXT,
    photos JSON,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Sample Data for Eurail Bookings
INSERT INTO eurail_bookings (user_id, pass_type, duration, start_date, passengers, countries, total_price, status) VALUES
(1, 'first-class', 15, '2024-03-01', 2, '["france", "italy", "switzerland"]', 1200.00, 'confirmed'),
(2, 'global', 30, '2024-04-15', 1, '["germany", "austria", "netherlands", "belgium"]', 800.00, 'pending');

-- Sample Data for Excursion Bookings
INSERT INTO excursion_bookings (user_id, excursion_type, destination, excursion_date, group_size, special_requests, total_price, status) VALUES
(1, 'adventure', 'Swiss Alps', '2024-03-05', 4, 'Beginner-friendly hiking routes preferred', 2400.00, 'confirmed'),
(2, 'cultural', 'Paris Museums', '2024-04-20', 2, 'English-speaking guide requested', 600.00, 'pending'),
(3, 'culinary', 'Tuscan Cuisine', '2024-05-10', 6, 'Vegetarian options needed for 2 participants', 1800.00, 'confirmed');

-- Sample Data for Service Reviews
INSERT INTO service_reviews (booking_id, booking_type, user_id, rating, review_text, status) VALUES
(1, 'eurail', 1, 5, 'Excellent first-class experience across Europe. The service was impeccable.', 'approved'),
(1, 'excursion', 1, 5, 'Amazing adventure in the Swiss Alps! Our guide was very knowledgeable.', 'approved');
