-- Sample data for combo itinerary system

-- Sample Users (if not already exists)
INSERT INTO users (id, name, email, password_hash, created_at) VALUES
(1, 'John Doe', 'john@example.com', '$2y$10$abcdefghijklmnopqrstuv', NOW()),
(2, 'Jane Smith', 'jane@example.com', '$2y$10$vwxyzabcdefghijklmnopq', NOW());

-- Sample Combo Itineraries
INSERT INTO combo_itineraries (id, user_id, title, start_date, end_date, total_price, status, created_at) VALUES
(1, 1, 'Luxury European Vacation', '2024-06-15', '2024-06-25', 5800.00, 'confirmed', NOW()),
(2, 2, 'Asian Adventure Package', '2024-07-01', '2024-07-10', 4200.00, 'pending', NOW());

-- Sample Itinerary Components
INSERT INTO itinerary_components (itinerary_id, component_type, service_id, start_datetime, end_datetime, price, details) VALUES
-- European Vacation Components
(1, 'flight', 'FL123', '2024-06-15 10:00:00', '2024-06-15 22:00:00', 1200.00, 
 '{"airline": "Luxury Airways", "class": "Business", "origin": "New York", "destination": "Paris", "flight_number": "LA123"}'),
(1, 'hotel', 'HT456', '2024-06-15 14:00:00', '2024-06-20 11:00:00', 2000.00,
 '{"hotel": "Ritz Paris", "room_type": "Luxury Suite", "amenities": ["Spa", "Pool", "Restaurant"]}'),
(1, 'activity', 'AC789', '2024-06-16 09:00:00', '2024-06-16 17:00:00', 400.00,
 '{"name": "Private Paris Tour", "guide": "Jean Pierre", "includes": ["Eiffel Tower", "Louvre", "Seine Cruise"]}'),

-- Asian Adventure Components
(2, 'flight', 'FL456', '2024-07-01 08:00:00', '2024-07-01 22:00:00', 1500.00,
 '{"airline": "Asian Express", "class": "First", "origin": "Los Angeles", "destination": "Tokyo", "flight_number": "AE456"}'),
(2, 'hotel', 'HT789', '2024-07-01 15:00:00', '2024-07-05 10:00:00', 1800.00,
 '{"hotel": "Park Hyatt Tokyo", "room_type": "Deluxe Room", "amenities": ["Spa", "Pool", "Restaurant"]}'),
(2, 'activity', 'AC012', '2024-07-02 09:00:00', '2024-07-02 16:00:00', 300.00,
 '{"name": "Tokyo Cultural Tour", "guide": "Tanaka San", "includes": ["Tea Ceremony", "Temple Visit", "Sushi Workshop"]}');

-- Sample Itinerary Schedule
INSERT INTO itinerary_schedule (itinerary_id, day_number, time_slot, activity_type, description, location, duration, notes) VALUES
-- European Vacation Schedule
(1, 1, '10:00:00', 'transport', 'Flight to Paris', 'JFK Airport', '12 hours', 'Business class, meal included'),
(1, 1, '22:00:00', 'transport', 'Hotel Transfer', 'Charles de Gaulle Airport', '1 hour', 'Private luxury car'),
(1, 2, '09:00:00', 'activity', 'Private Paris Tour', 'Hotel Lobby', '8 hours', 'Includes lunch at Michelin star restaurant'),
(1, 2, '19:00:00', 'dining', 'Welcome Dinner', 'Eiffel Tower Restaurant', '2 hours', 'Dress code: Formal'),

-- Asian Adventure Schedule
(2, 1, '08:00:00', 'transport', 'Flight to Tokyo', 'LAX Airport', '14 hours', 'First class, premium meals'),
(2, 1, '22:00:00', 'transport', 'Hotel Transfer', 'Narita Airport', '1.5 hours', 'Private luxury car'),
(2, 2, '09:00:00', 'activity', 'Tokyo Cultural Tour', 'Hotel Lobby', '7 hours', 'Traditional lunch included'),
(2, 2, '18:00:00', 'dining', 'Sushi Experience', 'Ginza District', '2 hours', 'Private master chef');

-- Sample Payments
INSERT INTO payments (user_id, itinerary_id, amount, payment_method, transaction_id, status, created_at, completed_at) VALUES
(1, 1, 5800.00, 'credit_card', 'TXN123456789', 'completed', NOW() - INTERVAL 1 DAY, NOW()),
(2, 2, 4200.00, 'paypal', 'TXN987654321', 'processing', NOW(), NULL);

-- Sample Payment Refunds
INSERT INTO payment_refunds (payment_id, amount, reason, refund_transaction_id, status, created_at, completed_at) VALUES
(1, 200.00, 'Activity cancellation due to weather', 'REF123456789', 'completed', NOW() - INTERVAL 12 HOUR, NOW());
