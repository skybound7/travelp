-- Performance metrics table
CREATE TABLE IF NOT EXISTS performance_metrics (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    operation VARCHAR(255) NOT NULL,
    duration DECIMAL(10,4) NOT NULL,
    memory_used BIGINT NOT NULL,
    peak_memory BIGINT NOT NULL,
    cpu_usage DECIMAL(5,2) NOT NULL,
    timestamp TIMESTAMP NOT NULL,
    INDEX idx_operation (operation),
    INDEX idx_timestamp (timestamp),
    INDEX idx_duration (duration)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Error logs table
CREATE TABLE IF NOT EXISTS error_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    error_type VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    context JSON,
    url VARCHAR(2048),
    user_agent VARCHAR(1024),
    ip_address VARCHAR(45),
    timestamp TIMESTAMP NOT NULL,
    INDEX idx_error_type (error_type),
    INDEX idx_timestamp (timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- User feedback table
CREATE TABLE IF NOT EXISTS user_feedback (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED,
    feedback TEXT,
    rating TINYINT UNSIGNED NOT NULL,
    category VARCHAR(100) NOT NULL,
    timestamp TIMESTAMP NOT NULL,
    INDEX idx_user (user_id),
    INDEX idx_rating (rating),
    INDEX idx_category (category),
    INDEX idx_timestamp (timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
