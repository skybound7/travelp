// In your query execution code:
-- Create database if not exists
CREATE DATABASE IF NOT EXISTS luxury_travel;
USE luxury_travel;

-- Create user if not exists
CREATE USER IF NOT EXISTS 'luxury_user'@'localhost' IDENTIFIED BY 'luxury_pass_123';
GRANT ALL PRIVILEGES ON luxury_travel.* TO 'luxury_user'@'localhost';
FLUSH PRIVILEGES;

-- Create tables
CREATE TABLE IF NOT EXISTS combo_itineraries (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status ENUM('draft', 'confirmed', 'cancelled', 'completed') DEFAULT 'draft',
    total_price DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS itinerary_components (
    id INT PRIMARY KEY AUTO_INCREMENT,
    itinerary_id INT NOT NULL,
    type ENUM('flight', 'hotel', 'activity', 'transport') NOT NULL,
    start_datetime DATETIME NOT NULL,
    end_datetime DATETIME NOT NULL,
    location_from VARCHAR(100) NOT NULL,
    location_to VARCHAR(100) NOT NULL,
    details JSON,
    price DECIMAL(10,2),
    status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (itinerary_id) REFERENCES combo_itineraries(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS available_activities (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    location VARCHAR(100) NOT NULL,
    duration_hours DECIMAL(4,1) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    rating DECIMAL(2,1),
    description TEXT,
    available_from TIME,
    available_to TIME,
    max_participants INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS available_transport (
    id INT PRIMARY KEY AUTO_INCREMENT,
    type ENUM('car', 'bus', 'train', 'boat') NOT NULL,
    location_from VARCHAR(100) NOT NULL,
    location_to VARCHAR(100) NOT NULL,
    duration_hours DECIMAL(4,1) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    schedule JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS payments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    itinerary_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    transaction_id VARCHAR(100),
    status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (itinerary_id) REFERENCES combo_itineraries(id)
);

CREATE TABLE IF NOT EXISTS payment_refunds (
    id INT PRIMARY KEY AUTO_INCREMENT,
    payment_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    reason TEXT,
    status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (payment_id) REFERENCES payments(id)
);

CREATE TABLE IF NOT EXISTS blocked_ips (
    id INT PRIMARY KEY AUTO_INCREMENT,
    ip_address VARCHAR(45) NOT NULL,
    reason TEXT,
    blocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL,
    UNIQUE KEY unique_ip (ip_address)
);

CREATE TABLE IF NOT EXISTS login_attempts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    ip_address VARCHAR(45) NOT NULL,
    attempt_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    success BOOLEAN DEFAULT FALSE,
    INDEX idx_ip_time (ip_address, attempt_time)
);

-- Insert sample data for testing
INSERT INTO available_activities (name, location, duration_hours, price, rating, description) VALUES
('City Tour', 'NYC', 4.0, 99.99, 4.5, 'Comprehensive city tour with local guide'),
('Wine Tasting', 'Napa', 2.5, 149.99, 4.8, 'Premium wine tasting experience'),
('Surfing Lesson', 'LAX', 3.0, 129.99, 4.3, 'Private surfing lesson for beginners');

INSERT INTO available_transport (type, location_from, location_to, duration_hours, price, schedule) VALUES
('car', 'NYC', 'BOS', 4.0, 299.99, '{"departure_times": ["09:00", "13:00", "17:00"]}'),
('train', 'NYC', 'DC', 3.5, 199.99, '{"departure_times": ["08:00", "12:00", "16:00"]}'),
('boat', 'MIA', 'KEY', 2.0, 149.99, '{"departure_times": ["10:00", "14:00", "18:00"]}');
