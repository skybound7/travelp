document.addEventListener('DOMContentLoaded', function() {
    // State management
    let currentPage = 1;
    const itemsPerPage = 12;
    let loading = false;
    let hasMore = true;
    
    // DOM Elements
    const galleryContainer = document.getElementById('galleryContainer');
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    const trainFilter = document.getElementById('trainFilter');
    const categoryFilter = document.getElementById('categoryFilter');
    const uploadForm = document.getElementById('photoUploadForm');
    const uploadBtn = document.getElementById('uploadBtn');
    
    // Initialize gallery
    loadGalleryItems();
    
    // Event Listeners
    loadMoreBtn.addEventListener('click', loadGalleryItems);
    trainFilter.addEventListener('change', resetAndReload);
    categoryFilter.addEventListener('change', resetAndReload);
    
    if (uploadBtn) {
        uploadBtn.addEventListener('click', handlePhotoUpload);
    }
    
    // Infinite scroll
    window.addEventListener('scroll', () => {
        if (loading || !hasMore) return;
        
        const { scrollTop, scrollHeight, clientHeight } = document.documentElement;
        if (scrollTop + clientHeight >= scrollHeight - 100) {
            loadGalleryItems();
        }
    });
    
    // Functions
    function loadGalleryItems() {
        if (loading || !hasMore) return;
        loading = true;
        showLoading();
        
        const params = new URLSearchParams({
            page: currentPage,
            limit: itemsPerPage,
            train: trainFilter.value,
            category: categoryFilter.value
        });
        
        fetch(`/api/trains/gallery?${params}`)
            .then(response => response.json())
            .then(data => {
                hideLoading();
                
                if (data.success) {
                    if (data.data.length < itemsPerPage) {
                        hasMore = false;
                        loadMoreBtn.style.display = 'none';
                    }
                    
                    renderGalleryItems(data.data);
                    currentPage++;
                } else {
                    showError('Failed to load gallery items');
                }
            })
            .catch(error => {
                hideLoading();
                showError('An error occurred while loading gallery items');
                console.error('Gallery error:', error);
            })
            .finally(() => {
                loading = false;
            });
    }
    
    function renderGalleryItems(items) {
        items.forEach(item => {
            const col = document.createElement('div');
            col.className = 'col-md-4 col-lg-3 fade-in';
            
            col.innerHTML = `
                <div class="gallery-item">
                    <a href="${item.fullImage}" data-lightbox="train-gallery" data-title="${item.description}">
                        <img src="${item.thumbnail}" alt="${item.title}" loading="lazy">
                        <div class="gallery-item-overlay">
                            <div class="gallery-item-title">${item.title}</div>
                            <div class="gallery-item-category">${item.category}</div>
                        </div>
                    </a>
                </div>
            `;
            
            galleryContainer.appendChild(col);
        });
        
        // Initialize lightbox for new items
        lightbox.init();
    }
    
    function resetAndReload() {
        currentPage = 1;
        hasMore = true;
        galleryContainer.innerHTML = '';
        loadMoreBtn.style.display = 'block';
        loadGalleryItems();
    }
    
    function handlePhotoUpload() {
        const formData = new FormData(uploadForm);
        
        fetch('/api/trains/gallery/upload', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('Photos uploaded successfully!', 'success');
                resetAndReload();
                bootstrap.Modal.getInstance(document.getElementById('uploadModal')).hide();
            } else {
                showNotification(data.error, 'error');
            }
        })
        .catch(error => {
            showNotification('Failed to upload photos', 'error');
            console.error('Upload error:', error);
        });
    }
    
    // Helper Functions
    function showLoading() {
        const spinner = document.createElement('div');
        spinner.className = 'loading-spinner';
        spinner.id = 'gallerySpinner';
        loadMoreBtn.parentNode.insertBefore(spinner, loadMoreBtn);
        loadMoreBtn.style.display = 'none';
    }
    
    function hideLoading() {
        const spinner = document.getElementById('gallerySpinner');
        if (spinner) spinner.remove();
        if (hasMore) loadMoreBtn.style.display = 'block';
    }
    
    function showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
        notification.style.zIndex = '1050';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        document.body.appendChild(notification);
        setTimeout(() => notification.remove(), 5000);
    }
    
    function showError(message) {
        showNotification(message, 'danger');
    }
});
