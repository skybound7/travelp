// Show/Hide Excursion Booking Form
function showExcursionForm(excursionType) {
    const form = document.getElementById('excursion-booking-form');
    const typeSelect = document.getElementById('excursionType');
    
    // Show form
    form.style.display = 'block';
    
    // Set selected excursion type
    typeSelect.value = excursionType;
    
    // Update destination options based on type
    updateDestinations(excursionType);
    
    // Smooth scroll to form
    form.scrollIntoView({ behavior: 'smooth' });
}

// Form Validation and Submission
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('excursionBookingForm');
    
    if (form) {
        form.addEventListener('submit', function(event) {
            event.preventDefault();
            
            if (form.checkValidity()) {
                submitExcursionBooking(form);
            }
            
            form.classList.add('was-validated');
        });
    }
    
    // Initialize date picker with minimum date
    const excursionDateInput = document.getElementById('excursionDate');
    if (excursionDateInput) {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        excursionDateInput.min = tomorrow.toISOString().split('T')[0];
    }
    
    // Update destinations when excursion type changes
    const excursionTypeSelect = document.getElementById('excursionType');
    if (excursionTypeSelect) {
        excursionTypeSelect.addEventListener('change', function() {
            updateDestinations(this.value);
        });
    }
});

// Update destination options based on selected excursion type
function updateDestinations(excursionType) {
    const destinationSelect = document.getElementById('destination');
    
    // Clear existing options
    destinationSelect.innerHTML = '<option value="">Select destination</option>';
    
    // Add options based on excursion type
    switch(excursionType) {
        case 'adventure':
            addDestinationOptions([
                { value: 'alps', text: 'Swiss Alps' },
                { value: 'safari', text: 'African Safari' },
                { value: 'amazon', text: 'Amazon Expedition' },
                { value: 'everest', text: 'Everest Base Camp' }
            ]);
            break;
            
        case 'cultural':
            addDestinationOptions([
                { value: 'paris', text: 'Paris Museums' },
                { value: 'rome', text: 'Ancient Rome' },
                { value: 'kyoto', text: 'Traditional Kyoto' },
                { value: 'cairo', text: 'Egyptian Pyramids' }
            ]);
            break;
            
        case 'culinary':
            addDestinationOptions([
                { value: 'tuscany', text: 'Tuscan Cuisine' },
                { value: 'tokyo', text: 'Tokyo Food Tour' },
                { value: 'provence', text: 'French Wine Country' },
                { value: 'bangkok', text: 'Thai Cooking' }
            ]);
            break;
    }
}

function addDestinationOptions(options) {
    const destinationSelect = document.getElementById('destination');
    options.forEach(option => {
        const optionElement = document.createElement('option');
        optionElement.value = option.value;
        optionElement.textContent = option.text;
        destinationSelect.appendChild(optionElement);
    });
}

// Submit booking
async function submitExcursionBooking(form) {
    const formData = new FormData(form);
    
    try {
        const response = await fetch('/api/book-excursion', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            showSuccessMessage();
            form.reset();
            form.classList.remove('was-validated');
        } else {
            showErrorMessage();
        }
    } catch (error) {
        console.error('Error submitting booking:', error);
        showErrorMessage();
    }
}

// Success/Error Messages
function showSuccessMessage() {
    const alertDiv = createAlert('success', 'Excursion booking submitted successfully! We will contact you shortly with confirmation details.');
    showAlert(alertDiv);
}

function showErrorMessage() {
    const alertDiv = createAlert('danger', 'There was an error processing your booking. Please try again later.');
    showAlert(alertDiv);
}

function createAlert(type, message) {
    const alertDiv = document.createElement('div');
    alertDiv.classList.add('alert', `alert-${type}`, 'mt-3');
    alertDiv.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> ${message}`;
    return alertDiv;
}

function showAlert(alertDiv) {
    const form = document.getElementById('excursionBookingForm');
    form.appendChild(alertDiv);
    
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

// Price calculation
function calculateExcursionPrice() {
    const excursionType = document.getElementById('excursionType').value;
    const destination = document.getElementById('destination').value;
    const groupSize = document.getElementById('groupSize').value;
    
    let basePrice = 0;
    
    // Set base prices based on excursion type and destination
    switch(excursionType) {
        case 'adventure':
            basePrice = destination === 'everest' ? 5000 : 3000;
            break;
        case 'cultural':
            basePrice = 1500;
            break;
        case 'culinary':
            basePrice = 2000;
            break;
    }
    
    // Group size adjustments
    let groupDiscount = 1;
    if (groupSize >= 5) {
        groupDiscount = 0.9; // 10% discount for groups of 5 or more
    } else if (groupSize >= 3) {
        groupDiscount = 0.95; // 5% discount for groups of 3-4
    }
    
    // Calculate total
    const total = basePrice * groupSize * groupDiscount;
    
    // Update price display
    document.getElementById('totalPrice').textContent = `$${total.toFixed(2)}`;
}
