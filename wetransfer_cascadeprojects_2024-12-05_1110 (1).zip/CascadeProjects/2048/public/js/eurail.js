// Show/Hide Pass Booking Form
function showPassForm(passType) {
    const form = document.getElementById('eurail-booking-form');
    const passTypeSelect = document.getElementById('passType');
    
    // Show form
    form.style.display = 'block';
    
    // Set selected pass type
    passTypeSelect.value = passType;
    
    // Smooth scroll to form
    form.scrollIntoView({ behavior: 'smooth' });
}

// Form Validation and Submission
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('passBookingForm');
    
    if (form) {
        form.addEventListener('submit', function(event) {
            event.preventDefault();
            
            if (form.checkValidity()) {
                submitPassBooking(form);
            }
            
            form.classList.add('was-validated');
        });
    }
    
    // Initialize date picker with minimum date
    const startDateInput = document.getElementById('startDate');
    if (startDateInput) {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        startDateInput.min = tomorrow.toISOString().split('T')[0];
    }
    
    // Update duration options based on pass type
    const passTypeSelect = document.getElementById('passType');
    if (passTypeSelect) {
        passTypeSelect.addEventListener('change', updateDurationOptions);
    }
});

// Update duration options based on selected pass type
function updateDurationOptions() {
    const passType = document.getElementById('passType').value;
    const durationSelect = document.getElementById('duration');
    
    // Clear existing options
    durationSelect.innerHTML = '<option value="">Select duration</option>';
    
    // Add options based on pass type
    if (passType === 'first-class' || passType === 'global') {
        addDurationOption(durationSelect, '15', '15 Days');
        addDurationOption(durationSelect, '22', '22 Days');
        addDurationOption(durationSelect, '30', '1 Month');
        addDurationOption(durationSelect, '60', '2 Months');
    } else if (passType === 'select') {
        addDurationOption(durationSelect, '7', '7 Days');
        addDurationOption(durationSelect, '15', '15 Days');
        addDurationOption(durationSelect, '30', '1 Month');
    }
}

function addDurationOption(select, value, text) {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = text;
    select.appendChild(option);
}

// Submit booking
async function submitPassBooking(form) {
    const formData = new FormData(form);
    
    try {
        const response = await fetch('/api/book-eurail-pass', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            showSuccessMessage();
            form.reset();
            form.classList.remove('was-validated');
        } else {
            showErrorMessage();
        }
    } catch (error) {
        console.error('Error submitting booking:', error);
        showErrorMessage();
    }
}

// Success/Error Messages
function showSuccessMessage() {
    const alertDiv = createAlert('success', 'Booking submitted successfully! We will contact you shortly with confirmation details.');
    showAlert(alertDiv);
}

function showErrorMessage() {
    const alertDiv = createAlert('danger', 'There was an error processing your booking. Please try again later.');
    showAlert(alertDiv);
}

function createAlert(type, message) {
    const alertDiv = document.createElement('div');
    alertDiv.classList.add('alert', `alert-${type}`, 'mt-3');
    alertDiv.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> ${message}`;
    return alertDiv;
}

function showAlert(alertDiv) {
    const form = document.getElementById('passBookingForm');
    form.appendChild(alertDiv);
    
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

// Price calculation
function calculatePrice() {
    const passType = document.getElementById('passType').value;
    const duration = document.getElementById('duration').value;
    const passengers = document.getElementById('passengers').value;
    
    let basePrice = 0;
    
    // Set base prices
    switch(passType) {
        case 'first-class':
            basePrice = 500;
            break;
        case 'global':
            basePrice = 400;
            break;
        case 'select':
            basePrice = 300;
            break;
    }
    
    // Adjust for duration
    const durationMultiplier = duration / 15;
    
    // Calculate total
    const total = basePrice * durationMultiplier * passengers;
    
    // Update price display
    document.getElementById('totalPrice').textContent = `€${total.toFixed(2)}`;
}
