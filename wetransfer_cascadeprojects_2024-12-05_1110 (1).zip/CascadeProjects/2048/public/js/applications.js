// Show/Hide Application Forms
function showApplicationForm(formType) {
    // Hide all forms first
    document.querySelectorAll('.application-form-container').forEach(form => {
        form.style.display = 'none';
    });

    // Show the selected form
    const selectedForm = document.getElementById(`${formType}-form`);
    if (selectedForm) {
        selectedForm.style.display = 'block';
        
        // Smooth scroll to form
        selectedForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

// Form Validation and Submission
document.addEventListener('DOMContentLoaded', function() {
    // Add validation styles to all forms
    const forms = document.querySelectorAll('.needs-validation');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            } else {
                event.preventDefault();
                submitApplication(form);
            }
            
            form.classList.add('was-validated');
        });
    });
});

// Handle file uploads with preview
document.querySelectorAll('input[type="file"]').forEach(input => {
    input.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            // Add file name display
            const fileNameDisplay = document.createElement('small');
            fileNameDisplay.classList.add('file-name');
            fileNameDisplay.textContent = file.name;
            
            // Remove any existing file name display
            const existingDisplay = input.parentElement.querySelector('.file-name');
            if (existingDisplay) {
                existingDisplay.remove();
            }
            
            input.parentElement.appendChild(fileNameDisplay);
        }
    });
});

// Submit application data
async function submitApplication(form) {
    const formData = new FormData(form);
    const formId = form.id;
    
    try {
        const response = await fetch('/api/submit-application', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            showSuccessMessage(formId);
            form.reset();
            form.classList.remove('was-validated');
        } else {
            showErrorMessage(formId);
        }
    } catch (error) {
        console.error('Error submitting application:', error);
        showErrorMessage(formId);
    }
}

// Success/Error Messages
function showSuccessMessage(formId) {
    const form = document.getElementById(formId);
    const alertDiv = document.createElement('div');
    alertDiv.classList.add('alert', 'alert-success', 'mt-3');
    alertDiv.innerHTML = `
        <i class="fas fa-check-circle"></i>
        Your application has been submitted successfully! We will review it and get back to you soon.
    `;
    
    form.appendChild(alertDiv);
    
    // Remove alert after 5 seconds
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

function showErrorMessage(formId) {
    const form = document.getElementById(formId);
    const alertDiv = document.createElement('div');
    alertDiv.classList.add('alert', 'alert-danger', 'mt-3');
    alertDiv.innerHTML = `
        <i class="fas fa-exclamation-circle"></i>
        There was an error submitting your application. Please try again later.
    `;
    
    form.appendChild(alertDiv);
    
    // Remove alert after 5 seconds
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

// Form Progress Tracking
let formProgress = {};

function saveFormProgress(formId) {
    const form = document.getElementById(formId);
    const formData = new FormData(form);
    formProgress[formId] = Object.fromEntries(formData.entries());
    
    // Save to localStorage
    localStorage.setItem('formProgress', JSON.stringify(formProgress));
}

function loadFormProgress() {
    const savedProgress = localStorage.getItem('formProgress');
    if (savedProgress) {
        formProgress = JSON.parse(savedProgress);
        
        // Populate forms with saved data
        Object.keys(formProgress).forEach(formId => {
            const form = document.getElementById(formId);
            if (form) {
                const data = formProgress[formId];
                Object.keys(data).forEach(key => {
                    const input = form.querySelector(`[name="${key}"]`);
                    if (input) {
                        input.value = data[key];
                    }
                });
            }
        });
    }
}

// Save form progress periodically
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('input', () => {
        saveFormProgress(form.id);
    });
});
