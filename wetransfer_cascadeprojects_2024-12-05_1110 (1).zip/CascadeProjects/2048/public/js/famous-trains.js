// Global Features for Famous Trains
class FamousTrainsApp {
    constructor() {
        this.supportedLanguages = ['en', 'es', 'fr', 'de', 'ja'];
        this.currentLanguage = 'en';
        this.currencies = {
            USD: { symbol: '$', rate: 1 },
            EUR: { symbol: '€', rate: 0.85 },
            GBP: { symbol: '£', rate: 0.73 },
            JPY: { symbol: '¥', rate: 110 }
        };
        this.currentCurrency = 'USD';
        
        // Feature configurations with error handling
        this.config = {
            aiRecommendations: true,
            realTimeNotifications: true,
            socialFeatures: true,
            augmentedReality: this.checkARSupport(),
            accessibility: {
                screenReader: true,
                highContrast: false,
                textToSpeech: 'speechSynthesis' in window
            }
        };

        // Initialize error tracking
        this.errorTracker = {
            errors: [],
            maxErrors: 50,
            logError: (error, context) => {
                const errorLog = {
                    timestamp: new Date(),
                    error: error.message,
                    stack: error.stack,
                    context
                };
                this.errorTracker.errors.unshift(errorLog);
                if (this.errorTracker.errors.length > this.errorTracker.maxErrors) {
                    this.errorTracker.errors.pop();
                }
                console.error('Application error:', errorLog);
            }
        };

        // Initialize state management
        this.state = {
            isLoading: false,
            lastError: null,
            notifications: [],
            currentView: null,
            userPreferences: null
        };

        this.init().catch(error => {
            this.errorTracker.logError(error, 'initialization');
            this.showNotification('Application initialization failed. Please refresh the page.', 'error');
        });
    }

    checkARSupport() {
        try {
            return 'xr' in navigator;
        } catch (error) {
            this.errorTracker.logError(error, 'AR support check');
            return false;
        }
    }

    async init() {
        try {
            await this.initializeComponents();
            await this.setupEventListeners();
            await this.initializeInternationalization();
            await this.initializeAdvancedFeatures();
            await this.initializeAIFeatures();
            await this.initializeSocialFeatures();
            await this.initializeARFeatures();
            await this.initializeAccessibility();
        } catch (error) {
            console.error('Initialization error:', error);
            this.showNotification('Error initializing application. Please refresh the page.', 'error');
        }
    }

    async initializeComponents() {
        try {
            // Initialize tooltips with error handling
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            if (tooltipTriggerList.length > 0) {
                tooltipTriggerList.map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
            }

            await Promise.all([
                this.initializeLazyLoading(),
                this.initializeSearch(),
                this.initializeFilters(),
                this.initializeBooking()
            ]);
        } catch (error) {
            console.error('Component initialization error:', error);
            throw error;
        }
    }

    initializeLazyLoading() {
        const images = document.querySelectorAll('img[data-src]');
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.add('fade-in');
                    observer.unobserve(img);
                }
            });
        }, {
            threshold: 0,
            rootMargin: '0px 0px 50px 0px'
        });

        images.forEach(img => imageObserver.observe(img));
    }

    initializeSearch() {
        const searchInput = document.querySelector('#train-search');
        if (searchInput) {
            searchInput.addEventListener('input', this.debounce((e) => {
                this.performSearch(e.target.value);
            }, 300));
        }
    }

    async performSearch(query) {
        try {
            if (!query || query.trim().length < 2) {
                this.updateSearchResults([]);
                return;
            }

            const response = await fetch(`/api/trains/search?q=${encodeURIComponent(query)}`, {
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`Search failed: ${response.statusText}`);
            }

            const results = await response.json();
            this.updateSearchResults(results);
        } catch (error) {
            console.error('Search error:', error);
            this.showNotification('Search failed. Please try again.', 'error');
        }
    }

    initializeFilters() {
        const filterInputs = document.querySelectorAll('.trains-archive-sidebar__checkbox input');
        filterInputs.forEach(input => {
            input.addEventListener('change', () => this.applyFilters());
        });
    }

    initializeBooking() {
        const bookingForm = document.querySelector('#train-booking-form');
        if (bookingForm) {
            bookingForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleBooking(new FormData(bookingForm));
            });
        }
    }

    async handleBooking(formData) {
        try {
            const bookingData = Object.fromEntries(formData);
            
            // Validate booking data
            if (!this.validateBookingData(bookingData)) {
                this.showNotification('Please fill in all required fields.', 'warning');
                return;
            }

            const response = await fetch('/api/bookings/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(bookingData)
            });

            if (!response.ok) {
                throw new Error(`Booking failed: ${response.statusText}`);
            }

            const result = await response.json();
            this.showNotification('Booking successful!', 'success');
            this.redirectToBookingConfirmation(result.bookingId);
        } catch (error) {
            console.error('Booking error:', error);
            this.showNotification('Booking failed. Please try again.', 'error');
        }
    }

    validateBookingData(data) {
        const requiredFields = ['trainId', 'date', 'passengers', 'class'];
        return requiredFields.every(field => data[field] && data[field].toString().trim() !== '');
    }

    redirectToBookingConfirmation(bookingId) {
        window.location.href = `/booking/confirmation/${bookingId}`;
    }

    initializeInternationalization() {
        // Language switcher
        const languageSelect = document.querySelector('#language-select');
        if (languageSelect) {
            languageSelect.addEventListener('change', (e) => {
                this.changeLanguage(e.target.value);
            });
        }

        // Currency switcher
        const currencySelect = document.querySelector('#currency-select');
        if (currencySelect) {
            currencySelect.addEventListener('change', (e) => {
                this.changeCurrency(e.target.value);
            });
        }
    }

    async changeLanguage(lang) {
        try {
            if (!this.supportedLanguages.includes(lang)) {
                throw new Error('Unsupported language');
            }

            const response = await fetch(`/api/translations/${lang}`);
            if (!response.ok) {
                throw new Error(`Language change failed: ${response.statusText}`);
            }

            const translations = await response.json();
            this.currentLanguage = lang;
            this.applyTranslations(translations);
            this.showNotification('Language updated successfully', 'success');
        } catch (error) {
            console.error('Language change error:', error);
            this.showNotification('Failed to change language. Please try again.', 'error');
        }
    }

    async changeCurrency(currency) {
        try {
            if (!this.currencies[currency]) {
                throw new Error('Unsupported currency');
            }

            const response = await fetch(`/api/exchange-rates/${currency}`);
            if (!response.ok) {
                throw new Error(`Currency change failed: ${response.statusText}`);
            }

            const rates = await response.json();
            this.currencies[currency].rate = rates.rate;
            this.currentCurrency = currency;
            await this.updatePrices();
            this.showNotification('Currency updated successfully', 'success');
        } catch (error) {
            console.error('Currency change error:', error);
            this.showNotification('Failed to change currency. Please try again.', 'error');
        }
    }

    initializeAdvancedFeatures() {
        // Virtual Tour
        this.initializeVirtualTour();
        
        // Real-time seat availability
        this.initializeSeatAvailability();
        
        // Weather information
        this.initializeWeatherInfo();
        
        // Live train tracking
        this.initializeTrainTracking();
    }

    initializeAIFeatures() {
        // AI-powered recommendations
        this.initializeRecommendationEngine();
        
        // Smart itinerary planning
        this.initializeItineraryPlanner();
        
        // Predictive pricing
        this.initializePricePrediction();
    }

    async initializeRecommendationEngine() {
        const userPreferences = await this.getUserPreferences();
        const recommendationEngine = {
            getSimilarTrains: (trainId) => {
                return fetch(`/api/recommendations/similar/${trainId}`);
            },
            getPersonalizedSuggestions: () => {
                return fetch('/api/recommendations/personalized', {
                    body: JSON.stringify(userPreferences)
                });
            },
            updateUserProfile: (interaction) => {
                return fetch('/api/recommendations/profile', {
                    method: 'POST',
                    body: JSON.stringify(interaction)
                });
            }
        };
        
        this.recommendationEngine = recommendationEngine;
    }

    initializeItineraryPlanner() {
        const planner = {
            optimizeRoute: (stops) => {
                return fetch('/api/itinerary/optimize', {
                    method: 'POST',
                    body: JSON.stringify(stops)
                });
            },
            suggestActivities: (location, duration) => {
                return fetch(`/api/itinerary/activities?location=${location}&duration=${duration}`);
            },
            checkConnections: (route) => {
                return fetch('/api/itinerary/connections', {
                    method: 'POST',
                    body: JSON.stringify(route)
                });
            }
        };
        
        this.itineraryPlanner = planner;
    }

    initializePricePrediction() {
        const pricePredictor = {
            getFuturePrice: (trainId, date) => {
                return fetch(`/api/pricing/predict?train=${trainId}&date=${date}`);
            },
            getBestBookingTime: (trainId) => {
                return fetch(`/api/pricing/best-time?train=${trainId}`);
            },
            getPriceAlert: (trainId, targetPrice) => {
                return fetch('/api/pricing/alert', {
                    method: 'POST',
                    body: JSON.stringify({ trainId, targetPrice })
                });
            }
        };
        
        this.pricePredictor = pricePredictor;
    }

    initializeSocialFeatures() {
        // User reviews and ratings
        this.initializeReviewSystem();
        
        // Social sharing
        this.initializeSocialSharing();
        
        // Travel community
        this.initializeCommunityFeatures();
    }

    initializeReviewSystem() {
        const reviewSystem = {
            submitReview: (trainId, review) => {
                return fetch('/api/reviews/submit', {
                    method: 'POST',
                    body: JSON.stringify(review)
                });
            },
            getReviews: (trainId) => {
                return fetch(`/api/reviews/${trainId}`);
            },
            updateReview: (reviewId, update) => {
                return fetch(`/api/reviews/${reviewId}`, {
                    method: 'PUT',
                    body: JSON.stringify(update)
                });
            }
        };
        
        this.reviewSystem = reviewSystem;
    }

    initializeSocialSharing() {
        const shareButtons = document.querySelectorAll('.share-button');
        shareButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const platform = e.target.dataset.platform;
                const trainId = e.target.dataset.trainId;
                this.shareToSocial(platform, trainId);
            });
        });
    }

    initializeCommunityFeatures() {
        const community = {
            createTravelGroup: (groupData) => {
                return fetch('/api/community/groups', {
                    method: 'POST',
                    body: JSON.stringify(groupData)
                });
            },
            joinGroup: (groupId) => {
                return fetch(`/api/community/groups/${groupId}/join`, {
                    method: 'POST'
                });
            },
            shareTravelStory: (story) => {
                return fetch('/api/community/stories', {
                    method: 'POST',
                    body: JSON.stringify(story)
                });
            }
        };
        
        this.community = community;
    }

    initializeARFeatures() {
        if (!this.config.augmentedReality) return;

        const ar = {
            initializeAR: async () => {
                if (!navigator.xr) {
                    console.warn('WebXR not supported');
                    return;
                }
                
                try {
                    const session = await navigator.xr.requestSession('immersive-ar');
                    this.arSession = session;
                    this.startARExperience();
                } catch (error) {
                    console.error('AR initialization failed:', error);
                }
            },
            showTrainInfo: (trainId) => {
                if (!this.arSession) return;
                // Show train information in AR
                this.renderARTrainInfo(trainId);
            },
            startVirtualTour: (trainId) => {
                if (!this.arSession) return;
                // Start virtual tour in AR
                this.startARTour(trainId);
            }
        };
        
        this.ar = ar;
    }

    initializeAccessibility() {
        if (!this.config.accessibility.screenReader) return;

        const accessibility = {
            enableScreenReader: () => {
                document.querySelectorAll('*').forEach(element => {
                    if (element.textContent && !element.getAttribute('aria-label')) {
                        element.setAttribute('aria-label', element.textContent.trim());
                    }
                });
            },
            toggleHighContrast: () => {
                document.body.classList.toggle('high-contrast-mode');
            },
            textToSpeech: (text) => {
                if ('speechSynthesis' in window) {
                    const utterance = new SpeechSynthesisUtterance(text);
                    utterance.lang = this.currentLanguage;
                    window.speechSynthesis.speak(utterance);
                }
            }
        };
        
        this.accessibility = accessibility;
        this.accessibility.enableScreenReader();
    }

    async getUserPreferences() {
        try {
            const response = await fetch('/api/user/preferences');
            return await response.json();
        } catch (error) {
            console.error('Failed to fetch user preferences:', error);
            return {};
        }
    }

    async shareToSocial(platform, trainId) {
        const trainInfo = await this.getTrainInfo(trainId);
        const shareData = {
            title: `Check out ${trainInfo.name} on Famous Trains!`,
            text: trainInfo.description,
            url: window.location.href
        };

        try {
            if (navigator.share && platform === 'native') {
                await navigator.share(shareData);
            } else {
                const shareUrls = {
                    twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareData.text)}&url=${encodeURIComponent(shareData.url)}`,
                    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareData.url)}`,
                    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareData.url)}`
                };
                window.open(shareUrls[platform], '_blank');
            }
        } catch (error) {
            console.error('Sharing failed:', error);
        }
    }

    async applyFilters() {
        const selectedFilters = Array.from(document.querySelectorAll('.trains-archive-sidebar__checkbox input:checked'))
            .map(input => input.parentElement.dataset.slug);

        const trainItems = document.querySelectorAll('.train-item');
        trainItems.forEach(item => {
            const destinations = item.dataset.destinations.split(',');
            const visible = selectedFilters.length === 0 || 
                           selectedFilters.some(filter => destinations.includes(filter));
            item.style.display = visible ? 'block' : 'none';
        });
    }

    async handleBooking(formData) {
        try {
            const bookingData = Object.fromEntries(formData);
            
            // Validate booking data
            if (!this.validateBookingData(bookingData)) {
                this.showNotification('Please fill in all required fields.', 'warning');
                return;
            }

            const response = await fetch('/api/bookings/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(bookingData)
            });

            if (!response.ok) {
                throw new Error(`Booking failed: ${response.statusText}`);
            }

            const result = await response.json();
            this.showNotification('Booking successful!', 'success');
            this.redirectToBookingConfirmation(result.bookingId);
        } catch (error) {
            console.error('Booking error:', error);
            this.showNotification('Booking failed. Please try again.', 'error');
        }
    }

    async changeLanguage(lang) {
        try {
            if (!this.supportedLanguages.includes(lang)) {
                throw new Error('Unsupported language');
            }

            const response = await fetch(`/api/translations/${lang}`);
            if (!response.ok) {
                throw new Error(`Language change failed: ${response.statusText}`);
            }

            const translations = await response.json();
            this.currentLanguage = lang;
            this.applyTranslations(translations);
            this.showNotification('Language updated successfully', 'success');
        } catch (error) {
            console.error('Language change error:', error);
            this.showNotification('Failed to change language. Please try again.', 'error');
        }
    }

    async changeCurrency(currency) {
        try {
            if (!this.currencies[currency]) {
                throw new Error('Unsupported currency');
            }

            const response = await fetch(`/api/exchange-rates/${currency}`);
            if (!response.ok) {
                throw new Error(`Currency change failed: ${response.statusText}`);
            }

            const rates = await response.json();
            this.currencies[currency].rate = rates.rate;
            this.currentCurrency = currency;
            await this.updatePrices();
            this.showNotification('Currency updated successfully', 'success');
        } catch (error) {
            console.error('Currency change error:', error);
            this.showNotification('Failed to change currency. Please try again.', 'error');
        }
    }

    initializeVirtualTour() {
        const tourButtons = document.querySelectorAll('.virtual-tour-btn');
        tourButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const trainId = e.target.dataset.trainId;
                this.loadVirtualTour(trainId);
            });
        });
    }

    initializeSeatAvailability() {
        this.seatAvailabilitySocket = new WebSocket('wss://your-websocket-server/seats');
        this.seatAvailabilitySocket.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.updateSeatAvailability(data);
        };
    }

    initializeWeatherInfo() {
        const weatherElements = document.querySelectorAll('.weather-info');
        weatherElements.forEach(async (el) => {
            const location = el.dataset.location;
            try {
                const weather = await this.fetchWeatherInfo(location);
                el.innerHTML = this.formatWeatherInfo(weather);
            } catch (error) {
                console.error('Weather fetch error:', error);
            }
        });
    }

    initializeTrainTracking() {
        const trackingMap = document.querySelector('#tracking-map');
        if (trackingMap) {
            this.initializeMap(trackingMap);
            this.startTrainTracking();
        }
    }

    // Utility Methods
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    showNotification(message, type = 'info', duration = 5000) {
        try {
            const notification = {
                id: Date.now(),
                message,
                type,
                timestamp: new Date()
            };
            
            this.state.notifications.push(notification);
            
            // Update UI
            const notificationElement = document.createElement('div');
            notificationElement.className = `notification notification--${type}`;
            notificationElement.textContent = message;
            
            const notificationsContainer = document.querySelector('.notifications-container') || 
                this.createNotificationsContainer();
            
            notificationsContainer.appendChild(notificationElement);
            
            // Auto-remove notification
            setTimeout(() => {
                notificationElement.remove();
                this.state.notifications = this.state.notifications.filter(n => n.id !== notification.id);
            }, duration);
            
        } catch (error) {
            this.errorTracker.logError(error, 'show notification');
            console.error('Failed to show notification:', message);
        }
    }

    createNotificationsContainer() {
        const container = document.createElement('div');
        container.className = 'notifications-container';
        document.body.appendChild(container);
        return container;
    }

    async updatePrices() {
        try {
            this.state.isLoading = true;
            const priceElements = document.querySelectorAll('[data-price]');
            const currency = this.currentCurrency;
            const rate = this.currencies[currency].rate;
            const symbol = this.currencies[currency].symbol;

            const updates = Array.from(priceElements).map(async (el) => {
                try {
                    const basePrice = parseFloat(el.dataset.price);
                    if (isNaN(basePrice)) {
                        throw new Error(`Invalid price value: ${el.dataset.price}`);
                    }
                    const convertedPrice = basePrice * rate;
                    el.textContent = `${symbol}${convertedPrice.toFixed(2)}`;
                } catch (error) {
                    this.errorTracker.logError(error, 'price update');
                }
            });

            await Promise.all(updates);
        } catch (error) {
            this.errorTracker.logError(error, 'update prices');
            this.showNotification('Failed to update prices. Please refresh the page.', 'error');
        } finally {
            this.state.isLoading = false;
        }
    }

    async applyTranslations(translations) {
        try {
            this.state.isLoading = true;
            const elements = document.querySelectorAll('[data-i18n]');
            
            elements.forEach(element => {
                const key = element.dataset.i18n;
                const translation = translations[key];
                
                if (!translation) {
                    throw new Error(`Missing translation for key: ${key}`);
                }
                
                if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                    element.placeholder = translation;
                } else {
                    element.textContent = translation;
                }
            });
            
            document.documentElement.lang = this.currentLanguage;
        } catch (error) {
            this.errorTracker.logError(error, 'apply translations');
            this.showNotification('Some translations could not be applied.', 'warning');
        } finally {
            this.state.isLoading = false;
        }
    }

    updateSearchResults(results) {
        const resultsContainer = document.querySelector('#search-results');
        if (resultsContainer) {
            resultsContainer.innerHTML = results.map(train => `
                <div class="train-result">
                    <h3>${train.name}</h3>
                    <p>${train.description}</p>
                    <div class="price" data-price="${train.price}">
                        ${this.currencies[this.currentCurrency].symbol}${(train.price * this.currencies[this.currentCurrency].rate).toFixed(2)}
                    </div>
                </div>
            `).join('');
        }
    }
}

// Luxury Trains Archive Implementation
class TrainsArchive {
    constructor() {
        this.state = {
            isLoading: false,
            error: null,
            filters: {
                destinations: new Set(),
                durations: new Set(),
                priceRange: { min: 0, max: 10000 },
                amenities: new Set()
            },
            currentSort: 'popular',
            currentPage: 1,
            itemsPerPage: 9,
            trains: [],
            totalResults: 0
        };

        this.elements = {};
        this.initializeElements();
        this.bindEvents();
        this.loadTrains().catch(error => {
            console.error('Failed to load trains:', error);
            this.showError('Failed to load trains. Please refresh the page.');
        });
    }

    initializeElements() {
        try {
            this.elements = {
                filterForm: document.querySelector('.trains-archive-sidebar__form'),
                filterInputs: document.querySelectorAll('.trains-archive-sidebar__checkbox input'),
                sortSelect: document.querySelector('.trains-archive__sort'),
                trainsContainer: document.querySelector('.trains-archive__grid'),
                pagination: document.querySelector('.trains-archive__pagination'),
                loadingIndicator: document.querySelector('.trains-archive__loading'),
                errorContainer: document.querySelector('.trains-archive__error')
            };

            if (!this.elements.trainsContainer) {
                throw new Error('Required container elements not found');
            }
        } catch (error) {
            console.error('Element initialization error:', error);
            this.showError('Failed to initialize page elements');
        }
    }

    bindEvents() {
        try {
            if (this.elements.filterForm) {
                this.elements.filterForm.addEventListener('submit', (e) => {
                    e.preventDefault();
                    this.applyFilters();
                });
            }

            this.elements.filterInputs?.forEach(input => {
                input.addEventListener('change', () => {
                    const { type, value, checked } = input;
                    const filterType = input.closest('[data-filter-type]')?.dataset.filterType;
                    if (filterType) {
                        this.updateFilter(filterType, value, checked);
                    }
                });
            });

            this.elements.sortSelect?.addEventListener('change', (e) => {
                this.state.currentSort = e.target.value;
                this.updateTrains();
            });
        } catch (error) {
            console.error('Event binding error:', error);
            this.showError('Failed to initialize page interactions');
        }
    }

    async loadTrains() {
        try {
            this.setLoading(true);
            const response = await fetch('/api/trains', {
                headers: {
                    'Accept': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            this.state.trains = data.trains;
            this.state.totalResults = data.total;
            
            await this.populateFilters();
            await this.updateTrains();
        } catch (error) {
            console.error('Train loading error:', error);
            this.showError('Failed to load trains data');
            throw error;
        } finally {
            this.setLoading(false);
        }
    }

    async populateFilters() {
        try {
            const uniqueValues = {
                destinations: new Set(),
                durations: new Set(),
                amenities: new Set()
            };

            this.state.trains.forEach(train => {
                uniqueValues.destinations.add(train.destination);
                uniqueValues.durations.add(train.duration);
                train.amenities?.forEach(amenity => uniqueValues.amenities.add(amenity));
            });

            for (const [filterType, values] of Object.entries(uniqueValues)) {
                const container = document.querySelector(`[data-filter-type="${filterType}"]`);
                if (container) {
                    container.innerHTML = Array.from(values)
                        .sort()
                        .map(value => this.createFilterCheckbox(filterType, value))
                        .join('');
                }
            }
        } catch (error) {
            console.error('Filter population error:', error);
            this.showError('Failed to load filter options');
        }
    }

    createFilterCheckbox(type, value) {
        const isChecked = this.state.filters[type].has(value);
        return `
            <label class="trains-archive-sidebar__checkbox">
                <input type="checkbox" value="${value}" ${isChecked ? 'checked' : ''}>
                <span>${value}</span>
            </label>
        `;
    }

    updateFilter(filterType, value, checked) {
        try {
            if (checked) {
                this.state.filters[filterType].add(value);
            } else {
                this.state.filters[filterType].delete(value);
            }
            this.state.currentPage = 1;
            this.updateTrains();
        } catch (error) {
            console.error('Filter update error:', error);
            this.showError('Failed to update filters');
        }
    }

    resetFilters() {
        try {
            Object.keys(this.state.filters).forEach(key => {
                if (this.state.filters[key] instanceof Set) {
                    this.state.filters[key].clear();
                }
            });
            this.state.filters.priceRange = { min: 0, max: 10000 };
            this.elements.filterInputs?.forEach(input => input.checked = false);
            this.updateTrains();
        } catch (error) {
            console.error('Filter reset error:', error);
            this.showError('Failed to reset filters');
        }
    }

    async updateTrains() {
        try {
            this.setLoading(true);
            const filteredTrains = this.filterTrains();
            const sortedTrains = this.sortTrains(filteredTrains);
            
            const startIndex = (this.state.currentPage - 1) * this.state.itemsPerPage;
            const endIndex = startIndex + this.state.itemsPerPage;
            const paginatedTrains = sortedTrains.slice(startIndex, endIndex);

            this.renderTrains(paginatedTrains);
            this.updatePagination(Math.ceil(sortedTrains.length / this.state.itemsPerPage));
        } catch (error) {
            console.error('Trains update error:', error);
            this.showError('Failed to update train listings');
        } finally {
            this.setLoading(false);
        }
    }

    setLoading(isLoading) {
        this.state.isLoading = isLoading;
        if (this.elements.loadingIndicator) {
            this.elements.loadingIndicator.style.display = isLoading ? 'block' : 'none';
        }
    }

    showError(message) {
        if (this.elements.errorContainer) {
            this.elements.errorContainer.textContent = message;
            this.elements.errorContainer.style.display = 'block';
            setTimeout(() => {
                this.elements.errorContainer.style.display = 'none';
            }, 5000);
        }
    }

    filterTrains() {
        return this.state.trains.filter(train => {
            // Apply destination filter
            if (this.state.filters.destinations.size > 0 && !this.state.filters.destinations.has(train.destination)) {
                return false;
            }

            // Apply duration filter
            if (this.state.filters.durations.size > 0 && !this.state.filters.durations.has(train.duration)) {
                return false;
            }

            // Apply price range filter
            if (train.price < this.state.filters.priceRange.min || train.price > this.state.filters.priceRange.max) {
                return false;
            }

            // Apply amenities filter
            if (this.state.filters.amenities.size > 0) {
                return [...this.state.filters.amenities].every(amenity => train.amenities.includes(amenity));
            }

            return true;
        });
    }

    sortTrains(trains) {
        return [...trains].sort((a, b) => {
            switch (this.state.currentSort) {
                case 'price-low':
                    return a.price - b.price;
                case 'price-high':
                    return b.price - a.price;
                case 'duration':
                    return a.duration.localeCompare(b.duration);
                case 'popular':
                default:
                    return b.popularity - a.popularity;
            }
        });
    }

    renderTrains(trains) {
        const trainCards = trains.map(train => `
            <div class="train-card">
                <h3>${train.name}</h3>
                <p>${train.description}</p>
                <div class="price" data-price="${train.price}">
                    ${this.currencies[this.currentCurrency].symbol}${(train.price * this.currencies[this.currentCurrency].rate).toFixed(2)}
                </div>
            </div>
        `).join('');

        this.elements.trainsContainer.innerHTML = trainCards;
    }

    updatePagination(totalPages) {
        // Update pagination buttons state
        this.elements.paginationPrev.disabled = this.state.currentPage === 1;
        this.elements.paginationNext.disabled = this.state.currentPage === totalPages;

        // Update pagination numbers
        let paginationHTML = '';
        for (let i = 1; i <= totalPages; i++) {
            paginationHTML += `
                <button class="${i === this.state.currentPage ? 'active' : ''}" data-page="${i}">
                    ${i}
                </button>
            `;
        }
        this.elements.paginationNumbers.innerHTML = paginationHTML;
    }

    changePage(page) {
        const totalPages = Math.ceil(this.filterTrains().length / this.state.itemsPerPage);
        if (page >= 1 && page <= totalPages) {
            this.state.currentPage = page;
            this.updateTrains();
        }
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    window.famousTrains = new FamousTrainsApp();
    new TrainsArchive();
});