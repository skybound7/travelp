// Initialize Swiper
document.addEventListener('DOMContentLoaded', function() {
    const testimonialSwiper = new Swiper('.testimonials-slider', {
        // Optional parameters
        slidesPerView: 1,
        spaceBetween: 30,
        loop: true,
        autoplay: {
            delay: 5000,
            disableOnInteraction: false,
        },
        
        // Responsive breakpoints
        breakpoints: {
            // when window width is >= 768px
            768: {
                slidesPerView: 2,
                spaceBetween: 30
            },
            // when window width is >= 1024px
            1024: {
                slidesPerView: 3,
                spaceBetween: 30
            }
        },
        
        // Navigation arrows
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        
        // Pagination
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
    });
});

// Image Gallery Popup
document.querySelectorAll('.experience-photos img').forEach(image => {
    image.addEventListener('click', function() {
        const modal = document.createElement('div');
        modal.classList.add('image-modal');
        
        const modalImage = document.createElement('img');
        modalImage.src = this.src;
        
        modal.appendChild(modalImage);
        document.body.appendChild(modal);
        
        modal.addEventListener('click', function() {
            this.remove();
        });
    });
});

// Animate stats on scroll
const stats = document.querySelectorAll('.stat-number');
const animationDuration = 2000;
let animated = false;

function animateStats() {
    stats.forEach(stat => {
        const target = parseInt(stat.textContent);
        const increment = target / (animationDuration / 16);
        let current = 0;
        
        const updateCount = () => {
            if (current < target) {
                current += increment;
                if (current > target) current = target;
                
                if (Number.isInteger(target)) {
                    stat.textContent = Math.floor(current).toLocaleString();
                } else {
                    stat.textContent = current.toFixed(1);
                }
                
                requestAnimationFrame(updateCount);
            }
        };
        
        updateCount();
    });
}

// Intersection Observer for stats animation
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting && !animated) {
            animateStats();
            animated = true;
        }
    });
}, { threshold: 0.5 });

document.querySelector('.review-stats').forEach(element => {
    observer.observe(element);
});
