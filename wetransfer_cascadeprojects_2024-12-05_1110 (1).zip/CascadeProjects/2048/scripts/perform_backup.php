<?php
require_once __DIR__ . '/backup.php';

// Perform backup
$backupManager = new BackupManager();
$result = $backupManager->performFullBackup();

// Output result
echo "Backup Status: " . $result['status'] . "\n";
echo "Message: " . $result['message'] . "\n";

if ($result['status'] === 'success') {
    echo "Backup saved to: " . $result['path'] . "\n";
}
