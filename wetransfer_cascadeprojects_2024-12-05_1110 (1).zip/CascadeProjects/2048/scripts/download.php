<?php
require_once __DIR__ . '/download_site.php';

// Initialize downloader
$downloader = new SiteDownloader();

// Start download
$result = $downloader->downloadSite();

// Output result
echo "Download Status: " . $result['status'] . "\n";
echo "Message: " . $result['message'] . "\n";

if ($result['status'] === 'success') {
    echo "Download saved to: " . $result['download_path'] . "\n";
    echo "You can now download this file to your local machine.\n";
}
