<?php
require_once __DIR__ . '/../includes/config/Database.php';

class SiteDownloader {
    private $config;
    private $downloadDir;
    private $db;
    
    public function __construct() {
        $this->config = [
            'download_dir' => __DIR__ . '/../downloads',
            'site_name' => 'luxury_travel_site',
            'include_dirs' => [
                'assets',
                'css',
                'includes',
                'js',
                'templates',
                'uploads'
            ],
            'exclude_patterns' => [
                '.git',
                '.env',
                'node_modules',
                'vendor/tmp',
                '*.log',
                '*.tmp',
                'downloads/*'
            ]
        ];
        
        $this->downloadDir = $this->config['download_dir'];
        $this->db = new Database();
        
        if (!file_exists($this->downloadDir)) {
            mkdir($this->downloadDir, 0755, true);
        }
    }
    
    /**
     * Download entire website
     */
    public function downloadSite() {
        try {
            $timestamp = date('Y-m-d_H-i-s');
            $siteName = $this->config['site_name'];
            $downloadPath = "{$this->downloadDir}/{$siteName}_{$timestamp}";
            
            // Create download directory
            mkdir($downloadPath, 0755, true);
            
            // Copy all site files
            $this->copySiteFiles($downloadPath);
            
            // Export database
            $this->exportDatabase($downloadPath);
            
            // Create site manifest
            $this->createManifest($downloadPath);
            
            // Create zip archive
            $zipPath = $this->createZipArchive($downloadPath);
            
            // Clean up temporary directory
            $this->cleanup($downloadPath);
            
            return [
                'status' => 'success',
                'message' => 'Site download completed successfully',
                'download_path' => $zipPath
            ];
            
        } catch (\Exception $e) {
            return [
                'status' => 'error',
                'message' => 'Download failed: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Copy all site files
     */
    private function copySiteFiles($downloadPath) {
        $rootDir = realpath(__DIR__ . '/..');
        $filesDir = $downloadPath . '/site_files';
        mkdir($filesDir, 0755, true);
        
        foreach ($this->config['include_dirs'] as $dir) {
            $sourcePath = $rootDir . '/' . $dir;
            if (file_exists($sourcePath)) {
                $this->copyDirectory($sourcePath, $filesDir . '/' . $dir);
            }
        }
        
        // Copy root files
        $rootFiles = glob($rootDir . '/*.{php,html,css,js,txt,md}', GLOB_BRACE);
        foreach ($rootFiles as $file) {
            if (!$this->isExcluded($file)) {
                copy($file, $filesDir . '/' . basename($file));
            }
        }
    }
    
    /**
     * Copy directory recursively
     */
    private function copyDirectory($source, $dest) {
        if (!file_exists($dest)) {
            mkdir($dest, 0755, true);
        }
        
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($source, \RecursiveDirectoryIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $item) {
            if ($this->isExcluded($item->getPathname())) {
                continue;
            }
            
            $targetPath = $dest . DIRECTORY_SEPARATOR . $iterator->getSubPathName();
            
            if ($item->isDir()) {
                if (!file_exists($targetPath)) {
                    mkdir($targetPath, 0755, true);
                }
            } else {
                copy($item->getPathname(), $targetPath);
            }
        }
    }
    
    /**
     * Export database
     */
    private function exportDatabase($downloadPath) {
        $conn = $this->db->getConnection();
        $dbDir = $downloadPath . '/database';
        mkdir($dbDir, 0755, true);
        
        // Get all tables
        $tables = [];
        $result = $conn->query("SHOW TABLES");
        while ($row = $result->fetch_array()) {
            $tables[] = $row[0];
        }
        
        // Export structure and data
        $structureFile = $dbDir . '/structure.sql';
        $dataFile = $dbDir . '/data.sql';
        
        $structureHandle = fopen($structureFile, 'w');
        $dataHandle = fopen($dataFile, 'w');
        
        // Write headers
        fwrite($structureHandle, "-- Database Structure\n-- Generated: " . date('Y-m-d H:i:s') . "\n\n");
        fwrite($dataHandle, "-- Database Data\n-- Generated: " . date('Y-m-d H:i:s') . "\n\n");
        
        foreach ($tables as $table) {
            // Export structure
            $result = $conn->query("SHOW CREATE TABLE `$table`");
            $row = $result->fetch_array();
            fwrite($structureHandle, "\n" . $row[1] . ";\n");
            
            // Export data
            $result = $conn->query("SELECT * FROM `$table`");
            while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
                $values = array_map(function($value) use ($conn) {
                    if ($value === null) return 'NULL';
                    return "'" . $conn->real_escape_string($value) . "'";
                }, $row);
                
                fwrite($dataHandle, "INSERT INTO `$table` VALUES (" . implode(',', $values) . ");\n");
            }
        }
        
        fclose($structureHandle);
        fclose($dataHandle);
    }
    
    /**
     * Create site manifest
     */
    private function createManifest($downloadPath) {
        $manifest = [
            'site_name' => $this->config['site_name'],
            'generated_at' => date('Y-m-d H:i:s'),
            'php_version' => PHP_VERSION,
            'mysql_version' => $this->db->getConnection()->get_server_info(),
            'included_directories' => $this->config['include_dirs'],
            'file_count' => $this->countFiles($downloadPath . '/site_files'),
            'database_tables' => $this->countDatabaseTables(),
            'checksum' => $this->calculateChecksum($downloadPath)
        ];
        
        file_put_contents(
            $downloadPath . '/manifest.json',
            json_encode($manifest, JSON_PRETTY_PRINT)
        );
    }
    
    /**
     * Create ZIP archive
     */
    private function createZipArchive($downloadPath) {
        $zip = new \ZipArchive();
        $zipPath = $downloadPath . '.zip';
        
        if ($zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) === true) {
            $this->addDirToZip($zip, $downloadPath, basename($downloadPath));
            $zip->close();
            return $zipPath;
        }
        
        throw new \Exception('Failed to create ZIP archive');
    }
    
    /**
     * Add directory to ZIP
     */
    private function addDirToZip($zip, $dir, $relativePath = '') {
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getPathname();
                $localPath = $relativePath . str_replace($dir, '', $filePath);
                $zip->addFile($filePath, $localPath);
            }
        }
    }
    
    /**
     * Check if path should be excluded
     */
    private function isExcluded($path) {
        foreach ($this->config['exclude_patterns'] as $pattern) {
            if (strpos($path, $pattern) !== false || fnmatch($pattern, basename($path))) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Count files in directory
     */
    private function countFiles($dir) {
        $count = 0;
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $count++;
            }
        }
        
        return $count;
    }
    
    /**
     * Count database tables
     */
    private function countDatabaseTables() {
        $result = $this->db->getConnection()->query("SHOW TABLES");
        return $result->num_rows;
    }
    
    /**
     * Calculate checksum for downloaded files
     */
    private function calculateChecksum($dir) {
        $checksums = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $checksums[] = md5_file($file->getPathname());
            }
        }
        
        return md5(implode('', $checksums));
    }
    
    /**
     * Clean up temporary directory
     */
    private function cleanup($dir) {
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \RecursiveDirectoryIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        
        foreach ($iterator as $file) {
            if ($file->isDir()) {
                rmdir($file->getPathname());
            } else {
                unlink($file->getPathname());
            }
        }
        
        rmdir($dir);
    }
}
