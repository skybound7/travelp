<?php
require_once __DIR__ . '/../includes/config/Database.php';

class BackupManager {
    private $config;
    private $backupDir;
    private $db;
    
    public function __construct() {
        $this->config = [
            'backup_dir' => __DIR__ . '/../backups',
            'exclude_dirs' => ['backups', 'node_modules', 'vendor/tmp'],
            'exclude_files' => ['.git', '.env', '*.log', '*.tmp'],
            'compress' => true
        ];
        
        $this->backupDir = $this->config['backup_dir'];
        $this->db = new Database();
        
        if (!file_exists($this->backupDir)) {
            mkdir($this->backupDir, 0755, true);
        }
    }
    
    /**
     * Perform complete backup
     */
    public function performFullBackup() {
        try {
            $timestamp = date('Y-m-d_H-i-s');
            $backupPath = $this->backupDir . '/backup_' . $timestamp;
            
            // Create backup directory
            mkdir($backupPath, 0755, true);
            
            // Backup files
            $this->backupFiles($backupPath);
            
            // Backup database
            $this->backupDatabase($backupPath);
            
            // Create backup manifest
            $this->createManifest($backupPath);
            
            // Compress backup
            if ($this->config['compress']) {
                $this->compressBackup($backupPath);
            }
            
            return [
                'status' => 'success',
                'message' => 'Backup completed successfully',
                'path' => $backupPath . ($this->config['compress'] ? '.zip' : '')
            ];
        } catch (\Exception $e) {
            return [
                'status' => 'error',
                'message' => 'Backup failed: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Backup all project files
     */
    private function backupFiles($backupPath) {
        $projectRoot = realpath(__DIR__ . '/..');
        $filesDir = $backupPath . '/files';
        mkdir($filesDir, 0755, true);
        
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($projectRoot),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $file) {
            if ($this->shouldExclude($file)) {
                continue;
            }
            
            $relativePath = str_replace($projectRoot, '', $file->getPathname());
            $targetPath = $filesDir . $relativePath;
            
            if ($file->isDir()) {
                if (!file_exists($targetPath)) {
                    mkdir($targetPath, 0755, true);
                }
            } else {
                $targetDir = dirname($targetPath);
                if (!file_exists($targetDir)) {
                    mkdir($targetDir, 0755, true);
                }
                copy($file->getPathname(), $targetPath);
            }
        }
    }
    
    /**
     * Backup database
     */
    private function backupDatabase($backupPath) {
        $conn = $this->db->getConnection();
        $dbConfig = $this->db->getConfig();
        
        // Get all tables
        $tables = [];
        $result = $conn->query("SHOW TABLES");
        while ($row = $result->fetch_array()) {
            $tables[] = $row[0];
        }
        
        $sqlFile = $backupPath . '/database.sql';
        $handle = fopen($sqlFile, 'w');
        
        // Add SQL header
        fwrite($handle, "-- Luxury Travel Website Database Backup\n");
        fwrite($handle, "-- Generated: " . date('Y-m-d H:i:s') . "\n\n");
        fwrite($handle, "SET FOREIGN_KEY_CHECKS=0;\n\n");
        
        // Export each table
        foreach ($tables as $table) {
            // Get create table syntax
            $result = $conn->query("SHOW CREATE TABLE `$table`");
            $row = $result->fetch_array();
            fwrite($handle, "\n\n" . $row[1] . ";\n\n");
            
            // Get table data
            $result = $conn->query("SELECT * FROM `$table`");
            while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
                $values = array_map(function($value) use ($conn) {
                    if ($value === null) {
                        return 'NULL';
                    }
                    return "'" . $conn->real_escape_string($value) . "'";
                }, $row);
                
                fwrite($handle, "INSERT INTO `$table` VALUES (" . implode(',', $values) . ");\n");
            }
        }
        
        fwrite($handle, "\nSET FOREIGN_KEY_CHECKS=1;\n");
        fclose($handle);
    }
    
    /**
     * Create backup manifest
     */
    private function createManifest($backupPath) {
        $manifest = [
            'timestamp' => date('Y-m-d H:i:s'),
            'version' => '1.0.0',
            'environment' => getenv('APP_ENV'),
            'files_count' => $this->countFiles($backupPath . '/files'),
            'database_tables' => $this->countDatabaseTables(),
            'checksum' => $this->calculateBackupChecksum($backupPath)
        ];
        
        file_put_contents(
            $backupPath . '/manifest.json',
            json_encode($manifest, JSON_PRETTY_PRINT)
        );
    }
    
    /**
     * Compress backup directory
     */
    private function compressBackup($backupPath) {
        $zip = new \ZipArchive();
        $zipFile = $backupPath . '.zip';
        
        if ($zip->open($zipFile, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) === true) {
            $this->addDirToZip($zip, $backupPath, basename($backupPath));
            $zip->close();
            
            // Remove uncompressed backup directory
            $this->removeDirectory($backupPath);
        }
    }
    
    /**
     * Add directory to zip archive
     */
    private function addDirToZip($zip, $dir, $relativePath = '') {
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $file) {
            if ($file->isDir()) {
                continue;
            }
            
            $filePath = $file->getPathname();
            $localPath = $relativePath . str_replace($dir, '', $filePath);
            
            $zip->addFile($filePath, $localPath);
        }
    }
    
    /**
     * Check if file/directory should be excluded
     */
    private function shouldExclude($file) {
        $relativePath = str_replace(realpath(__DIR__ . '/..'), '', $file->getPathname());
        
        // Check excluded directories
        foreach ($this->config['exclude_dirs'] as $dir) {
            if (strpos($relativePath, '/' . $dir . '/') !== false) {
                return true;
            }
        }
        
        // Check excluded files
        foreach ($this->config['exclude_files'] as $pattern) {
            if (fnmatch($pattern, $file->getBasename())) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Count files in backup
     */
    private function countFiles($dir) {
        $count = 0;
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $count++;
            }
        }
        
        return $count;
    }
    
    /**
     * Count database tables
     */
    private function countDatabaseTables() {
        $conn = $this->db->getConnection();
        $result = $conn->query("SHOW TABLES");
        return $result->num_rows;
    }
    
    /**
     * Calculate backup checksum
     */
    private function calculateBackupChecksum($backupPath) {
        $checksums = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($backupPath),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $checksums[] = md5_file($file->getPathname());
            }
        }
        
        return md5(implode('', $checksums));
    }
    
    /**
     * Remove directory and its contents
     */
    private function removeDirectory($dir) {
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \RecursiveDirectoryIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        
        foreach ($iterator as $file) {
            if ($file->isDir()) {
                rmdir($file->getPathname());
            } else {
                unlink($file->getPathname());
            }
        }
        
        rmdir($dir);
    }
}
