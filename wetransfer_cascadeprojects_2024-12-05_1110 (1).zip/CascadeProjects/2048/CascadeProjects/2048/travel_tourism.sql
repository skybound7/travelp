// Track a custom event
trackingManager.trackEvent('category', 'action', 'label', value);

// Track a booking
trackingManager.trackBookingComplete({
    bookingId: 'booking123',
    value: 999.99,
    items: [{
        id: 'tour1',
        name: 'Luxury Tour',
        price: 999.99,
        quantity: 1
    }]
});