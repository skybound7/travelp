<?php
require_once 'includes/header.php';
require_once 'vendor/autoload.php';

if (!isset($_SESSION['user_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Please login to book a package']);
    exit();
}

try {
    // Initialize Stripe
    \Stripe\Stripe::setApiKey('your_stripe_secret_key');

    // Get form data
    $package_id = $_POST['package_id'];
    $travel_date = $_POST['travel_date'];
    $num_people = $_POST['num_people'];

    // Validate package
    $stmt = $pdo->prepare("SELECT * FROM packages WHERE id = ? AND end_date >= ? AND available_seats >= ?");
    $stmt->execute([$package_id, $travel_date, $num_people]);
    $package = $stmt->fetch();

    if (!$package) {
        throw new Exception('Package not available for selected date or number of people');
    }

    // Calculate total price
    $total_price = $package['price'] * $num_people;

    // Start transaction
    $pdo->beginTransaction();

    // Create booking record
    $stmt = $pdo->prepare("
        INSERT INTO bookings (user_id, package_id, booking_date, num_people, total_price, payment_status)
        VALUES (?, ?, ?, ?, ?, 'pending')
    ");
    $stmt->execute([$_SESSION['user_id'], $package_id, $travel_date, $num_people, $total_price]);
    $booking_id = $pdo->lastInsertId();

    // Update available seats
    $stmt = $pdo->prepare("
        UPDATE packages 
        SET available_seats = available_seats - ? 
        WHERE id = ?
    ");
    $stmt->execute([$num_people, $package_id]);

    // Create Stripe payment intent
    $payment_intent = \Stripe\PaymentIntent::create([
        'amount' => $total_price * 100, // Amount in cents
        'currency' => 'usd',
        'metadata' => [
            'booking_id' => $booking_id,
            'package_id' => $package_id
        ]
    ]);

    // Commit transaction
    $pdo->commit();

    // Return success response with client secret
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'clientSecret' => $payment_intent->client_secret,
        'bookingId' => $booking_id
    ]);

} catch (Exception $e) {
    // Rollback transaction on error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    // Return error response
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
