<?php include 'includes/header.php'; ?>

<div class="container py-5">
    <h1 class="mb-4">Car Rentals</h1>

    <!-- Search Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Pickup Location</label>
                    <select name="location" class="form-select">
                        <option value="">All Locations</option>
                        <?php
                        $locations = $pdo->query("SELECT DISTINCT location FROM cars ORDER BY location")->fetchAll();
                        foreach($locations as $loc) {
                            $selected = ($_GET['location'] ?? '') == $loc['location'] ? 'selected' : '';
                            echo "<option value='{$loc['location']}' {$selected}>{$loc['location']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Category</label>
                    <select name="category" class="form-select">
                        <option value="">All Types</option>
                        <?php
                        $categories = $pdo->query("SELECT DISTINCT category FROM cars ORDER BY category")->fetchAll();
                        foreach($categories as $cat) {
                            $selected = ($_GET['category'] ?? '') == $cat['category'] ? 'selected' : '';
                            echo "<option value='{$cat['category']}' {$selected}>{$cat['category']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Pickup Date</label>
                    <input type="date" name="pickup_date" class="form-control" min="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Return Date</label>
                    <input type="date" name="return_date" class="form-control" min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">&nbsp;</label>
                    <button type="submit" class="btn btn-primary w-100">Search Cars</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Car Listings -->
    <div class="row">
        <?php
        $where = ["available_units > 0"];
        $params = [];

        if (!empty($_GET['location'])) {
            $where[] = "location = ?";
            $params[] = $_GET['location'];
        }

        if (!empty($_GET['category'])) {
            $where[] = "category = ?";
            $params[] = $_GET['category'];
        }

        $sql = "SELECT * FROM cars WHERE " . implode(" AND ", $where) . " ORDER BY price_per_day ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $cars = $stmt->fetchAll();

        foreach($cars as $car):
        ?>
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="card h-100">
                <img src="<?php echo htmlspecialchars($car['image_url']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($car['make'] . ' ' . $car['model']); ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($car['make'] . ' ' . $car['model'] . ' ' . $car['year']); ?></h5>
                    <div class="mb-3">
                        <span class="badge bg-primary"><?php echo htmlspecialchars($car['category']); ?></span>
                        <span class="badge bg-secondary"><?php echo htmlspecialchars($car['transmission']); ?></span>
                    </div>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-gas-pump me-2"></i><?php echo htmlspecialchars($car['fuel_type']); ?></li>
                        <li><i class="fas fa-users me-2"></i><?php echo $car['seats']; ?> Seats</li>
                        <li><i class="fas fa-map-marker-alt me-2"></i><?php echo htmlspecialchars($car['location']); ?></li>
                    </ul>

                    <!-- Features -->
                    <div class="mb-3">
                        <?php
                        $features = explode(',', $car['features']);
                        foreach(array_slice($features, 0, 3) as $feature): ?>
                            <span class="badge bg-light text-dark me-1"><?php echo trim($feature); ?></span>
                        <?php endforeach; ?>
                        <?php if(count($features) > 3): ?>
                            <span class="badge bg-light text-dark">+<?php echo count($features) - 3; ?> more</span>
                        <?php endif; ?>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="price">
                            <span class="h4">$<?php echo number_format($car['price_per_day'], 2); ?></span>
                            <small class="text-muted">per day</small>
                        </div>
                        <a href="car-details.php?id=<?php echo $car['id']; ?>" class="btn btn-primary">View Details</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <?php if (empty($cars)): ?>
    <div class="alert alert-info">No cars found matching your criteria. Please try different search parameters.</div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
