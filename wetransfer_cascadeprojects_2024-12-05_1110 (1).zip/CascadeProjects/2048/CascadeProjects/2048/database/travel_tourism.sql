CREATE DATABASE IF NOT EXISTS `travel_tourism`
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE `travel_tourism`;

SET storage_engine = INNODB;
SET NAMES utf8mb4;
SET character_set_client = utf8mb4;
SET character_set_connection = utf8mb4;
SET character_set_database = utf8mb4;
SET character_set_server = utf8mb4;

CREATE TABLE IF NOT EXISTS `users` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `first_name` VARCHAR(50) NOT NULL,
    `last_name` VARCHAR(50) NOT NULL,
    `email` VARCHAR(100) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `phone` VARCHAR(20),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `packages` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL,
    `description` TEXT NOT NULL,
    `base_price` DECIMAL(10,2) NOT NULL,
    `service_charge` DECIMAL(10,2) GENERATED ALWAYS AS (base_price * 0.10) STORED,
    `gst` DECIMAL(10,2) GENERATED ALWAYS AS (base_price * 0.18) STORED,
    `total_price` DECIMAL(10,2) GENERATED ALWAYS AS (base_price + service_charge + gst) STORED,
    `duration` VARCHAR(50) NOT NULL,
    `location` VARCHAR(100) NOT NULL,
    `image_url` VARCHAR(255),
    `start_date` DATE NOT NULL,
    `end_date` DATE NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cruises` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL,
    `description` TEXT NOT NULL,
    `cruise_line` VARCHAR(100) NOT NULL,
    `ship_name` VARCHAR(100) NOT NULL,
    `departure_port` VARCHAR(100) NOT NULL,
    `base_price_per_night` DECIMAL(10,2) NOT NULL,
    `service_charge` DECIMAL(10,2) GENERATED ALWAYS AS (base_price_per_night * 0.10) STORED,
    `gst` DECIMAL(10,2) GENERATED ALWAYS AS (base_price_per_night * 0.18) STORED,
    `total_price_per_night` DECIMAL(10,2) GENERATED ALWAYS AS (base_price_per_night + service_charge + gst) STORED,
    `duration_days` INT NOT NULL,
    `cabin_type` VARCHAR(50) NOT NULL,
    `max_passengers` INT NOT NULL,
    `departure_date` DATE NOT NULL,
    `return_date` DATE NOT NULL,
    `image_url` VARCHAR(255),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hotels` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL,
    `description` TEXT NOT NULL,
    `location` VARCHAR(100) NOT NULL,
    `address` TEXT NOT NULL,
    `star_rating` INT NOT NULL,
    `base_price_per_night` DECIMAL(10,2) NOT NULL,
    `service_charge` DECIMAL(10,2) GENERATED ALWAYS AS (base_price_per_night * 0.10) STORED,
    `gst` DECIMAL(10,2) GENERATED ALWAYS AS (base_price_per_night * 0.18) STORED,
    `total_price_per_night` DECIMAL(10,2) GENERATED ALWAYS AS (base_price_per_night + service_charge + gst) STORED,
    `amenities` TEXT NOT NULL,
    `room_types` TEXT NOT NULL,
    `total_rooms` INT NOT NULL,
    `available_rooms` INT NOT NULL,
    `image_url` VARCHAR(255),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cars` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `make` VARCHAR(50) NOT NULL,
    `model` VARCHAR(50) NOT NULL,
    `year` INT NOT NULL,
    `category` VARCHAR(50) NOT NULL,
    `transmission` VARCHAR(20) NOT NULL,
    `fuel_type` VARCHAR(20) NOT NULL,
    `seats` INT NOT NULL,
    `base_price_per_day` DECIMAL(10,2) NOT NULL,
    `service_charge` DECIMAL(10,2) GENERATED ALWAYS AS (base_price_per_day * 0.10) STORED,
    `gst` DECIMAL(10,2) GENERATED ALWAYS AS (base_price_per_day * 0.18) STORED,
    `total_price_per_day` DECIMAL(10,2) GENERATED ALWAYS AS (base_price_per_day + service_charge + gst) STORED,
    `available_units` INT NOT NULL,
    `features` TEXT NOT NULL,
    `image_url` VARCHAR(255),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `hotel_bookings` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `hotel_id` INT UNSIGNED NOT NULL,
    `room_type` VARCHAR(50) NOT NULL,
    `check_in_date` DATE NOT NULL,
    `check_out_date` DATE NOT NULL,
    `num_rooms` INT NOT NULL,
    `num_guests` INT NOT NULL,
    `total_price` DECIMAL(10,2) NOT NULL,
    `payment_status` ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    `payment_id` VARCHAR(255),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`hotel_id`) REFERENCES `hotels`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `car_rentals` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `car_id` INT UNSIGNED NOT NULL,
    `pickup_date` DATE NOT NULL,
    `return_date` DATE NOT NULL,
    `pickup_location` VARCHAR(100) NOT NULL,
    `return_location` VARCHAR(100) NOT NULL,
    `total_price` DECIMAL(10,2) NOT NULL,
    `insurance_option` VARCHAR(50),
    `payment_status` ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    `payment_id` VARCHAR(255),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`car_id`) REFERENCES `cars`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cruise_bookings` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `cruise_id` INT UNSIGNED NOT NULL,
    `cabin_type` VARCHAR(50) NOT NULL,
    `num_passengers` INT NOT NULL,
    `total_price` DECIMAL(10,2) NOT NULL,
    `dining_preference` VARCHAR(50),
    `special_requests` TEXT,
    `payment_status` ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    `payment_id` VARCHAR(255),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`cruise_id`) REFERENCES `cruises`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bookings` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `package_id` INT UNSIGNED NOT NULL,
    `booking_date` DATE NOT NULL,
    `num_people` INT NOT NULL,
    `total_price` DECIMAL(10,2) NOT NULL,
    `payment_status` ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    `payment_id` VARCHAR(255),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`package_id`) REFERENCES `packages`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `reviews` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `package_id` INT UNSIGNED NULL,
    `hotel_id` INT UNSIGNED NULL,
    `car_id` INT UNSIGNED NULL,
    `cruise_id` INT UNSIGNED NULL,
    `rating` INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    `comment` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`package_id`) REFERENCES `packages`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`hotel_id`) REFERENCES `hotels`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`car_id`) REFERENCES `cars`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`cruise_id`) REFERENCES `cruises`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `refunds` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `booking_id` INT UNSIGNED NOT NULL,
    `booking_type` ENUM('package', 'cruise', 'hotel', 'car', 'flight') NOT NULL,
    `user_id` INT UNSIGNED NOT NULL,
    `original_amount` DECIMAL(10,2) NOT NULL,
    `refund_amount` DECIMAL(10,2) NOT NULL,
    `cancellation_fee` DECIMAL(10,2) NOT NULL,
    `refund_percent` INT NOT NULL,
    `reason` TEXT,
    `status` ENUM('pending', 'approved', 'rejected', 'processed') NOT NULL DEFAULT 'pending',
    `processed_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cancellation_policies` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `service_type` ENUM('package', 'cruise', 'hotel', 'car', 'flight') NOT NULL,
    `days_before` INT NOT NULL,
    `refund_percentage` INT NOT NULL,
    `description` TEXT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `airlines` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL,
    `code` VARCHAR(3) NOT NULL UNIQUE,
    `logo_url` VARCHAR(255),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `airports` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL,
    `code` VARCHAR(3) NOT NULL UNIQUE,
    `city` VARCHAR(100) NOT NULL,
    `country` VARCHAR(100) NOT NULL,
    `timezone` VARCHAR(50) NOT NULL,
    `latitude` DECIMAL(10,8),
    `longitude` DECIMAL(11,8),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `flights` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `airline_id` INT UNSIGNED NOT NULL,
    `flight_number` VARCHAR(10) NOT NULL,
    `departure_airport_id` INT UNSIGNED NOT NULL,
    `arrival_airport_id` INT UNSIGNED NOT NULL,
    `departure_time` DATETIME NOT NULL,
    `arrival_time` DATETIME NOT NULL,
    `aircraft_type` VARCHAR(50) NOT NULL,
    `base_price` DECIMAL(10,2) NOT NULL,
    `service_charge` DECIMAL(10,2) GENERATED ALWAYS AS (base_price * 0.10) STORED,
    `gst` DECIMAL(10,2) GENERATED ALWAYS AS (base_price * 0.18) STORED,
    `total_price` DECIMAL(10,2) GENERATED ALWAYS AS (base_price + service_charge + gst) STORED,
    `duration_minutes` INT NOT NULL,
    `distance_km` INT NOT NULL,
    `available_seats` JSON NOT NULL,
    `status` ENUM('scheduled', 'delayed', 'cancelled', 'completed') DEFAULT 'scheduled',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`airline_id`) REFERENCES `airlines`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`departure_airport_id`) REFERENCES `airports`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`arrival_airport_id`) REFERENCES `airports`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `flight_classes` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `flight_id` INT UNSIGNED NOT NULL,
    `class_name` ENUM('economy', 'premium_economy', 'business', 'first') NOT NULL,
    `base_price` DECIMAL(10,2) NOT NULL,
    `service_charge` DECIMAL(10,2) GENERATED ALWAYS AS (base_price * 0.10) STORED,
    `gst` DECIMAL(10,2) GENERATED ALWAYS AS (base_price * 0.18) STORED,
    `total_price` DECIMAL(10,2) GENERATED ALWAYS AS (base_price + service_charge + gst) STORED,
    `seats_total` INT NOT NULL,
    `seats_available` INT NOT NULL,
    `baggage_allowance_kg` INT NOT NULL,
    `cabin_baggage_kg` INT NOT NULL,
    `cancellation_fee` DECIMAL(10,2) NOT NULL,
    `amenities` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`flight_id`) REFERENCES `flights`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `flight_bookings` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `flight_id` INT UNSIGNED NOT NULL,
    `flight_class_id` INT UNSIGNED NOT NULL,
    `booking_reference` VARCHAR(10) NOT NULL UNIQUE,
    `passenger_details` JSON NOT NULL,
    `seat_numbers` JSON NOT NULL,
    `base_price` DECIMAL(10,2) NOT NULL,
    `service_charge` DECIMAL(10,2) GENERATED ALWAYS AS (base_price * 0.10) STORED,
    `gst` DECIMAL(10,2) GENERATED ALWAYS AS (base_price * 0.18) STORED,
    `total_price` DECIMAL(10,2) GENERATED ALWAYS AS (base_price + service_charge + gst) STORED,
    `meal_preferences` JSON,
    `special_requests` TEXT,
    `payment_status` ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    `check_in_status` ENUM('not_available', 'available', 'completed') DEFAULT 'not_available',
    `booking_status` ENUM('confirmed', 'cancelled') DEFAULT 'confirmed',
    `payment_id` VARCHAR(255),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`flight_id`) REFERENCES `flights`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`flight_class_id`) REFERENCES `flight_classes`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cancellation_policies` (`service_type`, `days_before`, `refund_percentage`, `description`) VALUES
-- Cruise policies
('cruise', 30, 100, '100% refund if cancelled 30 or more days before departure'),
('cruise', 15, 50, '50% refund if cancelled 15-29 days before departure'),
('cruise', 7, 25, '25% refund if cancelled 7-14 days before departure'),
('cruise', 0, 0, 'No refund if cancelled less than 7 days before departure'),

-- Package policies
('package', 7, 100, '100% refund if cancelled 7 or more days before start'),
('package', 3, 50, '50% refund if cancelled 3-6 days before start'),
('package', 1, 25, '25% refund if cancelled 1-2 days before start'),
('package', 0, 0, 'No refund if cancelled less than 24 hours before start'),

-- Hotel policies
('hotel', 3, 100, '100% refund if cancelled 3 or more days before check-in'),
('hotel', 1, 50, '50% refund if cancelled 1-2 days before check-in'),
('hotel', 0, 0, 'No refund if cancelled less than 24 hours before check-in'),

-- Car rental policies
('car', 3, 100, '100% refund if cancelled 3 or more days before pickup'),
('car', 1, 50, '50% refund if cancelled 1-2 days before pickup'),
('car', 0, 0, 'No refund if cancelled less than 24 hours before pickup'),

-- Flight policies
('flight', 7, 100, '100% refund if cancelled 7 or more days before departure'),
('flight', 3, 75, '75% refund if cancelled 3-6 days before departure'),
('flight', 1, 50, '50% refund if cancelled 1-2 days before departure'),
('flight', 0, 0, 'No refund if cancelled less than 24 hours before departure');
