<?php 
include 'includes/header.php';

if (!isset($_GET['id'])) {
    header('Location: packages.php');
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM packages WHERE id = ?");
$stmt->execute([$_GET['id']]);
$package = $stmt->fetch();

if (!$package) {
    header('Location: packages.php');
    exit();
}
?>

<div class="container py-5">
    <div class="row">
        <!-- Package Details -->
        <div class="col-md-8">
            <img src="<?php echo htmlspecialchars($package['image_url']); ?>" class="img-fluid rounded mb-4" alt="<?php echo htmlspecialchars($package['name']); ?>">
            <h1 class="mb-4"><?php echo htmlspecialchars($package['name']); ?></h1>
            
            <div class="mb-4">
                <h4>Description</h4>
                <p><?php echo nl2br(htmlspecialchars($package['description'])); ?></p>
            </div>
            
            <div class="mb-4">
                <h4>Included Services</h4>
                <ul class="list-group">
                    <?php foreach(explode(',', $package['included_services']) as $service): ?>
                        <li class="list-group-item">
                            <i class="fas fa-check text-success me-2"></i>
                            <?php echo htmlspecialchars(trim($service)); ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            
            <!-- Reviews Section -->
            <div class="mb-4">
                <h4>Reviews</h4>
                <?php
                $stmt = $pdo->prepare("
                    SELECT r.*, u.first_name, u.last_name 
                    FROM reviews r 
                    JOIN users u ON r.user_id = u.id 
                    WHERE r.package_id = ? 
                    ORDER BY r.created_at DESC
                ");
                $stmt->execute([$package['id']]);
                $reviews = $stmt->fetchAll();
                
                foreach($reviews as $review):
                ?>
                <div class="review-card">
                    <div class="rating mb-2">
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <i class="fa<?php echo $i <= $review['rating'] ? 's' : 'r'; ?> fa-star"></i>
                        <?php endfor; ?>
                    </div>
                    <p><?php echo htmlspecialchars($review['comment']); ?></p>
                    <small class="text-muted">
                        - <?php echo htmlspecialchars($review['first_name'] . ' ' . $review['last_name']); ?>
                        (<?php echo date('M d, Y', strtotime($review['created_at'])); ?>)
                    </small>
                </div>
                <?php endforeach; ?>
                
                <?php if(isset($_SESSION['user_id'])): ?>
                <form id="reviewForm" class="mt-4" method="post" action="submit-review.php">
                    <input type="hidden" name="package_id" value="<?php echo $package['id']; ?>">
                    <div class="mb-3">
                        <label class="form-label">Rating</label>
                        <div>
                            <?php for($i = 1; $i <= 5; $i++): ?>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="rating" value="<?php echo $i; ?>" id="rating<?php echo $i; ?>">
                                <label class="form-check-label" for="rating<?php echo $i; ?>"><?php echo $i; ?></label>
                            </div>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="comment" class="form-label">Your Review</label>
                        <textarea class="form-control" id="comment" name="comment" rows="3" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit Review</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Booking Form -->
        <div class="col-md-4">
            <div class="booking-form">
                <h3 class="mb-4">Book This Package</h3>
                <div class="package-price mb-4">
                    <span class="h2">$<?php echo number_format($package['price'], 2); ?></span>
                    <small class="text-muted">per person</small>
                </div>
                
                <form id="bookingForm" method="post" action="process-booking.php">
                    <input type="hidden" name="package_id" value="<?php echo $package['id']; ?>">
                    <input type="hidden" id="base_price" value="<?php echo $package['price']; ?>">
                    
                    <div class="mb-3">
                        <label for="travel_date" class="form-label">Travel Date</label>
                        <input type="date" class="form-control" id="travel_date" name="travel_date" 
                               min="<?php echo $package['start_date']; ?>" 
                               max="<?php echo $package['end_date']; ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="num_people" class="form-label">Number of People</label>
                        <input type="number" class="form-control" id="num_people" name="num_people" 
                               min="1" max="<?php echo $package['available_seats']; ?>" 
                               value="1" onchange="updatePrice()" required>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label">Total Price</label>
                        <div class="h4">$<span id="total_price"><?php echo number_format($package['price'], 2); ?></span></div>
                    </div>
                    
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <button type="submit" class="btn btn-travel w-100">Book Now</button>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-travel w-100">Login to Book</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
