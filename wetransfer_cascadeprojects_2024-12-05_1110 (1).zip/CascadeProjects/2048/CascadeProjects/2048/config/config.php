<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');     // Change this to your database username
define('DB_PASS', '');         // Change this to your database password
define('DB_NAME', 'travel_tourism');

// Website configuration
define('SITE_NAME', 'Travel & Tourism');
define('SITE_URL', 'http://localhost/travel_tourism');  // Change this to your website URL

// Email configuration
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_USER', 'your-email@gmail.com');  // Change this to your email
define('SMTP_PASS', 'your-password');         // Change this to your email password
define('SMTP_PORT', 587);

// Payment configuration (Stripe)
define('STRIPE_PUBLIC_KEY', 'your_stripe_public_key');    // Add your Stripe public key
define('STRIPE_SECRET_KEY', 'your_stripe_secret_key');    // Add your Stripe secret key

// Session configuration
ini_set('session.cookie_lifetime', 86400);  // 24 hours
ini_set('session.gc_maxlifetime', 86400);   // 24 hours
?>
