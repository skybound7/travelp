<?php
include 'includes/header.php';

if (!isset($_GET['type']) || !isset($_GET['id'])) {
    header('Location: index.php');
    exit();
}

$booking_type = $_GET['type'];
$booking_id = $_GET['id'];
$booking = null;
$service = null;

try {
    switch($booking_type) {
        case 'package':
            $stmt = $pdo->prepare("
                SELECT b.*, p.name, p.description, p.image_url 
                FROM bookings b 
                JOIN packages p ON b.package_id = p.id 
                WHERE b.id = ? AND b.user_id = ?
            ");
            $stmt->execute([$booking_id, $_SESSION['user_id']]);
            $booking = $stmt->fetch();
            break;

        case 'cruise':
            $stmt = $pdo->prepare("
                SELECT b.*, c.name, c.description, c.image_url, c.cruise_line, c.ship_name 
                FROM cruise_bookings b 
                JOIN cruises c ON b.cruise_id = c.id 
                WHERE b.id = ? AND b.user_id = ?
            ");
            $stmt->execute([$booking_id, $_SESSION['user_id']]);
            $booking = $stmt->fetch();
            break;

        case 'hotel':
            $stmt = $pdo->prepare("
                SELECT b.*, h.name, h.description, h.image_url, h.location 
                FROM hotel_bookings b 
                JOIN hotels h ON b.hotel_id = h.id 
                WHERE b.id = ? AND b.user_id = ?
            ");
            $stmt->execute([$booking_id, $_SESSION['user_id']]);
            $booking = $stmt->fetch();
            break;

        case 'car':
            $stmt = $pdo->prepare("
                SELECT b.*, c.make, c.model, c.year, c.image_url 
                FROM car_rentals b 
                JOIN cars c ON b.car_id = c.id 
                WHERE b.id = ? AND b.user_id = ?
            ");
            $stmt->execute([$booking_id, $_SESSION['user_id']]);
            $booking = $stmt->fetch();
            break;

        default:
            throw new Exception('Invalid booking type');
    }

    if (!$booking) {
        throw new Exception('Booking not found');
    }

} catch (Exception $e) {
    header('Location: index.php');
    exit();
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <div class="text-center mb-4">
                        <i class="fas fa-check-circle text-success fa-3x mb-3"></i>
                        <h2>Booking Confirmed!</h2>
                        <p class="lead">Thank you for your booking. Your confirmation details are below.</p>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <img src="<?php echo htmlspecialchars($booking['image_url']); ?>" class="img-fluid rounded" alt="Booking Image">
                        </div>
                        <div class="col-md-6">
                            <h4><?php echo htmlspecialchars($booking['name']); ?></h4>
                            <?php if($booking_type == 'cruise'): ?>
                                <p><strong>Cruise Line:</strong> <?php echo htmlspecialchars($booking['cruise_line']); ?></p>
                                <p><strong>Ship:</strong> <?php echo htmlspecialchars($booking['ship_name']); ?></p>
                                <p><strong>Cabin Type:</strong> <?php echo htmlspecialchars($booking['cabin_type']); ?></p>
                            <?php elseif($booking_type == 'hotel'): ?>
                                <p><strong>Location:</strong> <?php echo htmlspecialchars($booking['location']); ?></p>
                                <p><strong>Room Type:</strong> <?php echo htmlspecialchars($booking['room_type']); ?></p>
                                <p><strong>Check-in:</strong> <?php echo date('M d, Y', strtotime($booking['check_in_date'])); ?></p>
                                <p><strong>Check-out:</strong> <?php echo date('M d, Y', strtotime($booking['check_out_date'])); ?></p>
                            <?php elseif($booking_type == 'car'): ?>
                                <p><strong>Vehicle:</strong> <?php echo htmlspecialchars($booking['year'] . ' ' . $booking['make'] . ' ' . $booking['model']); ?></p>
                                <p><strong>Pickup:</strong> <?php echo htmlspecialchars($booking['pickup_location']); ?></p>
                                <p><strong>Return:</strong> <?php echo htmlspecialchars($booking['return_location']); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="booking-details bg-light p-4 rounded">
                        <h5>Booking Details</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Booking ID:</strong> #<?php echo $booking_id; ?></p>
                                <p><strong>Booking Date:</strong> <?php echo date('M d, Y', strtotime($booking['created_at'])); ?></p>
                                <p><strong>Payment Status:</strong> 
                                    <span class="badge bg-<?php echo $booking['payment_status'] == 'completed' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($booking['payment_status']); ?>
                                    </span>
                                </p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Total Amount:</strong> $<?php echo number_format($booking['total_price'], 2); ?></p>
                                <?php if(isset($booking['num_people'])): ?>
                                    <p><strong>Number of People:</strong> <?php echo $booking['num_people']; ?></p>
                                <?php endif; ?>
                                <?php if(isset($booking['num_rooms'])): ?>
                                    <p><strong>Number of Rooms:</strong> <?php echo $booking['num_rooms']; ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="text-center mt-4">
                        <a href="index.php" class="btn btn-primary me-2">Back to Home</a>
                        <a href="#" class="btn btn-secondary" onclick="window.print()">Print Confirmation</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
