// Initialize Stripe
const stripe = Stripe('your_publishable_key');

// Handle booking form submission
document.addEventListener('DOMContentLoaded', function() {
    const bookingForm = document.getElementById('bookingForm');
    if (bookingForm) {
        bookingForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const submitButton = bookingForm.querySelector('button[type="submit"]');
            submitButton.disabled = true;
            submitButton.innerHTML = 'Processing...';

            try {
                const formData = new FormData(bookingForm);
                const response = await fetch('process_booking.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    // Handle successful payment
                    const result = await stripe.confirmCardPayment(data.clientSecret, {
                        payment_method: {
                            card: card,
                            billing_details: {
                                name: formData.get('name')
                            }
                        }
                    });

                    if (result.error) {
                        showError(result.error.message);
                    } else {
                        window.location.href = 'booking-confirmation.php?id=' + data.bookingId;
                    }
                } else {
                    showError(data.message);
                }
            } catch (error) {
                showError('An error occurred. Please try again.');
            }

            submitButton.disabled = false;
            submitButton.innerHTML = 'Book Now';
        });
    }
});

// Dynamic package price calculation
function updatePrice() {
    const numPeople = document.getElementById('num_people').value;
    const basePrice = document.getElementById('base_price').value;
    const totalPrice = numPeople * basePrice;
    document.getElementById('total_price').textContent = totalPrice.toFixed(2);
}

// Show error message
function showError(message) {
    const errorDiv = document.getElementById('error-message');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    setTimeout(() => {
        errorDiv.style.display = 'none';
    }, 5000);
}

// Image gallery
document.querySelectorAll('.gallery-image').forEach(image => {
    image.addEventListener('click', function() {
        const modal = document.getElementById('imageModal');
        const modalImg = document.getElementById('modalImage');
        modal.style.display = 'block';
        modalImg.src = this.src;
    });
});

// Review form validation
const reviewForm = document.getElementById('reviewForm');
if (reviewForm) {
    reviewForm.addEventListener('submit', function(e) {
        const rating = document.querySelector('input[name="rating"]:checked');
        const comment = document.getElementById('comment').value;
        
        if (!rating) {
            e.preventDefault();
            showError('Please select a rating');
        }
        
        if (comment.length < 10) {
            e.preventDefault();
            showError('Please write a comment with at least 10 characters');
        }
    });
}

// Smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});
