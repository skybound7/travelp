from app import app, db, Product

# Sample products data
products = [
    {
        'name': 'Laptop',
        'price': 999.99,
        'description': 'High-performance laptop with latest specifications',
        'image_url': 'https://via.placeholder.com/300x200'
    },
    {
        'name': 'Smartphone',
        'price': 699.99,
        'description': 'Latest smartphone with advanced camera features',
        'image_url': 'https://via.placeholder.com/300x200'
    },
    {
        'name': 'Headphones',
        'price': 199.99,
        'description': 'Wireless noise-canceling headphones',
        'image_url': 'https://via.placeholder.com/300x200'
    },
    {
        'name': 'Smartwatch',
        'price': 299.99,
        'description': 'Fitness tracking smartwatch with heart rate monitor',
        'image_url': 'https://via.placeholder.com/300x200'
    }
]

def add_sample_products():
    with app.app_context():
        # Clear existing products
        Product.query.delete()
        
        # Add new products
        for product_data in products:
            product = Product(**product_data)
            db.session.add(product)
        
        db.session.commit()
        print("Sample products added successfully!")

if __name__ == '__main__':
    add_sample_products()
