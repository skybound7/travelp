
      
   <?php
   require_once __DIR__ . '/../security/SecurityManager.php';
   
   class CookieManager {
       private $conn;
       private $config;
       private $security;
       
       public function __construct($conn) {
           $this->conn = $conn;
           $this->security = SecurityManager::getInstance();
           $this->config = [
               'cookie_lifetime' => 365, // days
               'necessary_cookies' => ['session_id', 'csrf_token'],
               'functional_cookies' => ['language', 'theme'],
               'analytics_cookies' => ['_ga', '_gid', '_fbp'],
               'marketing_cookies' => ['ads_id', 'campaign_id']
           ];
       }
   
       /**
        * Set a cookie with secure parameters
        */
       public function setCookie($name, $value, $options = []) {
           $default_options = [
               'expires' => time() + ($this->config['cookie_lifetime'] * 86400),
               'path' => '/',
               'domain' => '',
               'secure' => true,
               'httponly' => true,
               'samesite' => 'Strict'
           ];
           
           $options = array_merge($default_options, $options);
           $value = $this->security->validateInput($value, 'text');
           
           setcookie(
               $name,
               $value,
               [
                   'expires' => $options['expires'],
                   'path' => $options['path'],
                   'domain' => $options['domain'],
                   'secure' => $options['secure'],
                   'httponly' => $options['httponly'],
                   'samesite' => $options['samesite']
               ]
           );
           
           $this->logCookieEvent('set', $name);
       }
   
       /**
        * Update user's cookie preferences
        */
       public function updateCookiePreferences($preferences) {
           $user_id = $_SESSION['user_id'] ?? null;
           $validated_prefs = [];
           
           foreach ($preferences as $category => $enabled) {
               $validated_prefs[$category] = $this->security->validateInput($enabled, 'int');
           }
           
           $stmt = $this->conn->prepare("
               INSERT INTO cookie_preferences (user_id, functional, analytics, marketing, updated_at)
               VALUES (?, ?, ?, ?, NOW())
               ON DUPLICATE KEY UPDATE
                   functional = ?,
                   analytics = ?,
                   marketing = ?,
                   updated_at = NOW()
           ");
           
           $stmt->bind_param(
               "iiiiiii",
               $user_id,
               $validated_prefs['functional'],
               $validated_prefs['analytics'],
               $validated_prefs['marketing'],
               $validated_prefs['functional'],
               $validated_prefs['analytics'],
               $validated_prefs['marketing']
           );
           
           if ($stmt->execute()) {
               $this->logConsentUpdate($validated_prefs);
               return true;
           }
           
           return false;
       }
   
       /**
        * Log cookie consent updates
        */
       private function logConsentUpdate($preferences) {
           $this->security->logSecurityEvent(
               'cookie_consent_update',
               json_encode($preferences),
               'medium'
           );
           
           $stmt = $this->conn->prepare("
               INSERT INTO consent_logs (
                   user_id,
                   ip_address,
                   user_agent,
                   consent_data,
                   timestamp
               ) VALUES (?, ?, ?, ?, NOW())
           ");
           
           $user_id = $_SESSION['user_id'] ?? null;
           $ip = $_SERVER['REMOTE_ADDR'];
           $user_agent = $_SERVER['HTTP_USER_AGENT'];
           $consent_data = json_encode($preferences);
           
           $stmt->bind_param(
               "isss",
               $user_id,
               $ip,
               $user_agent,
               $consent_data
           );
           
           $stmt->execute();
       }
   
       /**
        * Check if a specific cookie category is allowed
        */
       public function isCookieCategoryAllowed($category) {
           $user_id = $_SESSION['user_id'] ?? null;
           
           if ($category === 'necessary') {
               return true; // Necessary cookies are always allowed
           }
           
           $stmt = $this->conn->prepare("
               SELECT $category
               FROM cookie_preferences
               WHERE user_id = ?
               ORDER BY updated_at DESC
               LIMIT 1
           ");
           
           $stmt->bind_param("i", $user_id);
           $stmt->execute();
           $result = $stmt->get_result();
           
           if ($row = $result->fetch_assoc()) {
               return (bool)$row[$category];
           }
           
           return false; // Default to not allowed if no preferences set
       }
   
       /**
        * Log cookie-related events
        */
       private function logCookieEvent($action, $cookie_name) {
           $this->security->logSecurityEvent(
               'cookie_' . $action,
               "Cookie: $cookie_name",
               'low'
           );
       }
   
       /**
        * Get user's current cookie preferences
        */
       public function getCookiePreferences() {
           $user_id = $_SESSION['user_id'] ?? null;
           
           $stmt = $this->conn->prepare("
               SELECT functional, analytics, marketing, updated_at
               FROM cookie_preferences
               WHERE user_id = ?
               ORDER BY updated_at DESC
               LIMIT 1
           ");
           
           $stmt->bind_param("i", $user_id);
           $stmt->execute();
           $result = $stmt->get_result();
           
           if ($row = $result->fetch_assoc()) {
               return [
                   'functional' => (bool)$row['functional'],
                   'analytics' => (bool)$row['analytics'],
                   'marketing' => (bool)$row['marketing'],
                   'last_updated' => $row['updated_at']
               ];
           }
           
           return [
               'functional' => false,
               'analytics' => false,
               'marketing' => false,
               'last_updated' => null
           ];
       }
   
       public function getCookieConsentBanner() {
           return <<<EOT
   <div id="cookie-consent" class="cookie-consent-banner">
       <!-- Your existing banner HTML here -->
   </div>
   EOT;
       }
   }