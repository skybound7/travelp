<?php include 'includes/header.php'; ?>

<div class="container py-5">
    <h1 class="mb-4">Cruise Packages</h1>
    
    <!-- Search Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Departure Port</label>
                    <select name="departure_port" class="form-select">
                        <option value="">All Ports</option>
                        <?php
                        $ports = $pdo->query("SELECT DISTINCT departure_port FROM cruises ORDER BY departure_port")->fetchAll();
                        foreach($ports as $port) {
                            $selected = ($_GET['departure_port'] ?? '') == $port['departure_port'] ? 'selected' : '';
                            echo "<option value='{$port['departure_port']}' {$selected}>{$port['departure_port']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Duration (Days)</label>
                    <select name="duration" class="form-select">
                        <option value="">Any Duration</option>
                        <option value="1-3">1-3 Days</option>
                        <option value="4-7">4-7 Days</option>
                        <option value="8-14">8-14 Days</option>
                        <option value="15+">15+ Days</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Departure Date</label>
                    <input type="date" name="departure_date" class="form-control" value="<?php echo $_GET['departure_date'] ?? ''; ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">&nbsp;</label>
                    <button type="submit" class="btn btn-primary w-100">Search</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Cruise Listings -->
    <div class="row">
        <?php
        $where = [];
        $params = [];

        if (!empty($_GET['departure_port'])) {
            $where[] = "departure_port = ?";
            $params[] = $_GET['departure_port'];
        }

        if (!empty($_GET['duration'])) {
            list($min, $max) = explode('-', $_GET['duration']);
            if ($max === '+') {
                $where[] = "duration_days >= ?";
                $params[] = $min;
            } else {
                $where[] = "duration_days BETWEEN ? AND ?";
                $params[] = $min;
                $params[] = $max;
            }
        }

        if (!empty($_GET['departure_date'])) {
            $where[] = "departure_date >= ?";
            $params[] = $_GET['departure_date'];
        }

        $sql = "SELECT * FROM cruises WHERE available_cabins > 0";
        if (!empty($where)) {
            $sql .= " AND " . implode(" AND ", $where);
        }
        $sql .= " ORDER BY departure_date ASC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $cruises = $stmt->fetchAll();

        foreach($cruises as $cruise):
        ?>
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="card h-100">
                <img src="<?php echo htmlspecialchars($cruise['image_url']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($cruise['name']); ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($cruise['name']); ?></h5>
                    <p class="card-text"><?php echo substr(htmlspecialchars($cruise['description']), 0, 100); ?>...</p>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-ship me-2"></i><?php echo htmlspecialchars($cruise['cruise_line']); ?></li>
                        <li><i class="fas fa-map-marker-alt me-2"></i><?php echo htmlspecialchars($cruise['departure_port']); ?></li>
                        <li><i class="fas fa-calendar me-2"></i><?php echo date('M d, Y', strtotime($cruise['departure_date'])); ?></li>
                        <li><i class="fas fa-clock me-2"></i><?php echo $cruise['duration_days']; ?> Days</li>
                    </ul>
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="price">
                            <span class="h4">$<?php echo number_format($cruise['price_per_night'], 2); ?></span>
                            <small class="text-muted">per night</small>
                        </div>
                        <a href="cruise-details.php?id=<?php echo $cruise['id']; ?>" class="btn btn-primary">View Details</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <?php if (empty($cruises)): ?>
    <div class="alert alert-info">No cruises found matching your criteria. Please try different search parameters.</div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
