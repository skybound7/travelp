<?php include 'includes/header.php'; ?>

<!-- Hero Section -->
<section class="hero">
    <div class="container text-center">
        <h1 class="display-4 mb-4">Your Complete Travel Solution</h1>
        <p class="lead mb-4">Discover amazing destinations, luxurious cruises, comfortable hotels, and convenient car rentals all in one place.</p>
        <div class="d-flex justify-content-center gap-3">
            <a href="packages.php" class="btn btn-travel btn-lg">Tour Packages</a>
            <a href="cruises.php" class="btn btn-outline-light btn-lg">Cruises</a>
        </div>
    </div>
</section>

<!-- Services Section -->
<section class="py-5">
    <div class="container">
        <h2 class="text-center mb-4">Our Services</h2>
        <div class="row">
            <div class="col-md-3 mb-4">
                <div class="card text-center h-100">
                    <div class="card-body">
                        <i class="fas fa-globe fa-3x mb-3 text-primary"></i>
                        <h4>Tour Packages</h4>
                        <p>Explore our handpicked selection of amazing destinations.</p>
                        <a href="packages.php" class="btn btn-primary">View Packages</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card text-center h-100">
                    <div class="card-body">
                        <i class="fas fa-ship fa-3x mb-3 text-info"></i>
                        <h4>Cruises</h4>
                        <p>Experience luxury on the seas with our cruise packages.</p>
                        <a href="cruises.php" class="btn btn-primary">View Cruises</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card text-center h-100">
                    <div class="card-body">
                        <i class="fas fa-hotel fa-3x mb-3 text-success"></i>
                        <h4>Hotels</h4>
                        <p>Find comfortable stays at the best prices worldwide.</p>
                        <a href="hotels.php" class="btn btn-primary">Book Hotels</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card text-center h-100">
                    <div class="card-body">
                        <i class="fas fa-car fa-3x mb-3 text-warning"></i>
                        <h4>Car Rentals</h4>
                        <p>Rent vehicles for convenient travel at your destination.</p>
                        <a href="car-rentals.php" class="btn btn-primary">Rent Cars</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Featured Packages -->
<section class="py-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-4">Featured Tour Packages</h2>
        <div class="row">
            <?php
            $stmt = $pdo->query("SELECT * FROM packages WHERE end_date > CURRENT_DATE ORDER BY created_at DESC LIMIT 3");
            while($package = $stmt->fetch()) {
            ?>
            <div class="col-md-4">
                <div class="card package-card">
                    <img src="<?php echo htmlspecialchars($package['image_url']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($package['name']); ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($package['name']); ?></h5>
                        <p class="card-text"><?php echo substr(htmlspecialchars($package['description']), 0, 100); ?>...</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="package-price">$<?php echo number_format($package['price'], 2); ?></span>
                            <a href="package-details.php?id=<?php echo $package['id']; ?>" class="btn btn-travel">View Details</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
        <div class="text-center mt-4">
            <a href="packages.php" class="btn btn-travel btn-lg">View All Packages</a>
        </div>
    </div>
</section>

<!-- Featured Cruises -->
<section class="py-5">
    <div class="container">
        <h2 class="text-center mb-4">Popular Cruises</h2>
        <div class="row">
            <?php
            $stmt = $pdo->query("SELECT * FROM cruises WHERE departure_date > CURRENT_DATE ORDER BY created_at DESC LIMIT 3");
            while($cruise = $stmt->fetch()) {
            ?>
            <div class="col-md-4">
                <div class="card package-card">
                    <img src="<?php echo htmlspecialchars($cruise['image_url']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($cruise['name']); ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($cruise['name']); ?></h5>
                        <ul class="list-unstyled">
                            <li><i class="fas fa-ship me-2"></i><?php echo htmlspecialchars($cruise['cruise_line']); ?></li>
                            <li><i class="fas fa-map-marker-alt me-2"></i><?php echo htmlspecialchars($cruise['departure_port']); ?></li>
                            <li><i class="fas fa-calendar me-2"></i><?php echo date('M d, Y', strtotime($cruise['departure_date'])); ?></li>
                        </ul>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="package-price">$<?php echo number_format($cruise['price_per_night'], 2); ?>/night</span>
                            <a href="cruise-details.php?id=<?php echo $cruise['id']; ?>" class="btn btn-travel">View Details</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
        <div class="text-center mt-4">
            <a href="cruises.php" class="btn btn-travel btn-lg">View All Cruises</a>
        </div>
    </div>
</section>

<!-- Featured Hotels -->
<section class="py-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-4">Top Rated Hotels</h2>
        <div class="row">
            <?php
            $stmt = $pdo->query("SELECT * FROM hotels ORDER BY star_rating DESC, price_per_night ASC LIMIT 3");
            while($hotel = $stmt->fetch()) {
            ?>
            <div class="col-md-4">
                <div class="card package-card">
                    <img src="<?php echo htmlspecialchars($hotel['image_url']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($hotel['name']); ?>">
                    <div class="card-body">
                        <h5 class="card-title">
                            <?php echo htmlspecialchars($hotel['name']); ?>
                            <span class="float-end">
                                <?php echo str_repeat('⭐', $hotel['star_rating']); ?>
                            </span>
                        </h5>
                        <p class="card-text"><?php echo substr(htmlspecialchars($hotel['description']), 0, 100); ?>...</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="package-price">$<?php echo number_format($hotel['price_per_night'], 2); ?>/night</span>
                            <a href="hotel-details.php?id=<?php echo $hotel['id']; ?>" class="btn btn-travel">View Details</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
        <div class="text-center mt-4">
            <a href="hotels.php" class="btn btn-travel btn-lg">View All Hotels</a>
        </div>
    </div>
</section>

<!-- Newsletter -->
<section class="bg-dark text-white py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h3>Subscribe to Our Newsletter</h3>
                <p>Get the latest updates and special offers delivered directly to your inbox.</p>
            </div>
            <div class="col-md-6">
                <form class="row g-3" id="newsletterForm">
                    <div class="col-md-8">
                        <input type="email" class="form-control" placeholder="Enter your email" required>
                    </div>
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-travel w-100">Subscribe</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
