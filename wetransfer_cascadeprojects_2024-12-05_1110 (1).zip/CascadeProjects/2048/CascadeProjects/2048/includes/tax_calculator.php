<?php
/**
 * Tax Calculator Utility Class
 * Handles Indian taxation calculations including service charges and GST
 */
class TaxCalculator {
    // Constants for tax rates
    const SERVICE_CHARGE_RATE = 0.10; // 10% service charge
    const GST_RATE = 0.18;           // 18% GST

    /**
     * Calculate total price including taxes
     * @param float $basePrice Base price before taxes
     * @return array Array containing breakdown of charges
     */
    public static function calculateTotalPrice($basePrice) {
        $serviceCharge = $basePrice * self::SERVICE_CHARGE_RATE;
        $gst = $basePrice * self::GST_RATE;
        $totalPrice = $basePrice + $serviceCharge + $gst;

        return [
            'base_price' => $basePrice,
            'service_charge' => $serviceCharge,
            'gst' => $gst,
            'total_price' => $totalPrice
        ];
    }

    /**
     * Calculate total price for duration-based services (hotels, cars, cruises)
     * @param float $basePricePerDay Base price per day/night
     * @param int $numberOfDays Number of days/nights
     * @return array Array containing breakdown of charges
     */
    public static function calculateDurationBasedPrice($basePricePerDay, $numberOfDays) {
        $baseTotal = $basePricePerDay * $numberOfDays;
        return self::calculateTotalPrice($baseTotal);
    }

    /**
     * Format price breakdown for display
     * @param array $priceBreakdown Price breakdown array
     * @return string Formatted HTML string
     */
    public static function formatPriceBreakdown($priceBreakdown) {
        $html = '<div class="price-breakdown">';
        $html .= '<p><strong>Base Price:</strong> ₹' . number_format($priceBreakdown['base_price'], 2) . '</p>';
        $html .= '<p><strong>Service Charge (10%):</strong> ₹' . number_format($priceBreakdown['service_charge'], 2) . '</p>';
        $html .= '<p><strong>GST (18%):</strong> ₹' . number_format($priceBreakdown['gst'], 2) . '</p>';
        $html .= '<p class="total"><strong>Total Price:</strong> ₹' . number_format($priceBreakdown['total_price'], 2) . '</p>';
        $html .= '</div>';
        return $html;
    }

    /**
     * Get tax rates for reference
     * @return array Array containing tax rates
     */
    public static function getTaxRates() {
        return [
            'service_charge' => self::SERVICE_CHARGE_RATE * 100 . '%',
            'gst' => self::GST_RATE * 100 . '%'
        ];
    }
}

// Example usage:
/*
$basePrice = 1000;
$priceBreakdown = TaxCalculator::calculateTotalPrice($basePrice);
echo TaxCalculator::formatPriceBreakdown($priceBreakdown);

// For duration-based pricing (e.g., hotel stays)
$basePricePerNight = 2000;
$numberOfNights = 3;
$hotelPriceBreakdown = TaxCalculator::calculateDurationBasedPrice($basePricePerNight, $numberOfNights);
echo TaxCalculator::formatPriceBreakdown($hotelPriceBreakdown);
*/
?>
