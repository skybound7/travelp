<?php
/**
 * Refund Calculator Utility Class
 * Handles refund calculations based on cancellation policies
 */
class RefundCalculator {
    // Constants for refund policies
    const FULL_REFUND_DAYS = 7;     // Full refund if cancelled 7 or more days before
    const PARTIAL_REFUND_DAYS = 3;  // Partial refund if cancelled 3-6 days before
    
    // Refund percentages
    const FULL_REFUND_PERCENT = 100;
    const PARTIAL_REFUND_PERCENT = 50;
    const LATE_REFUND_PERCENT = 25;
    const NO_REFUND_PERCENT = 0;

    /**
     * Calculate refund amount based on booking type and days until start
     * @param float $totalAmount Total booking amount
     * @param string $bookingType Type of booking (package/cruise/hotel/car)
     * @param int $daysUntilStart Days remaining until start date
     * @return array Refund calculation details
     */
    public static function calculateRefund($totalAmount, $bookingType, $daysUntilStart) {
        $refundPercent = self::getRefundPercentage($daysUntilStart, $bookingType);
        $refundAmount = ($totalAmount * $refundPercent) / 100;
        $cancellationFee = $totalAmount - $refundAmount;

        return [
            'original_amount' => $totalAmount,
            'refund_percent' => $refundPercent,
            'refund_amount' => $refundAmount,
            'cancellation_fee' => $cancellationFee,
            'days_until_start' => $daysUntilStart,
            'policy_applied' => self::getRefundPolicyDescription($daysUntilStart)
        ];
    }

    /**
     * Get refund percentage based on days until start and booking type
     * @param int $daysUntilStart Days remaining until start date
     * @param string $bookingType Type of booking
     * @return float Refund percentage
     */
    private static function getRefundPercentage($daysUntilStart, $bookingType) {
        // Special handling for different booking types
        switch($bookingType) {
            case 'cruise':
                if ($daysUntilStart >= 30) return self::FULL_REFUND_PERCENT;
                if ($daysUntilStart >= 15) return self::PARTIAL_REFUND_PERCENT;
                if ($daysUntilStart >= 7) return self::LATE_REFUND_PERCENT;
                return self::NO_REFUND_PERCENT;

            case 'package':
                if ($daysUntilStart >= self::FULL_REFUND_DAYS) return self::FULL_REFUND_PERCENT;
                if ($daysUntilStart >= self::PARTIAL_REFUND_DAYS) return self::PARTIAL_REFUND_PERCENT;
                if ($daysUntilStart >= 1) return self::LATE_REFUND_PERCENT;
                return self::NO_REFUND_PERCENT;

            case 'hotel':
            case 'car':
                if ($daysUntilStart >= 3) return self::FULL_REFUND_PERCENT;
                if ($daysUntilStart >= 1) return self::PARTIAL_REFUND_PERCENT;
                return self::NO_REFUND_PERCENT;

            default:
                return self::NO_REFUND_PERCENT;
        }
    }

    /**
     * Get description of refund policy based on days until start
     * @param int $daysUntilStart Days remaining until start date
     * @return string Policy description
     */
    private static function getRefundPolicyDescription($daysUntilStart) {
        if ($daysUntilStart >= self::FULL_REFUND_DAYS) {
            return "Full Refund Policy (7+ days before)";
        } elseif ($daysUntilStart >= self::PARTIAL_REFUND_DAYS) {
            return "Partial Refund Policy (3-6 days before)";
        } elseif ($daysUntilStart >= 1) {
            return "Late Cancellation Policy (1-2 days before)";
        } else {
            return "No Refund Policy (less than 24 hours)";
        }
    }

    /**
     * Format refund details for display
     * @param array $refundDetails Refund calculation details
     * @return string Formatted HTML string
     */
    public static function formatRefundDetails($refundDetails) {
        $html = '<div class="refund-details">';
        $html .= '<h4>Refund Calculation</h4>';
        $html .= '<p><strong>Original Amount:</strong> ₹' . number_format($refundDetails['original_amount'], 2) . '</p>';
        $html .= '<p><strong>Policy Applied:</strong> ' . $refundDetails['policy_applied'] . '</p>';
        $html .= '<p><strong>Refund Percentage:</strong> ' . $refundDetails['refund_percent'] . '%</p>';
        $html .= '<p><strong>Refund Amount:</strong> ₹' . number_format($refundDetails['refund_amount'], 2) . '</p>';
        $html .= '<p><strong>Cancellation Fee:</strong> ₹' . number_format($refundDetails['cancellation_fee'], 2) . '</p>';
        $html .= '</div>';
        return $html;
    }

    /**
     * Get refund policies for all booking types
     * @return array Array containing refund policies
     */
    public static function getRefundPolicies() {
        return [
            'cruise' => [
                '30+ days before: 100% refund',
                '15-29 days before: 50% refund',
                '7-14 days before: 25% refund',
                'Less than 7 days: No refund'
            ],
            'package' => [
                '7+ days before: 100% refund',
                '3-6 days before: 50% refund',
                '1-2 days before: 25% refund',
                'Less than 24 hours: No refund'
            ],
            'hotel' => [
                '3+ days before: 100% refund',
                '1-2 days before: 50% refund',
                'Less than 24 hours: No refund'
            ],
            'car' => [
                '3+ days before: 100% refund',
                '1-2 days before: 50% refund',
                'Less than 24 hours: No refund'
            ]
        ];
    }
}

// Example usage:
/*
$totalAmount = 10000;
$bookingType = 'package';
$daysUntilStart = 5;

$refundDetails = RefundCalculator::calculateRefund($totalAmount, $bookingType, $daysUntilStart);
echo RefundCalculator::formatRefundDetails($refundDetails);

// Get all refund policies
$policies = RefundCalculator::getRefundPolicies();
*/
?>
