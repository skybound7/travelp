<?php include 'includes/header.php'; ?>

<div class="container py-5">
    <h1 class="mb-4">Hotel Bookings</h1>

    <!-- Search Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Location</label>
                    <select name="location" class="form-select">
                        <option value="">All Locations</option>
                        <?php
                        $locations = $pdo->query("SELECT DISTINCT location FROM hotels ORDER BY location")->fetchAll();
                        foreach($locations as $loc) {
                            $selected = ($_GET['location'] ?? '') == $loc['location'] ? 'selected' : '';
                            echo "<option value='{$loc['location']}' {$selected}>{$loc['location']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Star Rating</label>
                    <select name="star_rating" class="form-select">
                        <option value="">Any Rating</option>
                        <?php for($i = 5; $i >= 1; $i--): ?>
                            <option value="<?php echo $i; ?>"><?php echo str_repeat('⭐', $i); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Check In</label>
                    <input type="date" name="check_in" class="form-control" min="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Check Out</label>
                    <input type="date" name="check_out" class="form-control" min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">&nbsp;</label>
                    <button type="submit" class="btn btn-primary w-100">Search Hotels</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Hotel Listings -->
    <div class="row">
        <?php
        $where = ["available_rooms > 0"];
        $params = [];

        if (!empty($_GET['location'])) {
            $where[] = "location = ?";
            $params[] = $_GET['location'];
        }

        if (!empty($_GET['star_rating'])) {
            $where[] = "star_rating = ?";
            $params[] = $_GET['star_rating'];
        }

        $sql = "SELECT * FROM hotels WHERE " . implode(" AND ", $where) . " ORDER BY star_rating DESC, price_per_night ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $hotels = $stmt->fetchAll();

        foreach($hotels as $hotel):
        ?>
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="card h-100">
                <img src="<?php echo htmlspecialchars($hotel['image_url']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($hotel['name']); ?>">
                <div class="card-body">
                    <h5 class="card-title">
                        <?php echo htmlspecialchars($hotel['name']); ?>
                        <span class="float-end">
                            <?php echo str_repeat('⭐', $hotel['star_rating']); ?>
                        </span>
                    </h5>
                    <p class="card-text"><?php echo substr(htmlspecialchars($hotel['description']), 0, 100); ?>...</p>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-map-marker-alt me-2"></i><?php echo htmlspecialchars($hotel['location']); ?></li>
                        <li><i class="fas fa-bed me-2"></i><?php echo $hotel['available_rooms']; ?> rooms available</li>
                    </ul>
                    
                    <!-- Amenities -->
                    <div class="mb-3">
                        <?php
                        $amenities = explode(',', $hotel['amenities']);
                        foreach(array_slice($amenities, 0, 3) as $amenity): ?>
                            <span class="badge bg-light text-dark me-1"><?php echo trim($amenity); ?></span>
                        <?php endforeach; ?>
                        <?php if(count($amenities) > 3): ?>
                            <span class="badge bg-light text-dark">+<?php echo count($amenities) - 3; ?> more</span>
                        <?php endif; ?>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div class="price">
                            <span class="h4">$<?php echo number_format($hotel['price_per_night'], 2); ?></span>
                            <small class="text-muted">per night</small>
                        </div>
                        <a href="hotel-details.php?id=<?php echo $hotel['id']; ?>" class="btn btn-primary">View Details</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <?php if (empty($hotels)): ?>
    <div class="alert alert-info">No hotels found matching your criteria. Please try different search parameters.</div>
    <?php endif; ?>

    <!-- Map View -->
    <div class="card mt-4">
        <div class="card-body">
            <h5 class="card-title">Map View</h5>
            <div id="map" style="height: 400px;"></div>
        </div>
    </div>
</div>

<!-- Google Maps JavaScript -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY"></script>
<script>
function initMap() {
    const map = new google.maps.Map(document.getElementById('map'), {
        zoom: 12,
        center: { lat: <?php echo $hotels[0]['latitude'] ?? 0; ?>, lng: <?php echo $hotels[0]['longitude'] ?? 0; ?> }
    });

    <?php foreach($hotels as $hotel): ?>
    new google.maps.Marker({
        position: { lat: <?php echo $hotel['latitude']; ?>, lng: <?php echo $hotel['longitude']; ?> },
        map: map,
        title: '<?php echo addslashes($hotel['name']); ?>'
    });
    <?php endforeach; ?>
}

document.addEventListener('DOMContentLoaded', initMap);
</script>

<?php include 'includes/footer.php'; ?>
