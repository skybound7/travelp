<?php
// Database Configuration
define('DB_HOST', 'localhost');     // Your database host
define('DB_NAME', 'payment_db');    // Your database name
define('DB_USER', 'root');          // Your database username
define('DB_PASS', '');              // Your database password
define('DB_CHARSET', 'utf8mb4');    // Database charset
define('DB_COLLATE', 'utf8mb4_unicode_ci'); // Database collation
