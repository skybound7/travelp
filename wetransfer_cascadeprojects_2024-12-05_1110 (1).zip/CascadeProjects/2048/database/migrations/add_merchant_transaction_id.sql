ALTER TABLE payments ADD COLUMN merchant_transaction_id VARCHAR(100);
ALTER TABLE payments ADD INDEX idx_merchant_txn (merchant_transaction_id);
ALTER TABLE payment_attempts ADD COLUMN merchant_transaction_id VARCHAR(100);
ALTER TABLE payment_attempts ADD INDEX idx_merchant_txn (merchant_transaction_id);
