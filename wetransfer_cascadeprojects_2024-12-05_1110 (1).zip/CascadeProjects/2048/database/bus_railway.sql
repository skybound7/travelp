-- Bus Transportation Tables
CREATE TABLE `bus_operators` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL,
    `contact_number` VARCHAR(15),
    `email` VARCHAR(100),
    `address` TEXT,
    `license_number` VARCHAR(50),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `bus_types` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `type` VARCHAR(50) NOT NULL,  -- AC Sleeper, Non-AC Sleeper, AC Seater, etc.
    `description` TEXT,
    `amenities` JSON
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `bus_routes` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `origin` VARCHAR(100) NOT NULL,
    `destination` VARCHAR(100) NOT NULL,
    `distance_km` DECIMAL(10,2),
    `duration_minutes` INT,
    `via_cities` JSON,  -- Stores intermediate stops
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `bus_schedules` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `operator_id` INT,
    `route_id` INT,
    `bus_type_id` INT,
    `departure_time` DATETIME NOT NULL,
    `arrival_time` DATETIME NOT NULL,
    `base_fare` DECIMAL(10,2) NOT NULL,
    `total_seats` INT NOT NULL,
    `available_seats` INT NOT NULL,
    `seat_layout` JSON,  -- Stores seat numbers and their status
    `boarding_points` JSON,  -- Multiple pickup points with timings
    `dropping_points` JSON,  -- Multiple drop points with timings
    FOREIGN KEY (`operator_id`) REFERENCES `bus_operators`(`id`),
    FOREIGN KEY (`route_id`) REFERENCES `bus_routes`(`id`),
    FOREIGN KEY (`bus_type_id`) REFERENCES `bus_types`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `bus_bookings` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `schedule_id` INT,
    `user_id` INT,
    `booking_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `travel_date` DATE NOT NULL,
    `seat_numbers` JSON,
    `passenger_details` JSON,
    `boarding_point` VARCHAR(100),
    `dropping_point` VARCHAR(100),
    `base_fare` DECIMAL(10,2),
    `service_charge` DECIMAL(10,2),
    `gst` DECIMAL(10,2),
    `total_amount` DECIMAL(10,2),
    `status` ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
    `payment_status` ENUM('pending', 'completed', 'refunded') DEFAULT 'pending',
    FOREIGN KEY (`schedule_id`) REFERENCES `bus_schedules`(`id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Indian Railways Tables
CREATE TABLE `railway_stations` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `code` VARCHAR(10) NOT NULL UNIQUE,  -- Station code (e.g., NDLS for New Delhi)
    `name` VARCHAR(100) NOT NULL,
    `city` VARCHAR(100) NOT NULL,
    `state` VARCHAR(100),
    `zone` VARCHAR(50),  -- Railway zone (e.g., NR for Northern Railway)
    `latitude` DECIMAL(10,8),
    `longitude` DECIMAL(11,8)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `train_types` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `code` VARCHAR(10) NOT NULL,  -- RAJ for Rajdhani, SHT for Shatabdi, etc.
    `name` VARCHAR(100) NOT NULL,
    `description` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `train_classes` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `code` VARCHAR(5) NOT NULL,  -- 1A, 2A, 3A, SL, CC, etc.
    `name` VARCHAR(50) NOT NULL,
    `description` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `trains` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `number` VARCHAR(10) NOT NULL UNIQUE,  -- Train number (e.g., 12301)
    `name` VARCHAR(100) NOT NULL,
    `type_id` INT,
    `source_station_id` INT,
    `destination_station_id` INT,
    `distance_km` INT,
    `journey_time_minutes` INT,
    `runs_on` JSON,  -- Days of week when train operates
    `pantry` BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (`type_id`) REFERENCES `train_types`(`id`),
    FOREIGN KEY (`source_station_id`) REFERENCES `railway_stations`(`id`),
    FOREIGN KEY (`destination_station_id`) REFERENCES `railway_stations`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `train_schedules` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `train_id` INT,
    `station_id` INT,
    `stop_number` INT,
    `arrival_time` TIME,
    `departure_time` TIME,
    `day_number` INT,  -- Day 1, 2, etc. of the journey
    `distance_from_source` INT,
    `platform` VARCHAR(10),
    FOREIGN KEY (`train_id`) REFERENCES `trains`(`id`),
    FOREIGN KEY (`station_id`) REFERENCES `railway_stations`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `train_fares` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `train_id` INT,
    `class_id` INT,
    `base_fare` DECIMAL(10,2),
    `dynamic_fare_factor` DECIMAL(4,2) DEFAULT 1.0,  -- For dynamic pricing
    `tatkal_fare` DECIMAL(10,2),
    `premium_tatkal_fare` DECIMAL(10,2),
    FOREIGN KEY (`train_id`) REFERENCES `trains`(`id`),
    FOREIGN KEY (`class_id`) REFERENCES `train_classes`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `train_bookings` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `user_id` INT,
    `train_id` INT,
    `class_id` INT,
    `booking_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `travel_date` DATE,
    `from_station_id` INT,
    `to_station_id` INT,
    `booking_type` ENUM('general', 'tatkal', 'premium_tatkal') DEFAULT 'general',
    `passenger_details` JSON,
    `seat_numbers` JSON,
    `base_fare` DECIMAL(10,2),
    `service_charge` DECIMAL(10,2),
    `gst` DECIMAL(10,2),
    `total_amount` DECIMAL(10,2),
    `status` ENUM('pending', 'confirmed', 'RAC', 'waitlist', 'cancelled') DEFAULT 'pending',
    `payment_status` ENUM('pending', 'completed', 'refunded') DEFAULT 'pending',
    `pnr_number` VARCHAR(20) UNIQUE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`),
    FOREIGN KEY (`train_id`) REFERENCES `trains`(`id`),
    FOREIGN KEY (`class_id`) REFERENCES `train_classes`(`id`),
    FOREIGN KEY (`from_station_id`) REFERENCES `railway_stations`(`id`),
    FOREIGN KEY (`to_station_id`) REFERENCES `railway_stations`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert some sample data for train classes
INSERT INTO `train_classes` (`code`, `name`, `description`) VALUES
('1A', 'First AC', 'First Class Air Conditioned'),
('2A', 'Second AC', 'Two Tier Air Conditioned'),
('3A', 'Third AC', 'Three Tier Air Conditioned'),
('SL', 'Sleeper', 'Non-AC Sleeper Class'),
('CC', 'Chair Car', 'Air Conditioned Chair Car');

-- Insert some sample data for train types
INSERT INTO `train_types` (`code`, `name`, `description`) VALUES
('RAJ', 'Rajdhani Express', 'Premium fully air-conditioned super-fast train'),
('SHT', 'Shatabdi Express', 'Premium super-fast day train'),
('DUR', 'Duronto Express', 'Non-stop super-fast train'),
('SUP', 'Superfast', 'Superfast trains'),
('EXP', 'Express', 'Express trains'),
('PAS', 'Passenger', 'Passenger trains');

-- Insert some sample data for bus types
INSERT INTO `bus_types` (`type`, `description`, `amenities`) VALUES
('AC Sleeper', 'Air Conditioned Sleeper Bus', '{"wifi": true, "usb_charging": true, "blanket": true, "water_bottle": true}'),
('Non-AC Sleeper', 'Non Air Conditioned Sleeper Bus', '{"usb_charging": true, "water_bottle": true}'),
('AC Seater', 'Air Conditioned Seater Bus', '{"wifi": true, "usb_charging": true, "water_bottle": true}'),
('Non-AC Seater', 'Non Air Conditioned Seater Bus', '{"water_bottle": true}'),
('Volvo AC', 'Luxury Volvo Bus with AC', '{"wifi": true, "usb_charging": true, "blanket": true, "water_bottle": true, "entertainment": true}');
