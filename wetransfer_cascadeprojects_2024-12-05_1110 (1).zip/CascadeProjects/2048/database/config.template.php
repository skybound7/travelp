<?php
// Database Configuration
define('DB_HOST', 'localhost');     // Your database host
define('DB_NAME', '');             // Your database name
define('DB_USER', '');             // Your database username
define('DB_PASS', '');             // Your database password
define('DB_CHARSET', 'utf8mb4');   // Database charset
define('DB_COLLATE', 'utf8mb4_unicode_ci'); // Database collation
