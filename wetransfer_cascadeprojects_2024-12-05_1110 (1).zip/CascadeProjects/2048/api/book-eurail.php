<?php
require_once __DIR__ . '/../includes/services/ServiceManager.php';
require_once __DIR__ . '/../includes/services/PaymentManager.php';
require_once __DIR__ . '/../includes/auth/AuthManager.php';

header('Content-Type: application/json');

try {
    // Verify user is logged in
    $auth = new AuthManager();
    $user = $auth->getCurrentUser();
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'Authentication required']);
        exit;
    }
    
    // Validate request
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        exit;
    }
    
    // Get booking data
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Create booking
    $serviceManager = new ServiceManager();
    $bookingId = $serviceManager->bookEurailPass($user['id'], [
        'passType' => $data['passType'],
        'duration' => $data['duration'],
        'startDate' => $data['startDate'],
        'passengers' => $data['passengers'],
        'countries' => $data['countries'],
        'totalPrice' => $data['totalPrice']
    ]);
    
    // Initialize payment if payment method is provided
    $paymentData = null;
    if (isset($data['paymentMethod'])) {
        $paymentManager = new PaymentManager();
        $paymentData = $paymentManager->initiatePayment(
            $bookingId,
            'eurail',
            $data['totalPrice'],
            $data['paymentMethod'],
            $data['paymentDetails'] ?? []
        );
    }
    
    // Return response
    echo json_encode([
        'success' => true,
        'bookingId' => $bookingId,
        'payment' => $paymentData
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Booking failed',
        'message' => $e->getMessage()
    ]);
}
