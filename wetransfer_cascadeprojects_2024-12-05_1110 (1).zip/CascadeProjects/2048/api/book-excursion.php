<?php
require_once __DIR__ . '/../includes/services/ServiceManager.php';
require_once __DIR__ . '/../includes/services/PaymentManager.php';
require_once __DIR__ . '/../includes/auth/AuthManager.php';

header('Content-Type: application/json');

try {
    // Verify user is logged in
    $auth = new AuthManager();
    $user = $auth->getCurrentUser();
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'Authentication required']);
        exit;
    }
    
    // Validate request
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        exit;
    }
    
    // Get booking data
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    $requiredFields = ['excursionType', 'destination', 'excursionDate', 'groupSize', 'totalPrice'];
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || empty($data[$field])) {
            http_response_code(400);
            echo json_encode(['error' => "Missing required field: {$field}"]);
            exit;
        }
    }
    
    // Create booking
    $serviceManager = new ServiceManager();
    $bookingId = $serviceManager->bookExcursion($user['id'], [
        'excursionType' => $data['excursionType'],
        'destination' => $data['destination'],
        'excursionDate' => $data['excursionDate'],
        'groupSize' => $data['groupSize'],
        'specialRequests' => $data['specialRequests'] ?? '',
        'totalPrice' => $data['totalPrice']
    ]);
    
    // Initialize payment if payment method is provided
    $paymentData = null;
    if (isset($data['paymentMethod'])) {
        $paymentManager = new PaymentManager();
        
        // Validate payment method
        if (!in_array($data['paymentMethod'], ['stripe', 'paypal', 'upi', 'phonepe'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid payment method']);
            exit;
        }
        
        // Process payment
        $paymentData = $paymentManager->initiatePayment(
            $bookingId,
            'excursion',
            $data['totalPrice'],
            $data['paymentMethod'],
            array_merge($data['paymentDetails'] ?? [], [
                'userId' => $user['id'],
                'email' => $user['email'],
                'name' => $user['name']
            ])
        );
        
        // Update booking with payment information
        $serviceManager->updateBookingPaymentStatus($bookingId, 'excursion', [
            'payment_method' => $data['paymentMethod'],
            'payment_status' => $paymentData['status'],
            'transaction_id' => $paymentData['transactionId'] ?? null
        ]);
    }
    
    // Prepare response data
    $responseData = [
        'success' => true,
        'bookingId' => $bookingId,
        'status' => 'created',
        'payment' => $paymentData
    ];
    
    // Add payment redirect URL if available
    if ($paymentData && isset($paymentData['redirectUrl'])) {
        $responseData['redirectUrl'] = $paymentData['redirectUrl'];
    }
    
    // Return response
    echo json_encode($responseData);
    
} catch (ValidationException $e) {
    http_response_code(400);
    echo json_encode([
        'error' => 'Validation failed',
        'message' => $e->getMessage()
    ]);
} catch (PaymentException $e) {
    http_response_code(402);
    echo json_encode([
        'error' => 'Payment failed',
        'message' => $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Booking failed',
        'message' => $e->getMessage()
    ]);
}
