<?php
require_once __DIR__ . '/../includes/services/ServiceManager.php';
require_once __DIR__ . '/../includes/auth/AuthManager.php';

header('Content-Type: application/json');

try {
    // Verify user is logged in
    $auth = new AuthManager();
    $user = $auth->getCurrentUser();
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'User must be logged in to book a pass']);
        exit;
    }
    
    // Validate request
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        exit;
    }
    
    // Get booking data
    $bookingData = [
        'passType' => $_POST['passType'] ?? '',
        'duration' => intval($_POST['duration'] ?? 0),
        'startDate' => $_POST['startDate'] ?? '',
        'passengers' => intval($_POST['passengers'] ?? 0),
        'countries' => $_POST['countries'] ?? [],
        'totalPrice' => floatval($_POST['totalPrice'] ?? 0)
    ];
    
    // Validate booking data
    if (!$bookingData['passType'] || !$bookingData['duration'] || !$bookingData['startDate'] || 
        !$bookingData['passengers'] || empty($bookingData['countries'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing required booking information']);
        exit;
    }
    
    // Submit booking
    $serviceManager = new ServiceManager();
    $bookingId = $serviceManager->bookEurailPass($user['id'], $bookingData);
    
    // Send confirmation email
    $emailManager = new EmailManager();
    $emailManager->sendEurailBookingConfirmation($user['email'], $bookingId, $bookingData);
    
    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Eurail pass booking submitted successfully',
        'bookingId' => $bookingId
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'An error occurred while processing your booking',
        'message' => $e->getMessage()
    ]);
}
