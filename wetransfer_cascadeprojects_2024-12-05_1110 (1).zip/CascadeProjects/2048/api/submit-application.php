<?php
require_once __DIR__ . '/../includes/applications/ApplicationManager.php';
require_once __DIR__ . '/../includes/auth/AuthManager.php';

header('Content-Type: application/json');

try {
    // Verify user is logged in
    $auth = new AuthManager();
    $user = $auth->getCurrentUser();
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'User must be logged in to submit application']);
        exit;
    }
    
    // Validate request
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        exit;
    }
    
    // Get application data
    $serviceType = $_POST['serviceType'] ?? '';
    $applicationData = $_POST;
    unset($applicationData['serviceType']); // Remove service type from application data
    
    // Handle file uploads
    $documents = [];
    foreach ($_FILES as $key => $file) {
        if ($file['error'] === UPLOAD_ERR_OK) {
            $documents[$key] = $file;
        }
    }
    
    // Validate service type
    $validServiceTypes = ['property_listing', 'car_rental', 'travel_insurance', 'homestay'];
    if (!in_array($serviceType, $validServiceTypes)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid service type']);
        exit;
    }
    
    // Submit application
    $applicationManager = new ApplicationManager();
    $applicationId = $applicationManager->submitApplication(
        $user['id'],
        $serviceType,
        $applicationData,
        $documents
    );
    
    // Send confirmation email
    $emailManager = new EmailManager();
    $emailManager->sendApplicationConfirmation($user['email'], $applicationId, $serviceType);
    
    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Application submitted successfully',
        'applicationId' => $applicationId
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'An error occurred while processing your application',
        'message' => $e->getMessage()
    ]);
}
