<?php
require_once __DIR__ . '/../../../includes/payments/PaymentFactory.php';
require_once __DIR__ . '/../../../includes/utils/Logger.php';

$logger = new Logger(PAYMENT_LOG_FILE, PAYMENT_LOG_ENABLED);
$logger->debug('PhonePe callback received');
$logger->debug('Request Headers: ' . json_encode(getallheaders()));

try {
    // Validate request method
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        $logger->error('Invalid request method: ' . $_SERVER['REQUEST_METHOD']);
        http_response_code(405);
        exit('Method Not Allowed');
    }
    $logger->debug('Request method validated: POST');

    // Validate IP address
    $clientIP = $_SERVER['REMOTE_ADDR'];
    $logger->debug("Client IP: {$clientIP}");
    if (!in_array($clientIP, PAYMENT_IP_WHITELIST)) {
        $logger->error("Unauthorized IP address: {$clientIP}");
        http_response_code(403);
        exit('Unauthorized IP');
    }
    $logger->debug('IP address validated successfully');

    // Verify content type
    $contentType = $_SERVER['CONTENT_TYPE'] ?? 'not set';
    $logger->debug("Content-Type: {$contentType}");
    if (!isset($_SERVER['CONTENT_TYPE']) || strpos($_SERVER['CONTENT_TYPE'], 'application/json') === false) {
        $logger->error('Invalid content type: ' . $contentType);
        http_response_code(400);
        exit('Invalid Content Type');
    }
    $logger->debug('Content type validated successfully');

    // Read and validate payload
    $payload = file_get_contents('php://input');
    $logger->debug('Received payload: ' . $payload);
    if (empty($payload)) {
        $logger->error('Empty payload received');
        http_response_code(400);
        exit('Empty payload');
    }

    $headers = getallheaders();
    $signature = $headers['X-VERIFY'] ?? '';
    $logger->debug("PhonePe signature: {$signature}");
    
    if (empty($signature)) {
        $logger->error('Missing PhonePe signature');
        http_response_code(400);
        exit('Missing signature');
    }

    $logger->debug('Verifying signature...');
    if (!verifySignature($payload, $signature)) {
        $logger->error('Invalid PhonePe signature. Payload: ' . substr($payload, 0, 100) . '...');
        http_response_code(400);
        exit('Invalid signature');
    }
    $logger->debug('Signature verified successfully');

    // Parse and process callback data
    $data = json_decode($payload, true);
    $logger->debug('Parsed callback data: ' . json_encode($data));

    if (json_last_error() !== JSON_ERROR_NONE) {
        $logger->error('Invalid JSON payload: ' . json_last_error_msg());
        http_response_code(400);
        exit('Invalid JSON');
    }

    // Validate required fields
    $requiredFields = ['merchantTransactionId', 'transactionId', 'amount', 'code'];
    foreach ($requiredFields as $field) {
        if (!isset($data[$field])) {
            $logger->error("Missing required field: {$field}");
            http_response_code(400);
            exit("Missing {$field}");
        }
    }
    
    // Extract and validate transaction details
    $merchantTransactionId = $data['merchantTransactionId'];
    $transactionId = $data['transactionId'];
    $amount = $data['amount'] / 100;
    $status = $data['code'];

    $logger->info("Processing PhonePe callback - MerchantTxnID: {$merchantTransactionId}, Status: {$status}, Amount: {$amount}");

    // Process the payment callback
    $logger->debug('Processing payment callback...');
    $paymentManager = new PaymentManager();
    $callbackData = [
        'transactionId' => $transactionId,
        'merchantTransactionId' => $merchantTransactionId,
        'amount' => $amount,
        'status' => $status
    ];
    $result = $paymentManager->handlePaymentCallback('phonepe', $callbackData);
    $logger->debug('Callback processing result: ' . json_encode($result));

    // Send response
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'message' => 'Callback processed successfully',
        'data' => $result
    ]);
    $logger->debug('Callback response sent successfully');

} catch (Exception $e) {
    $logger->error('Callback processing failed: ' . $e->getMessage());
    $logger->debug('Error trace: ' . $e->getTraceAsString());
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Internal server error',
        'message' => $e->getMessage()
    ]);
}

function verifySignature($payload, $signature) {
    $logger = new Logger(PAYMENT_LOG_FILE, PAYMENT_LOG_ENABLED);
    $logger->debug('Verifying PhonePe signature');
    
    try {
        // Get the salt key and index
        $saltKey = PHONEPE_SALT_KEY;
        $saltIndex = PHONEPE_SALT_INDEX;
        
        // Create verification string
        $verificationString = $payload . '/pg/v1/status/notify' . $saltKey;
        $logger->debug('Verification string created (first 50 chars): ' . substr($verificationString, 0, 50) . '...');
        
        // Calculate expected signature
        $expectedSignature = hash('sha256', $verificationString);
        $logger->debug("Expected signature: {$expectedSignature}");
        $logger->debug("Received signature: {$signature}");
        
        // Compare signatures
        $isValid = hash_equals($expectedSignature, $signature);
        $logger->debug($isValid ? 'Signature verification successful' : 'Signature verification failed');
        
        return $isValid;
    } catch (Exception $e) {
        $logger->error('Signature verification failed: ' . $e->getMessage());
        $logger->debug('Error trace: ' . $e->getTraceAsString());
        return false;
    }
}
