<?php
require_once __DIR__ . '/../../includes/services/PaymentManager.php';
require_once __DIR__ . '/../../includes/auth/AuthManager.php';

header('Content-Type: application/json');

try {
    // Verify user is logged in
    $auth = new AuthManager();
    $user = $auth->getCurrentUser();
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'Authentication required']);
        exit;
    }
    
    // Get request parameters
    $bookingId = $_GET['bookingId'] ?? null;
    $bookingType = $_GET['bookingType'] ?? null;
    
    if (!$bookingId || !$bookingType) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing booking ID or type']);
        exit;
    }
    
    // Verify booking belongs to user
    $serviceManager = new ServiceManager();
    $booking = $serviceManager->getBooking($bookingId, $bookingType);
    
    if (!$booking || $booking['user_id'] !== $user['id']) {
        http_response_code(403);
        echo json_encode(['error' => 'Unauthorized access to booking']);
        exit;
    }
    
    // Get payment status
    $paymentManager = new PaymentManager();
    $paymentStatus = $paymentManager->getPaymentStatus($bookingId, $bookingType);
    
    // Prepare response
    $response = [
        'success' => true,
        'bookingId' => $bookingId,
        'bookingType' => $bookingType,
        'bookingStatus' => $booking['status'],
        'payment' => [
            'status' => $paymentStatus['status'] ?? 'pending',
            'method' => $paymentStatus['payment_method'] ?? null,
            'amount' => $booking['total_price'],
            'transactionId' => $paymentStatus['transaction_id'] ?? null,
            'lastUpdated' => $paymentStatus['updated_at'] ?? null
        ]
    ];
    
    // Add payment method specific details if available
    if ($paymentStatus && isset($paymentStatus['response_data'])) {
        $responseData = json_decode($paymentStatus['response_data'], true);
        if ($responseData) {
            $response['payment']['details'] = $responseData;
        }
    }
    
    echo json_encode($response);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Failed to retrieve payment status',
        'message' => $e->getMessage()
    ]);
}
