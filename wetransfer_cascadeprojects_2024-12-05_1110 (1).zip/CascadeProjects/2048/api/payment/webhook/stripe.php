<?php
require_once __DIR__ . '/../../../includes/payments/PaymentFactory.php';
require_once __DIR__ . '/../../../includes/utils/Logger.php';

$logger = new Logger(PAYMENT_LOG_FILE, PAYMENT_LOG_ENABLED);

try {
    // Get payload and signature
    $payload = @file_get_contents('php://input');
    $sigHeader = $_SERVER['HTTP_STRIPE_SIGNATURE'];
    
    // Verify webhook signature
    $event = \Stripe\Webhook::constructEvent(
        $payload, $sigHeader, STRIPE_WEBHOOK_SECRET
    );
    
    // Handle the event
    switch ($event->type) {
        case 'payment_intent.succeeded':
            $paymentIntent = $event->data->object;
            handleSuccessfulPayment($paymentIntent);
            break;
            
        case 'payment_intent.payment_failed':
            $paymentIntent = $event->data->object;
            handleFailedPayment($paymentIntent);
            break;
            
        case 'charge.refunded':
            $charge = $event->data->object;
            handleRefund($charge);
            break;
            
        default:
            $logger->info('Received unhandled Stripe webhook event: ' . $event->type);
    }
    
    http_response_code(200);
    
} catch(\UnexpectedValueException $e) {
    $logger->error('Invalid payload: ' . $e->getMessage());
    http_response_code(400);
    exit();
} catch(\Stripe\Exception\SignatureVerificationException $e) {
    $logger->error('Invalid signature: ' . $e->getMessage());
    http_response_code(400);
    exit();
} catch (Exception $e) {
    $logger->error('Stripe webhook error: ' . $e->getMessage());
    http_response_code(500);
    exit();
}

function handleSuccessfulPayment($paymentIntent) {
    global $logger;
    
    try {
        $bookingId = $paymentIntent->metadata->booking_id;
        $bookingType = $paymentIntent->metadata->booking_type;
        
        // Update booking status
        $serviceManager = new ServiceManager();
        $serviceManager->updateBookingStatus($bookingId, $bookingType, 'confirmed');
        
        // Send confirmation email
        $emailManager = new EmailManager();
        if ($bookingType === 'eurail') {
            $emailManager->sendEurailBookingConfirmation($paymentIntent->customer_email, $bookingId);
        } else {
            $emailManager->sendExcursionBookingConfirmation($paymentIntent->customer_email, $bookingId);
        }
        
        $logger->info("Payment successful for {$bookingType} booking {$bookingId}");
        
    } catch (Exception $e) {
        $logger->error("Error processing successful payment: " . $e->getMessage());
        throw $e;
    }
}

function handleFailedPayment($paymentIntent) {
    global $logger;
    
    try {
        $bookingId = $paymentIntent->metadata->booking_id;
        $bookingType = $paymentIntent->metadata->booking_type;
        
        // Update booking status
        $serviceManager = new ServiceManager();
        $serviceManager->updateBookingStatus($bookingId, $bookingType, 'payment_failed');
        
        // Send failure notification
        $emailManager = new EmailManager();
        $emailManager->sendPaymentFailureNotification(
            $paymentIntent->customer_email,
            $bookingId,
            $bookingType,
            $paymentIntent->last_payment_error->message ?? 'Payment failed'
        );
        
        $logger->info("Payment failed for {$bookingType} booking {$bookingId}");
        
    } catch (Exception $e) {
        $logger->error("Error processing failed payment: " . $e->getMessage());
        throw $e;
    }
}

function handleRefund($charge) {
    global $logger;
    
    try {
        $bookingId = $charge->metadata->booking_id;
        $bookingType = $charge->metadata->booking_type;
        
        // Update booking status
        $serviceManager = new ServiceManager();
        $serviceManager->updateBookingStatus($bookingId, $bookingType, 'refunded');
        
        // Send refund confirmation
        $emailManager = new EmailManager();
        $emailManager->sendRefundConfirmation(
            $charge->customer_email,
            $bookingId,
            $bookingType,
            $charge->amount_refunded / 100
        );
        
        $logger->info("Refund processed for {$bookingType} booking {$bookingId}");
        
    } catch (Exception $e) {
        $logger->error("Error processing refund: " . $e->getMessage());
        throw $e;
    }
}
