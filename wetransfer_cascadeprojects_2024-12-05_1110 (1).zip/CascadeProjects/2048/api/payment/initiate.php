<?php
require_once __DIR__ . '/../../includes/services/PaymentManager.php';
require_once __DIR__ . '/../../includes/auth/AuthManager.php';

header('Content-Type: application/json');

try {
    // Verify user is logged in
    $auth = new AuthManager();
    $user = $auth->getCurrentUser();

    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'Authentication required']);
        exit;
    }
    
    // Validate request
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        exit;
    }
    
    // Get request data
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['bookingId'], $data['bookingType'], $data['paymentMethod'], $data['amount'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing required payment information']);
        exit;
    }
    
    // Initialize payment
    $paymentManager = new PaymentManager();
    $result = $paymentManager->initiatePayment(
        $data['bookingId'],
        $data['bookingType'],
        $data['amount'],
        $data['paymentMethod'],
        $data['paymentDetails'] ?? []
    );
    
    echo json_encode([
        'success' => true,
        'data' => $result
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Payment initiation failed',
        'message' => $e->getMessage()
    ]);
}
