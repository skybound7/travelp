<?php
require_once __DIR__ . '/../../includes/services/ReviewManager.php';
require_once __DIR__ . '/../../includes/auth/AuthManager.php';

header('Content-Type: application/json');

try {
    $auth = new AuthManager();
    $reviewManager = new ReviewManager();
    
    switch ($_SERVER['REQUEST_METHOD']) {
        case 'GET':
            // Get reviews for a train
            $trainId = $_GET['trainId'] ?? null;
            if (!$trainId) {
                http_response_code(400);
                echo json_encode(['error' => 'Train ID is required']);
                exit;
            }
            
            $page = intval($_GET['page'] ?? 1);
            $limit = intval($_GET['limit'] ?? 10);
            
            $reviews = $reviewManager->getTrainReviews($trainId, $page, $limit);
            echo json_encode([
                'success' => true,
                'data' => $reviews
            ]);
            break;
            
        case 'POST':
            // Add a new review
            $user = $auth->getCurrentUser();
            if (!$user) {
                http_response_code(401);
                echo json_encode(['error' => 'Authentication required']);
                exit;
            }
            
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Validate required fields
            $requiredFields = ['trainId', 'rating', 'review'];
            foreach ($requiredFields as $field) {
                if (!isset($data[$field]) || empty($data[$field])) {
                    http_response_code(400);
                    echo json_encode(['error' => "Missing required field: {$field}"]);
                    exit;
                }
            }
            
            // Validate rating
            if ($data['rating'] < 1 || $data['rating'] > 5) {
                http_response_code(400);
                echo json_encode(['error' => 'Rating must be between 1 and 5']);
                exit;
            }
            
            $reviewId = $reviewManager->addReview($user['id'], [
                'train_id' => $data['trainId'],
                'rating' => $data['rating'],
                'review' => $data['review'],
                'journey_date' => $data['journeyDate'] ?? null,
                'photos' => $data['photos'] ?? []
            ]);
            
            echo json_encode([
                'success' => true,
                'reviewId' => $reviewId
            ]);
            break;
            
        case 'DELETE':
            // Delete a review
            $user = $auth->getCurrentUser();
            if (!$user) {
                http_response_code(401);
                echo json_encode(['error' => 'Authentication required']);
                exit;
            }
            
            $reviewId = $_GET['reviewId'] ?? null;
            if (!$reviewId) {
                http_response_code(400);
                echo json_encode(['error' => 'Review ID is required']);
                exit;
            }
            
            // Verify review belongs to user
            if (!$reviewManager->verifyReviewOwnership($user['id'], $reviewId)) {
                http_response_code(403);
                echo json_encode(['error' => 'Unauthorized access to review']);
                exit;
            }
            
            $reviewManager->deleteReview($reviewId);
            echo json_encode(['success' => true]);
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Operation failed',
        'message' => $e->getMessage()
    ]);
}
