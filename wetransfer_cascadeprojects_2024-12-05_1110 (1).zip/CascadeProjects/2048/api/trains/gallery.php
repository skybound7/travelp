<?php
require_once __DIR__ . '/../../includes/services/GalleryManager.php';
require_once __DIR__ . '/../../includes/auth/AuthManager.php';
require_once __DIR__ . '/../../includes/utils/ImageProcessor.php';

header('Content-Type: application/json');

try {
    $auth = new AuthManager();
    $galleryManager = new GalleryManager();
    
    switch ($_SERVER['REQUEST_METHOD']) {
        case 'GET':
            // Get gallery items
            $page = intval($_GET['page'] ?? 1);
            $limit = intval($_GET['limit'] ?? 12);
            $train = $_GET['train'] ?? '';
            $category = $_GET['category'] ?? '';
            
            $items = $galleryManager->getGalleryItems([
                'page' => $page,
                'limit' => $limit,
                'train' => $train,
                'category' => $category
            ]);
            
            echo json_encode([
                'success' => true,
                'data' => $items
            ]);
            break;
            
        case 'POST':
            // Upload new photos (admin only)
            $user = $auth->getCurrentUser();
            if (!$user || !$auth->isAdmin($user['id'])) {
                http_response_code(403);
                echo json_encode(['error' => 'Unauthorized access']);
                exit;
            }
            
            // Validate request
            if (!isset($_FILES['photos'])) {
                http_response_code(400);
                echo json_encode(['error' => 'No photos uploaded']);
                exit;
            }
            
            $trainId = $_POST['trainId'] ?? '';
            $category = $_POST['category'] ?? '';
            $description = $_POST['description'] ?? '';
            
            if (!$trainId || !$category) {
                http_response_code(400);
                echo json_encode(['error' => 'Missing required fields']);
                exit;
            }
            
            // Process and save photos
            $imageProcessor = new ImageProcessor();
            $uploadedPhotos = [];
            
            foreach ($_FILES['photos']['tmp_name'] as $index => $tmpName) {
                $fileName = $_FILES['photos']['name'][$index];
                $fileType = $_FILES['photos']['type'][$index];
                
                // Validate file type
                if (!in_array($fileType, ['image/jpeg', 'image/png', 'image/webp'])) {
                    continue;
                }
                
                // Generate unique filename
                $uniqueName = uniqid() . '_' . $fileName;
                
                // Process images
                $fullImage = $imageProcessor->processImage($tmpName, [
                    'maxWidth' => 1920,
                    'maxHeight' => 1080,
                    'quality' => 85
                ]);
                
                $thumbnail = $imageProcessor->processImage($tmpName, [
                    'maxWidth' => 400,
                    'maxHeight' => 300,
                    'quality' => 75
                ]);
                
                // Save images
                $fullImagePath = "/uploads/gallery/full/{$uniqueName}";
                $thumbnailPath = "/uploads/gallery/thumbnails/{$uniqueName}";
                
                move_uploaded_file($fullImage, $_SERVER['DOCUMENT_ROOT'] . $fullImagePath);
                move_uploaded_file($thumbnail, $_SERVER['DOCUMENT_ROOT'] . $thumbnailPath);
                
                // Save to database
                $photoId = $galleryManager->addPhoto([
                    'train_id' => $trainId,
                    'category' => $category,
                    'description' => $description,
                    'full_image' => $fullImagePath,
                    'thumbnail' => $thumbnailPath,
                    'uploaded_by' => $user['id']
                ]);
                
                $uploadedPhotos[] = $photoId;
            }
            
            if (empty($uploadedPhotos)) {
                http_response_code(400);
                echo json_encode(['error' => 'No valid photos were uploaded']);
                exit;
            }
            
            echo json_encode([
                'success' => true,
                'message' => count($uploadedPhotos) . ' photos uploaded successfully',
                'photoIds' => $uploadedPhotos
            ]);
            break;
            
        case 'DELETE':
            // Delete photo (admin only)
            $user = $auth->getCurrentUser();
            if (!$user || !$auth->isAdmin($user['id'])) {
                http_response_code(403);
                echo json_encode(['error' => 'Unauthorized access']);
                exit;
            }
            
            $photoId = $_GET['photoId'] ?? null;
            if (!$photoId) {
                http_response_code(400);
                echo json_encode(['error' => 'Photo ID is required']);
                exit;
            }
            
            $galleryManager->deletePhoto($photoId);
            echo json_encode(['success' => true]);
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Operation failed',
        'message' => $e->getMessage()
    ]);
}
