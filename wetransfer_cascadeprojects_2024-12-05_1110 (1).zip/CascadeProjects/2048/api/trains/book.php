<?php
require_once __DIR__ . '/../../includes/services/TrainBookingManager.php';
require_once __DIR__ . '/../../includes/auth/AuthManager.php';

header('Content-Type: application/json');

try {
    // Verify user is logged in
    $auth = new AuthManager();
    $user = $auth->getCurrentUser();
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'Authentication required']);
        exit;
    }
    
    // Validate request
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        exit;
    }
    
    // Get booking data
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    $requiredFields = ['trainId', 'journeyDate', 'cabinType', 'passengers', 'totalPrice'];
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || empty($data[$field])) {
            http_response_code(400);
            echo json_encode(['error' => "Missing required field: {$field}"]);
            exit;
        }
    }
    
    // Create booking
    $bookingManager = new TrainBookingManager();
    $bookingId = $bookingManager->createBooking($user['id'], [
        'train_id' => $data['trainId'],
        'journey_date' => $data['journeyDate'],
        'cabin_type' => $data['cabinType'],
        'passengers' => $data['passengers'],
        'special_requests' => $data['specialRequests'] ?? '',
        'total_price' => $data['totalPrice']
    ]);
    
    // Initialize payment if payment method is provided
    $paymentData = null;
    if (isset($data['paymentMethod'])) {
        $paymentManager = new PaymentManager();
        $paymentData = $paymentManager->initiatePayment(
            $bookingId,
            'train',
            $data['totalPrice'],
            $data['paymentMethod'],
            array_merge($data['paymentDetails'] ?? [], [
                'userId' => $user['id'],
                'email' => $user['email'],
                'name' => $user['name']
            ])
        );
    }
    
    // Send confirmation email
    $emailManager = new EmailManager();
    $emailManager->sendTrainBookingConfirmation($user['email'], $bookingId);
    
    echo json_encode([
        'success' => true,
        'bookingId' => $bookingId,
        'payment' => $paymentData
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Booking failed',
        'message' => $e->getMessage()
    ]);
}
