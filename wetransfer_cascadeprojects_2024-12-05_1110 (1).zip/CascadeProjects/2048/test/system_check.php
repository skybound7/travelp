<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/booking/ComboItinerary.php';

class SystemCheck {
    private $conn;
    private $errors = [];
    private $warnings = [];
    
    public function __construct() {
        try {
            $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASS);
            $this->log("Database connection successful");
        } catch (Exception $e) {
            $this->error("Database connection failed: " . $e->getMessage());
        }
    }
    
    public function runAllChecks() {
        $this->checkDatabaseExists();
        $this->checkTables();
        $this->checkRequiredFiles();
        $this->validateSampleItinerary();
        $this->checkPermissions();
        $this->displayResults();
    }
    
    private function checkDatabaseExists() {
        $result = $this->conn->query("SHOW DATABASES LIKE '" . DB_NAME . "'");
        if ($result->num_rows === 0) {
            $this->error("Database '" . DB_NAME . "' does not exist");
            // Create database
            $this->conn->query("CREATE DATABASE IF NOT EXISTS " . DB_NAME);
            $this->log("Created database " . DB_NAME);
        }
        
        $this->conn->select_db(DB_NAME);
    }
    
    private function checkTables() {
        $requiredTables = [
            'combo_itineraries',
            'itinerary_components',
            'available_activities',
            'available_transport',
            'payments',
            'payment_refunds',
            'blocked_ips',
            'login_attempts'
        ];
        
        foreach ($requiredTables as $table) {
            $result = $this->conn->query("SHOW TABLES LIKE '$table'");
            if ($result->num_rows === 0) {
                $this->error("Table '$table' does not exist");
                // Import schema
                $this->importSchema();
                break;
            }
        }
    }
    
    private function importSchema() {
        $schemaFile = __DIR__ . '/../sql/combo_itinerary.sql';
        $sampleDataFile = __DIR__ . '/../sql/sample_data.sql';
        
        if (file_exists($schemaFile)) {
            $sql = file_get_contents($schemaFile);
            if ($this->conn->multi_query($sql)) {
                do {
                    // Process each result set
                    if ($result = $this->conn->store_result()) {
                        $result->free();
                    }
                } while ($this->conn->next_result());
                $this->log("Schema imported successfully");
            } else {
                $this->error("Schema import failed: " . $this->conn->error);
            }
        }
        
        if (file_exists($sampleDataFile)) {
            $sql = file_get_contents($sampleDataFile);
            if ($this->conn->multi_query($sql)) {
                do {
                    if ($result = $this->conn->store_result()) {
                        $result->free();
                    }
                } while ($this->conn->next_result());
                $this->log("Sample data imported successfully");
            } else {
                $this->error("Sample data import failed: " . $this->conn->error);
            }
        }
    }
    
    private function checkRequiredFiles() {
        $requiredFiles = [
            '../includes/config.php',
            '../includes/booking/ComboItinerary.php',
            '../deploy/monitor_logs.sh',
            '../deploy/error_resolver.php',
            '../sql/combo_itinerary.sql',
            '../sql/sample_data.sql'
        ];
        
        foreach ($requiredFiles as $file) {
            if (!file_exists(__DIR__ . '/' . $file)) {
                $this->error("Required file missing: $file");
            }
        }
    }
    
    private function validateSampleItinerary() {
        try {
            // Create test itinerary
            $query = "INSERT INTO combo_itineraries (user_id, start_date, end_date, status) 
                     VALUES (1, NOW(), DATE_ADD(NOW(), INTERVAL 7 DAY), 'draft')";
            $this->conn->query($query);
            $itineraryId = $this->conn->insert_id;
            
            $itinerary = new ComboItinerary($itineraryId);
            
            // Add test components
            $query = "INSERT INTO itinerary_components (itinerary_id, type, start_datetime, end_datetime, location_from, location_to) 
                     VALUES (?, 'flight', NOW(), DATE_ADD(NOW(), INTERVAL 2 HOUR), 'NYC', 'LAX')";
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('i', $itineraryId);
            $stmt->execute();
            
            // Test validation
            $mismatches = $itinerary->validateDateTimeConsistency();
            if (!empty($mismatches)) {
                $this->warning("Found " . count($mismatches) . " time mismatches in test itinerary");
                
                // Test fixing
                $results = $itinerary->fixDateTimeMismatches($mismatches);
                foreach ($results as $result) {
                    $this->log("Fix attempt: " . $result['message']);
                }
            }
            
            // Cleanup
            $this->conn->query("DELETE FROM itinerary_components WHERE itinerary_id = $itineraryId");
            $this->conn->query("DELETE FROM combo_itineraries WHERE id = $itineraryId");
            
        } catch (Exception $e) {
            $this->error("Itinerary validation failed: " . $e->getMessage());
        }
    }
    
    private function checkPermissions() {
        $directories = [
            '../logs',
            '../uploads',
            '../cache',
            '../backups'
        ];
        
        foreach ($directories as $dir) {
            $fullPath = __DIR__ . '/' . $dir;
            if (!file_exists($fullPath)) {
                mkdir($fullPath, 0775, true);
                $this->log("Created directory: $dir");
            }
            
            if (!is_writable($fullPath)) {
                $this->error("Directory not writable: $dir");
                chmod($fullPath, 0775);
                $this->log("Fixed permissions for: $dir");
            }
        }
    }
    
    private function log($message) {
        echo "[INFO] $message\n";
    }
    
    private function error($message) {
        $this->errors[] = $message;
        echo "[ERROR] $message\n";
    }
    
    private function warning($message) {
        $this->warnings[] = $message;
        echo "[WARNING] $message\n";
    }
    
    private function displayResults() {
        echo "\n=== System Check Results ===\n";
        echo "Errors: " . count($this->errors) . "\n";
        echo "Warnings: " . count($this->warnings) . "\n";
        
        if (empty($this->errors) && empty($this->warnings)) {
            echo "\nSystem check completed successfully! The project is ready to run.\n";
        } else {
            if (!empty($this->errors)) {
                echo "\nErrors found:\n";
                foreach ($this->errors as $error) {
                    echo "- $error\n";
                }
            }
            if (!empty($this->warnings)) {
                echo "\nWarnings found:\n";
                foreach ($this->warnings as $warning) {
                    echo "- $warning\n";
                }
            }
        }
    }
}

// Run the system check
$checker = new SystemCheck();
$checker->runAllChecks();
