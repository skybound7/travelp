<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/booking/ComboItinerary.php';

class ValidationSuite {
    private $conn;
    private $results = [];
    
    public function __construct() {
        $this->conn = getDBConnection();
    }
    
    public function runAllTests() {
        $this->validateDatabaseStructure();
        $this->validateItineraryComponents();
        $this->validateTimeConsistency();
        $this->validatePayments();
        $this->displayResults();
    }
    
    private function validateDatabaseStructure() {
        $this->startTest('Database Structure');
        
        // Check required tables
        $requiredTables = [
            'combo_itineraries' => [
                'id', 'user_id', 'title', 'start_date', 'end_date', 
                'status', 'total_price', 'created_at', 'updated_at'
            ],
            'itinerary_components' => [
                'id', 'itinerary_id', 'component_type', 'start_datetime',
                'end_datetime', 'location_from', 'location_to', 'price'
            ],
            'itinerary_schedule' => [
                'id', 'itinerary_id', 'day_number', 'time_slot',
                'activity_type', 'description', 'location', 'duration'
            ],
            'payments' => [
                'id', 'itinerary_id', 'amount', 'payment_method',
                'transaction_id', 'status', 'created_at'
            ]
        ];
        
        foreach ($requiredTables as $table => $columns) {
            $result = $this->conn->query("SHOW TABLES LIKE '$table'");
            if ($result->num_rows === 0) {
                $this->addError("Missing table: $table");
                continue;
            }
            
            $result = $this->conn->query("SHOW COLUMNS FROM $table");
            $existingColumns = [];
            while ($row = $result->fetch_assoc()) {
                $existingColumns[] = $row['Field'];
            }
            
            foreach ($columns as $column) {
                if (!in_array($column, $existingColumns)) {
                    $this->addError("Missing column $column in table $table");
                }
            }
        }
    }
    
    private function validateItineraryComponents() {
        $this->startTest('Itinerary Components');
        
        // Check component relationships
        $query = "
            SELECT ic.id, ic.itinerary_id, ci.id as parent_id
            FROM itinerary_components ic
            LEFT JOIN combo_itineraries ci ON ic.itinerary_id = ci.id
            WHERE ci.id IS NULL
        ";
        
        $result = $this->conn->query($query);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $this->addError("Orphaned component {$row['id']} references non-existent itinerary {$row['itinerary_id']}");
            }
        }
        
        // Check location consistency
        $query = "
            SELECT ic1.id as comp1_id, ic2.id as comp2_id
            FROM itinerary_components ic1
            JOIN itinerary_components ic2 ON ic1.itinerary_id = ic2.itinerary_id
            WHERE ic1.end_datetime = ic2.start_datetime
            AND ic1.location_to != ic2.location_from
        ";
        
        $result = $this->conn->query($query);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $this->addWarning("Location mismatch between components {$row['comp1_id']} and {$row['comp2_id']}");
            }
        }
    }
    
    private function validateTimeConsistency() {
        $this->startTest('Time Consistency');
        
        // Check for overlapping components
        $query = "
            SELECT ic1.id as comp1_id, ic2.id as comp2_id,
                   ic1.start_datetime as start1, ic1.end_datetime as end1,
                   ic2.start_datetime as start2, ic2.end_datetime as end2
            FROM itinerary_components ic1
            JOIN itinerary_components ic2 ON ic1.itinerary_id = ic2.itinerary_id
            WHERE ic1.id < ic2.id
            AND (
                (ic1.start_datetime BETWEEN ic2.start_datetime AND ic2.end_datetime)
                OR (ic1.end_datetime BETWEEN ic2.start_datetime AND ic2.end_datetime)
            )
        ";
        
        $result = $this->conn->query($query);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $this->addError("Time overlap between components {$row['comp1_id']} and {$row['comp2_id']}");
            }
        }
        
        // Check for components outside itinerary dates
        $query = "
            SELECT ic.id, ci.id as itinerary_id
            FROM itinerary_components ic
            JOIN combo_itineraries ci ON ic.itinerary_id = ci.id
            WHERE ic.start_datetime < ci.start_date
            OR ic.end_datetime > ci.end_date
        ";
        
        $result = $this->conn->query($query);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $this->addError("Component {$row['id']} falls outside itinerary {$row['itinerary_id']} dates");
            }
        }
    }
    
    private function validatePayments() {
        $this->startTest('Payments');
        
        // Check payment totals match itinerary prices
        $query = "
            SELECT ci.id, ci.total_price,
                   COALESCE(SUM(p.amount), 0) as paid_amount
            FROM combo_itineraries ci
            LEFT JOIN payments p ON ci.id = p.itinerary_id
            WHERE p.status = 'completed'
            GROUP BY ci.id
            HAVING ci.total_price != paid_amount
        ";
        
        $result = $this->conn->query($query);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $this->addWarning("Payment mismatch for itinerary {$row['id']}: Expected {$row['total_price']}, Got {$row['paid_amount']}");
            }
        }
        
        // Check for duplicate payments
        $query = "
            SELECT itinerary_id, transaction_id, COUNT(*) as count
            FROM payments
            WHERE transaction_id IS NOT NULL
            GROUP BY itinerary_id, transaction_id
            HAVING count > 1
        ";
        
        $result = $this->conn->query($query);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $this->addError("Duplicate payment found for itinerary {$row['itinerary_id']}: Transaction {$row['transaction_id']}");
            }
        }
    }
    
    private function startTest($name) {
        $this->currentTest = $name;
        $this->results[$name] = [
            'errors' => [],
            'warnings' => []
        ];
    }
    
    private function addError($message) {
        $this->results[$this->currentTest]['errors'][] = $message;
    }
    
    private function addWarning($message) {
        $this->results[$this->currentTest]['warnings'][] = $message;
    }
    
    private function displayResults() {
        echo "\n=== Validation Results ===\n\n";
        
        $totalErrors = 0;
        $totalWarnings = 0;
        
        foreach ($this->results as $test => $result) {
            $errors = count($result['errors']);
            $warnings = count($result['warnings']);
            $totalErrors += $errors;
            $totalWarnings += $warnings;
            
            echo "Test: $test\n";
            echo "- Errors: $errors\n";
            echo "- Warnings: $warnings\n";
            
            if ($errors > 0) {
                echo "\nErrors:\n";
                foreach ($result['errors'] as $error) {
                    echo "- $error\n";
                }
            }
            
            if ($warnings > 0) {
                echo "\nWarnings:\n";
                foreach ($result['warnings'] as $warning) {
                    echo "- $warning\n";
                }
            }
            
            echo "\n";
        }
        
        echo "=== Summary ===\n";
        echo "Total Errors: $totalErrors\n";
        echo "Total Warnings: $totalWarnings\n";
        
        if ($totalErrors === 0 && $totalWarnings === 0) {
            echo "\nAll validation tests passed successfully!\n";
        }
    }
}

// Run the validation suite
$validator = new ValidationSuite();
$validator->runAllTests();
