Required destination images:

1. maldives.jpg
- High-resolution image of overwater villas in the Maldives
- Minimum resolution: 1920x1080
- Aspect ratio: 16:9
- File size: < 500KB
- Shows luxury overwater villas with clear turquoise water

2. dubai.jpg
- High-resolution image of Dubai skyline or luxury experience
- Minimum resolution: 1920x1080
- Aspect ratio: 16:9
- File size: < 500KB
- Shows iconic Dubai landmarks or luxury activities
