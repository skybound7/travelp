# Image Assets Required

Please add the following high-quality images to this directory:

## Hero Images
- `hero-bg.jpg` (1920x1080px) - Luxury travel scene (e.g., infinity pool overlooking ocean or mountain vista)

## Destination Images
- `maldives.jpg` (800x600px) - Luxury water villa or beach scene
- `dubai.jpg` (800x600px) - Dubai skyline or Burj Khalifa

## Testimonial Profile Pictures
- `testimonial1.jpg` (100x100px) - Professional headshot
- `testimonial2.jpg` (100x100px) - Professional headshot
- `testimonial3.jpg` (100x100px) - Professional headshot

## Service Icons (if not using Font Awesome)
- `flight-icon.svg` (64x64px)
- `hotel-icon.svg` (64x64px)
- `transport-icon.svg` (64x64px)

## Image Guidelines:
1. All images should be high resolution and professionally shot
2. Maintain aspect ratios as specified
3. Optimize images for web (compress without visible quality loss)
4. Use .jpg for photos and .svg for icons
5. Ensure images reflect luxury and premium quality

## Image Sources:
You can obtain high-quality images from:
- Licensed stock photo websites (Shutterstock, Adobe Stock)
- Professional photographers
- Your own high-quality photographs

Note: Ensure you have proper licenses for all images used in production.
