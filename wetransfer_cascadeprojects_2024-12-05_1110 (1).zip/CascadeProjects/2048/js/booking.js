// Booking System JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize date picker
    const dateInputs = document.querySelectorAll('.booking-date');
    dateInputs.forEach(input => {
        flatpickr(input, {
            minDate: "today",
            maxDate: new Date().fp_incr(365),
            dateFormat: "Y-m-d",
            disable: [
                function(date) {
                    return (date.getDay() === 0); // Disable Sundays
                }
            ]
        });
    });

    // Dynamic price calculation
    const calculatePrice = async (serviceId, guests, preferences) => {
        try {
            const response = await fetch('/includes/booking-system/calculate-price.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ serviceId, guests, preferences })
            });
            const data = await response.json();
            return data.price;
        } catch (error) {
            console.error('Error calculating price:', error);
            return null;
        }
    };

    // Handle booking form submission
    const bookingForm = document.getElementById('booking-form');
    if (bookingForm) {
        bookingForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(bookingForm);
            try {
                const response = await fetch('/includes/booking-system/process-booking.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                
                if (result.success) {
                    showNotification('Booking successful!', 'success');
                    // Redirect to booking confirmation page
                    window.location.href = `/booking-confirmation.php?id=${result.bookingId}`;
                } else {
                    showNotification(result.message || 'Booking failed. Please try again.', 'error');
                }
            } catch (error) {
                console.error('Error processing booking:', error);
                showNotification('An error occurred. Please try again.', 'error');
            }
        });
    }

    // Update price when guests or preferences change
    const updatePrice = async () => {
        const serviceId = document.getElementById('service-id').value;
        const guests = document.getElementById('guests').value;
        const preferencesInputs = document.querySelectorAll('input[name="preferences[]"]:checked');
        const preferences = Array.from(preferencesInputs).map(input => ({
            id: input.value,
            price: parseFloat(input.dataset.price)
        }));

        const price = await calculatePrice(serviceId, guests, preferences);
        if (price !== null) {
            document.getElementById('total-price').textContent = `$${price.toFixed(2)}`;
        }
    };

    // Add event listeners for price updates
    document.getElementById('guests')?.addEventListener('change', updatePrice);
    document.querySelectorAll('input[name="preferences[]"]').forEach(input => {
        input.addEventListener('change', updatePrice);
    });

    // Show notification function
    const showNotification = (message, type = 'info') => {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('fade-out');
            setTimeout(() => notification.remove(), 500);
        }, 3000);
    };
});
