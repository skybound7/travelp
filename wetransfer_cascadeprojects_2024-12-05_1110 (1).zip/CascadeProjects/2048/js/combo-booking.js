/**
 * Combo Booking Form Handler
 */

function initializeBookingForm(availableServices) {
    const form = document.getElementById('combo-booking-form');
    const componentsSection = document.getElementById('components-section');
    const scheduleBuilder = document.getElementById('schedule-builder');
    const totalAmount = document.getElementById('total-amount');
    
    let selectedComponents = [];
    let scheduleItems = [];
    
    // Initialize tab switching
    initializeTabs();
    
    // Initialize component selection
    initializeComponentSelection(availableServices);
    
    // Initialize schedule builder
    initializeScheduleBuilder();
    
    // Initialize payment method switching
    initializePaymentMethod();
    
    // Form submission handler
    form.addEventListener('submit', handleFormSubmit);
    
    /**
     * Initialize tab switching functionality
     */
    function initializeTabs() {
        const tabs = componentsSection.querySelectorAll('.tab-button');
        const contents = componentsSection.querySelectorAll('.tab-content');
        
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                // Remove active class from all tabs and contents
                tabs.forEach(t => t.classList.remove('active'));
                contents.forEach(c => c.classList.remove('active'));
                
                // Add active class to clicked tab and corresponding content
                tab.classList.add('active');
                const content = document.getElementById(`${tab.dataset.tab}-tab`);
                content.classList.add('active');
            });
        });
    }
    
    /**
     * Initialize component selection
     */
    function initializeComponentSelection(services) {
        // Populate flights tab
        const flightsTab = document.getElementById('flights-tab');
        populateFlights(services.flights, flightsTab);
        
        // Populate hotels tab
        const hotelsTab = document.getElementById('hotels-tab');
        populateHotels(services.hotels, hotelsTab);
        
        // Populate activities tab
        const activitiesTab = document.getElementById('activities-tab');
        populateActivities(services.activities, activitiesTab);
    }
    
    /**
     * Populate flights selection
     */
    function populateFlights(flights, container) {
        flights.forEach(flight => {
            const flightCard = createServiceCard('flight', flight);
            container.appendChild(flightCard);
        });
    }
    
    /**
     * Populate hotels selection
     */
    function populateHotels(hotels, container) {
        hotels.forEach(hotel => {
            const hotelCard = createServiceCard('hotel', hotel);
            container.appendChild(hotelCard);
        });
    }
    
    /**
     * Populate activities selection
     */
    function populateActivities(activities, container) {
        activities.forEach(activity => {
            const activityCard = createServiceCard('activity', activity);
            container.appendChild(activityCard);
        });
    }
    
    /**
     * Create service selection card
     */
    function createServiceCard(type, service) {
        const card = document.createElement('div');
        card.className = 'service-card';
        card.dataset.id = service.id;
        card.dataset.type = type;
        
        card.innerHTML = `
            <div class="service-header">
                <h3>${service.name}</h3>
                <span class="price">$${service.price.toFixed(2)}</span>
            </div>
            <div class="service-details">
                ${getServiceDetails(type, service)}
            </div>
            <button type="button" class="btn-secondary add-service">Add to Itinerary</button>
        `;
        
        card.querySelector('.add-service').addEventListener('click', () => {
            addComponentToItinerary(type, service);
        });
        
        return card;
    }
    
    /**
     * Get service-specific details HTML
     */
    function getServiceDetails(type, service) {
        switch (type) {
            case 'flight':
                return `
                    <p><strong>From:</strong> ${service.origin}</p>
                    <p><strong>To:</strong> ${service.destination}</p>
                    <p><strong>Date:</strong> ${service.date}</p>
                    <p><strong>Time:</strong> ${service.time}</p>
                `;
            case 'hotel':
                return `
                    <p><strong>Location:</strong> ${service.location}</p>
                    <p><strong>Room Type:</strong> ${service.roomType}</p>
                    <p><strong>Check-in:</strong> ${service.checkIn}</p>
                    <p><strong>Check-out:</strong> ${service.checkOut}</p>
                `;
            case 'activity':
                return `
                    <p><strong>Location:</strong> ${service.location}</p>
                    <p><strong>Duration:</strong> ${service.duration}</p>
                    <p><strong>Date:</strong> ${service.date}</p>
                    <p><strong>Time:</strong> ${service.time}</p>
                `;
        }
    }
    
    /**
     * Add component to itinerary
     */
    function addComponentToItinerary(type, service) {
        selectedComponents.push({
            type: type,
            service_id: service.id,
            price: service.price,
            details: service
        });
        
        updateTotalPrice();
        updateSelectedComponents();
    }
    
    /**
     * Initialize schedule builder
     */
    function initializeScheduleBuilder() {
        const addDayButton = document.getElementById('add-day');
        let dayCount = 1;
        
        addDayButton.addEventListener('click', () => {
            addScheduleDay(dayCount++);
        });
        
        // Add first day by default
        addScheduleDay(dayCount++);
    }
    
    /**
     * Add a new day to the schedule
     */
    function addScheduleDay(dayNumber) {
        const dayContainer = document.createElement('div');
        dayContainer.className = 'schedule-day';
        dayContainer.dataset.day = dayNumber;
        
        dayContainer.innerHTML = `
            <h3>Day ${dayNumber}</h3>
            <div class="schedule-items"></div>
            <button type="button" class="btn-secondary add-activity">Add Activity</button>
        `;
        
        scheduleBuilder.insertBefore(dayContainer, document.getElementById('add-day'));
        
        dayContainer.querySelector('.add-activity').addEventListener('click', () => {
            addScheduleItem(dayNumber);
        });
    }
    
    /**
     * Add a new schedule item
     */
    function addScheduleItem(dayNumber) {
        const container = document.querySelector(`.schedule-day[data-day="${dayNumber}"] .schedule-items`);
        const itemId = `schedule-item-${Date.now()}`;
        
        const item = document.createElement('div');
        item.className = 'schedule-item';
        item.dataset.id = itemId;
        
        item.innerHTML = `
            <input type="time" name="schedule[${dayNumber}][${itemId}][time]" required>
            <input type="text" name="schedule[${dayNumber}][${itemId}][activity]" placeholder="Activity" required>
            <input type="text" name="schedule[${dayNumber}][${itemId}][location]" placeholder="Location" required>
            <input type="text" name="schedule[${dayNumber}][${itemId}][duration]" placeholder="Duration" required>
            <textarea name="schedule[${dayNumber}][${itemId}][notes]" placeholder="Notes"></textarea>
            <button type="button" class="btn-danger remove-item">Remove</button>
        `;
        
        container.appendChild(item);
        
        item.querySelector('.remove-item').addEventListener('click', () => {
            item.remove();
        });
    }
    
    /**
     * Initialize payment method switching
     */
    function initializePaymentMethod() {
        const paymentMethod = document.getElementById('payment_method');
        const creditCardFields = document.getElementById('credit-card-fields');
        
        paymentMethod.addEventListener('change', () => {
            creditCardFields.style.display = 
                paymentMethod.value === 'credit_card' ? 'block' : 'none';
        });
    }
    
    /**
     * Update total price display
     */
    function updateTotalPrice() {
        const total = selectedComponents.reduce((sum, component) => sum + component.price, 0);
        totalAmount.textContent = `$${total.toFixed(2)}`;
    }
    
    /**
     * Update selected components display
     */
    function updateSelectedComponents() {
        // Implementation to update UI with selected components
    }
    
    /**
     * Handle form submission
     */
    function handleFormSubmit(event) {
        event.preventDefault();
        
        // Validate form
        if (!validateForm()) {
            return;
        }
        
        // Add selected components to form data
        const componentsInput = document.createElement('input');
        componentsInput.type = 'hidden';
        componentsInput.name = 'components';
        componentsInput.value = JSON.stringify(selectedComponents);
        form.appendChild(componentsInput);
        
        // Submit form
        form.submit();
    }
    
    /**
     * Validate form data
     */
    function validateForm() {
        // Validate dates
        const startDate = new Date(document.getElementById('start_date').value);
        const endDate = new Date(document.getElementById('end_date').value);
        
        if (endDate <= startDate) {
            alert('End date must be after start date');
            return false;
        }
        
        // Validate components
        if (selectedComponents.length === 0) {
            alert('Please select at least one travel component');
            return false;
        }
        
        // Validate schedule
        const scheduleItems = document.querySelectorAll('.schedule-item');
        if (scheduleItems.length === 0) {
            alert('Please add at least one schedule item');
            return false;
        }
        
        return true;
    }
}
