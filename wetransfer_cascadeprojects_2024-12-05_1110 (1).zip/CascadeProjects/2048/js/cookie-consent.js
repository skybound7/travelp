class CookieConsent {
    constructor() {
        this.cookieConsent = document.getElementById('cookie-consent');
        this.tabButtons = document.querySelectorAll('.tab-button');
        this.tabContents = document.querySelectorAll('.tab-content');
        this.initializeEventListeners();
        this.checkCookiePreferences();
    }

    initializeEventListeners() {
        // Tab switching
        this.tabButtons.forEach(button => {
            button.addEventListener('click', () => this.switchTab(button.dataset.tab));
        });

        // Close button
        document.getElementById('cookie-close').addEventListener('click', () => {
            this.hideBanner();
        });

        // Accept all
        document.getElementById('accept-all-cookies').addEventListener('click', () => {
            this.setAllCookies(true);
            this.hideBanner();
        });

        // Save preferences
        document.getElementById('save-preferences').addEventListener('click', () => {
            this.savePreferences();
            this.hideBanner();
        });
    }

    switchTab(tab) {
        this.tabButtons.forEach(btn => btn.classList.remove('active'));
        this.tabContents.forEach(content => content.classList.remove('active'));
        
        document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
        document.getElementById(`tab-${tab}`).classList.add('active');
    }

    checkCookiePreferences() {
        if (!this.getCookie('cookie_preferences')) {
            this.showBanner();
        }
    }

    showBanner() {
        this.cookieConsent.style.display = 'flex';
    }

    hideBanner() {
        this.cookieConsent.style.display = 'none';
    }

    setAllCookies(enabled) {
        const preferences = {
            necessary: true,
            functional: enabled,
            analytics: enabled,
            marketing: enabled
        };
        
        this.saveCookiePreferences(preferences);
    }

    savePreferences() {
        const preferences = {
            necessary: true,
            functional: document.getElementById('functional-cookies').checked,
            analytics: document.getElementById('analytics-cookies').checked,
            marketing: document.getElementById('marketing-cookies').checked
        };
        
        this.saveCookiePreferences(preferences);
    }

    async saveCookiePreferences(preferences) {
        try {
            const response = await fetch('/api/cookie-preferences', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify(preferences)
            });

            if (!response.ok) {
                throw new Error('Failed to save preferences');
            }

            this.setCookie('cookie_preferences', JSON.stringify(preferences), 365);
            this.applyPreferences(preferences);

        } catch (error) {
            console.error('Error saving cookie preferences:', error);
            alert('Failed to save your preferences. Please try again.');
        }
    }

    applyPreferences(preferences) {
        // Apply functional preferences
        if (!preferences.functional) {
            // Disable functional cookies
            this.deleteCookie('language');
            this.deleteCookie('theme');
        }

        // Apply analytics preferences
        if (!preferences.analytics) {
            // Disable Google Analytics
            window['ga-disable-UA-XXXXX-Y'] = true;
            this.deleteCookie('_ga');
            this.deleteCookie('_gid');
        }

        // Apply marketing preferences
        if (!preferences.marketing) {
            // Disable marketing cookies
            this.deleteCookie('_fbp');
            this.deleteCookie('ads_id');
        }
    }

    setCookie(name, value, days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        
        document.cookie = `${name}=${value}; expires=${date.toUTCString()}; path=/; secure; samesite=Strict`;
    }

    getCookie(name) {
        const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
        return match ? match[2] : null;
    }

    deleteCookie(name) {
        document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/`;
    }
}

// Initialize cookie consent when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new CookieConsent();
});
