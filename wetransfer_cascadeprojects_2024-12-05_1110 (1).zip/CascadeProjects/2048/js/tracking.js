// Tracking Implementation
class TrackingManager {
    constructor() {
        this.initializeEventListeners();
    }

    initializeEventListeners() {
        // Track form submissions
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', (e) => this.trackFormSubmission(e));
        });

        // Track button clicks
        document.querySelectorAll('button, .btn').forEach(button => {
            button.addEventListener('click', (e) => this.trackButtonClick(e));
        });

        // Track page scroll depth
        window.addEventListener('scroll', this.debounce(() => this.trackScrollDepth(), 250));

        // Track time spent on page
        this.startTimeTracking();
    }

    trackFormSubmission(event) {
        const form = event.target;
        const formId = form.id || 'unnamed_form';
        const formType = form.getAttribute('data-form-type') || 'general';

        gtag('event', 'form_submission', {
            'event_category': 'Forms',
            'event_label': formId,
            'form_type': formType
        });

        fbq('trackCustom', 'FormSubmission', {
            form_id: formId,
            form_type: formType
        });
    }

    trackButtonClick(event) {
        const button = event.target.closest('button, .btn');
        const buttonText = button.innerText.trim();
        const buttonType = button.getAttribute('data-tracking-type') || 'general';

        gtag('event', 'button_click', {
            'event_category': 'Engagement',
            'event_label': buttonText,
            'button_type': buttonType
        });

        fbq('trackCustom', 'ButtonClick', {
            button_text: buttonText,
            button_type: buttonType
        });
    }

    trackScrollDepth() {
        const winHeight = window.innerHeight;
        const docHeight = document.documentElement.scrollHeight;
        const scrollTop = window.pageYOffset;
        const scrollPercent = (scrollTop / (docHeight - winHeight)) * 100;

        const milestones = [25, 50, 75, 100];
        const milestone = milestones.find(m => scrollPercent >= m && !this.isScrollMilestoneTracked(m));

        if (milestone) {
            this.trackScrollMilestone(milestone);
        }
    }

    isScrollMilestoneTracked(milestone) {
        const tracked = sessionStorage.getItem(`scroll_${milestone}`);
        return tracked === 'true';
    }

    trackScrollMilestone(milestone) {
        sessionStorage.setItem(`scroll_${milestone}`, 'true');

        gtag('event', 'scroll_depth', {
            'event_category': 'Engagement',
            'event_label': `${milestone}%`,
            'value': milestone
        });

        fbq('trackCustom', 'ScrollDepth', {
            milestone: milestone
        });
    }

    startTimeTracking() {
        const startTime = Date.now();
        
        window.addEventListener('beforeunload', () => {
            const timeSpent = Math.round((Date.now() - startTime) / 1000);
            
            gtag('event', 'time_spent', {
                'event_category': 'Engagement',
                'event_label': 'Time on Page',
                'value': timeSpent
            });

            fbq('trackCustom', 'TimeSpent', {
                seconds: timeSpent
            });
        });
    }

    trackBookingStart() {
        gtag('event', 'begin_checkout', {
            'event_category': 'Booking',
            'event_label': 'Start Booking Process'
        });

        fbq('track', 'InitiateCheckout');
    }

    trackBookingComplete(bookingData) {
        gtag('event', 'purchase', {
            'transaction_id': bookingData.bookingId,
            'value': bookingData.value,
            'currency': 'USD',
            'items': bookingData.items
        });

        fbq('track', 'Purchase', {
            value: bookingData.value,
            currency: 'USD'
        });
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}

// Initialize tracking
document.addEventListener('DOMContentLoaded', () => {
    window.trackingManager = new TrackingManager();
});
