// Enhanced Booking System JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Stripe
    const stripe = Stripe('your_publishable_key');
    const elements = stripe.elements();
    const cardElement = elements.create('card', {
        style: {
            base: {
                fontSize: '16px',
                color: '#32325d',
                fontFamily: '"Montserrat", sans-serif',
            }
        }
    });
    cardElement.mount('#card-element');

    // Form steps handling
    let currentStep = 1;
    const form = document.getElementById('booking-form');
    const steps = document.querySelectorAll('.form-step');
    const progressSteps = document.querySelectorAll('.progress-step');
    const btnNext = document.querySelector('.btn-next');
    const btnPrev = document.querySelector('.btn-prev');
    const btnSubmit = document.querySelector('.btn-submit');

    // Service selection
    const serviceCards = document.querySelectorAll('.service-card');
    let selectedService = null;

    serviceCards.forEach(card => {
        card.addEventListener('click', function() {
            serviceCards.forEach(c => c.classList.remove('selected'));
            this.classList.add('selected');
            selectedService = this.dataset.serviceId;
            loadServiceDetails(selectedService);
        });
    });

    // Guest number handling
    const guestInput = document.getElementById('guests');
    const btnMinus = document.querySelector('.guest-btn.minus');
    const btnPlus = document.querySelector('.guest-btn.plus');

    btnMinus.addEventListener('click', () => updateGuests(-1));
    btnPlus.addEventListener('click', () => updateGuests(1));

    function updateGuests(change) {
        const newValue = parseInt(guestInput.value) + change;
        if (newValue >= parseInt(guestInput.min) && newValue <= parseInt(guestInput.max)) {
            guestInput.value = newValue;
            updatePrice();
        }
    }

    // Date picker initialization with availability
    const dateInput = document.querySelector('.booking-date');
    const fpInstance = flatpickr(dateInput, {
        minDate: "today",
        maxDate: new Date().fp_incr(365),
        disable: [
            function(date) {
                // Check availability from server
                return !checkDateAvailability(date);
            }
        ],
        onChange: function(selectedDates, dateStr) {
            loadTimeSlots(selectedDates[0]);
        }
    });

    // Time slots handling
    function loadTimeSlots(date) {
        const timeGrid = document.querySelector('.time-grid');
        fetch(`/includes/booking-system/get-time-slots.php?date=${date}&service=${selectedService}`)
            .then(response => response.json())
            .then(slots => {
                timeGrid.innerHTML = slots.map(slot => `
                    <div class="time-slot" data-time="${slot.time}">
                        ${slot.formatted_time}
                    </div>
                `).join('');
                
                // Add click handlers to time slots
                document.querySelectorAll('.time-slot').forEach(slot => {
                    slot.addEventListener('click', function() {
                        document.querySelectorAll('.time-slot').forEach(s => s.classList.remove('selected'));
                        this.classList.add('selected');
                        updatePrice();
                    });
                });
            });
    }

    // Load service preferences
    function loadServicePreferences(serviceId) {
        const preferencesGrid = document.querySelector('.preferences-grid');
        fetch(`/includes/booking-system/get-preferences.php?service=${serviceId}`)
            .then(response => response.json())
            .then(preferences => {
                preferencesGrid.innerHTML = preferences.map(pref => `
                    <div class="preference-item" data-pref-id="${pref.id}" data-price="${pref.price_adjustment}">
                        <h4>${pref.name}</h4>
                        <p>${pref.description}</p>
                        <div class="preference-price">+$${pref.price_adjustment}</div>
                    </div>
                `).join('');
                
                // Add click handlers to preferences
                document.querySelectorAll('.preference-item').forEach(item => {
                    item.addEventListener('click', function() {
                        this.classList.toggle('selected');
                        updatePrice();
                    });
                });
            });
    }

    // Dynamic price calculation
    async function updatePrice() {
        const guests = parseInt(guestInput.value);
        const preferences = Array.from(document.querySelectorAll('.preference-item.selected'))
            .map(item => ({
                id: item.dataset.prefId,
                price: parseFloat(item.dataset.price)
            }));

        try {
            const response = await fetch('/includes/booking-system/calculate-price.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    serviceId: selectedService,
                    guests: guests,
                    preferences: preferences
                })
            });
            const data = await response.json();
            
            if (data.success) {
                updatePriceSummary(data.breakdown);
            }
        } catch (error) {
            console.error('Error calculating price:', error);
        }
    }

    // Update price breakdown in summary
    function updatePriceSummary(breakdown) {
        const summary = document.querySelector('.price-breakdown');
        summary.innerHTML = `
            <div class="base-price">
                <span>Base Price:</span>
                <span>$${breakdown.base_price}</span>
            </div>
            ${breakdown.preferences_cost > 0 ? `
                <div class="preferences-cost">
                    <span>Additional Services:</span>
                    <span>$${breakdown.preferences_cost}</span>
                </div>
            ` : ''}
            ${breakdown.group_discount > 0 ? `
                <div class="group-discount">
                    <span>Group Discount:</span>
                    <span>-$${breakdown.group_discount}</span>
                </div>
            ` : ''}
            <div class="total-price">
                <span>Total:</span>
                <span>$${breakdown.total_price}</span>
            </div>
        `;
    }

    // Navigation between steps
    btnNext.addEventListener('click', () => {
        if (validateStep(currentStep)) {
            if (currentStep < 4) {
                currentStep++;
                updateFormStep();
            }
        }
    });

    btnPrev.addEventListener('click', () => {
        if (currentStep > 1) {
            currentStep--;
            updateFormStep();
        }
    });

    function updateFormStep() {
        steps.forEach(step => step.classList.remove('active'));
        progressSteps.forEach(step => step.classList.remove('active'));
        
        document.querySelector(`.form-step[data-step="${currentStep}"]`).classList.add('active');
        for (let i = 1; i <= currentStep; i++) {
            document.querySelector(`.progress-step[data-step="${i}"]`).classList.add('active');
        }

        // Update button visibility
        btnPrev.style.display = currentStep === 1 ? 'none' : 'block';
        btnNext.style.display = currentStep === 4 ? 'none' : 'block';
        btnSubmit.style.display = currentStep === 4 ? 'block' : 'none';
    }

    // Form validation
    function validateStep(step) {
        switch(step) {
            case 1:
                return selectedService !== null;
            case 2:
                return dateInput.value && document.querySelector('.time-slot.selected');
            case 3:
                return true; // Preferences are optional
            case 4:
                return true; // Validation handled by Stripe
            default:
                return false;
        }
    }

    // Handle form submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const submitButton = document.querySelector('.btn-submit');
        submitButton.disabled = true;
        submitButton.textContent = 'Processing...';

        try {
            // Create payment method
            const {paymentMethod, error} = await stripe.createPaymentMethod({
                type: 'card',
                card: cardElement,
            });

            if (error) {
                throw new Error(error.message);
            }

            // Submit booking
            const response = await fetch('/includes/booking-system/process-booking.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    service_id: selectedService,
                    date: dateInput.value,
                    time: document.querySelector('.time-slot.selected').dataset.time,
                    guests: guestInput.value,
                    preferences: Array.from(document.querySelectorAll('.preference-item.selected'))
                        .map(item => item.dataset.prefId),
                    payment_method_id: paymentMethod.id,
                    special_requests: document.getElementById('special-requests').value
                })
            });

            const result = await response.json();
            
            if (result.success) {
                window.location.href = `/booking-confirmation.php?id=${result.booking_id}`;
            } else {
                throw new Error(result.message);
            }
        } catch (error) {
            showError(error.message);
            submitButton.disabled = false;
            submitButton.textContent = 'Confirm Booking';
        }
    });

    // Error handling
    function showError(message) {
        const errorDiv = document.getElementById('card-errors');
        errorDiv.textContent = message;
        errorDiv.style.display = 'block';
        
        setTimeout(() => {
            errorDiv.style.display = 'none';
        }, 5000);
    }

    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
