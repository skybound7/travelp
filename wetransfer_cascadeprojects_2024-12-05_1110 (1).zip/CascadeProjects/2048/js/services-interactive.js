// Interactive Features for Service Pages
document.addEventListener('DOMContentLoaded', function() {
    // 360° Virtual Tour Viewer
    const initVirtualTour = () => {
        const viewer = document.querySelector('.virtual-tour-viewer');
        if (!viewer) return;

        let currentAngle = 0;
        let isDragging = false;
        let startX;

        viewer.addEventListener('mousedown', (e) => {
            isDragging = true;
            startX = e.pageX;
        });

        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            const diff = e.pageX - startX;
            currentAngle += diff / 5;
            viewer.style.transform = `rotateY(${currentAngle}deg)`;
            startX = e.pageX;
        });

        document.addEventListener('mouseup', () => {
            isDragging = false;
        });
    };

    // Dynamic Price Calculator
    const initPriceCalculator = () => {
        const calculator = document.querySelector('.price-calculator');
        if (!calculator) return;

        const updatePrice = () => {
            const duration = parseInt(calculator.querySelector('[name="duration"]').value);
            const passengers = parseInt(calculator.querySelector('[name="passengers"]').value);
            const extras = Array.from(calculator.querySelectorAll('[name="extras"]:checked'))
                .reduce((sum, checkbox) => sum + parseInt(checkbox.value), 0);

            const basePrice = duration * 500 * passengers;
            const totalPrice = basePrice + extras;

            calculator.querySelector('.calculated-price').textContent = 
                `$${totalPrice.toLocaleString()}`;
        };

        calculator.querySelectorAll('select, input').forEach(input => {
            input.addEventListener('change', updatePrice);
        });

        updatePrice();
    };

    // Live Availability Calendar
    const initAvailabilityCalendar = () => {
        const calendar = document.querySelector('.availability-calendar');
        if (!calendar) return;

        const dates = calendar.querySelectorAll('.calendar-date');
        dates.forEach(date => {
            date.addEventListener('click', () => {
                dates.forEach(d => d.classList.remove('selected'));
                date.classList.add('selected');
                
                // Show available time slots
                const timeSlots = calendar.querySelector('.time-slots');
                timeSlots.innerHTML = generateTimeSlots();
                timeSlots.style.display = 'block';
            });
        });
    };

    // Generate random time slots for demo
    const generateTimeSlots = () => {
        const slots = ['09:00', '11:00', '14:00', '16:00'];
        return slots.map(time => `
            <div class="time-slot">
                <span>${time}</span>
                <button class="btn btn-sm btn-outline-primary">Select</button>
            </div>
        `).join('');
    };

    // Interactive Experience Customizer
    const initExperienceCustomizer = () => {
        const customizer = document.querySelector('.experience-customizer');
        if (!customizer) return;

        const updatePreview = () => {
            const selectedOptions = Array.from(customizer.querySelectorAll('select, input:checked'))
                .map(input => input.options ? input.options[input.selectedIndex].text : input.dataset.label);

            const preview = customizer.querySelector('.experience-preview');
            preview.innerHTML = `
                <h5>Your Custom Experience</h5>
                <ul>
                    ${selectedOptions.map(option => `<li>${option}</li>`).join('')}
                </ul>
            `;
        };

        customizer.querySelectorAll('select, input').forEach(input => {
            input.addEventListener('change', updatePreview);
        });
    };

    // Animated Stats Counter
    const initStatsCounter = () => {
        const stats = document.querySelectorAll('.stat-counter');
        const options = {
            threshold: 0.5
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const target = entry.target;
                    const end = parseInt(target.dataset.end);
                    animateValue(target, 0, end, 2000);
                    observer.unobserve(target);
                }
            });
        }, options);

        stats.forEach(stat => observer.observe(stat));
    };

    const animateValue = (element, start, end, duration) => {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            const value = Math.floor(progress * (end - start) + start);
            element.textContent = value.toLocaleString();
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    };

    // Weather Integration for Helicopter Tours
    const initWeatherWidget = async () => {
        const widget = document.querySelector('.weather-widget');
        if (!widget) return;

        try {
            // Simulate weather API call
            const weather = {
                temperature: 25,
                conditions: 'Clear Sky',
                visibility: 'Excellent',
                wind: '5 mph'
            };

            widget.innerHTML = `
                <div class="weather-info">
                    <h5>Current Flying Conditions</h5>
                    <div class="weather-details">
                        <div><i class="fas fa-temperature-high"></i> ${weather.temperature}°C</div>
                        <div><i class="fas fa-cloud"></i> ${weather.conditions}</div>
                        <div><i class="fas fa-eye"></i> ${weather.visibility}</div>
                        <div><i class="fas fa-wind"></i> ${weather.wind}</div>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error fetching weather data:', error);
        }
    };

    // Initialize all features
    initVirtualTour();
    initPriceCalculator();
    initAvailabilityCalendar();
    initExperienceCustomizer();
    initStatsCounter();
    initWeatherWidget();
});
