<?php
class PerformanceOptimizer {
    private $conn;
    private $config;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->config = [
            'cache_duration' => 3600,
            'minify_assets' => true,
            'enable_compression' => true,
            'lazy_load_images' => true
        ];
    }
    
    public function optimizePageLoad() {
        // Resource hints
        $hints = [
            '<link rel="dns-prefetch" href="//fonts.googleapis.com">',
            '<link rel="preconnect" href="//fonts.googleapis.com">',
            '<link rel="preload" href="/assets/fonts/luxury-primary.woff2" as="font" type="font/woff2" crossorigin>',
            '<link rel="preload" href="/assets/css/critical.css" as="style">'
        ];
        
        // Critical CSS
        $criticalCss = $this->loadCriticalCss();
        
        // Deferred loading
        $deferScripts = $this->getDeferredScripts();
        
        return [
            'hints' => implode("\n", $hints),
            'critical_css' => $criticalCss,
            'deferred_scripts' => $deferScripts
        ];
    }
    
    public function monitorPerformance() {
        $metrics = [
            'load_time' => $this->calculateLoadTime(),
            'ttfb' => $this->calculateTTFB(),
            'fcp' => $this->calculateFCP(),
            'lcp' => $this->calculateLCP()
        ];
        
        $this->logPerformanceMetrics($metrics);
        return $metrics;
    }
    
    private function calculateLoadTime() {
        return [
            'start' => $_SERVER["REQUEST_TIME_FLOAT"],
            'end' => microtime(true)
        ];
    }
    
    private function calculateTTFB() {
        return microtime(true) - $_SERVER["REQUEST_TIME_FLOAT"];
    }
    
    private function calculateFCP() {
        return <<<EOT
<script>
new PerformanceObserver((entryList) => {
    for (const entry of entryList.getEntries()) {
        fetch('/api/performance/log', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                metric: 'fcp',
                value: entry.startTime,
                url: window.location.pathname
            })
        });
    }
}).observe({ type: 'paint', buffered: true });
</script>
EOT;
    }
    
    private function calculateLCP() {
        return <<<EOT
<script>
new PerformanceObserver((entryList) => {
    for (const entry of entryList.getEntries()) {
        fetch('/api/performance/log', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                metric: 'lcp',
                value: entry.startTime,
                url: window.location.pathname
            })
        });
    }
}).observe({ type: 'largest-contentful-paint', buffered: true });
</script>
EOT;
    }
    
    private function logPerformanceMetrics($metrics) {
        $stmt = $this->conn->prepare("
            INSERT INTO performance_metrics (
                page_url,
                load_time,
                ttfb,
                fcp,
                lcp,
                user_agent,
                created_at
            ) VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $pageUrl = $_SERVER['REQUEST_URI'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        
        $stmt->bind_param('sdddss',
            $pageUrl,
            $metrics['load_time']['end'] - $metrics['load_time']['start'],
            $metrics['ttfb'],
            0, // FCP will be updated via AJAX
            0, // LCP will be updated via AJAX
            $userAgent
        );
        
        $stmt->execute();
    }
    
    private function loadCriticalCss() {
        return file_get_contents(__DIR__ . '/../../assets/css/critical.css');
    }
    
    private function getDeferredScripts() {
        return [
            '/assets/js/non-critical.js',
            '/assets/js/analytics.js',
            '/assets/js/third-party.js'
        ];
    }
}

// Create performance metrics table
$performanceTable = "
CREATE TABLE IF NOT EXISTS performance_metrics (
    id INT PRIMARY KEY AUTO_INCREMENT,
    page_url VARCHAR(255) NOT NULL,
    load_time FLOAT,
    ttfb FLOAT,
    fcp FLOAT,
    lcp FLOAT,
    user_agent VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_url_time (page_url, created_at)
);";
?>
