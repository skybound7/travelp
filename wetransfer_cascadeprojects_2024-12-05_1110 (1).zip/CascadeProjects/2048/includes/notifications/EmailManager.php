<?php
require_once __DIR__ . '/../config.php';

class EmailManager {
    private $mailer;
    private $fromEmail;
    private $fromName;
    
    public function __construct() {
        // Initialize PHPMailer
        $this->mailer = new PHPMailer(true);
        $this->fromEmail = 'bookings@luxurytravel.com';
        $this->fromName = 'Luxury Travel';
        
        // Configure mailer settings
        $this->setupMailer();
    }
    
    private function setupMailer() {
        try {
            $this->mailer->isSMTP();
            $this->mailer->Host = SMTP_HOST;
            $this->mailer->SMTPAuth = true;
            $this->mailer->Username = SMTP_USERNAME;
            $this->mailer->Password = SMTP_PASSWORD;
            $this->mailer->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $this->mailer->Port = SMTP_PORT;
            
            $this->mailer->setFrom($this->fromEmail, $this->fromName);
            $this->mailer->isHTML(true);
        } catch (Exception $e) {
            error_log("Email setup error: " . $e->getMessage());
            throw $e;
        }
    }
    
    public function sendEurailBookingConfirmation($userEmail, $bookingId, $bookingData) {
        try {
            $this->mailer->clearAddresses();
            $this->mailer->addAddress($userEmail);
            
            $this->mailer->Subject = 'Eurail Pass Booking Confirmation - #' . $bookingId;
            
            // Create HTML content
            $html = $this->getEmailTemplate('eurail-confirmation');
            $html = str_replace([
                '{{BOOKING_ID}}',
                '{{PASS_TYPE}}',
                '{{DURATION}}',
                '{{START_DATE}}',
                '{{PASSENGERS}}',
                '{{COUNTRIES}}',
                '{{TOTAL_PRICE}}'
            ], [
                $bookingId,
                ucfirst($bookingData['passType']),
                $bookingData['duration'] . ' Days',
                date('F j, Y', strtotime($bookingData['startDate'])),
                $bookingData['passengers'],
                implode(', ', array_map('ucfirst', $bookingData['countries'])),
                number_format($bookingData['totalPrice'], 2)
            ], $html);
            
            $this->mailer->Body = $html;
            $this->mailer->send();
            
            return true;
        } catch (Exception $e) {
            error_log("Failed to send Eurail booking confirmation: " . $e->getMessage());
            throw $e;
        }
    }
    
    public function sendExcursionBookingConfirmation($userEmail, $bookingId, $bookingData) {
        try {
            $this->mailer->clearAddresses();
            $this->mailer->addAddress($userEmail);
            
            $this->mailer->Subject = 'Excursion Booking Confirmation - #' . $bookingId;
            
            // Create HTML content
            $html = $this->getEmailTemplate('excursion-confirmation');
            $html = str_replace([
                '{{BOOKING_ID}}',
                '{{EXCURSION_TYPE}}',
                '{{DESTINATION}}',
                '{{DATE}}',
                '{{GROUP_SIZE}}',
                '{{SPECIAL_REQUESTS}}',
                '{{TOTAL_PRICE}}'
            ], [
                $bookingId,
                ucfirst($bookingData['excursionType']),
                $bookingData['destination'],
                date('F j, Y', strtotime($bookingData['excursionDate'])),
                $bookingData['groupSize'],
                $bookingData['specialRequests'] ?: 'None',
                number_format($bookingData['totalPrice'], 2)
            ], $html);
            
            $this->mailer->Body = $html;
            $this->mailer->send();
            
            return true;
        } catch (Exception $e) {
            error_log("Failed to send excursion booking confirmation: " . $e->getMessage());
            throw $e;
        }
    }
    
    public function sendBookingStatusUpdate($userEmail, $bookingId, $bookingType, $status) {
        try {
            $this->mailer->clearAddresses();
            $this->mailer->addAddress($userEmail);
            
            $this->mailer->Subject = ucfirst($bookingType) . ' Booking Update - #' . $bookingId;
            
            // Create HTML content
            $html = $this->getEmailTemplate('status-update');
            $html = str_replace([
                '{{BOOKING_TYPE}}',
                '{{BOOKING_ID}}',
                '{{STATUS}}',
                '{{UPDATE_DATE}}'
            ], [
                ucfirst($bookingType),
                $bookingId,
                ucfirst($status),
                date('F j, Y H:i:s')
            ], $html);
            
            $this->mailer->Body = $html;
            $this->mailer->send();
            
            return true;
        } catch (Exception $e) {
            error_log("Failed to send booking status update: " . $e->getMessage());
            throw $e;
        }
    }
    
    private function getEmailTemplate($templateName) {
        $templatePath = __DIR__ . '/../../templates/emails/' . $templateName . '.html';
        
        if (!file_exists($templatePath)) {
            throw new Exception("Email template not found: " . $templateName);
        }
        
        return file_get_contents($templatePath);
    }
}
