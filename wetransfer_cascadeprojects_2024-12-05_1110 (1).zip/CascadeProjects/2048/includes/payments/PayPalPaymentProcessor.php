<?php
require_once __DIR__ . '/PaymentProcessor.php';
require_once __DIR__ . '/../config.php';

class PayPalPaymentProcessor implements PaymentProcessor {
    private $logger;
    private $client;
    private $environment;
    
    public function __construct() {
        $this->logger = new Logger(EMAIL_LOG_FILE, EMAIL_LOG_ENABLED);
        $this->environment = PAYPAL_ENVIRONMENT === 'production' 
            ? new PayPalCheckoutSdk\Core\ProductionEnvironment(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET)
            : new PayPalCheckoutSdk\Core\SandboxEnvironment(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET);
            
        $this->client = new PayPalCheckoutSdk\Core\PayPalHttpClient($this->environment);
    }
    
    public function processPayment($bookingId, $bookingType, $amount, array $paymentDetails) {
        try {
            $this->validatePaymentDetails($paymentDetails);
            
            $request = new PayPalCheckoutSdk\Orders\OrdersCreateRequest();
            $request->prefer('return=representation');
            
            $request->body = [
                'intent' => 'CAPTURE',
                'purchase_units' => [[
                    'reference_id' => $bookingId,
                    'description' => ucfirst($bookingType) . ' Booking #' . $bookingId,
                    'amount' => [
                        'currency_code' => 'EUR',
                        'value' => number_format($amount, 2, '.', '')
                    ]
                ]],
                'application_context' => [
                    'return_url' => SITE_URL . '/payment/success',
                    'cancel_url' => SITE_URL . '/payment/cancel'
                ]
            ];
            
            $response = $this->client->execute($request);
            
            $this->logger->info("PayPal payment initiated for booking {$bookingId}");
            
            return [
                'success' => true,
                'transactionId' => $response->result->id,
                'status' => $response->result->status,
                'amount' => $amount,
                'approvalUrl' => $this->getApprovalUrl($response->result->links)
            ];
            
        } catch (Exception $e) {
            $this->logger->error("PayPal payment error for booking {$bookingId}: " . $e->getMessage());
            throw new PaymentException("PayPal payment failed: " . $e->getMessage());
        }
    }
    
    public function refundPayment($transactionId, $amount, $reason) {
        try {
            $request = new PayPalCheckoutSdk\Payments\CapturesRefundRequest($transactionId);
            $request->body = [
                'amount' => [
                    'currency_code' => 'EUR',
                    'value' => number_format($amount, 2, '.', '')
                ],
                'note_to_payer' => $reason
            ];
            
            $response = $this->client->execute($request);
            
            $this->logger->info("PayPal refund processed for transaction {$transactionId}");
            
            return [
                'success' => true,
                'refundId' => $response->result->id,
                'status' => $response->result->status,
                'amount' => $amount
            ];
            
        } catch (Exception $e) {
            $this->logger->error("PayPal refund error for transaction {$transactionId}: " . $e->getMessage());
            throw new PaymentException("PayPal refund failed: " . $e->getMessage());
        }
    }
    
    public function getPaymentStatus($transactionId) {
        try {
            $request = new PayPalCheckoutSdk\Orders\OrdersGetRequest($transactionId);
            $response = $this->client->execute($request);
            
            return [
                'status' => $response->result->status,
                'amount' => $response->result->purchase_units[0]->amount->value,
                'currency' => $response->result->purchase_units[0]->amount->currency_code,
                'created' => $response->result->create_time,
                'payer' => $response->result->payer->email_address ?? null
            ];
            
        } catch (Exception $e) {
            $this->logger->error("Error checking PayPal payment status for {$transactionId}: " . $e->getMessage());
            throw new PaymentException("PayPal status check failed: " . $e->getMessage());
        }
    }
    
    public function validatePaymentDetails(array $paymentDetails) {
        // PayPal doesn't require upfront validation as the user will be redirected to PayPal's site
        return true;
    }
    
    private function getApprovalUrl($links) {
        foreach ($links as $link) {
            if ($link->rel === 'approve') {
                return $link->href;
            }
        }
        throw new PaymentException("PayPal approval URL not found");
    }
    
    public function capturePayment($orderId) {
        try {
            $request = new PayPalCheckoutSdk\Orders\OrdersCaptureRequest($orderId);
            $response = $this->client->execute($request);
            
            return [
                'success' => true,
                'transactionId' => $response->result->id,
                'status' => $response->result->status,
                'amount' => $response->result->purchase_units[0]->payments->captures[0]->amount->value
            ];
            
        } catch (Exception $e) {
            $this->logger->error("PayPal capture error for order {$orderId}: " . $e->getMessage());
            throw new PaymentException("PayPal capture failed: " . $e->getMessage());
        }
    }
}
