<?php
require_once __DIR__ . '/../config/payment.php';
require_once __DIR__ . '/StripePaymentProcessor.php';
require_once __DIR__ . '/PayPalPaymentProcessor.php';
require_once __DIR__ . '/UPIPaymentProcessor.php';
require_once __DIR__ . '/PhonePePaymentProcessor.php';

class PaymentFactory {
    private static $instances = [];
    
    public static function getProcessor($paymentMethod) {
        // Validate payment method
        if (!isset(PAYMENT_METHODS[$paymentMethod])) {
            throw new InvalidArgumentException("Invalid payment method: {$paymentMethod}");
        }
        
        $config = PAYMENT_METHODS[$paymentMethod];
        
        // Check if payment method is enabled
        if (!$config['enabled']) {
            throw new Exception("Payment method {$paymentMethod} is currently disabled");
        }
        
        // Return cached instance if available
        if (isset(self::$instances[$paymentMethod])) {
            return self::$instances[$paymentMethod];
        }
        
        // Create new instance
        $processorClass = $config['processor'];
        self::$instances[$paymentMethod] = new $processorClass();
        
        return self::$instances[$paymentMethod];
    }
    
    public static function getAvailablePaymentMethods() {
        $methods = [];
        
        foreach (PAYMENT_METHODS as $key => $config) {
            if ($config['enabled']) {
                $methods[$key] = [
                    'name' => $config['name'],
                    'icon' => $config['icon']
                ];
            }
        }
        
        return $methods;
    }
    
    public static function validatePaymentMethod($paymentMethod) {
        return isset(PAYMENT_METHODS[$paymentMethod]) && PAYMENT_METHODS[$paymentMethod]['enabled'];
    }
}
