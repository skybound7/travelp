<?php
require_once __DIR__ . '/PaymentProcessor.php';
require_once __DIR__ . '/../config.php';

class UPIPaymentProcessor implements PaymentProcessor {
    private $logger;
    private $apiEndpoint;
    private $merchantId;
    private $apiKey;
    
    public function __construct() {
        $this->logger = new Logger(EMAIL_LOG_FILE, EMAIL_LOG_ENABLED);
        $this->apiEndpoint = UPI_API_ENDPOINT;
        $this->merchantId = UPI_MERCHANT_ID;
        $this->apiKey = UPI_API_KEY;
    }
    
    public function processPayment($bookingId, $bookingType, $amount, array $paymentDetails) {
        try {
            $this->validatePaymentDetails($paymentDetails);
            
            // Create UPI payment request
            $payload = [
                'merchantId' => $this->merchantId,
                'merchantTransactionId' => 'TXN_' . $bookingId . '_' . time(),
                'merchantUserId' => $paymentDetails['userId'],
                'amount' => $amount * 100,
                'redirectUrl' => SITE_URL . '/payment/callback/upi',
                'redirectMode' => 'POST',
                'callbackUrl' => SITE_URL . '/api/payment/callback/upi',
                'mobileNumber' => $paymentDetails['mobileNumber'],
                'paymentInstrument' => [
                    'type' => 'UPI_INTENT',
                    'targetApp' => $paymentDetails['upiApp'] ?? 'ANY'
                ]
            ];
            
            $response = $this->makeApiRequest('payment/init', $payload);
            
            if ($response['success']) {
                $this->logger->info("UPI payment initiated for booking {$bookingId}");
                return [
                    'success' => true,
                    'transactionId' => $response['data']['transactionId'],
                    'status' => 'initiated',
                    'amount' => $amount,
                    'redirectUrl' => $response['data']['instrumentResponse']['intentUrl']
                ];
            }
            
            throw new PaymentException("UPI payment initiation failed: " . $response['message']);
            
        } catch (Exception $e) {
            $this->logger->error("UPI payment error for booking {$bookingId}: " . $e->getMessage());
            throw new PaymentException("UPI payment failed: " . $e->getMessage());
        }
    }
    
    public function refundPayment($transactionId, $amount, $reason) {
        try {
            $payload = [
                'merchantId' => $this->merchantId,
                'merchantTransactionId' => 'REF_' . $transactionId . '_' . time(),
                'originalTransactionId' => $transactionId,
                'amount' => $amount * 100,
                'reason' => $reason
            ];
            
            $response = $this->makeApiRequest('refund/init', $payload);
            
            if ($response['success']) {
                $this->logger->info("UPI refund processed for transaction {$transactionId}");
                return [
                    'success' => true,
                    'refundId' => $response['data']['refundId'],
                    'status' => $response['data']['status'],
                    'amount' => $amount
                ];
            }
            
            throw new PaymentException("UPI refund failed: " . $response['message']);
            
        } catch (Exception $e) {
            $this->logger->error("UPI refund error for transaction {$transactionId}: " . $e->getMessage());
            throw new PaymentException("UPI refund failed: " . $e->getMessage());
        }
    }
    
    public function getPaymentStatus($transactionId) {
        try {
            $response = $this->makeApiRequest('payment/status/' . $transactionId, [], 'GET');
            
            if ($response['success']) {
                return [
                    'status' => $response['data']['status'],
                    'amount' => $response['data']['amount'] / 100,
                    'transactionId' => $response['data']['transactionId'],
                    'created' => $response['data']['createTime'],
                    'upiId' => $response['data']['upiId']
                ];
            }
            
            throw new PaymentException("Could not retrieve UPI payment status");
            
        } catch (Exception $e) {
            $this->logger->error("Error checking UPI payment status for {$transactionId}: " . $e->getMessage());
            throw new PaymentException("UPI status check failed: " . $e->getMessage());
        }
    }
    
    public function validatePaymentDetails(array $paymentDetails) {
        $requiredFields = ['userId', 'mobileNumber'];
        
        foreach ($requiredFields as $field) {
            if (!isset($paymentDetails[$field]) || empty($paymentDetails[$field])) {
                throw new ValidationException("Missing required UPI field: {$field}");
            }
        }
        
        // Validate mobile number format
        if (!preg_match('/^[0-9]{10}$/', $paymentDetails['mobileNumber'])) {
            throw new ValidationException("Invalid mobile number format");
        }
        
        return true;
    }
    
    private function makeApiRequest($endpoint, $payload = [], $method = 'POST') {
        $curl = curl_init();
        
        $headers = [
            'Content-Type: application/json',
            'x-api-key: ' . $this->apiKey,
            'x-merchant-id: ' . $this->merchantId
        ];
        
        $url = $this->apiEndpoint . '/' . $endpoint;
        
        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers
        ]);
        
        if ($method === 'POST' && !empty($payload)) {
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($payload));
        }
        
        $response = curl_exec($curl);
        $error = curl_error($curl);
        
        curl_close($curl);
        
        if ($error) {
            throw new PaymentException("API request failed: " . $error);
        }
        
        return json_decode($response, true);
    }
}
