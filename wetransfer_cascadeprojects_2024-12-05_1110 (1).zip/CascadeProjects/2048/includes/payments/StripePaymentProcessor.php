<?php
require_once __DIR__ . '/PaymentProcessor.php';
require_once __DIR__ . '/../config.php';

class StripePaymentProcessor implements PaymentProcessor {
    private $stripe;
    private $logger;
    
    public function __construct() {
        $this->stripe = new \Stripe\StripeClient(STRIPE_SECRET_KEY);
        $this->logger = new Logger(EMAIL_LOG_FILE, EMAIL_LOG_ENABLED);
    }
    
    public function processPayment($bookingId, $bookingType, $amount, array $paymentDetails) {
        try {
            $this->validatePaymentDetails($paymentDetails);
            
            // Create payment intent
            $paymentIntent = $this->stripe->paymentIntents->create([
                'amount' => $amount * 100, // Convert to cents
                'currency' => 'eur',
                'payment_method' => $paymentDetails['paymentMethodId'],
                'confirm' => true,
                'metadata' => [
                    'bookingId' => $bookingId,
                    'bookingType' => $bookingType
                ]
            ]);
            
            $this->logger->info("Payment processed successfully for booking {$bookingId}");
            
            return [
                'success' => true,
                'transactionId' => $paymentIntent->id,
                'status' => $paymentIntent->status,
                'amount' => $amount
            ];
            
        } catch (\Stripe\Exception\CardException $e) {
            $this->logger->error("Card error for booking {$bookingId}: " . $e->getMessage());
            throw new PaymentException("Card payment failed: " . $e->getMessage());
            
        } catch (\Exception $e) {
            $this->logger->error("Payment processing error for booking {$bookingId}: " . $e->getMessage());
            throw new PaymentException("Payment processing failed: " . $e->getMessage());
        }
    }
    
    public function refundPayment($transactionId, $amount, $reason) {
        try {
            $refund = $this->stripe->refunds->create([
                'payment_intent' => $transactionId,
                'amount' => $amount * 100,
                'reason' => $reason
            ]);
            
            $this->logger->info("Refund processed successfully for transaction {$transactionId}");
            
            return [
                'success' => true,
                'refundId' => $refund->id,
                'status' => $refund->status,
                'amount' => $amount
            ];
            
        } catch (\Exception $e) {
            $this->logger->error("Refund processing error for transaction {$transactionId}: " . $e->getMessage());
            throw new PaymentException("Refund processing failed: " . $e->getMessage());
        }
    }
    
    public function getPaymentStatus($transactionId) {
        try {
            $paymentIntent = $this->stripe->paymentIntents->retrieve($transactionId);
            
            return [
                'status' => $paymentIntent->status,
                'amount' => $paymentIntent->amount / 100,
                'currency' => $paymentIntent->currency,
                'created' => date('Y-m-d H:i:s', $paymentIntent->created),
                'metadata' => $paymentIntent->metadata->toArray()
            ];
            
        } catch (\Exception $e) {
            $this->logger->error("Error retrieving payment status for transaction {$transactionId}: " . $e->getMessage());
            throw new PaymentException("Could not retrieve payment status: " . $e->getMessage());
        }
    }
    
    public function validatePaymentDetails(array $paymentDetails) {
        $requiredFields = ['paymentMethodId'];
        
        foreach ($requiredFields as $field) {
            if (!isset($paymentDetails[$field]) || empty($paymentDetails[$field])) {
                throw new ValidationException("Missing required payment field: {$field}");
            }
        }
        
        return true;
    }
}
