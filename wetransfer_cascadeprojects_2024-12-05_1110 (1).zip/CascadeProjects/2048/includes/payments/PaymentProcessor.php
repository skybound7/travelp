<?php
interface PaymentProcessor {
    /**
     * Process a payment for a booking
     * 
     * @param int $bookingId The ID of the booking
     * @param string $bookingType The type of booking (eurail, excursion)
     * @param float $amount The amount to charge
     * @param array $paymentDetails Payment details including card info or payment token
     * @return array Payment result with transaction ID and status
     * @throws PaymentException If payment processing fails
     */
    public function processPayment($bookingId, $bookingType, $amount, array $paymentDetails);
    
    /**
     * Refund a payment
     * 
     * @param string $transactionId Original transaction ID
     * @param float $amount Amount to refund
     * @param string $reason Reason for refund
     * @return array Refund result with refund ID and status
     * @throws PaymentException If refund fails
     */
    public function refundPayment($transactionId, $amount, $reason);
    
    /**
     * Get payment status
     * 
     * @param string $transactionId Transaction ID to check
     * @return array Payment status details
     */
    public function getPaymentStatus($transactionId);
    
    /**
     * Validate payment details before processing
     * 
     * @param array $paymentDetails Payment details to validate
     * @return bool True if valid, throws exception if invalid
     * @throws ValidationException If payment details are invalid
     */
    public function validatePaymentDetails(array $paymentDetails);
}

class PaymentException extends Exception {}
class ValidationException extends Exception {}
