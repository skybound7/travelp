<?php
require_once __DIR__ . '/PaymentProcessor.php';
require_once __DIR__ . '/../config.php';

class PhonePePaymentProcessor implements PaymentProcessor {
    private $logger;
    private $merchantId;
    private $saltKey;
    private $saltIndex;
    private $apiEndpoint;
    
    public function __construct() {
        $this->logger = new Logger(EMAIL_LOG_FILE, EMAIL_LOG_ENABLED);
        $this->merchantId = PHONEPE_MERCHANT_ID;
        $this->saltKey = PHONEPE_SALT_KEY;
        $this->saltIndex = PHONEPE_SALT_INDEX;
        $this->apiEndpoint = PHONEPE_API_ENDPOINT;
    }
    
    public function processPayment($bookingId, $bookingType, $amount, array $paymentDetails) {
        try {
            $this->validatePaymentDetails($paymentDetails);
            
            // Use merchant transaction ID from payment details
            $merchantTransactionId = $paymentDetails['bookingMetadata']['merchantTransactionId'];
            
            $payload = [
                'merchantId' => $this->merchantId,
                'merchantTransactionId' => $merchantTransactionId,
                'merchantUserId' => $paymentDetails['userId'],
                'amount' => $amount * 100,
                'redirectUrl' => SITE_URL . '/payment/callback/phonepe',
                'redirectMode' => 'POST',
                'callbackUrl' => SITE_URL . '/api/payment/callback/phonepe',
                'mobileNumber' => $paymentDetails['mobileNumber'],
                'paymentInstrument' => [
                    'type' => 'PAY_PAGE'
                ]
            ];
            
            $base64Payload = base64_encode(json_encode($payload));
            $checksum = hash('sha256', $base64Payload . '/pg/v1/pay' . $this->saltKey) . '###' . $this->saltIndex;
            
            $headers = [
                'Content-Type: application/json',
                'X-VERIFY: ' . $checksum
            ];
            
            $response = $this->makeApiRequest('/pg/v1/pay', [
                'request' => $base64Payload
            ], $headers);
            
            if ($response['success']) {
                $this->logger->info("PhonePe payment initiated for booking {$bookingId} with merchant transaction ID {$merchantTransactionId}");
                return [
                    'success' => true,
                    'transactionId' => $response['data']['merchantTransactionId'] ?? $merchantTransactionId,
                    'merchantTransactionId' => $merchantTransactionId,
                    'status' => 'initiated',
                    'amount' => $amount,
                    'redirectUrl' => $response['data']['instrumentResponse']['redirectInfo']['url']
                ];
            }
            
            throw new PaymentException("PhonePe payment initiation failed: " . $response['message']);
            
        } catch (Exception $e) {
            $this->logger->error("PhonePe payment error for booking {$bookingId}: " . $e->getMessage());
            throw new PaymentException("PhonePe payment failed: " . $e->getMessage());
        }
    }
    
    public function refundPayment($transactionId, $amount, $reason) {
        try {
            $payload = [
                'merchantId' => $this->merchantId,
                'merchantTransactionId' => 'REF_' . $transactionId . '_' . time(),
                'originalTransactionId' => $transactionId,
                'amount' => $amount * 100,
                'callbackUrl' => SITE_URL . '/api/payment/callback/phonepe/refund'
            ];
            
            $base64Payload = base64_encode(json_encode($payload));
            $checksum = hash('sha256', $base64Payload . '/pg/v1/refund' . $this->saltKey) . '###' . $this->saltIndex;
            
            $headers = [
                'Content-Type: application/json',
                'X-VERIFY: ' . $checksum
            ];
            
            $response = $this->makeApiRequest('/pg/v1/refund', [
                'request' => $base64Payload
            ], $headers);
            
            if ($response['success']) {
                $this->logger->info("PhonePe refund processed for transaction {$transactionId}");
                return [
                    'success' => true,
                    'refundId' => $response['data']['refundId'],
                    'status' => $response['data']['state'],
                    'amount' => $amount
                ];
            }
            
            throw new PaymentException("PhonePe refund failed: " . $response['message']);
            
        } catch (Exception $e) {
            $this->logger->error("PhonePe refund error for transaction {$transactionId}: " . $e->getMessage());
            throw new PaymentException("PhonePe refund failed: " . $e->getMessage());
        }
    }
    
    public function getPaymentStatus($transactionId) {
        try {
            $payload = [
                'merchantId' => $this->merchantId,
                'merchantTransactionId' => $transactionId
            ];
            
            $base64Payload = base64_encode(json_encode($payload));
            $checksum = hash('sha256', $base64Payload . '/pg/v1/status' . $this->saltKey) . '###' . $this->saltIndex;
            
            $headers = [
                'Content-Type: application/json',
                'X-VERIFY: ' . $checksum
            ];
            
            $response = $this->makeApiRequest('/pg/v1/status/' . $transactionId, [], $headers, 'GET');
            
            if ($response['success']) {
                return [
                    'status' => $response['data']['state'],
                    'amount' => $response['data']['amount'] / 100,
                    'transactionId' => $response['data']['merchantTransactionId'],
                    'created' => $response['data']['responseTimestamp'],
                    'paymentInstrument' => $response['data']['paymentInstrument']
                ];
            }
            
            throw new PaymentException("Could not retrieve PhonePe payment status");
            
        } catch (Exception $e) {
            $this->logger->error("Error checking PhonePe payment status for {$transactionId}: " . $e->getMessage());
            throw new PaymentException("PhonePe status check failed: " . $e->getMessage());
        }
    }
    
    public function validatePaymentDetails(array $paymentDetails) {
        $requiredFields = ['userId', 'mobileNumber'];
        
        foreach ($requiredFields as $field) {
            if (!isset($paymentDetails[$field]) || empty($paymentDetails[$field])) {
                throw new ValidationException("Missing required PhonePe field: {$field}");
            }
        }
        
        // Validate mobile number format
        if (!preg_match('/^[0-9]{10}$/', $paymentDetails['mobileNumber'])) {
            throw new ValidationException("Invalid mobile number format");
        }
        
        return true;
    }
    
    private function makeApiRequest($endpoint, $payload = [], $headers = [], $method = 'POST') {
        $curl = curl_init();
        
        $url = $this->apiEndpoint . $endpoint;
        
        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers
        ]);
        
        if ($method === 'POST' && !empty($payload)) {
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($payload));
        }
        
        $response = curl_exec($curl);
        $error = curl_error($curl);
        
        curl_close($curl);
        
        if ($error) {
            throw new PaymentException("API request failed: " . $error);
        }
        
        return json_decode($response, true);
    }
}
