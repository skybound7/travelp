<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'luxury_user');
define('DB_PASS', 'luxury_pass_123');
define('DB_NAME', 'luxury_travel');

// Email Configuration
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'your-email@gmail.com');
define('SMTP_PASS', 'your-app-specific-password');
define('ADMIN_EMAIL', 'admin@yourdomain.com');

// File Upload Configuration
define('UPLOAD_DIR', __DIR__ . '/../uploads');
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024); // 10MB

// Cache Configuration
define('CACHE_DIR', __DIR__ . '/../cache');
define('CACHE_LIFETIME', 3600); // 1 hour

// Logging Configuration
define('LOG_DIR', __DIR__ . '/../logs');
define('ERROR_LOG', LOG_DIR . '/error.log');
define('ACCESS_LOG', LOG_DIR . '/access.log');

// Security Configuration
define('SESSION_LIFETIME', 3600); // 1 hour
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_TIMEOUT', 900); // 15 minutes

// API Configuration
define('API_RATE_LIMIT', 100); // requests per hour
define('API_TIMEOUT', 30); // seconds

// Payment Gateway Configuration
define('PAYMENT_MODE', 'test'); // 'test' or 'live'
define('STRIPE_PUBLIC_KEY', 'your-stripe-public-key');
define('STRIPE_SECRET_KEY', 'your-stripe-secret-key');

// Create required directories if they don't exist
$directories = [UPLOAD_DIR, CACHE_DIR, LOG_DIR];
foreach ($directories as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0775, true);
    }
}

// Initialize error logging
ini_set('error_log', ERROR_LOG);
ini_set('log_errors', 1);
error_reporting(E_ALL);

// Set timezone
date_default_timezone_set('UTC');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Security headers
header("X-Frame-Options: SAMEORIGIN");
header("X-XSS-Protection: 1; mode=block");
header("X-Content-Type-Options: nosniff");
header("Referrer-Policy: strict-origin-when-cross-origin");

// Database connection
function getDBConnection() {
    static $conn = null;
    if ($conn === null) {
        try {
            $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            if ($conn->connect_error) {
                throw new Exception("Connection failed: " . $conn->connect_error);
            }
            $conn->set_charset("utf8mb4");
        } catch (Exception $e) {
            error_log("Database connection error: " . $e->getMessage());
            throw $e;
        }
    }
    return $conn;
}
