<?php
require_once __DIR__ . '/../config.php';

class InsuranceManager {
    private $conn;
    
    public function __construct() {
        $this->conn = getDBConnection();
    }
    
    public function getAvailablePlans() {
        $stmt = $this->conn->prepare("
            SELECT * FROM insurance_plans 
            WHERE status = 'active'
            ORDER BY name
        ");
        
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    public function calculatePremium($planId, $itineraryId, $travelersData) {
        // Get plan details
        $stmt = $this->conn->prepare("
            SELECT * FROM insurance_plans WHERE id = ?
        ");
        $stmt->bind_param("i", $planId);
        $stmt->execute();
        $plan = $stmt->get_result()->fetch_assoc();
        
        // Get itinerary details
        $stmt = $this->conn->prepare("
            SELECT * FROM combo_itineraries WHERE id = ?
        ");
        $stmt->bind_param("i", $itineraryId);
        $stmt->execute();
        $itinerary = $stmt->get_result()->fetch_assoc();
        
        // Calculate duration
        $startDate = new DateTime($itinerary['start_date']);
        $endDate = new DateTime($itinerary['end_date']);
        $duration = $startDate->diff($endDate)->days + 1;
        
        // Base calculation factors
        $basePremium = 0;
        $coverage = json_decode($plan['coverage_details'], true);
        
        // Calculate based on coverage levels and duration
        if ($coverage['medical_coverage'] >= 1000000) {
            $basePremium += 50; // Premium medical coverage
        } else {
            $basePremium += 30; // Standard medical coverage
        }
        
        if ($coverage['trip_cancellation']) {
            $basePremium += 25;
        }
        
        if ($coverage['emergency_evacuation']) {
            $basePremium += 20;
        }
        
        // Adjust for number of travelers and their ages
        foreach ($travelersData as $traveler) {
            $age = $traveler['age'];
            $multiplier = 1.0;
            
            if ($age < 18) {
                $multiplier = 0.5;
            } else if ($age > 65) {
                $multiplier = 1.5;
            }
            
            $basePremium += ($basePremium * $multiplier);
        }
        
        // Final adjustment for trip duration
        $totalPremium = $basePremium * $duration;
        
        return round($totalPremium, 2);
    }
    
    public function purchaseInsurance($planId, $itineraryId, $travelersData) {
        $this->conn->begin_transaction();
        
        try {
            $premium = $this->calculatePremium($planId, $itineraryId, $travelersData);
            
            // Get itinerary dates
            $stmt = $this->conn->prepare("
                SELECT start_date, end_date FROM combo_itineraries 
                WHERE id = ?
            ");
            $stmt->bind_param("i", $itineraryId);
            $stmt->execute();
            $itinerary = $stmt->get_result()->fetch_assoc();
            
            // Generate policy number
            $policyNumber = 'POL-' . date('Y') . '-' . str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
            
            // Create insurance record
            $stmt = $this->conn->prepare("
                INSERT INTO itinerary_insurance 
                (itinerary_id, insurance_plan_id, coverage_start_date, 
                coverage_end_date, total_price, policy_number, insured_persons, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 'active')
            ");
            
            $travelersJson = json_encode($travelersData);
            
            $stmt->bind_param("iissdss",
                $itineraryId,
                $planId,
                $itinerary['start_date'],
                $itinerary['end_date'],
                $premium,
                $policyNumber,
                $travelersJson
            );
            
            $stmt->execute();
            $insuranceId = $this->conn->insert_id;
            
            $this->conn->commit();
            
            return [
                'insurance_id' => $insuranceId,
                'policy_number' => $policyNumber,
                'premium' => $premium,
                'status' => 'active'
            ];
        } catch (Exception $e) {
            $this->conn->rollback();
            throw $e;
        }
    }
    
    public function fileClaim($insuranceId, $claimData) {
        $stmt = $this->conn->prepare("
            INSERT INTO insurance_claims 
            (insurance_id, claim_type, description, amount, supporting_documents) 
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $documentsJson = json_encode($claimData['supporting_documents']);
        
        $stmt->bind_param("issds",
            $insuranceId,
            $claimData['claim_type'],
            $claimData['description'],
            $claimData['amount'],
            $documentsJson
        );
        
        if ($stmt->execute()) {
            return $this->conn->insert_id;
        }
        
        return false;
    }
    
    public function getClaimStatus($claimId) {
        $stmt = $this->conn->prepare("
            SELECT ic.*, ii.policy_number
            FROM insurance_claims ic
            JOIN itinerary_insurance ii ON ic.insurance_id = ii.id
            WHERE ic.id = ?
        ");
        
        $stmt->bind_param("i", $claimId);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_assoc();
    }
    
    public function getPolicyDetails($policyNumber) {
        $stmt = $this->conn->prepare("
            SELECT ii.*, ip.name as plan_name, ip.coverage_details,
                   ci.title as itinerary_title
            FROM itinerary_insurance ii
            JOIN insurance_plans ip ON ii.insurance_plan_id = ip.id
            JOIN combo_itineraries ci ON ii.itinerary_id = ci.id
            WHERE ii.policy_number = ?
        ");
        
        $stmt->bind_param("s", $policyNumber);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_assoc();
    }
}
