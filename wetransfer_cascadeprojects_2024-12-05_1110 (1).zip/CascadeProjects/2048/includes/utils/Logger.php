<?php
class Logger {
    private $logFile;
    private $enabled;
    
    public function __construct($logFile, $enabled = true) {
        $this->logFile = $logFile;
        $this->enabled = $enabled;
        
        if ($this->enabled && !file_exists(dirname($logFile))) {
            mkdir(dirname($logFile), 0777, true);
        }
    }
    
    public function log($message, $level = 'INFO') {
        if (!$this->enabled) {
            return;
        }
        
        $timestamp = date('Y-m-d H:i:s');
        $logEntry = sprintf("[%s] [%s] %s\n", $timestamp, strtoupper($level), $message);
        
        file_put_contents($this->logFile, $logEntry, FILE_APPEND);
    }
    
    public function info($message) {
        $this->log($message, 'INFO');
    }
    
    public function error($message) {
        $this->log($message, 'ERROR');
    }
    
    public function warning($message) {
        $this->log($message, 'WARNING');
    }
    
    public function debug($message) {
        if (EMAIL_DEBUG_MODE) {
            $this->log($message, 'DEBUG');
        }
    }
    
    public function getLogContents($lines = 100) {
        if (!file_exists($this->logFile)) {
            return [];
        }
        
        $file = new SplFileObject($this->logFile, 'r');
        $file->seek(PHP_INT_MAX);
        $totalLines = $file->key();
        
        $startLine = max(0, $totalLines - $lines);
        $logs = [];
        
        $file->seek($startLine);
        while (!$file->eof()) {
            $logs[] = $file->current();
            $file->next();
        }
        
        return $logs;
    }
    
    public function clearLog() {
        if (file_exists($this->logFile)) {
            unlink($this->logFile);
        }
    }
}
