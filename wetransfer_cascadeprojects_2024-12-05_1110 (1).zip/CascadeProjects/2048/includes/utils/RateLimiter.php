<?php
class RateLimiter {
    private $conn;
    private $tableName = 'rate_limits';
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->ensureTableExists();
    }
    
    private function ensureTableExists() {
        $sql = "CREATE TABLE IF NOT EXISTS {$this->tableName} (
            id INT PRIMARY KEY AUTO_INCREMENT,
            type VARCHAR(50) NOT NULL,
            count INT DEFAULT 0,
            reset_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_type_reset (type, reset_time)
        )";
        
        $this->conn->query($sql);
    }
    
    public function checkLimit($type, $maxCount, $periodInSeconds) {
        // Clean up old records
        $this->cleanup($type, $periodInSeconds);
        
        // Get current count
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) as current_count 
            FROM {$this->tableName}
            WHERE type = ? 
            AND reset_time > DATE_SUB(NOW(), INTERVAL ? SECOND)
        ");
        
        $stmt->bind_param("si", $type, $periodInSeconds);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        return $result['current_count'] < $maxCount;
    }
    
    public function increment($type) {
        $stmt = $this->conn->prepare("
            INSERT INTO {$this->tableName} (type, count, reset_time)
            VALUES (?, 1, CURRENT_TIMESTAMP)
        ");
        
        $stmt->bind_param("s", $type);
        return $stmt->execute();
    }
    
    private function cleanup($type, $periodInSeconds) {
        $stmt = $this->conn->prepare("
            DELETE FROM {$this->tableName}
            WHERE type = ?
            AND reset_time <= DATE_SUB(NOW(), INTERVAL ? SECOND)
        ");
        
        $stmt->bind_param("si", $type, $periodInSeconds);
        $stmt->execute();
    }
    
    public function getRemainingLimit($type, $maxCount, $periodInSeconds) {
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) as used_count 
            FROM {$this->tableName}
            WHERE type = ? 
            AND reset_time > DATE_SUB(NOW(), INTERVAL ? SECOND)
        ");
        
        $stmt->bind_param("si", $type, $periodInSeconds);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        return $maxCount - $result['used_count'];
    }
    
    public function getNextResetTime($type) {
        $stmt = $this->conn->prepare("
            SELECT MIN(reset_time) as next_reset
            FROM {$this->tableName}
            WHERE type = ?
        ");
        
        $stmt->bind_param("s", $type);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        return $result['next_reset'];
    }
}
