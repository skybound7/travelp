<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Luxury Travel Platform</title>
    
    <!-- Meta Tags -->
    <meta name="description" content="Experience unparalleled luxury travel with our premium services including private jets, yacht charters, and VIP experiences.">
    <meta name="keywords" content="luxury travel, private jets, yacht charter, VIP experiences, helicopter tours, luxury stays">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="/assets/images/favicon.png">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/luxury.css">
    <link rel="stylesheet" href="/css/services.css">
    
    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" defer></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js" defer></script>
    <script src="/js/services-interactive.js" defer></script>
    <script src="/js/main.js" defer></script>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="loader">
            <div class="luxury-spinner"></div>
        </div>
    </div>

    <!-- Language & Currency Selector -->
    <div class="top-bar bg-dark text-white py-2">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="d-flex align-items-center">
                        <div class="dropdown me-3">
                            <button class="btn btn-link text-white dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown">
                                <i class="fas fa-globe me-1"></i> EN
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">English</a></li>
                                <li><a class="dropdown-item" href="#">Français</a></li>
                                <li><a class="dropdown-item" href="#">العربية</a></li>
                                <li><a class="dropdown-item" href="#">中文</a></li>
                            </ul>
                        </div>
                        <div class="dropdown">
                            <button class="btn btn-link text-white dropdown-toggle" type="button" id="currencyDropdown" data-bs-toggle="dropdown">
                                <i class="fas fa-dollar-sign me-1"></i> USD
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">USD ($)</a></li>
                                <li><a class="dropdown-item" href="#">EUR (€)</a></li>
                                <li><a class="dropdown-item" href="#">GBP (£)</a></li>
                                <li><a class="dropdown-item" href="#">AED (د.إ)</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 text-end">
                    <a href="tel:+18001234567" class="text-white me-3">
                        <i class="fas fa-phone-alt me-1"></i> +1 800 123 4567
                    </a>
                    <a href="#" class="text-white" data-bs-toggle="modal" data-bs-target="#contactModal">
                        <i class="fas fa-envelope me-1"></i> Contact Us
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container">
            <a class="navbar-brand" href="/">
                <img src="/assets/images/logo.png" alt="Luxury Travel Logo" height="50">
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="servicesDropdown" role="button" data-bs-toggle="dropdown">
                            Our Services
                        </a>
                        <ul class="dropdown-menu mega-menu">
                            <div class="row">
                                <div class="col-md-4">
                                    <h6 class="dropdown-header">Air Travel</h6>
                                    <li><a class="dropdown-item" href="/services/private-jets.php">Private Jets</a></li>
                                    <li><a class="dropdown-item" href="/services/helicopter-tours.php">Helicopter Tours</a></li>
                                </div>
                                <div class="col-md-4">
                                    <h6 class="dropdown-header">Sea Travel</h6>
                                    <li><a class="dropdown-item" href="/services/yacht-charters.php">Yacht Charters</a></li>
                                    <li><a class="dropdown-item" href="/services/luxury-cruises.php">Luxury Cruises</a></li>
                                </div>
                                <div class="col-md-4">
                                    <h6 class="dropdown-header">Experiences</h6>
                                    <li><a class="dropdown-item" href="/services/vip-experiences.php">VIP Events</a></li>
                                    <li><a class="dropdown-item" href="/services/ultra-luxury-stays.php">Ultra-Luxury Stays</a></li>
                                </div>
                            </div>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="destinationsDropdown" role="button" data-bs-toggle="dropdown">
                            Destinations
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="/destinations/europe.php">Europe</a></li>
                            <li><a class="dropdown-item" href="/destinations/middle-east.php">Middle East</a></li>
                            <li><a class="dropdown-item" href="/destinations/caribbean.php">Caribbean</a></li>
                            <li><a class="dropdown-item" href="/destinations/asia-pacific.php">Asia Pacific</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/about.php">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/blog.php">Travel Journal</a>
                    </li>
                </ul>
                
                <div class="nav-buttons">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" 
                               data-bs-toggle="dropdown">
                                <i class="fas fa-user-crown me-1"></i>My Account
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end royal-dropdown">
                                <li><a class="dropdown-item" href="my-bookings.php">
                                    <i class="fas fa-ticket me-2"></i>My Bookings</a></li>
                                <li><a class="dropdown-item" href="profile.php">
                                    <i class="fas fa-user-edit me-2"></i>Profile</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php">
                                    <i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <a href="#" class="btn btn-outline-primary me-2" data-bs-toggle="modal" data-bs-target="#loginModal">
                            <i class="fas fa-user me-1"></i> Login
                        </a>
                    <?php endif; ?>
                    <a href="/book-now.php" class="btn btn-primary">
                        <i class="fas fa-calendar-check me-1"></i> Book Now
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Search Overlay -->
    <div class="search-overlay">
        <div class="container">
            <div class="search-content">
                <input type="text" class="form-control search-input" placeholder="Search for destinations, services...">
                <div class="search-suggestions"></div>
            </div>
        </div>
    </div>

    <!-- Login Modal -->
    <div class="modal fade" id="loginModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <h4>Welcome Back</h4>
                        <p>Sign in to access your luxury travel account</p>
                    </div>
                    <form>
                        <div class="mb-3">
                            <input type="email" class="form-control" placeholder="Email Address">
                        </div>
                        <div class="mb-3">
                            <input type="password" class="form-control" placeholder="Password">
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="rememberMe">
                            <label class="form-check-label" for="rememberMe">Remember me</label>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Sign In</button>
                    </form>
                    <div class="text-center mt-3">
                        <a href="#" class="text-muted">Forgot Password?</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Contact Modal -->
    <div class="modal fade" id="contactModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <h4>Contact Us</h4>
                        <p>Our luxury travel experts are here to help</p>
                    </div>
                    <form>
                        <div class="mb-3">
                            <input type="text" class="form-control" placeholder="Full Name">
                        </div>
                        <div class="mb-3">
                            <input type="email" class="form-control" placeholder="Email Address">
                        </div>
                        <div class="mb-3">
                            <input type="tel" class="form-control" placeholder="Phone Number">
                        </div>
                        <div class="mb-3">
                            <textarea class="form-control" rows="4" placeholder="How can we help you?"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
