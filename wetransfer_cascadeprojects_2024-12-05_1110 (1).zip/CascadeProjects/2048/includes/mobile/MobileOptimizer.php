<?php
class MobileOptimizer {
    private $conn;
    private $config;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->config = [
            'viewport_width' => 'device-width',
            'initial_scale' => '1.0',
            'minimum_touch_target' => 44, // pixels
            'font_size_minimum' => 16 // pixels
        ];
    }
    
    public function getMobileMetaTags() {
        return [
            '<meta name="viewport" content="width=' . $this->config['viewport_width'] . 
                ', initial-scale=' . $this->config['initial_scale'] . 
                ', minimum-scale=1.0, maximum-scale=5.0, user-scalable=yes">',
            '<meta name="theme-color" content="#D4AF37">',
            '<meta name="mobile-web-app-capable" content="yes">',
            '<meta name="apple-mobile-web-app-capable" content="yes">',
            '<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">',
            '<link rel="manifest" href="/manifest.json">'
        ];
    }
    
    public function optimizeTouchTargets() {
        return <<<EOT
<style>
/* Ensure minimum touch target size */
button, 
.button, 
input[type="button"], 
input[type="submit"],
input[type="reset"],
.nav-link,
.menu-item {
    min-width: {$this->config['minimum_touch_target']}px;
    min-height: {$this->config['minimum_touch_target']}px;
    padding: 12px 16px;
    margin: 4px;
}

/* Adjust spacing for touch targets */
.nav-menu > li,
.footer-links > li {
    margin: 8px 0;
}

/* Ensure readable font sizes on mobile */
body {
    font-size: {$this->config['font_size_minimum']}px;
}

@media (max-width: 768px) {
    .container {
        padding-left: 16px;
        padding-right: 16px;
    }
    
    h1 { font-size: 2em; }
    h2 { font-size: 1.75em; }
    h3 { font-size: 1.5em; }
    
    .mobile-stack {
        flex-direction: column !important;
    }
    
    .mobile-full-width {
        width: 100% !important;
    }
}
</style>
EOT;
    }
    
    public function generateManifest() {
        $manifest = [
            'name' => 'Luxury Travel Platform',
            'short_name' => 'LuxTravel',
            'start_url' => '/',
            'display' => 'standalone',
            'background_color' => '#FFFFFF',
            'theme_color' => '#D4AF37',
            'icons' => [
                [
                    'src' => '/assets/icons/icon-72x72.png',
                    'sizes' => '72x72',
                    'type' => 'image/png'
                ],
                [
                    'src' => '/assets/icons/icon-96x96.png',
                    'sizes' => '96x96',
                    'type' => 'image/png'
                ],
                [
                    'src' => '/assets/icons/icon-128x128.png',
                    'sizes' => '128x128',
                    'type' => 'image/png'
                ],
                [
                    'src' => '/assets/icons/icon-144x144.png',
                    'sizes' => '144x144',
                    'type' => 'image/png'
                ],
                [
                    'src' => '/assets/icons/icon-152x152.png',
                    'sizes' => '152x152',
                    'type' => 'image/png'
                ],
                [
                    'src' => '/assets/icons/icon-192x192.png',
                    'sizes' => '192x192',
                    'type' => 'image/png'
                ],
                [
                    'src' => '/assets/icons/icon-384x384.png',
                    'sizes' => '384x384',
                    'type' => 'image/png'
                ],
                [
                    'src' => '/assets/icons/icon-512x512.png',
                    'sizes' => '512x512',
                    'type' => 'image/png'
                ]
            ]
        ];
        
        return json_encode($manifest, JSON_PRETTY_PRINT);
    }
    
    public function enableOfflineSupport() {
        return <<<EOT
<!-- Service Worker Registration -->
<script>
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/sw.js').then(function(registration) {
            console.log('ServiceWorker registration successful');
        }).catch(function(err) {
            console.log('ServiceWorker registration failed: ', err);
        });
    });
}
</script>
EOT;
    }
    
    public function generateServiceWorker() {
        return <<<EOT
// Service Worker
const CACHE_NAME = 'luxury-travel-v1';
const urlsToCache = [
    '/',
    '/assets/css/style.css',
    '/assets/js/main.js',
    '/assets/images/logo.png',
    '/offline.html'
];

self.addEventListener('install', function(event) {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(function(cache) {
                return cache.addAll(urlsToCache);
            })
    );
});

self.addEventListener('fetch', function(event) {
    event.respondWith(
        caches.match(event.request)
            .then(function(response) {
                if (response) {
                    return response;
                }
                return fetch(event.request).then(
                    function(response) {
                        if(!response || response.status !== 200 || response.type !== 'basic') {
                            return response;
                        }
                        
                        var responseToCache = response.clone();
                        
                        caches.open(CACHE_NAME)
                            .then(function(cache) {
                                cache.put(event.request, responseToCache);
                            });
                            
                        return response;
                    }
                );
            }).catch(function() {
                return caches.match('/offline.html');
            })
    );
});

self.addEventListener('activate', function(event) {
    event.waitUntil(
        caches.keys().then(function(cacheNames) {
            return Promise.all(
                cacheNames.map(function(cacheName) {
                    if (cacheName !== CACHE_NAME) {
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});
EOT;
    }
}
?>
