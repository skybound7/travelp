
<?php
require_once __DIR__ . '/../security/SecurityManager.php';

class CookieManager {
    private $conn;
    private $config;
    private $security;

    public function __construct($conn) {
        $this->conn = $conn;
        $this->security = SecurityManager::getInstance();
        $this->config = [
            'cookie_lifetime' => 365, // days
            'necessary_cookies' => ['session_id', 'csrf_token'],
            'functional_cookies' => ['language', 'theme'],
            'analytics_cookies' => ['_ga', '_gid', '_fbp'],
            'marketing_cookies' => ['ads_id', 'campaign_id']
        ];
    }

    /**
     * Set a cookie with secure parameters
     */
    public function setCookie($name, $value, $options = []) {
        $default_options = [
            'expires' => time() + ($this->config['cookie_lifetime'] * 86400),
            'path' => '/',
            'domain' => '',
            'secure' => true,
            'httponly' => true,
     luxury_travel_site_[timestamp].zip
     ├── site_files/
     │   ├── assets/
     │   ├── css/
     │   ├── includes/
     │   ├── js/
     │   ├── templates/
     │   └── [root files]
     ├── database/
     │   ├── structure.sql
     │   └── data.sql
     └── manifest.json       'samesite' => 'Strict'
        ];

        $options = array_merge($default_options, $options);
        $value = $this->security->validateInput($value, 'text');

        setcookie(
            $name,
            $value,
            [
                'expires' => $options['expires'],
                'path' => $options['path'],
                'domain' => $options['domain'],
                'secure' => $options['secure'],
                'httponly' => $options['httponly'],
                'samesite' => $options['samesite']
            ]
        );

        $this->logCookieEvent('set', $name);
    }

    /**
     * Update user's cookie preferences
     */
    public function updateCookiePreferences($preferences) {
        $user_id = $_SESSION['user_id'] ?? null;
        $validated_prefs = [];

        foreach ($preferences as $category => $enabled) {
            $validated_prefs[$category] = $this->security->validateInput($enabled, 'int');
        }

        $stmt = $this->conn->prepare("
            INSERT INTO cookie_preferences (user_id, functional, analytics, marketing, updated_at)
            VALUES (?, ?, ?, ?, NOW())
            ON DUPLICATE KEY UPDATE
                functional = ?,
                analytics = ?,
                marketing = ?,
                updated_at = NOW()
        ");

        $stmt->bind_param(
            "iiiiiii",
            $user_id,
            $validated_prefs['functional'],
            $validated_prefs['analytics'],
            $validated_prefs['marketing'],
            $validated_prefs['functional'],
            $validated_prefs['analytics'],
            $validated_prefs['marketing']
        );

        if ($stmt->execute()) {
            $this->logConsentUpdate($validated_prefs);
            return true;
        }

        return false;
    }

    /**
     * Log cookie consent updates
     */
    private function logConsentUpdate($preferences) {
        $this->security->logSecurityEvent(
            'cookie_consent_update',
            json_encode($preferences),
            'medium'
        );

        $stmt = $this->conn->prepare("
            INSERT INTO consent_logs (
                user_id,
                ip_address,
                user_agent,
                consent_data,
                timestamp
            ) VALUES (?, ?, ?, ?, NOW())
        ");

        $user_id = $_SESSION['user_id'] ?? null;
        $ip = $_SERVER['REMOTE_ADDR'];
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $consent_data = json_encode($preferences);

        $stmt->bind_param(
            "isss",
            $user_id,
            $ip,
            $user_agent,
            $consent_data
        );

        $stmt->execute();
    }

    /**
     * Check if a specific cookie category is allowed
     */
    public function isCookieCategoryAllowed($category) {
        $user_id = $_SESSION['user_id'] ?? null;

        if ($category === 'necessary') {
            return true; // Necessary cookies are always allowed
        }

        $stmt = $this->conn->prepare("
            SELECT $category
            FROM cookie_preferences
            WHERE user_id = ?
            ORDER BY updated_at DESC
            LIMIT 1
        ");

        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            return (bool)$row[$category];
        }

        return false; // Default to not allowed if no preferences set
    }

    /**
     * Log cookie-related events
     */
    private function logCookieEvent($action, $cookie_name) {
        $this->security->logSecurityEvent(
            'cookie_' . $action,
            "Cookie: $cookie_name",
            'low'
        );
    }

    /**
     * Get user's current cookie preferences
     */
    public function getCookiePreferences() {
        $user_id = $_SESSION['user_id'] ?? null;

        $stmt = $this->conn->prepare("
            SELECT functional, analytics, marketing, updated_at
            FROM cookie_preferences
            WHERE user_id = ?
            ORDER BY updated_at DESC
            LIMIT 1
        ");

        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            return [
                'functional' => (bool)$row['functional'],
                'analytics' => (bool)$row['analytics'],
                'marketing' => (bool)$row['marketing'],
                'last_updated' => $row['updated_at']
            ];
        }

        return [
            'functional' => false,
            'analytics' => false,
            'marketing' => false,
            'last_updated' => null
        ];
    }

    public function getCookieConsentBanner() {
        $preferences = $this->getCookiePreferences();

        return <<<HTML
        <div id="cookie-consent" class="cookie-consent">
            <div class="cookie-modal">
                <div class="modal-header">
                    <h2>Privacy Preferences</h2>
                    <button id="cookie-close" class="close-button" aria-label="Close">×</button>
                </div>

                <div class="modal-tabs">
                    <button class="tab-button active" data-tab="privacy">Privacy Settings</button>
                    <button class="tab-button" data-tab="details">Cookie Details</button>
                </div>

                <div class="modal-content">
                    <div id="tab-privacy" class="tab-content active">
                        <p class="consent-description">
                            We use cookies to enhance your browsing experience, serve personalized content, and analyze our traffic.
                            Please select which cookies you're willing to store on your device.
                        </p>

                        <div class="cookie-options">
                            <div class="cookie-option">
                                <label class="switch-label">
                                    <input type="checkbox" id="necessary-cookies" checked disabled>
                                    <span class="switch"></span>
                                    <span class="label-text">
                                        <strong>Necessary Cookies</strong>
                                        <small>Required for the website to function properly</small>
                                    </span>
                                </label>
                            </div>

                            <div class="cookie-option">
                                <label class="switch-label">
                                    <input type="checkbox" id="functional-cookies" 
                                        {$preferences['functional'] ? 'checked' : ''}>
                                    <span class="switch"></span>
                                    <span class="label-text">
                                        <strong>Functional Cookies</strong>
                                        <small>Remember your preferences and personalize your experience</small>
                                    </span>
                                </label>
                            </div>

                            <div class="cookie-option">
                                <label class="switch-label">
                                    <input type="checkbox" id="analytics-cookies"
                                        {$preferences['analytics'] ? 'checked' : ''}>
                                    <span class="switch"></span>
                                    <span class="label-text">
                                        <strong>Analytics Cookies</strong>
                                        <small>Help us improve our website by collecting anonymous usage data</small>
                                    </span>
                                </label>
                            </div>

                            <div class="cookie-option">
                                <label class="switch-label">
                                    <input type="checkbox" id="marketing-cookies"
                                        {$preferences['marketing'] ? 'checked' : ''}>
                                    <span class="switch"></span>
                                    <span class="label-text">
                                        <strong>Marketing Cookies</strong>
                                        <small>Allow us to personalize advertisements across platforms</small>
                                    </span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div id="tab-details" class="tab-content">
                        <div class="cookie-details">
                            <h3>Cookie Information</h3>
                            <table class="cookie-table">
                                <thead>
                                    <tr>
                                        <th>Category</th>
                                        <th>Purpose</th>
                                        <th>Duration</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Necessary</td>
                                        <td>Essential for website functionality, authentication, and security</td>
                                        <td>Session</td>
                                    </tr>
                                    <tr>
                                        <td>Functional</td>
                                        <td>Remember language preferences, themes, and customizations</td>
                                        <td>1 year</td>
                                    </tr>
                                    <tr>
                                        <td>Analytics</td>
                                        <td>Track website usage patterns and improve user experience</td>
                                        <td>2 years</td>
                                    </tr>
                                    <tr>
                                        <td>Marketing</td>
                                        <td>Display personalized advertisements and track campaign effectiveness</td>
                                        <td>1 year</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button id="accept-all-cookies" class="btn-primary">Accept All</button>
                    <button id="save-preferences" class="btn-secondary">Save Preferences</button>
                </div>
            </div>
        </div>
        HTML;
    }
}