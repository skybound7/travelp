<?php
class DataRequestManager {
    private $conn;
    private $config;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->config = [
            'request_expiry_days' => 30,
            'max_requests_per_user' => 2,
            'processing_time_days' => 30,
            'notification_email' => 'privacy@luxurytravel.com'
        ];
    }
    
    public function createDataRequest($userId, $requestType, $additionalData = []) {
        // Validate request type
        if (!in_array($requestType, ['export', 'delete', 'update', 'restrict'])) {
            throw new Exception('Invalid request type');
        }
        
        // Check existing requests
        if ($this->hasActiveRequests($userId)) {
            throw new Exception('You have pending data requests');
        }
        
        // Create request
        $stmt = $this->conn->prepare("
            INSERT INTO data_requests (
                user_id,
                request_type,
                status,
                additional_data,
                ip_address,
                user_agent,
                created_at,
                expires_at
            ) VALUES (?, ?, 'pending', ?, ?, ?, NOW(), DATE_ADD(NOW(), INTERVAL ? DAY))
        ");
        
        $additionalDataJson = json_encode($additionalData);
        $ipAddress = $_SERVER['REMOTE_ADDR'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        
        $stmt->bind_param('issssi',
            $userId,
            $requestType,
            $additionalDataJson,
            $ipAddress,
            $userAgent,
            $this->config['request_expiry_days']
        );
        
        $stmt->execute();
        $requestId = $stmt->insert_id;
        
        // Notify admin
        $this->notifyAdmin($requestId, $userId, $requestType);
        
        return $requestId;
    }
    
    public function processDataRequest($requestId) {
        $request = $this->getRequest($requestId);
        
        switch ($request['request_type']) {
            case 'export':
                return $this->exportUserData($request['user_id']);
            case 'delete':
                return $this->deleteUserData($request['user_id']);
            case 'update':
                return $this->updateUserData($request['user_id'], json_decode($request['additional_data'], true));
            case 'restrict':
                return $this->restrictProcessing($request['user_id']);
        }
    }
    
    private function exportUserData($userId) {
        $data = [
            'personal_info' => $this->getPersonalInfo($userId),
            'bookings' => $this->getBookings($userId),
            'preferences' => $this->getPreferences($userId),
            'marketing_preferences' => $this->getMarketingPreferences($userId),
            'login_history' => $this->getLoginHistory($userId)
        ];
        
        // Generate PDF report
        $pdf = $this->generatePdfReport($data);
        
        // Store for download
        $filename = "user_data_export_{$userId}_" . date('Ymd_His') . ".pdf";
        file_put_contents(__DIR__ . "/../../exports/{$filename}", $pdf);
        
        return $filename;
    }
    
    private function deleteUserData($userId) {
        // Start transaction
        $this->conn->begin_transaction();
        
        try {
            // Anonymize personal data
            $this->anonymizeUserData($userId);
            
            // Delete non-essential data
            $this->deleteNonEssentialData($userId);
            
            // Mark account as deleted
            $this->markAccountDeleted($userId);
            
            $this->conn->commit();
            return true;
        } catch (Exception $e) {
            $this->conn->rollback();
            throw $e;
        }
    }
    
    private function updateUserData($userId, $newData) {
        $allowedFields = ['email', 'phone', 'address', 'preferences'];
        $updates = array_intersect_key($newData, array_flip($allowedFields));
        
        if (empty($updates)) {
            throw new Exception('No valid fields to update');
        }
        
        foreach ($updates as $field => $value) {
            $stmt = $this->conn->prepare("
                UPDATE users 
                SET {$field} = ?,
                    updated_at = NOW()
                WHERE id = ?
            ");
            
            $stmt->bind_param('si', $value, $userId);
            $stmt->execute();
        }
        
        return true;
    }
    
    private function restrictProcessing($userId) {
        $stmt = $this->conn->prepare("
            UPDATE users 
            SET processing_restricted = 1,
                updated_at = NOW()
            WHERE id = ?
        ");
        
        $stmt->bind_param('i', $userId);
        return $stmt->execute();
    }
    
    private function hasActiveRequests($userId) {
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) as count
            FROM data_requests
            WHERE user_id = ?
            AND status = 'pending'
            AND created_at > DATE_SUB(NOW(), INTERVAL ? DAY)
        ");
        
        $stmt->bind_param('ii', $userId, $this->config['request_expiry_days']);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        return $result['count'] >= $this->config['max_requests_per_user'];
    }
    
    private function notifyAdmin($requestId, $userId, $requestType) {
        $subject = "New Data Request #{$requestId}";
        $message = "A new {$requestType} request has been submitted by user {$userId}";
        
        mail(
            $this->config['notification_email'],
            $subject,
            $message,
            "From: system@luxurytravel.com\r\n"
        );
    }
    
    private function getRequest($requestId) {
        $stmt = $this->conn->prepare("
            SELECT *
            FROM data_requests
            WHERE id = ?
        ");
        
        $stmt->bind_param('i', $requestId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    
    // Helper methods for data export
    private function getPersonalInfo($userId) {
        $stmt = $this->conn->prepare("
            SELECT id, email, name, phone, address, created_at
            FROM users
            WHERE id = ?
        ");
        
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    
    private function getBookings($userId) {
        $stmt = $this->conn->prepare("
            SELECT *
            FROM bookings
            WHERE user_id = ?
            ORDER BY created_at DESC
        ");
        
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    private function getPreferences($userId) {
        $stmt = $this->conn->prepare("
            SELECT *
            FROM user_preferences
            WHERE user_id = ?
        ");
        
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    
    private function getMarketingPreferences($userId) {
        $stmt = $this->conn->prepare("
            SELECT *
            FROM marketing_preferences
            WHERE user_id = ?
        ");
        
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    
    private function getLoginHistory($userId) {
        $stmt = $this->conn->prepare("
            SELECT timestamp, ip_address, user_agent
            FROM login_history
            WHERE user_id = ?
            ORDER BY timestamp DESC
            LIMIT 50
        ");
        
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    private function generatePdfReport($data) {
        // Implementation would use a PDF library like TCPDF or FPDF
        // This is a placeholder
        return json_encode($data);
    }
    
    private function anonymizeUserData($userId) {
        $stmt = $this->conn->prepare("
            UPDATE users
            SET 
                email = CONCAT('deleted_', id, '@anonymous.com'),
                name = CONCAT('Anonymous User ', id),
                phone = NULL,
                address = NULL,
                is_anonymized = 1,
                anonymized_at = NOW()
            WHERE id = ?
        ");
        
        $stmt->bind_param('i', $userId);
        $stmt->execute();
    }
    
    private function deleteNonEssentialData($userId) {
        // Delete marketing preferences
        $stmt = $this->conn->prepare("
            DELETE FROM marketing_preferences WHERE user_id = ?
        ");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        
        // Delete user preferences
        $stmt = $this->conn->prepare("
            DELETE FROM user_preferences WHERE user_id = ?
        ");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        
        // Delete login history
        $stmt = $this->conn->prepare("
            DELETE FROM login_history WHERE user_id = ?
        ");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
    }
    
    private function markAccountDeleted($userId) {
        $stmt = $this->conn->prepare("
            UPDATE users
            SET 
                status = 'deleted',
                deleted_at = NOW()
            WHERE id = ?
        ");
        
        $stmt->bind_param('i', $userId);
        $stmt->execute();
    }
}

// Create necessary tables
$dataTables = "
CREATE TABLE IF NOT EXISTS data_requests (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    request_type ENUM('export', 'delete', 'update', 'restrict') NOT NULL,
    status ENUM('pending', 'processing', 'completed', 'failed') NOT NULL,
    additional_data JSON,
    ip_address VARCHAR(45),
    user_agent VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,
    expires_at TIMESTAMP NULL,
    INDEX idx_user (user_id),
    INDEX idx_status (status),
    INDEX idx_type (request_type)
);

CREATE TABLE IF NOT EXISTS login_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    ip_address VARCHAR(45),
    user_agent VARCHAR(255),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_timestamp (timestamp)
);

CREATE TABLE IF NOT EXISTS marketing_preferences (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    email_marketing BOOLEAN DEFAULT FALSE,
    sms_marketing BOOLEAN DEFAULT FALSE,
    phone_marketing BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL,
    UNIQUE KEY idx_user (user_id)
);
";
?>
