<?php
require_once __DIR__ . '/../payments/PaymentFactory.php';
require_once __DIR__ . '/../utils/Logger.php';

class PaymentManager {
    private $logger;
    private $conn;
    
    public function __construct() {
        $this->logger = new Logger(PAYMENT_LOG_FILE, PAYMENT_LOG_ENABLED);
        $this->conn = getDBConnection();
    }
    
    public function initiatePayment($bookingId, $bookingType, $amount, $paymentMethod, $paymentDetails) {
        try {
            $this->logger->debug("Initiating payment - BookingID: {$bookingId}, Type: {$bookingType}, Amount: {$amount}, Method: {$paymentMethod}");
            $this->logger->debug("Payment Details: " . json_encode($paymentDetails));
            
            // Validate payment method
            if (!PaymentFactory::validatePaymentMethod($paymentMethod)) {
                $this->logger->error("Invalid payment method: {$paymentMethod}");
                throw new Exception("Invalid payment method: {$paymentMethod}");
            }
            $this->logger->debug("Payment method validated successfully");
            
            // Generate merchant transaction ID
            $merchantTransactionId = 'TXN_' . $bookingId . '_' . time() . '_' . substr(md5(uniqid()), 0, 8);
            $this->logger->debug("Generated merchant transaction ID: {$merchantTransactionId}");
            
            // Get payment processor
            $processor = PaymentFactory::getProcessor($paymentMethod);
            $this->logger->debug("Payment processor initialized: " . get_class($processor));
            
            // Add booking metadata to payment details
            $paymentDetails['bookingMetadata'] = [
                'bookingId' => $bookingId,
                'bookingType' => $bookingType,
                'amount' => $amount,
                'merchantTransactionId' => $merchantTransactionId
            ];
            $this->logger->debug("Added booking metadata to payment details");
            
            // Process payment
            $this->logger->debug("Processing payment with processor...");
            $result = $processor->processPayment($bookingId, $bookingType, $amount, $paymentDetails);
            $this->logger->debug("Payment processor result: " . json_encode($result));
            
            // Add merchant transaction ID to result
            $result['merchantTransactionId'] = $merchantTransactionId;
            
            // Record payment attempt
            $this->logger->debug("Recording payment attempt in database...");
            $this->recordPaymentAttempt($bookingId, $bookingType, $paymentMethod, $amount, $result);
            $this->logger->debug("Payment attempt recorded successfully");
            
            return $result;
            
        } catch (Exception $e) {
            $this->logger->error("Payment initiation failed: " . $e->getMessage());
            $this->logger->debug("Error trace: " . $e->getTraceAsString());
            throw $e;
        }
    }
    
    public function handlePaymentCallback($paymentMethod, $data) {
        try {
            $this->logger->debug("Handling payment callback - Method: {$paymentMethod}, Data: " . json_encode($data));
            
            $processor = PaymentFactory::getProcessor($paymentMethod);
            $this->logger->debug("Payment processor initialized: " . get_class($processor));
            
            // Validate required data
            if (!isset($data['transactionId'], $data['merchantTransactionId'])) {
                $this->logger->error("Missing transaction details");
                throw new Exception("Missing transaction details");
            }
            $this->logger->debug("Transaction details validated successfully");
            
            // Get original payment attempt
            $stmt = $this->conn->prepare("
                SELECT booking_id, booking_type, amount, status
                FROM payment_attempts
                WHERE merchant_transaction_id = ?
                ORDER BY created_at DESC
                LIMIT 1
            ");
            
            $stmt->bind_param("s", $data['merchantTransactionId']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if (!$result || !($attempt = $result->fetch_assoc())) {
                $this->logger->error("Original payment attempt not found");
                throw new Exception("Original payment attempt not found");
            }
            $this->logger->debug("Original payment attempt found: " . json_encode($attempt));
            
            // Verify payment status
            $this->logger->debug("Verifying payment status with processor...");
            $status = $processor->getPaymentStatus($data['transactionId']);
            $this->logger->debug("Payment status: " . json_encode($status));
            
            // Validate amount if payment is successful
            if ($status['status'] === 'completed' && abs($status['amount'] - $attempt['amount']) > 0.01) {
                $this->logger->error("Payment amount mismatch");
                throw new Exception("Payment amount mismatch");
            }
            $this->logger->debug("Payment amount validated successfully");
            
            // Only process if payment is not already completed
            if ($attempt['status'] === 'completed') {
                $this->logger->debug("Payment already completed, returning status");
                return $status;
            }
            
            if ($status['status'] === 'completed') {
                $this->logger->debug("Confirming payment...");
                $this->confirmPayment(
                    $attempt['booking_id'],
                    $attempt['booking_type'],
                    $data['transactionId'],
                    $status['amount'],
                    $data['merchantTransactionId']
                );
                $this->logger->debug("Payment confirmed successfully");
            } else if (in_array($status['status'], ['failed', 'cancelled'])) {
                $this->logger->debug("Handling failed payment...");
                $this->handleFailedPayment(
                    $attempt['booking_id'],
                    $attempt['booking_type'],
                    $data['transactionId'],
                    $status['status'],
                    $data['merchantTransactionId']
                );
                $this->logger->debug("Failed payment handled successfully");
            }
            
            return $status;
            
        } catch (Exception $e) {
            $this->logger->error("Payment callback handling failed: " . $e->getMessage());
            $this->logger->debug("Error trace: " . $e->getTraceAsString());
            throw $e;
        }
    }
    
    private function confirmPayment($bookingId, $bookingType, $transactionId, $amount, $merchantTransactionId) {
        try {
            $this->logger->debug("Confirming payment - BookingID: {$bookingId}, Type: {$bookingType}, Amount: {$amount}, TransactionID: {$transactionId}, MerchantTransactionID: {$merchantTransactionId}");
            
            $this->conn->begin_transaction();
            
            // Verify booking status
            $stmt = $this->conn->prepare("
                SELECT status, payment_status, amount
                FROM {$bookingType}_bookings
                WHERE id = ?
                FOR UPDATE
            ");
            
            $stmt->bind_param("i", $bookingId);
            $stmt->execute();
            $result = $stmt->get_result();
            $booking = $result->fetch_assoc();
            
            if (!$booking) {
                $this->logger->error("Booking not found");
                throw new Exception("Booking not found");
            }
            $this->logger->debug("Booking found: " . json_encode($booking));
            
            if ($booking['payment_status'] === 'paid') {
                $this->logger->error("Payment already processed");
                throw new Exception("Payment already processed");
            }
            $this->logger->debug("Payment not already processed");
            
            if (!in_array($booking['status'], ['pending_payment', 'processing_payment'])) {
                $this->logger->error("Invalid booking status for payment");
                throw new Exception("Invalid booking status for payment");
            }
            $this->logger->debug("Booking status validated successfully");
            
            // Validate amount
            if (abs($booking['amount'] - $amount) > 0.01) {
                $this->logger->error("Payment amount mismatch");
                throw new Exception("Payment amount mismatch");
            }
            $this->logger->debug("Payment amount validated successfully");
            
            // Update payment record
            $stmt = $this->conn->prepare("
                UPDATE payments 
                SET status = 'completed', 
                    completed_at = CURRENT_TIMESTAMP,
                    transaction_id = ?,
                    merchant_transaction_id = ?
                WHERE booking_id = ? 
                AND booking_type = ?
            ");
            
            $stmt->bind_param("ssis", $transactionId, $merchantTransactionId, $bookingId, $bookingType);
            $stmt->execute();
            $this->logger->debug("Payment record updated successfully");
            
            // Update payment attempt
            $stmt = $this->conn->prepare("
                UPDATE payment_attempts
                SET status = 'completed',
                    transaction_id = ?
                WHERE merchant_transaction_id = ?
            ");
            
            $stmt->bind_param("ss", $transactionId, $merchantTransactionId);
            $stmt->execute();
            $this->logger->debug("Payment attempt updated successfully");
            
            // Update booking status
            $stmt = $this->conn->prepare("
                UPDATE {$bookingType}_bookings 
                SET status = 'confirmed',
                    payment_status = 'paid',
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");
            
            $stmt->bind_param("i", $bookingId);
            $stmt->execute();
            $this->logger->debug("Booking status updated successfully");
            
            $this->conn->commit();
            $this->logger->debug("Transaction committed successfully");
            
            // Send confirmation email
            $emailManager = new EmailManager();
            if ($bookingType === 'eurail') {
                $emailManager->sendEurailBookingConfirmation($bookingId);
            } else {
                $emailManager->sendExcursionBookingConfirmation($bookingId);
            }
            $this->logger->debug("Confirmation email sent successfully");
            
        } catch (Exception $e) {
            $this->conn->rollback();
            $this->logger->error("Payment confirmation failed: " . $e->getMessage());
            $this->logger->debug("Error trace: " . $e->getTraceAsString());
            throw $e;
        }
    }
    
    private function handleFailedPayment($bookingId, $bookingType, $transactionId, $status, $merchantTransactionId) {
        try {
            $this->logger->debug("Handling failed payment - BookingID: {$bookingId}, Type: {$bookingType}, TransactionID: {$transactionId}, Status: {$status}, MerchantTransactionID: {$merchantTransactionId}");
            
            $this->conn->begin_transaction();
            
            // Update payment record
            $stmt = $this->conn->prepare("
                UPDATE payments 
                SET status = ?,
                    updated_at = CURRENT_TIMESTAMP,
                    transaction_id = ?,
                    merchant_transaction_id = ?
                WHERE booking_id = ? 
                AND booking_type = ?
            ");
            
            $stmt->bind_param("ssssis", $status, $transactionId, $merchantTransactionId, $bookingId, $bookingType);
            $stmt->execute();
            $this->logger->debug("Payment record updated successfully");
            
            // Update payment attempt
            $stmt = $this->conn->prepare("
                UPDATE payment_attempts
                SET status = ?,
                    transaction_id = ?
                WHERE merchant_transaction_id = ?
            ");
            
            $stmt->bind_param("sss", $status, $transactionId, $merchantTransactionId);
            $stmt->execute();
            $this->logger->debug("Payment attempt updated successfully");
            
            // Update booking status
            $stmt = $this->conn->prepare("
                UPDATE {$bookingType}_bookings 
                SET status = 'payment_failed',
                    payment_status = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");
            
            $stmt->bind_param("si", $status, $bookingId);
            $stmt->execute();
            $this->logger->debug("Booking status updated successfully");
            
            $this->conn->commit();
            $this->logger->debug("Transaction committed successfully");
            
            // Send failure notification
            $emailManager = new EmailManager();
            $emailManager->sendPaymentFailureNotification($bookingId, $bookingType);
            $this->logger->debug("Failure notification sent successfully");
            
        } catch (Exception $e) {
            $this->conn->rollback();
            $this->logger->error("Failed payment handling failed: " . $e->getMessage());
            $this->logger->debug("Error trace: " . $e->getTraceAsString());
            throw $e;
        }
    }
    
    private function recordPaymentAttempt($bookingId, $bookingType, $paymentMethod, $amount, $result) {
        try {
            $this->logger->debug("Recording payment attempt - BookingID: {$bookingId}, Type: {$bookingType}, Method: {$paymentMethod}, Amount: {$amount}, Result: " . json_encode($result));
            
            $stmt = $this->conn->prepare("
                INSERT INTO payment_attempts (
                    booking_id, 
                    booking_type,
                    payment_method,
                    amount,
                    transaction_id,
                    merchant_transaction_id,
                    status,
                    response_data,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ");
            
            $responseData = json_encode($result);
            $status = $result['status'] ?? 'initiated';
            $transactionId = $result['transactionId'] ?? null;
            $merchantTransactionId = $result['merchantTransactionId'] ?? null;
            
            $stmt->bind_param(
                "issdsss",
                $bookingId,
                $bookingType,
                $paymentMethod,
                $amount,
                $transactionId,
                $merchantTransactionId,
                $status,
                $responseData
            );
            
            $stmt->execute();
            $this->logger->debug("Payment attempt recorded successfully");
            
        } catch (Exception $e) {
            $this->logger->error("Failed to record payment attempt: " . $e->getMessage());
            $this->logger->debug("Error trace: " . $e->getTraceAsString());
            throw $e;
        }
    }
    
    public function getAvailablePaymentMethods() {
        $this->logger->debug("Getting available payment methods");
        return PaymentFactory::getAvailablePaymentMethods();
    }
    
    public function getPaymentStatus($bookingId, $bookingType) {
        $this->logger->debug("Getting payment status - BookingID: {$bookingId}, Type: {$bookingType}");
        
        $stmt = $this->conn->prepare("
            SELECT p.*, pa.payment_method, pa.response_data
            FROM payments p
            LEFT JOIN payment_attempts pa ON p.transaction_id = pa.transaction_id
            WHERE p.booking_id = ? AND p.booking_type = ?
            ORDER BY p.created_at DESC
            LIMIT 1
        ");
        
        $stmt->bind_param("is", $bookingId, $bookingType);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_assoc();
    }
}
