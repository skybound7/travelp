<?php
require_once __DIR__ . '/../config.php';

class ServiceManager {
    private $conn;
    
    public function __construct() {
        $this->conn = getDBConnection();
    }
    
    // Eurail Pass Booking
    public function bookEurailPass($userId, $bookingData) {
        try {
            $this->conn->begin_transaction();
            
            $stmt = $this->conn->prepare("
                INSERT INTO eurail_bookings 
                (user_id, pass_type, duration, start_date, passengers, countries, total_price, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
            ");
            
            $countriesJson = json_encode($bookingData['countries']);
            
            $stmt->bind_param("isisids", 
                $userId,
                $bookingData['passType'],
                $bookingData['duration'],
                $bookingData['startDate'],
                $bookingData['passengers'],
                $countriesJson,
                $bookingData['totalPrice']
            );
            
            $stmt->execute();
            $bookingId = $this->conn->insert_id;
            
            // Create payment record
            $this->createPaymentRecord($bookingId, 'eurail', $bookingData['totalPrice']);
            
            $this->conn->commit();
            return $bookingId;
            
        } catch (Exception $e) {
            $this->conn->rollback();
            throw $e;
        }
    }
    
    // Excursion Booking
    public function bookExcursion($userId, $bookingData) {
        try {
            $this->conn->begin_transaction();
            
            $stmt = $this->conn->prepare("
                INSERT INTO excursion_bookings 
                (user_id, excursion_type, destination, excursion_date, group_size, special_requests, total_price, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
            ");
            
            $stmt->bind_param("isssiss", 
                $userId,
                $bookingData['excursionType'],
                $bookingData['destination'],
                $bookingData['excursionDate'],
                $bookingData['groupSize'],
                $bookingData['specialRequests'],
                $bookingData['totalPrice']
            );
            
            $stmt->execute();
            $bookingId = $this->conn->insert_id;
            
            // Create payment record
            $this->createPaymentRecord($bookingId, 'excursion', $bookingData['totalPrice']);
            
            $this->conn->commit();
            return $bookingId;
            
        } catch (Exception $e) {
            $this->conn->rollback();
            throw $e;
        }
    }
    
    // Create payment record
    private function createPaymentRecord($bookingId, $bookingType, $amount) {
        $stmt = $this->conn->prepare("
            INSERT INTO payments 
            (booking_id, booking_type, amount, status) 
            VALUES (?, ?, ?, 'pending')
        ");
        
        $stmt->bind_param("isd", $bookingId, $bookingType, $amount);
        $stmt->execute();
        
        return $this->conn->insert_id;
    }
    
    // Get booking details
    public function getBooking($bookingId, $bookingType) {
        $table = $bookingType . '_bookings';
        
        $stmt = $this->conn->prepare("
            SELECT b.*, u.name as user_name, u.email as user_email,
                   p.status as payment_status, p.transaction_id
            FROM {$table} b
            JOIN users u ON b.user_id = u.id
            LEFT JOIN payments p ON b.id = p.booking_id AND p.booking_type = ?
            WHERE b.id = ?
        ");
        
        $stmt->bind_param("si", $bookingType, $bookingId);
        $stmt->execute();
        
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    // Update booking status
    public function updateBookingStatus($bookingId, $bookingType, $status) {
        $table = $bookingType . '_bookings';
        
        $stmt = $this->conn->prepare("
            UPDATE {$table} 
            SET status = ? 
            WHERE id = ?
        ");
        
        $stmt->bind_param("si", $status, $bookingId);
        return $stmt->execute();
    }
    
    // Get user bookings
    public function getUserBookings($userId) {
        $bookings = [];
        
        // Get Eurail bookings
        $stmt = $this->conn->prepare("
            SELECT 'eurail' as booking_type, b.*, p.status as payment_status
            FROM eurail_bookings b
            LEFT JOIN payments p ON b.id = p.booking_id AND p.booking_type = 'eurail'
            WHERE b.user_id = ?
            ORDER BY b.created_at DESC
        ");
        
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $bookings['eurail'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Get Excursion bookings
        $stmt = $this->conn->prepare("
            SELECT 'excursion' as booking_type, b.*, p.status as payment_status
            FROM excursion_bookings b
            LEFT JOIN payments p ON b.id = p.booking_id AND p.booking_type = 'excursion'
            WHERE b.user_id = ?
            ORDER BY b.created_at DESC
        ");
        
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $bookings['excursion'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        return $bookings;
    }
}
