<?php
// Payment Gateway Configuration

// PhonePe Configuration
define('PHONEPE_MERCHANT_ID', ''); // Your PhonePe merchant ID
define('PHONEPE_SALT_KEY', '');    // Your PhonePe salt key
define('PHONEPE_SALT_INDEX', '1'); // Your PhonePe salt index
define('PHONEPE_API_ENDPOINT', 'https://api.phonepe.com/apis');

// General Payment Settings
define('PAYMENT_CURRENCY', 'INR');
define('PAYMENT_DECIMAL_PLACES', 2);
define('PAYMENT_RETRY_ATTEMPTS', 3);
define('PAYMENT_TIMEOUT_SECONDS', 300);

// Payment Status Constants
define('PAYMENT_STATUS_PENDING', 'pending');
define('PAYMENT_STATUS_PROCESSING', 'processing');
define('PAYMENT_STATUS_COMPLETED', 'completed');
define('PAYMENT_STATUS_FAILED', 'failed');
define('PAYMENT_STATUS_REFUNDED', 'refunded');

// Payment Methods
define('PAYMENT_METHODS', [
    'phonepe' => [
        'name' => 'PhonePe',
        'enabled' => true,
        'icon' => '/images/payment/phonepe.png',
        'processor' => 'PhonePePaymentProcessor'
    ]
]);

// Payment Gateway URLs
define('SITE_URL', ''); // Your site URL (e.g., https://example.com)
define('PAYMENT_SUCCESS_URL', SITE_URL . '/payment/success');
define('PAYMENT_CANCEL_URL', SITE_URL . '/payment/cancel');
define('PAYMENT_WEBHOOK_URL', SITE_URL . '/api/payment/webhook');

// Payment Security
define('PAYMENT_IP_WHITELIST', [
    // Add PhonePe's IP addresses here
]);

// Payment Logging
define('PAYMENT_LOG_ENABLED', true);
define('PAYMENT_LOG_FILE', __DIR__ . '/../../logs/payments.log');

// Payment Rate Limiting
define('PAYMENT_RATE_LIMIT_ATTEMPTS', 5);
define('PAYMENT_RATE_LIMIT_MINUTES', 15);
