<?php
// Payment Gateway Configuration

// Stripe Configuration
define('STRIPE_PUBLIC_KEY', 'your_stripe_public_key');
define('STRIPE_SECRET_KEY', 'your_stripe_secret_key');
define('STRIPE_WEBHOOK_SECRET', 'your_stripe_webhook_secret');

// PayPal Configuration
define('PAYPAL_CLIENT_ID', 'your_paypal_client_id');
define('PAYPAL_CLIENT_SECRET', 'your_paypal_client_secret');
define('PAYPAL_ENVIRONMENT', 'sandbox'); // 'sandbox' or 'production'

// UPI Configuration
define('UPI_MERCHANT_ID', 'your_upi_merchant_id');
define('UPI_API_KEY', 'your_upi_api_key');
define('UPI_API_ENDPOINT', 'https://api.upi.com');

// PhonePe Configuration
define('PHONEPE_MERCHANT_ID', 'your_phonepe_merchant_id');
define('PHONEPE_SALT_KEY', 'your_phonepe_salt_key');
define('PHONEPE_SALT_INDEX', '1');
define('PHONEPE_API_ENDPOINT', 'https://api.phonepe.com/apis');

// General Payment Settings
define('PAYMENT_CURRENCY', 'EUR');
define('PAYMENT_DECIMAL_PLACES', 2);
define('PAYMENT_RETRY_ATTEMPTS', 3);
define('PAYMENT_TIMEOUT_SECONDS', 300);

// Payment Status Constants
define('PAYMENT_STATUS_PENDING', 'pending');
define('PAYMENT_STATUS_PROCESSING', 'processing');
define('PAYMENT_STATUS_COMPLETED', 'completed');
define('PAYMENT_STATUS_FAILED', 'failed');
define('PAYMENT_STATUS_REFUNDED', 'refunded');

// Payment Methods
define('PAYMENT_METHODS', [
    'stripe' => [
        'name' => 'Credit/Debit Card',
        'enabled' => true,
        'icon' => '/images/payment/stripe.png',
        'processor' => 'StripePaymentProcessor'
    ],
    'paypal' => [
        'name' => 'PayPal',
        'enabled' => true,
        'icon' => '/images/payment/paypal.png',
        'processor' => 'PayPalPaymentProcessor'
    ],
    'upi' => [
        'name' => 'UPI',
        'enabled' => true,
        'icon' => '/images/payment/upi.png',
        'processor' => 'UPIPaymentProcessor'
    ],
    'phonepe' => [
        'name' => 'PhonePe',
        'enabled' => true,
        'icon' => '/images/payment/phonepe.png',
        'processor' => 'PhonePePaymentProcessor'
    ]
]);

// Payment Gateway URLs
define('SITE_URL', 'https://yourdomain.com');
define('PAYMENT_SUCCESS_URL', SITE_URL . '/payment/success');
define('PAYMENT_CANCEL_URL', SITE_URL . '/payment/cancel');
define('PAYMENT_WEBHOOK_URL', SITE_URL . '/api/payment/webhook');

// Payment Security
define('PAYMENT_IP_WHITELIST', [
    // Add trusted IP addresses for webhooks
    '192.168.1.1',
    // Add payment gateway IPs
]);

// Payment Logging
define('PAYMENT_LOG_ENABLED', true);
define('PAYMENT_LOG_FILE', __DIR__ . '/../../logs/payments.log');

// Payment Rate Limiting
define('PAYMENT_RATE_LIMIT_ATTEMPTS', 5);
define('PAYMENT_RATE_LIMIT_MINUTES', 15);
