<?php
// Email Configuration Settings

// SMTP Configuration
define('SMTP_HOST', 'smtp.yourserver.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your_smtp_username');
define('SMTP_PASSWORD', 'your_smtp_password');

// Sender Information
define('EMAIL_FROM_ADDRESS', 'bookings@luxurytravel.com');
define('EMAIL_FROM_NAME', 'Luxury Travel');

// Email Templates Directory
define('EMAIL_TEMPLATES_DIR', __DIR__ . '/../../templates/emails/');

// Notification Settings
define('SEND_BOOKING_CONFIRMATIONS', true);
define('SEND_STATUS_UPDATES', true);
define('SEND_PAYMENT_CONFIRMATIONS', true);

// Support Contact Information
define('SUPPORT_EMAIL', 'support@luxurytravel.com');
define('SUPPORT_PHONE', '+1-800-LUXURY-TRAVEL');

// Email Retry Settings
define('MAX_EMAIL_RETRIES', 3);
define('EMAIL_RETRY_DELAY', 300); // 5 minutes in seconds

// Debug Mode (set to false in production)
define('EMAIL_DEBUG_MODE', false);

// Logging
define('EMAIL_LOG_ENABLED', true);
define('EMAIL_LOG_FILE', __DIR__ . '/../../logs/email.log');

// Rate Limiting
define('MAX_EMAILS_PER_HOUR', 100);
define('MAX_EMAILS_PER_DAY', 1000);

// Template Variables
define('BOOKING_URL_BASE', 'https://luxurytravel.com/bookings/');
define('COMPANY_SOCIAL_MEDIA', [
    'facebook' => 'https://facebook.com/luxurytravel',
    'instagram' => 'https://instagram.com/luxurytravel',
    'twitter' => 'https://twitter.com/luxurytravel'
]);
