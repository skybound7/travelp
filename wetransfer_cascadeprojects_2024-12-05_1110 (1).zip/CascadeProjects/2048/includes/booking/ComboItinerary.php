<?php
namespace Booking;

class ComboItinerary {
    private $conn;
    private $userId;
    
    public function __construct($conn, $userId = null) {
        $this->conn = $conn;
        $this->userId = $userId;
    }
    
    /**
     * Create a new combo itinerary
     */
    public function createComboItinerary($data) {
        try {
            $this->conn->begin_transaction();
            
            // Create main itinerary record
            $stmt = $this->conn->prepare("
                INSERT INTO combo_itineraries (
                    user_id,
                    title,
                    start_date,
                    end_date,
                    total_price,
                    status,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, 'pending', NOW())
            ");
            
            $stmt->bind_param(
                "isssd",
                $this->userId,
                $data['title'],
                $data['start_date'],
                $data['end_date'],
                $data['total_price']
            );
            
            $stmt->execute();
            $itineraryId = $this->conn->insert_id;
            
            // Add itinerary components
            foreach ($data['components'] as $component) {
                $this->addItineraryComponent($itineraryId, $component);
            }
            
            // Add detailed daily schedule
            foreach ($data['schedule'] as $day => $activities) {
                $this->addDailySchedule($itineraryId, $day, $activities);
            }
            
            $this->conn->commit();
            return $itineraryId;
            
        } catch (\Exception $e) {
            $this->conn->rollback();
            throw $e;
        }
    }
    
    /**
     * Add a component to the itinerary (flight, hotel, activity, etc.)
     */
    private function addItineraryComponent($itineraryId, $component) {
        $stmt = $this->conn->prepare("
            INSERT INTO itinerary_components (
                itinerary_id,
                component_type,
                service_id,
                start_datetime,
                end_datetime,
                price,
                details
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->bind_param(
            "issssdj",
            $itineraryId,
            $component['type'],
            $component['service_id'],
            $component['start_datetime'],
            $component['end_datetime'],
            $component['price'],
            json_encode($component['details'])
        );
        
        $stmt->execute();
    }
    
    /**
     * Add daily schedule details
     */
    private function addDailySchedule($itineraryId, $day, $activities) {
        foreach ($activities as $activity) {
            $stmt = $this->conn->prepare("
                INSERT INTO itinerary_schedule (
                    itinerary_id,
                    day_number,
                    time_slot,
                    activity_type,
                    description,
                    location,
                    duration,
                    notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->bind_param(
                "iissssss",
                $itineraryId,
                $day,
                $activity['time'],
                $activity['type'],
                $activity['description'],
                $activity['location'],
                $activity['duration'],
                $activity['notes']
            );
            
            $stmt->execute();
        }
    }
    
    /**
     * Process payment for the itinerary
     */
    public function processPayment($itineraryId, $paymentData) {
        try {
            $this->conn->begin_transaction();
            
            // Get itinerary details
            $stmt = $this->conn->prepare("
                SELECT total_price, status 
                FROM combo_itineraries 
                WHERE id = ? AND user_id = ?
            ");
            
            $stmt->bind_param("ii", $itineraryId, $this->userId);
            $stmt->execute();
            $result = $stmt->get_result();
            $itinerary = $result->fetch_assoc();
            
            if (!$itinerary || $itinerary['status'] !== 'pending') {
                throw new \Exception('Invalid itinerary or already processed');
            }
            
            // Create payment record
            $stmt = $this->conn->prepare("
                INSERT INTO payments (
                    user_id,
                    itinerary_id,
                    amount,
                    payment_method,
                    transaction_id,
                    status,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, 'processing', NOW())
            ");
            
            $stmt->bind_param(
                "iidss",
                $this->userId,
                $itineraryId,
                $itinerary['total_price'],
                $paymentData['method'],
                $paymentData['transaction_id']
            );
            
            $stmt->execute();
            $paymentId = $this->conn->insert_id;
            
            // Process payment through payment gateway
            $paymentResult = $this->processPaymentGateway($paymentData, $itinerary['total_price']);
            
            if ($paymentResult['status'] === 'success') {
                // Update payment status
                $stmt = $this->conn->prepare("
                    UPDATE payments 
                    SET status = 'completed',
                        gateway_response = ?,
                        completed_at = NOW()
                    WHERE id = ?
                ");
                
                $response = json_encode($paymentResult);
                $stmt->bind_param("si", $response, $paymentId);
                $stmt->execute();
                
                // Update itinerary status
                $stmt = $this->conn->prepare("
                    UPDATE combo_itineraries 
                    SET status = 'confirmed' 
                    WHERE id = ?
                ");
                
                $stmt->bind_param("i", $itineraryId);
                $stmt->execute();
                
                // Send confirmation
                $this->sendConfirmation($itineraryId);
                
            } else {
                throw new \Exception('Payment processing failed: ' . $paymentResult['message']);
            }
            
            $this->conn->commit();
            return [
                'status' => 'success',
                'payment_id' => $paymentId,
                'transaction_id' => $paymentResult['transaction_id']
            ];
            
        } catch (\Exception $e) {
            $this->conn->rollback();
            throw $e;
        }
    }
    
    /**
     * Process payment through payment gateway
     */
    private function processPaymentGateway($paymentData, $amount) {
        // Implement your payment gateway integration here
        // This is a placeholder for demonstration
        return [
            'status' => 'success',
            'transaction_id' => uniqid('TXN'),
            'message' => 'Payment processed successfully'
        ];
    }
    
    /**
     * Send booking confirmation
     */
    private function sendConfirmation($itineraryId) {
        // Get user details
        $stmt = $this->conn->prepare("
            SELECT u.email, u.name, ci.title, ci.start_date, ci.end_date
            FROM users u
            JOIN combo_itineraries ci ON ci.user_id = u.id
            WHERE ci.id = ?
        ");
        
        $stmt->bind_param("i", $itineraryId);
        $stmt->execute();
        $result = $stmt->get_result();
        $booking = $result->fetch_assoc();
        
        // Generate PDF itinerary
        $pdf = $this->generatePDFItinerary($itineraryId);
        
        // Send email
        $subject = "Booking Confirmation - " . $booking['title'];
        $message = $this->generateConfirmationEmail($booking);
        
        // Send email with PDF attachment
        mail(
            $booking['email'],
            $subject,
            $message,
            [
                'From' => 'bookings@yourdomain.com',
                'Content-Type' => 'text/html; charset=UTF-8'
            ]
        );
    }
    
    /**
     * Generate PDF itinerary
     */
    private function generatePDFItinerary($itineraryId) {
        // Get all itinerary details
        $details = $this->getItineraryDetails($itineraryId);
        
        // Generate PDF using a library like TCPDF or FPDF
        // This is a placeholder for demonstration
        return "PDF content";
    }
    
    /**
     * Get detailed itinerary information
     */
    public function getItineraryDetails($itineraryId) {
        // Get main itinerary details
        $stmt = $this->conn->prepare("
            SELECT * FROM combo_itineraries 
            WHERE id = ? AND user_id = ?
        ");
        
        $stmt->bind_param("ii", $itineraryId, $this->userId);
        $stmt->execute();
        $itinerary = $stmt->get_result()->fetch_assoc();
        
        if (!$itinerary) {
            throw new \Exception('Itinerary not found');
        }
        
        // Get components
        $stmt = $this->conn->prepare("
            SELECT * FROM itinerary_components 
            WHERE itinerary_id = ?
            ORDER BY start_datetime
        ");
        
        $stmt->bind_param("i", $itineraryId);
        $stmt->execute();
        $itinerary['components'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Get daily schedule
        $stmt = $this->conn->prepare("
            SELECT * FROM itinerary_schedule 
            WHERE itinerary_id = ?
            ORDER BY day_number, time_slot
        ");
        
        $stmt->bind_param("i", $itineraryId);
        $stmt->execute();
        $itinerary['schedule'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Get payment information
        $stmt = $this->conn->prepare("
            SELECT * FROM payments 
            WHERE itinerary_id = ?
            ORDER BY created_at DESC
            LIMIT 1
        ");
        
        $stmt->bind_param("i", $itineraryId);
        $stmt->execute();
        $itinerary['payment'] = $stmt->get_result()->fetch_assoc();
        
        return $itinerary;
    }
    
    /**
     * Generate confirmation email content
     */
    private function generateConfirmationEmail($booking) {
        return "
            <h2>Booking Confirmation</h2>
            <p>Dear {$booking['name']},</p>
            <p>Your booking for {$booking['title']} has been confirmed!</p>
            <p><strong>Travel Dates:</strong> {$booking['start_date']} to {$booking['end_date']}</p>
            <p>Please find your detailed itinerary attached to this email.</p>
        ";
    }
    
    /**
     * Validate and highlight date/time mismatches in itinerary
     * @return array Array of mismatches found
     */
    public function validateDateTimeConsistency() {
        $mismatches = [];
        $itineraryId = $this->id;

        // Get all segments in chronological order
        $query = "
            SELECT 
                ic.id as component_id,
                ic.type as component_type,
                ic.start_datetime,
                ic.end_datetime,
                ic.location_from,
                ic.location_to,
                ci.start_date as itinerary_start,
                ci.end_date as itinerary_end
            FROM itinerary_components ic
            JOIN combo_itineraries ci ON ic.itinerary_id = ci.id
            WHERE ic.itinerary_id = ?
            ORDER BY ic.start_datetime ASC
        ";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $itineraryId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $components = [];
        while ($row = $result->fetch_assoc()) {
            $components[] = $row;
        }
        
        // Check overall itinerary date boundaries
        foreach ($components as $component) {
            $componentStart = new DateTime($component['start_datetime']);
            $componentEnd = new DateTime($component['end_datetime']);
            $itineraryStart = new DateTime($component['itinerary_start']);
            $itineraryEnd = new DateTime($component['itinerary_end']);
            
            // Check if component is outside itinerary dates
            if ($componentStart < $itineraryStart || $componentEnd > $itineraryEnd) {
                $mismatches[] = [
                    'type' => 'boundary_mismatch',
                    'component_id' => $component['component_id'],
                    'component_type' => $component['component_type'],
                    'message' => "Component {$component['component_type']} ({$component['component_id']}) falls outside itinerary dates",
                    'details' => [
                        'component_start' => $componentStart->format('Y-m-d H:i'),
                        'component_end' => $componentEnd->format('Y-m-d H:i'),
                        'itinerary_start' => $itineraryStart->format('Y-m-d H:i'),
                        'itinerary_end' => $itineraryEnd->format('Y-m-d H:i')
                    ]
                ];
            }
        }
        
        // Check for overlaps and gaps between components
        for ($i = 0; $i < count($components) - 1; $i++) {
            $current = $components[$i];
            $next = $components[$i + 1];
            
            $currentEnd = new DateTime($current['end_datetime']);
            $nextStart = new DateTime($next['start_datetime']);
            
            // Check for overlaps
            if ($currentEnd > $nextStart) {
                $mismatches[] = [
                    'type' => 'overlap',
                    'component1_id' => $current['component_id'],
                    'component2_id' => $next['component_id'],
                    'message' => "Overlap detected between {$current['component_type']} and {$next['component_type']}",
                    'details' => [
                        'component1_end' => $currentEnd->format('Y-m-d H:i'),
                        'component2_start' => $nextStart->format('Y-m-d H:i')
                    ]
                ];
            }
            
            // Check for unreasonable gaps (more than 12 hours)
            $gap = $nextStart->getTimestamp() - $currentEnd->getTimestamp();
            if ($gap > 43200) { // 12 hours in seconds
                $mismatches[] = [
                    'type' => 'large_gap',
                    'component1_id' => $current['component_id'],
                    'component2_id' => $next['component_id'],
                    'message' => "Large gap detected between {$current['component_type']} and {$next['component_type']}",
                    'details' => [
                        'component1_end' => $currentEnd->format('Y-m-d H:i'),
                        'component2_start' => $nextStart->format('Y-m-d H:i'),
                        'gap_hours' => round($gap / 3600, 1)
                    ]
                ];
            }
            
            // Check for location consistency
            if ($current['location_to'] !== $next['location_from']) {
                $mismatches[] = [
                    'type' => 'location_mismatch',
                    'component1_id' => $current['component_id'],
                    'component2_id' => $next['component_id'],
                    'message' => "Location mismatch between consecutive components",
                    'details' => [
                        'component1_end_location' => $current['location_to'],
                        'component2_start_location' => $next['location_from']
                    ]
                ];
            }
        }
        
        return $mismatches;
    }
    
    /**
     * Fix date/time mismatches automatically where possible
     * @param array $mismatches Array of mismatches to fix
     * @return array Results of fix attempts
     */
    public function fixDateTimeMismatches($mismatches) {
        $results = [];
        
        foreach ($mismatches as $mismatch) {
            $result = [
                'type' => $mismatch['type'],
                'status' => 'pending',
                'message' => '',
                'changes_made' => []
            ];
            
            switch ($mismatch['type']) {
                case 'boundary_mismatch':
                    $result = $this->fixBoundaryMismatch($mismatch);
                    break;
                    
                case 'overlap':
                    $result = $this->fixOverlap($mismatch);
                    break;
                    
                case 'large_gap':
                    $result = $this->suggestGapFill($mismatch);
                    break;
                    
                case 'location_mismatch':
                    $result = $this->suggestTransportOption($mismatch);
                    break;
            }
            
            $results[] = $result;
        }
        
        return $results;
    }
    
    /**
     * Fix boundary mismatches by adjusting itinerary dates
     */
    private function fixBoundaryMismatch($mismatch) {
        $componentId = $mismatch['component_id'];
        $details = $mismatch['details'];
        
        // Expand itinerary boundaries if needed
        $query = "
            UPDATE combo_itineraries
            SET 
                start_date = LEAST(start_date, ?),
                end_date = GREATEST(end_date, ?)
            WHERE id = ?
        ";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('ssi', 
            $details['component_start'],
            $details['component_end'],
            $this->id
        );
        
        if ($stmt->execute()) {
            return [
                'status' => 'fixed',
                'message' => "Itinerary boundaries adjusted to accommodate component",
                'changes_made' => [
                    'new_start' => $details['component_start'],
                    'new_end' => $details['component_end']
                ]
            ];
        }
        
        return [
            'status' => 'failed',
            'message' => "Failed to adjust itinerary boundaries"
        ];
    }
    
    /**
     * Fix overlapping components
     */
    private function fixOverlap($mismatch) {
        $comp1Id = $mismatch['component1_id'];
        $comp2Id = $mismatch['component2_id'];
        $details = $mismatch['details'];
        
        // Try to adjust end time of first component
        $query = "
            UPDATE itinerary_components
            SET end_datetime = ?
            WHERE id = ?
        ";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('si', 
            $details['component2_start'],
            $comp1Id
        );
        
        if ($stmt->execute()) {
            return [
                'status' => 'fixed',
                'message' => "Adjusted component end time to resolve overlap",
                'changes_made' => [
                    'component_id' => $comp1Id,
                    'new_end_time' => $details['component2_start']
                ]
            ];
        }
        
        return [
            'status' => 'failed',
            'message' => "Failed to resolve component overlap"
        ];
    }
    
    /**
     * Suggest activities to fill large gaps
     */
    private function suggestGapFill($mismatch) {
        $location = $mismatch['details']['component1_end_location'];
        $gapHours = $mismatch['details']['gap_hours'];
        
        // Query available activities at the location
        $query = "
            SELECT id, name, duration_hours, price
            FROM available_activities
            WHERE location = ?
            AND duration_hours <= ?
            ORDER BY rating DESC
            LIMIT 5
        ";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('sd', $location, $gapHours);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $suggestions = [];
        while ($row = $result->fetch_assoc()) {
            $suggestions[] = $row;
        }
        
        return [
            'status' => 'suggestion',
            'message' => "Found " . count($suggestions) . " activities to fill the gap",
            'suggestions' => $suggestions
        ];
    }
    
    /**
     * Suggest transport options for location mismatches
     */
    private function suggestTransportOption($mismatch) {
        $fromLocation = $mismatch['details']['component1_end_location'];
        $toLocation = $mismatch['details']['component2_start_location'];
        
        // Query available transport options
        $query = "
            SELECT id, type, duration_hours, price
            FROM available_transport
            WHERE location_from = ?
            AND location_to = ?
            ORDER BY price ASC
            LIMIT 5
        ";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('ss', $fromLocation, $toLocation);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $suggestions = [];
        while ($row = $result->fetch_assoc()) {
            $suggestions[] = $row;
        }
        
        return [
            'status' => 'suggestion',
            'message' => "Found " . count($suggestions) . " transport options",
            'suggestions' => $suggestions
        ];
    }
}
