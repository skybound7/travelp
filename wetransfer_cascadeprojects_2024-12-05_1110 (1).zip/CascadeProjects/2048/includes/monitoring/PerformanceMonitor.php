<?php
namespace Monitoring;

class PerformanceMonitor {
    private $conn;
    private $config;
    private static $instance = null;
    private $startTime;
    private $metrics = [];
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->startTime = microtime(true);
        $this->config = [
            'slow_query_threshold' => 1.0, // seconds
            'memory_threshold' => 128 * 1024 * 1024, // 128MB
            'cpu_threshold' => 80, // percentage
            'metrics_retention_days' => 30
        ];
    }
    
    public static function getInstance($conn) {
        if (self::$instance === null) {
            self::$instance = new self($conn);
        }
        return self::$instance;
    }
    
    /**
     * Start measuring a specific operation
     */
    public function startMeasure($operation) {
        $this->metrics[$operation] = [
            'start' => microtime(true),
            'memory_start' => memory_get_usage()
        ];
    }
    
    /**
     * End measuring a specific operation
     */
    public function endMeasure($operation) {
        if (!isset($this->metrics[$operation])) {
            return;
        }
        
        $end = microtime(true);
        $memory_end = memory_get_usage();
        
        $duration = $end - $this->metrics[$operation]['start'];
        $memory_used = $memory_end - $this->metrics[$operation]['memory_start'];
        
        $this->logMetrics($operation, [
            'duration' => $duration,
            'memory_used' => $memory_used,
            'peak_memory' => memory_get_peak_usage(),
            'cpu_usage' => $this->getCPUUsage()
        ]);
        
        // Alert if thresholds exceeded
        if ($duration > $this->config['slow_query_threshold']) {
            $this->alertSlowOperation($operation, $duration);
        }
        
        if ($memory_used > $this->config['memory_threshold']) {
            $this->alertHighMemoryUsage($operation, $memory_used);
        }
    }
    
    /**
     * Log error with context
     */
    public function logError($error, $context = []) {
        $errorData = [
            'message' => $error instanceof \Exception ? $error->getMessage() : $error,
            'type' => $error instanceof \Exception ? get_class($error) : 'General Error',
            'file' => $error instanceof \Exception ? $error->getFile() : '',
            'line' => $error instanceof \Exception ? $error->getLine() : '',
            'context' => $context,
            'url' => $_SERVER['REQUEST_URI'] ?? '',
            'method' => $_SERVER['REQUEST_METHOD'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        // Log to database
        $stmt = $this->conn->prepare("
            INSERT INTO error_logs (
                error_type,
                message,
                context,
                url,
                user_agent,
                ip_address,
                timestamp
            ) VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->bind_param(
            "ssssss",
            $errorData['type'],
            $errorData['message'],
            json_encode($context),
            $errorData['url'],
            $errorData['user_agent'],
            $errorData['ip']
        );
        
        $stmt->execute();
        
        // Alert if critical error
        if ($this->isCriticalError($error)) {
            $this->notifyAdmins('Critical Error: ' . $errorData['message'], $errorData);
        }
    }
    
    /**
     * Log user feedback
     */
    public function logFeedback($userId, $feedback, $rating, $category) {
        $stmt = $this->conn->prepare("
            INSERT INTO user_feedback (
                user_id,
                feedback,
                rating,
                category,
                timestamp
            ) VALUES (?, ?, ?, ?, NOW())
        ");
        
        $stmt->bind_param(
            "isis",
            $userId,
            $feedback,
            $rating,
            $category
        );
        
        $stmt->execute();
        
        // Alert on negative feedback
        if ($rating <= 2) {
            $this->notifyAdmins("Negative Feedback Received", [
                'user_id' => $userId,
                'feedback' => $feedback,
                'rating' => $rating,
                'category' => $category
            ]);
        }
    }
    
    /**
     * Get performance report for a time period
     */
    public function getPerformanceReport($startDate, $endDate) {
        $stmt = $this->conn->prepare("
            SELECT 
                operation,
                AVG(duration) as avg_duration,
                MAX(duration) as max_duration,
                AVG(memory_used) as avg_memory,
                MAX(memory_used) as max_memory,
                AVG(cpu_usage) as avg_cpu,
                COUNT(*) as count
            FROM performance_metrics
            WHERE timestamp BETWEEN ? AND ?
            GROUP BY operation
            ORDER BY avg_duration DESC
        ");
        
        $stmt->bind_param("ss", $startDate, $endDate);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    /**
     * Get error summary for a time period
     */
    public function getErrorReport($startDate, $endDate) {
        $stmt = $this->conn->prepare("
            SELECT 
                error_type,
                COUNT(*) as count,
                MIN(timestamp) as first_occurrence,
                MAX(timestamp) as last_occurrence
            FROM error_logs
            WHERE timestamp BETWEEN ? AND ?
            GROUP BY error_type
            ORDER BY count DESC
        ");
        
        $stmt->bind_param("ss", $startDate, $endDate);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    /**
     * Get user feedback summary
     */
    public function getFeedbackReport($startDate, $endDate) {
        $stmt = $this->conn->prepare("
            SELECT 
                category,
                AVG(rating) as avg_rating,
                COUNT(*) as count,
                COUNT(CASE WHEN rating <= 2 THEN 1 END) as negative_count
            FROM user_feedback
            WHERE timestamp BETWEEN ? AND ?
            GROUP BY category
            ORDER BY avg_rating ASC
        ");
        
        $stmt->bind_param("ss", $startDate, $endDate);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    /**
     * Clean up old metrics
     */
    public function cleanupOldMetrics() {
        $retention = $this->config['metrics_retention_days'];
        
        $tables = ['performance_metrics', 'error_logs', 'user_feedback'];
        foreach ($tables as $table) {
            $stmt = $this->conn->prepare("
                DELETE FROM $table 
                WHERE timestamp < DATE_SUB(NOW(), INTERVAL ? DAY)
            ");
            
            $stmt->bind_param("i", $retention);
            $stmt->execute();
        }
    }
    
    private function logMetrics($operation, $metrics) {
        $stmt = $this->conn->prepare("
            INSERT INTO performance_metrics (
                operation,
                duration,
                memory_used,
                peak_memory,
                cpu_usage,
                timestamp
            ) VALUES (?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->bind_param(
            "sdddd",
            $operation,
            $metrics['duration'],
            $metrics['memory_used'],
            $metrics['peak_memory'],
            $metrics['cpu_usage']
        );
        
        $stmt->execute();
    }
    
    private function getCPUUsage() {
        if (function_exists('sys_getloadavg')) {
            $load = sys_getloadavg();
            return $load[0] * 100;
        }
        return 0;
    }
    
    private function isCriticalError($error) {
        $criticalTypes = [
            'PDOException',
            'mysqli_sql_exception',
            'RuntimeException',
            'ParseError'
        ];
        
        if ($error instanceof \Exception) {
            return in_array(get_class($error), $criticalTypes);
        }
        
        return false;
    }
    
    private function alertSlowOperation($operation, $duration) {
        $this->notifyAdmins("Slow Operation Detected", [
            'operation' => $operation,
            'duration' => $duration,
            'threshold' => $this->config['slow_query_threshold']
        ]);
    }
    
    private function alertHighMemoryUsage($operation, $memory) {
        $this->notifyAdmins("High Memory Usage Detected", [
            'operation' => $operation,
            'memory_used' => $memory,
            'threshold' => $this->config['memory_threshold']
        ]);
    }
    
    private function notifyAdmins($subject, $data) {
        // Send to configured notification channels (Slack, Email, etc.)
        if ($webhook = getenv('SLACK_WEBHOOK_URL')) {
            $this->sendSlackNotification($webhook, $subject, $data);
        }
        
        if ($email = getenv('ADMIN_EMAIL')) {
            $this->sendEmailNotification($email, $subject, $data);
        }
    }
    
    private function sendSlackNotification($webhook, $subject, $data) {
        $payload = json_encode([
            'text' => "🚨 *{$subject}*\n```" . json_encode($data, JSON_PRETTY_PRINT) . "```",
            'username' => 'Performance Monitor',
            'icon_emoji' => ':chart_with_downwards_trend:'
        ]);
        
        $ch = curl_init($webhook);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($payload)
        ]);
        
        curl_exec($ch);
        curl_close($ch);
    }
    
    private function sendEmailNotification($email, $subject, $data) {
        $headers = [
            'From' => 'monitoring@' . $_SERVER['HTTP_HOST'],
            'Content-Type' => 'text/html; charset=UTF-8'
        ];
        
        $body = "
            <h2>{$subject}</h2>
            <pre>" . json_encode($data, JSON_PRETTY_PRINT) . "</pre>
            <p><strong>Environment:</strong> " . getenv('APP_ENV') . "</p>
            <p><strong>Time:</strong> " . date('Y-m-d H:i:s') . "</p>
        ";
        
        mail($email, "🔍 Monitor Alert: {$subject}", $body, $headers);
    }
}
