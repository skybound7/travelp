<?php
namespace Monitoring;

class UptimeMonitor {
    private $conn;
    private $config;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->config = [
            'critical_services' => [
                'database' => true,
                'redis_cache' => false,
                'api_endpoints' => true
            ],
            'notification_endpoints' => [
                'slack_webhook' => getenv('SLACK_WEBHOOK_URL'),
                'email' => getenv('ADMIN_EMAIL')
            ]
        ];
    }
    
    /**
     * Check the health of critical services
     * @return array Health status of all monitored services
     */
    public function checkHealth() {
        $status = [
            'status' => 'healthy',
            'timestamp' => date('Y-m-d H:i:s'),
            'services' => []
        ];
        
        // Check database connection
        if ($this->config['critical_services']['database']) {
            $dbStatus = $this->checkDatabaseConnection();
            $status['services']['database'] = $dbStatus;
            if (!$dbStatus['healthy']) $status['status'] = 'degraded';
        }
        
        // Check Redis if enabled
        if ($this->config['critical_services']['redis_cache']) {
            $redisStatus = $this->checkRedisConnection();
            $status['services']['redis'] = $redisStatus;
            if (!$redisStatus['healthy']) $status['status'] = 'degraded';
        }
        
        // Check API endpoints
        if ($this->config['critical_services']['api_endpoints']) {
            $apiStatus = $this->checkAPIEndpoints();
            $status['services']['api'] = $apiStatus;
            if (!$apiStatus['healthy']) $status['status'] = 'degraded';
        }
        
        // Log health check
        $this->logHealthCheck($status);
        
        return $status;
    }
    
    /**
     * Check database connection
     * @return array Connection status
     */
    private function checkDatabaseConnection() {
        try {
            $this->conn->query("SELECT 1");
            return [
                'healthy' => true,
                'latency' => $this->measureDBLatency(),
                'message' => 'Database connection successful'
            ];
        } catch (\Exception $e) {
            $this->notifyAdmins('Database connection failed: ' . $e->getMessage());
            return [
                'healthy' => false,
                'latency' => null,
                'message' => 'Database connection failed'
            ];
        }
    }
    
    /**
     * Measure database query latency
     * @return float Latency in milliseconds
     */
    private function measureDBLatency() {
        $start = microtime(true);
        $this->conn->query("SELECT 1");
        $end = microtime(true);
        return round(($end - $start) * 1000, 2); // Convert to milliseconds
    }
    
    /**
     * Check Redis connection if enabled
     * @return array Connection status
     */
    private function checkRedisConnection() {
        if (!extension_loaded('redis')) {
            return [
                'healthy' => false,
                'message' => 'Redis extension not loaded'
            ];
        }
        
        try {
            $redis = new \Redis();
            $redis->connect('127.0.0.1', 6379, 2); // 2 second timeout
            $redis->ping();
            return [
                'healthy' => true,
                'message' => 'Redis connection successful'
            ];
        } catch (\Exception $e) {
            $this->notifyAdmins('Redis connection failed: ' . $e->getMessage());
            return [
                'healthy' => false,
                'message' => 'Redis connection failed'
            ];
        }
    }
    
    /**
     * Check critical API endpoints
     * @return array API status
     */
    private function checkAPIEndpoints() {
        $endpoints = [
            '/api/booking',
            '/api/search',
            '/api/auth'
        ];
        
        $failures = [];
        foreach ($endpoints as $endpoint) {
            if (!$this->pingEndpoint($endpoint)) {
                $failures[] = $endpoint;
            }
        }
        
        if (empty($failures)) {
            return [
                'healthy' => true,
                'message' => 'All API endpoints responding'
            ];
        } else {
            $this->notifyAdmins('API endpoints failing: ' . implode(', ', $failures));
            return [
                'healthy' => false,
                'message' => 'Failed endpoints: ' . implode(', ', $failures)
            ];
        }
    }
    
    /**
     * Ping an API endpoint
     * @param string $endpoint Endpoint to check
     * @return bool Whether endpoint is responding
     */
    private function pingEndpoint($endpoint) {
        $ch = curl_init($_SERVER['HTTP_HOST'] . $endpoint);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return $httpCode >= 200 && $httpCode < 500;
    }
    
    /**
     * Log health check results
     * @param array $status Health check results
     */
    private function logHealthCheck($status) {
        $stmt = $this->conn->prepare("
            INSERT INTO health_logs (
                status,
                details,
                timestamp
            ) VALUES (?, ?, NOW())
        ");
        
        $stmt->bind_param(
            "ss",
            $status['status'],
            json_encode($status)
        );
        
        $stmt->execute();
    }
    
    /**
     * Notify administrators of issues
     * @param string $message Error message
     */
    private function notifyAdmins($message) {
        // Slack notification
        if ($webhook = $this->config['notification_endpoints']['slack_webhook']) {
            $this->sendSlackNotification($webhook, $message);
        }
        
        // Email notification
        if ($email = $this->config['notification_endpoints']['email']) {
            $this->sendEmailNotification($email, $message);
        }
    }
    
    /**
     * Send Slack notification
     * @param string $webhook Slack webhook URL
     * @param string $message Error message
     */
    private function sendSlackNotification($webhook, $message) {
        $payload = json_encode([
            'text' => "🚨 *Alert*: {$message}\nEnvironment: " . getenv('APP_ENV')
        ]);
        
        $ch = curl_init($webhook);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($payload)
        ]);
        
        curl_exec($ch);
        curl_close($ch);
    }
    
    /**
     * Send email notification
     * @param string $email Admin email address
     * @param string $message Error message
     */
    private function sendEmailNotification($email, $message) {
        $subject = "🚨 Site Alert: Service Degradation";
        $headers = [
            'From' => 'monitoring@' . $_SERVER['HTTP_HOST'],
            'Content-Type' => 'text/html; charset=UTF-8'
        ];
        
        $body = "
            <h2>Service Alert</h2>
            <p><strong>Message:</strong> {$message}</p>
            <p><strong>Environment:</strong> " . getenv('APP_ENV') . "</p>
            <p><strong>Time:</strong> " . date('Y-m-d H:i:s') . "</p>
        ";
        
        mail($email, $subject, $body, $headers);
    }
}
