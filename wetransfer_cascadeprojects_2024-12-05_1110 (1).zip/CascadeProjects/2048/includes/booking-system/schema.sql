-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create services table
CREATE TABLE IF NOT EXISTS services (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    duration INT, -- in minutes
    group_discount DECIMAL(5,2), -- percentage
    max_guests INT,
    availability_schedule JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    service_id INT NOT NULL,
    booking_date DATE NOT NULL,
    booking_time TIME,
    guests INT NOT NULL DEFAULT 1,
    preferences JSON,
    total_price DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'confirmed', 'completed', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- Create service_preferences table
CREATE TABLE IF NOT EXISTS service_preferences (
    id INT PRIMARY KEY AUTO_INCREMENT,
    service_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price_adjustment DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- Create booking_reviews table
CREATE TABLE IF NOT EXISTS booking_reviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    booking_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    review_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id)
);

-- Create indexes for better performance
CREATE INDEX idx_booking_date ON bookings(booking_date);
CREATE INDEX idx_service_price ON services(price);
CREATE INDEX idx_user_email ON users(email);

-- Insert sample luxury services
INSERT INTO services (name, description, price, duration, group_discount, max_guests) VALUES
('Private Yacht Tour', 'Luxury yacht experience with personal chef and crew', 5000.00, 480, 10.00, 12),
('Helicopter City Tour', 'Exclusive aerial tour of the city landmarks', 1500.00, 60, 5.00, 6),
('Private Villa Retreat', 'Luxury villa stay with butler service', 3000.00, 1440, 0.00, 8),
('Gourmet Food Tour', 'Exclusive restaurant tours with private chef', 800.00, 240, 15.00, 8);

-- Insert sample service preferences
INSERT INTO service_preferences (service_id, name, description, price_adjustment) VALUES
(1, 'Champagne Package', 'Premium champagne selection', 300.00),
(1, 'Sunset Timing', 'Schedule during sunset hours', 200.00),
(2, 'Photography Package', 'Professional aerial photography', 250.00),
(3, 'Spa Package', 'In-villa spa treatments', 400.00),
(4, 'Wine Pairing', 'Premium wine pairing with each course', 150.00);
