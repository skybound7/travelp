<?php
// Security enhancements for booking system

class BookingSecurityManager {
    private $conn;
    private $config;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->config = [
            'session_lifetime' => 3600, // 1 hour
            'max_login_attempts' => 5,
            'lockout_duration' => 900, // 15 minutes
            'password_reset_expiry' => 3600, // 1 hour
            'csrf_token_expiry' => 3600 // 1 hour
        ];
        
        $this->initializeSecurityMeasures();
    }
    
    private function initializeSecurityMeasures() {
        // Set secure session parameters
        ini_set('session.cookie_httponly', 1);
        ini_set('session.cookie_secure', 1);
        ini_set('session.use_strict_mode', 1);
        ini_set('session.cookie_samesite', 'Lax');
        
        // Set session lifetime
        ini_set('session.gc_maxlifetime', $this->config['session_lifetime']);
        session_set_cookie_params($this->config['session_lifetime']);
        
        // Start session if not already started
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // Regenerate session ID periodically
        if (!isset($_SESSION['last_regeneration'])) {
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = time();
        } else if (time() - $_SESSION['last_regeneration'] > 300) {
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = time();
        }
    }
    
    public function validateCSRFToken($token) {
        if (!isset($_SESSION['csrf_token']) || !isset($_SESSION['csrf_token_time'])) {
            return false;
        }
        
        if (time() - $_SESSION['csrf_token_time'] > $this->config['csrf_token_expiry']) {
            return false;
        }
        
        return hash_equals($_SESSION['csrf_token'], $token);
    }
    
    public function generateCSRFToken() {
        $token = bin2hex(random_bytes(32));
        $_SESSION['csrf_token'] = $token;
        $_SESSION['csrf_token_time'] = time();
        return $token;
    }
    
    public function validateBookingRequest($data) {
        // Validate service ID
        if (!isset($data['service_id']) || !is_numeric($data['service_id'])) {
            throw new Exception('Invalid service selected');
        }
        
        // Validate date
        if (!isset($data['date']) || !strtotime($data['date'])) {
            throw new Exception('Invalid date selected');
        }
        
        // Validate time
        if (!isset($data['time']) || !preg_match('/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/', $data['time'])) {
            throw new Exception('Invalid time selected');
        }
        
        // Validate guests number
        if (!isset($data['guests']) || !is_numeric($data['guests']) || $data['guests'] < 1) {
            throw new Exception('Invalid number of guests');
        }
        
        // Validate preferences
        if (isset($data['preferences']) && is_array($data['preferences'])) {
            foreach ($data['preferences'] as $pref) {
                if (!is_numeric($pref)) {
                    throw new Exception('Invalid preference selected');
                }
            }
        }
        
        return true;
    }
    
    public function rateLimit($ip, $action = 'booking') {
        $stmt = $this->conn->prepare("SELECT COUNT(*) as attempts, MAX(timestamp) as last_attempt 
                                    FROM rate_limits 
                                    WHERE ip = ? AND action = ? 
                                    AND timestamp > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
        $stmt->bind_param('ss', $ip, $action);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        if ($result['attempts'] >= 60) { // Max 60 requests per hour
            throw new Exception('Rate limit exceeded. Please try again later.');
        }
        
        // Log this attempt
        $stmt = $this->conn->prepare("INSERT INTO rate_limits (ip, action) VALUES (?, ?)");
        $stmt->bind_param('ss', $ip, $action);
        $stmt->execute();
        
        return true;
    }
    
    public function sanitizeInput($data) {
        if (is_array($data)) {
            return array_map([$this, 'sanitizeInput'], $data);
        }
        
        return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
    }
    
    public function validatePaymentData($paymentData) {
        // Validate payment method ID
        if (!isset($paymentData['payment_method_id']) || 
            !preg_match('/^pm_[a-zA-Z0-9]+$/', $paymentData['payment_method_id'])) {
            throw new Exception('Invalid payment method');
        }
        
        // Validate amount
        if (!isset($paymentData['amount']) || 
            !is_numeric($paymentData['amount']) || 
            $paymentData['amount'] <= 0) {
            throw new Exception('Invalid payment amount');
        }
        
        return true;
    }
    
    public function logSecurityEvent($event, $userId = null, $details = null) {
        $stmt = $this->conn->prepare("INSERT INTO security_logs (user_id, event_type, details, ip_address) 
                                    VALUES (?, ?, ?, ?)");
        $ip = $_SERVER['REMOTE_ADDR'];
        $stmt->bind_param('isss', $userId, $event, $details, $ip);
        $stmt->execute();
    }
    
    public function validateUserSession() {
        if (!isset($_SESSION['user_id'])) {
            throw new Exception('User not authenticated');
        }
        
        // Check if session is expired
        if (isset($_SESSION['last_activity']) && 
            (time() - $_SESSION['last_activity'] > $this->config['session_lifetime'])) {
            session_unset();
            session_destroy();
            throw new Exception('Session expired');
        }
        
        $_SESSION['last_activity'] = time();
        return true;
    }
}

// Additional security tables SQL
$securityTables = "
CREATE TABLE IF NOT EXISTS rate_limits (
    id INT PRIMARY KEY AUTO_INCREMENT,
    ip VARCHAR(45) NOT NULL,
    action VARCHAR(50) NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ip_action (ip, action)
);

CREATE TABLE IF NOT EXISTS security_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    event_type VARCHAR(50) NOT NULL,
    details TEXT,
    ip_address VARCHAR(45),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_event (user_id, event_type),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS login_attempts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    ip VARCHAR(45) NOT NULL,
    email VARCHAR(255) NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ip_email (ip, email)
);
";
