<?php
class Booking {
    private $conn;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    public function createBooking($userId, $serviceId, $date, $guests, $preferences) {
        $userId = sanitize_input($userId);
        $serviceId = sanitize_input($serviceId);
        $date = sanitize_input($date);
        $guests = (int)$guests;
        $preferences = json_encode($preferences);
        
        $query = "INSERT INTO bookings (user_id, service_id, booking_date, guests, preferences, status) 
                 VALUES ('$userId', '$serviceId', '$date', $guests, '$preferences', 'pending')";
        
        if ($this->conn->query($query)) {
            return $this->conn->insert_id;
        }
        return handle_db_error($query);
    }
    
    public function getBooking($bookingId) {
        $bookingId = (int)$bookingId;
        $query = "SELECT b.*, s.name as service_name, s.price as base_price, u.email 
                 FROM bookings b 
                 JOIN services s ON b.service_id = s.id 
                 JOIN users u ON b.user_id = u.id 
                 WHERE b.id = $bookingId";
        
        $result = $this->conn->query($query);
        return ($result) ? $result->fetch_assoc() : handle_db_error($query);
    }
    
    public function updateBookingStatus($bookingId, $status) {
        $bookingId = (int)$bookingId;
        $status = sanitize_input($status);
        
        $query = "UPDATE bookings SET status = '$status' WHERE id = $bookingId";
        return ($this->conn->query($query)) ? true : handle_db_error($query);
    }
    
    public function calculatePrice($serviceId, $guests, $preferences) {
        $serviceId = (int)$serviceId;
        $guests = (int)$guests;
        
        $query = "SELECT price, group_discount FROM services WHERE id = $serviceId";
        $result = $this->conn->query($query);
        
        if ($result) {
            $service = $result->fetch_assoc();
            $basePrice = $service['price'];
            $groupDiscount = $service['group_discount'];
            
            // Calculate total price with group discount
            $totalPrice = $basePrice * $guests;
            if ($guests >= 5 && $groupDiscount > 0) {
                $totalPrice *= (1 - ($groupDiscount / 100));
            }
            
            // Add premium options
            if (!empty($preferences)) {
                foreach ($preferences as $pref) {
                    $totalPrice += $pref['price'];
                }
            }
            
            return $totalPrice;
        }
        return handle_db_error($query);
    }
}
?>
