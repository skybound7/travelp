<?php
require_once 'database.php';
require_once 'Booking.php';

header('Content-Type: application/json');

// Get JSON input
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['serviceId']) || !isset($data['guests'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

// Initialize booking system
$booking = new Booking($conn);

// Calculate price
try {
    $price = $booking->calculatePrice(
        $data['serviceId'],
        $data['guests'],
        $data['preferences'] ?? []
    );
    
    echo json_encode([
        'success' => true,
        'price' => $price
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error calculating price: ' . $e->getMessage()
    ]);
}
?>
