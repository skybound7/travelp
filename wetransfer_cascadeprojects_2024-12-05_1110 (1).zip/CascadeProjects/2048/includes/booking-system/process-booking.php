<?php
require_once 'database.php';
require_once 'Booking.php';

header('Content-Type: application/json');

// Check if user is logged in
session_start();
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please log in to make a booking']);
    exit;
}

// Validate input
if (!isset($_POST['service_id']) || !isset($_POST['booking_date']) || !isset($_POST['guests'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

// Initialize booking system
$booking = new Booking($conn);

// Process the booking
try {
    $userId = $_SESSION['user_id'];
    $serviceId = (int)$_POST['service_id'];
    $bookingDate = sanitize_input($_POST['booking_date']);
    $guests = (int)$_POST['guests'];
    
    // Process preferences
    $preferences = [];
    if (isset($_POST['preferences']) && is_array($_POST['preferences'])) {
        foreach ($_POST['preferences'] as $pref) {
            $preferences[] = sanitize_input($pref);
        }
    }

    // Create the booking
    $bookingId = $booking->createBooking($userId, $serviceId, $bookingDate, $guests, $preferences);
    
    if ($bookingId) {
        // Send confirmation email
        $userEmail = $_SESSION['user_email'];
        $bookingDetails = $booking->getBooking($bookingId);
        sendBookingConfirmation($userEmail, $bookingDetails);
        
        echo json_encode([
            'success' => true,
            'bookingId' => $bookingId,
            'message' => 'Booking successful!'
        ]);
    } else {
        throw new Exception('Failed to create booking');
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred: ' . $e->getMessage()
    ]);
}

// Helper function to send confirmation email
function sendBookingConfirmation($email, $bookingDetails) {
    $subject = "Booking Confirmation - Luxury Travel";
    
    $message = "Thank you for your booking!\n\n";
    $message .= "Booking Details:\n";
    $message .= "Service: " . $bookingDetails['service_name'] . "\n";
    $message .= "Date: " . $bookingDetails['booking_date'] . "\n";
    $message .= "Guests: " . $bookingDetails['guests'] . "\n";
    $message .= "Total Price: $" . number_format($bookingDetails['total_price'], 2) . "\n\n";
    $message .= "We look forward to providing you with an exceptional experience!\n";
    
    $headers = "From: bookings@luxurytravel.com";
    
    mail($email, $subject, $message, $headers);
}
?>
