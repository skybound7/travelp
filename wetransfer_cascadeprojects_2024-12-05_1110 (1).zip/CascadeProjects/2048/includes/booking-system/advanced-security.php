<?php
class AdvancedSecurityManager {
    private $conn;
    private $config;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->config = [
            'jwt_secret' => getenv('JWT_SECRET'),
            'encryption_key' => getenv('ENCRYPTION_KEY'),
            'api_rate_limit' => 100, // requests per hour
            'max_file_size' => 5242880, // 5MB
            'allowed_file_types' => ['image/jpeg', 'image/png', 'application/pdf'],
            'password_history_limit' => 5
        ];
    }
    
    // Two-Factor Authentication
    public function setup2FA($userId) {
        require_once 'vendor/autoload.php';
        $google2fa = new \PragmaRX\Google2FA\Google2FA();
        
        $secret = $google2fa->generateSecretKey();
        $qrCodeUrl = $google2fa->getQRCodeUrl(
            'Luxury Travel',
            $_SESSION['user_email'],
            $secret
        );
        
        // Store encrypted secret
        $encryptedSecret = $this->encryptData($secret);
        $stmt = $this->conn->prepare("UPDATE users SET two_factor_secret = ? WHERE id = ?");
        $stmt->bind_param('si', $encryptedSecret, $userId);
        $stmt->execute();
        
        return $qrCodeUrl;
    }
    
    public function verify2FA($userId, $code) {
        require_once 'vendor/autoload.php';
        $google2fa = new \PragmaRX\Google2FA\Google2FA();
        
        // Get user's secret
        $stmt = $this->conn->prepare("SELECT two_factor_secret FROM users WHERE id = ?");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        $secret = $this->decryptData($result['two_factor_secret']);
        return $google2fa->verifyKey($secret, $code);
    }
    
    // Advanced Encryption
    private function encryptData($data) {
        $key = base64_decode($this->config['encryption_key']);
        $iv = random_bytes(16);
        $encrypted = openssl_encrypt(
            $data,
            'AES-256-CBC',
            $key,
            OPENSSL_RAW_DATA,
            $iv
        );
        return base64_encode($iv . $encrypted);
    }
    
    private function decryptData($encryptedData) {
        $key = base64_decode($this->config['encryption_key']);
        $data = base64_decode($encryptedData);
        $iv = substr($data, 0, 16);
        $encrypted = substr($data, 16);
        return openssl_decrypt(
            $encrypted,
            'AES-256-CBC',
            $key,
            OPENSSL_RAW_DATA,
            $iv
        );
    }
    
    // JWT Token Management
    public function generateJWT($userId) {
        $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
        $payload = json_encode([
            'user_id' => $userId,
            'iat' => time(),
            'exp' => time() + 3600
        ]);
        
        $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
        $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
        
        $signature = hash_hmac('sha256', $base64Header . '.' . $base64Payload, $this->config['jwt_secret'], true);
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
        
        return $base64Header . '.' . $base64Payload . '.' . $base64Signature;
    }
    
    public function verifyJWT($token) {
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            return false;
        }
        
        $signature = hash_hmac('sha256', $parts[0] . '.' . $parts[1], $this->config['jwt_secret'], true);
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
        
        if (!hash_equals($base64Signature, $parts[2])) {
            return false;
        }
        
        $payload = json_decode(base64_decode($parts[1]), true);
        return $payload['exp'] > time() ? $payload : false;
    }
    
    // Advanced Password Security
    public function enforcePasswordPolicy($password) {
        $errors = [];
        
        if (strlen($password) < 12) {
            $errors[] = 'Password must be at least 12 characters long';
        }
        if (!preg_match('/[A-Z]/', $password)) {
            $errors[] = 'Password must contain at least one uppercase letter';
        }
        if (!preg_match('/[a-z]/', $password)) {
            $errors[] = 'Password must contain at least one lowercase letter';
        }
        if (!preg_match('/[0-9]/', $password)) {
            $errors[] = 'Password must contain at least one number';
        }
        if (!preg_match('/[^A-Za-z0-9]/', $password)) {
            $errors[] = 'Password must contain at least one special character';
        }
        
        return empty($errors) ? true : $errors;
    }
    
    public function checkPasswordHistory($userId, $password) {
        $stmt = $this->conn->prepare("SELECT password_history FROM users WHERE id = ?");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        $history = json_decode($result['password_history'], true) ?? [];
        foreach ($history as $oldPassword) {
            if (password_verify($password, $oldPassword)) {
                return false;
            }
        }
        return true;
    }
    
    // File Upload Security
    public function validateFileUpload($file) {
        if ($file['size'] > $this->config['max_file_size']) {
            throw new Exception('File size exceeds limit');
        }
        
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        if (!in_array($mimeType, $this->config['allowed_file_types'])) {
            throw new Exception('Invalid file type');
        }
        
        // Scan file for malware (example integration)
        if (!$this->scanFileForMalware($file['tmp_name'])) {
            throw new Exception('File failed security scan');
        }
        
        return true;
    }
    
    private function scanFileForMalware($filePath) {
        // Integrate with ClamAV or other antivirus API
        // This is a placeholder implementation
        return true;
    }
    
    // IP-based Security
    public function checkIPReputation($ip) {
        // Integration with IP reputation service (e.g., AbuseIPDB)
        $apiKey = getenv('ABUSEIPDB_API_KEY');
        $url = "https://api.abuseipdb.com/api/v2/check";
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url . "?ipAddress=" . $ip,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                "Key: " . $apiKey,
                "Accept: application/json"
            ]
        ]);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $data = json_decode($response, true);
        return $data['data']['abuseConfidenceScore'] < 25;
    }
    
    // Audit Logging
    public function logSecurityAudit($event, $userId = null, $details = [], $severity = 'info') {
        $stmt = $this->conn->prepare("
            INSERT INTO security_audit_logs 
            (user_id, event_type, details, severity, ip_address, user_agent) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        $detailsJson = json_encode($details);
        $ip = $_SERVER['REMOTE_ADDR'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        
        $stmt->bind_param(
            'isssss',
            $userId,
            $event,
            $detailsJson,
            $severity,
            $ip,
            $userAgent
        );
        
        $stmt->execute();
    }
}

// Create security audit logs table
$securityAuditTable = "
CREATE TABLE IF NOT EXISTS security_audit_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    event_type VARCHAR(100) NOT NULL,
    details JSON,
    severity ENUM('info', 'warning', 'error', 'critical') DEFAULT 'info',
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_event_severity (user_id, event_type, severity),
    INDEX idx_created_at (created_at)
);
";
