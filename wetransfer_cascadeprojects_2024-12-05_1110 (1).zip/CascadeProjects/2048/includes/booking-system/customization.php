<?php
class BookingCustomizationManager {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    // Dynamic Package Builder
    public function createCustomPackage($baseServiceId, $options) {
        $baseService = $this->getServiceDetails($baseServiceId);
        $totalPrice = $baseService['price'];
        $duration = $baseService['duration'];
        
        $customizations = [];
        
        // Add selected options
        foreach ($options as $option) {
            $optionDetails = $this->getOptionDetails($option['id']);
            $totalPrice += $optionDetails['price'];
            $duration += $optionDetails['duration'];
            $customizations[] = $optionDetails;
        }
        
        return [
            'base_service' => $baseService,
            'customizations' => $customizations,
            'total_price' => $totalPrice,
            'total_duration' => $duration
        ];
    }
    
    // Seasonal Pricing
    public function calculateSeasonalPrice($serviceId, $date) {
        $stmt = $this->conn->prepare("
            SELECT adjustment_factor 
            FROM seasonal_pricing 
            WHERE service_id = ? 
            AND ? BETWEEN start_date AND end_date
        ");
        
        $stmt->bind_param('is', $serviceId, $date);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        return $result ? $result['adjustment_factor'] : 1.0;
    }
    
    // VIP Upgrades
    public function getVIPOptions($serviceId) {
        $stmt = $this->conn->prepare("
            SELECT * FROM vip_upgrades 
            WHERE service_id = ? 
            ORDER BY price ASC
        ");
        
        $stmt->bind_param('i', $serviceId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    // Special Occasions
    public function getOccasionPackages($occasion) {
        $stmt = $this->conn->prepare("
            SELECT * FROM occasion_packages 
            WHERE occasion_type = ?
        ");
        
        $stmt->bind_param('s', $occasion);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    // Group Customization
    public function calculateGroupOptions($serviceId, $groupSize) {
        $stmt = $this->conn->prepare("
            SELECT * FROM group_options 
            WHERE service_id = ? 
            AND min_guests <= ? 
            AND max_guests >= ?
        ");
        
        $stmt->bind_param('iii', $serviceId, $groupSize, $groupSize);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    // Dietary Preferences
    public function getDietaryOptions() {
        $query = "SELECT * FROM dietary_options ORDER BY name";
        $result = $this->conn->query($query);
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Transportation Options
    public function getTransportOptions($serviceId, $location) {
        $stmt = $this->conn->prepare("
            SELECT t.* 
            FROM transport_options t
            JOIN service_transport_availability sta ON t.id = sta.transport_id
            WHERE sta.service_id = ? AND t.available_in_location = ?
        ");
        
        $stmt->bind_param('is', $serviceId, $location);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    // Photography Packages
    public function getPhotographyPackages($serviceId) {
        $stmt = $this->conn->prepare("
            SELECT * FROM photography_packages 
            WHERE service_id = ? 
            ORDER BY price ASC
        ");
        
        $stmt->bind_param('i', $serviceId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    // Language Preferences
    public function getLanguageOptions($serviceId) {
        $stmt = $this->conn->prepare("
            SELECT l.* 
            FROM languages l
            JOIN service_language_availability sla ON l.id = sla.language_id
            WHERE sla.service_id = ?
        ");
        
        $stmt->bind_param('i', $serviceId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    // Equipment Rentals
    public function getEquipmentOptions($serviceId) {
        $stmt = $this->conn->prepare("
            SELECT * FROM equipment_rentals 
            WHERE service_id = ? 
            AND available_quantity > 0
        ");
        
        $stmt->bind_param('i', $serviceId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    // Private Guide Options
    public function getGuideOptions($serviceId, $date, $language) {
        $stmt = $this->conn->prepare("
            SELECT g.* 
            FROM guides g
            JOIN guide_availability ga ON g.id = ga.guide_id
            WHERE g.service_id = ? 
            AND ? BETWEEN ga.available_from AND ga.available_to
            AND g.language_id = ?
        ");
        
        $stmt->bind_param('isi', $serviceId, $date, $language);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}

// Create customization tables
$customizationTables = "
-- Seasonal Pricing
CREATE TABLE IF NOT EXISTS seasonal_pricing (
    id INT PRIMARY KEY AUTO_INCREMENT,
    service_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    adjustment_factor DECIMAL(4,2) NOT NULL,
    description VARCHAR(255),
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- VIP Upgrades
CREATE TABLE IF NOT EXISTS vip_upgrades (
    id INT PRIMARY KEY AUTO_INCREMENT,
    service_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    features JSON,
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- Occasion Packages
CREATE TABLE IF NOT EXISTS occasion_packages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    occasion_type VARCHAR(50) NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price_adjustment DECIMAL(10,2) NOT NULL,
    included_items JSON,
    INDEX idx_occasion (occasion_type)
);

-- Group Options
CREATE TABLE IF NOT EXISTS group_options (
    id INT PRIMARY KEY AUTO_INCREMENT,
    service_id INT NOT NULL,
    min_guests INT NOT NULL,
    max_guests INT NOT NULL,
    price_per_person DECIMAL(10,2),
    group_discount DECIMAL(5,2),
    additional_features JSON,
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- Dietary Options
CREATE TABLE IF NOT EXISTS dietary_options (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    description TEXT,
    price_adjustment DECIMAL(10,2),
    available_for_services JSON
);

-- Transportation Options
CREATE TABLE IF NOT EXISTS transport_options (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price_per_km DECIMAL(10,2),
    min_distance INT,
    max_passengers INT,
    available_in_location JSON,
    features JSON
);

-- Service Transport Availability
CREATE TABLE IF NOT EXISTS service_transport_availability (
    service_id INT NOT NULL,
    transport_id INT NOT NULL,
    PRIMARY KEY (service_id, transport_id),
    FOREIGN KEY (service_id) REFERENCES services(id),
    FOREIGN KEY (transport_id) REFERENCES transport_options(id)
);

-- Photography Packages
CREATE TABLE IF NOT EXISTS photography_packages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    service_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    duration INT,
    price DECIMAL(10,2) NOT NULL,
    deliverables JSON,
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- Languages
CREATE TABLE IF NOT EXISTS languages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    native_name VARCHAR(50),
    iso_code VARCHAR(5)
);

-- Service Language Availability
CREATE TABLE IF NOT EXISTS service_language_availability (
    service_id INT NOT NULL,
    language_id INT NOT NULL,
    price_adjustment DECIMAL(10,2),
    PRIMARY KEY (service_id, language_id),
    FOREIGN KEY (service_id) REFERENCES services(id),
    FOREIGN KEY (language_id) REFERENCES languages(id)
);

-- Equipment Rentals
CREATE TABLE IF NOT EXISTS equipment_rentals (
    id INT PRIMARY KEY AUTO_INCREMENT,
    service_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price_per_day DECIMAL(10,2) NOT NULL,
    available_quantity INT NOT NULL,
    specifications JSON,
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- Guides
CREATE TABLE IF NOT EXISTS guides (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    bio TEXT,
    language_id INT NOT NULL,
    expertise JSON,
    rating DECIMAL(3,2),
    price_per_day DECIMAL(10,2),
    FOREIGN KEY (language_id) REFERENCES languages(id)
);

-- Guide Availability
CREATE TABLE IF NOT EXISTS guide_availability (
    guide_id INT NOT NULL,
    available_from DATE NOT NULL,
    available_to DATE NOT NULL,
    PRIMARY KEY (guide_id, available_from, available_to),
    FOREIGN KEY (guide_id) REFERENCES guides(id)
);
";
