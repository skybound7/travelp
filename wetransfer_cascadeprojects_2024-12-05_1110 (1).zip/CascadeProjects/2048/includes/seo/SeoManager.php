<?php
class SeoManager {
    private $conn;
    private $baseUrl;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->baseUrl = 'https://luxurytravel.com'; // Update with actual domain
    }
    
    // Meta Tags Generation
    public function generateMetaTags($pageData) {
        $meta = [];
        
        // Essential meta tags
        $meta[] = "<title>{$pageData['title']} | Luxury Travel</title>";
        $meta[] = "<meta name=\"description\" content=\"{$pageData['description']}\">";
        
        // Open Graph tags
        $meta[] = "<meta property=\"og:title\" content=\"{$pageData['title']}\">";
        $meta[] = "<meta property=\"og:description\" content=\"{$pageData['description']}\">";
        $meta[] = "<meta property=\"og:image\" content=\"{$pageData['image']}\">";
        $meta[] = "<meta property=\"og:url\" content=\"{$this->getCurrentUrl()}\">";
        
        // Twitter Card tags
        $meta[] = "<meta name=\"twitter:card\" content=\"summary_large_image\">";
        $meta[] = "<meta name=\"twitter:title\" content=\"{$pageData['title']}\">";
        $meta[] = "<meta name=\"twitter:description\" content=\"{$pageData['description']}\">";
        $meta[] = "<meta name=\"twitter:image\" content=\"{$pageData['image']}\">";
        
        // Additional SEO tags
        $meta[] = "<meta name=\"robots\" content=\"index, follow\">";
        $meta[] = "<meta name=\"keywords\" content=\"{$pageData['keywords']}\">";
        $meta[] = "<link rel=\"canonical\" href=\"{$this->getCurrentUrl()}\">";
        
        return implode("\n    ", $meta);
    }
    
    // Schema.org Markup Generation
    public function generateSchemaMarkup($type, $data) {
        $schema = [];
        
        switch ($type) {
            case 'TravelService':
                $schema = [
                    "@context" => "https://schema.org",
                    "@type" => "TravelService",
                    "name" => $data['name'],
                    "description" => $data['description'],
                    "image" => $data['image'],
                    "priceRange" => $data['priceRange'],
                    "address" => [
                        "@type" => "PostalAddress",
                        "streetAddress" => $data['address']['street'],
                        "addressLocality" => $data['address']['city'],
                        "addressRegion" => $data['address']['region'],
                        "postalCode" => $data['address']['postal'],
                        "addressCountry" => $data['address']['country']
                    ],
                    "aggregateRating" => [
                        "@type" => "AggregateRating",
                        "ratingValue" => $data['rating']['value'],
                        "reviewCount" => $data['rating']['count']
                    ]
                ];
                break;
                
            case 'TourPackage':
                $schema = [
                    "@context" => "https://schema.org",
                    "@type" => "TourPackage",
                    "name" => $data['name'],
                    "description" => $data['description'],
                    "tourOperator" => [
                        "@type" => "Organization",
                        "name" => "Luxury Travel"
                    ],
                    "offers" => [
                        "@type" => "Offer",
                        "price" => $data['price'],
                        "priceCurrency" => "USD"
                    ]
                ];
                break;
        }
        
        return '<script type="application/ld+json">' . json_encode($schema, JSON_PRETTY_PRINT) . '</script>';
    }
    
    // URL Structure Management
    public function generateSeoUrl($type, $title, $id) {
        $slug = $this->createSlug($title);
        return "/{$type}/{$slug}-{$id}";
    }
    
    private function createSlug($text) {
        $text = preg_replace('~[^\pL\d]+~u', '-', $text);
        $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
        $text = preg_replace('~[^-\w]+~', '', $text);
        $text = trim($text, '-');
        $text = preg_replace('~-+~', '-', $text);
        return strtolower($text);
    }
    
    // Image Optimization
    public function optimizeImage($imagePath, $altText) {
        $imageInfo = getimagesize($imagePath);
        $width = $imageInfo[0];
        $height = $imageInfo[1];
        
        // Generate responsive image markup
        $sizes = [
            'small' => ['width' => 400, 'height' => round(400 * $height / $width)],
            'medium' => ['width' => 800, 'height' => round(800 * $height / $width)],
            'large' => ['width' => 1200, 'height' => round(1200 * $height / $width)]
        ];
        
        $srcset = [];
        foreach ($sizes as $size => $dimensions) {
            $srcset[] = $this->generateResizedImageUrl($imagePath, $dimensions['width']) . " {$dimensions['width']}w";
        }
        
        return sprintf(
            '<img src="%s" srcset="%s" sizes="(max-width: 400px) 400px, (max-width: 800px) 800px, 1200px" alt="%s" loading="lazy" width="%d" height="%d">',
            $imagePath,
            implode(', ', $srcset),
            htmlspecialchars($altText),
            $width,
            $height
        );
    }
    
    // XML Sitemap Generation
    public function generateSitemap() {
        $xml = new XMLWriter();
        $xml->openMemory();
        $xml->setIndent(true);
        $xml->startDocument('1.0', 'UTF-8');
        
        $xml->startElement('urlset');
        $xml->writeAttribute('xmlns', 'http://www.sitemaps.org/schemas/sitemap/0.9');
        
        // Add static pages
        $staticPages = ['', 'about', 'services', 'contact'];
        foreach ($staticPages as $page) {
            $this->addSitemapUrl($xml, $page);
        }
        
        // Add dynamic pages
        $this->addDynamicPagesToSitemap($xml);
        
        $xml->endElement(); // urlset
        
        // Save sitemap
        file_put_contents(__DIR__ . '/../../sitemap.xml', $xml->outputMemory());
    }
    
    private function addSitemapUrl($xml, $path, $priority = '0.8', $changefreq = 'weekly') {
        $xml->startElement('url');
        $xml->writeElement('loc', $this->baseUrl . '/' . $path);
        $xml->writeElement('lastmod', date('Y-m-d'));
        $xml->writeElement('changefreq', $changefreq);
        $xml->writeElement('priority', $priority);
        $xml->endElement(); // url
    }
    
    private function addDynamicPagesToSitemap($xml) {
        // Add services
        $query = "SELECT id, title, updated_at FROM services WHERE active = 1";
        $result = $this->conn->query($query);
        
        while ($row = $result->fetch_assoc()) {
            $url = $this->generateSeoUrl('services', $row['title'], $row['id']);
            $this->addSitemapUrl($xml, ltrim($url, '/'), '0.9', 'daily');
        }
    }
    
    // Robots.txt Generation
    public function generateRobotsTxt() {
        $content = [
            'User-agent: *',
            'Allow: /',
            'Disallow: /admin/',
            'Disallow: /includes/',
            'Disallow: /private/',
            'Disallow: /temp/',
            'Disallow: /*?*',
            '',
            'Sitemap: ' . $this->baseUrl . '/sitemap.xml'
        ];
        
        file_put_contents(__DIR__ . '/../../robots.txt', implode("\n", $content));
    }
    
    // Mobile Optimization Check
    public function checkMobileOptimization() {
        $issues = [];
        
        // Check viewport meta tag
        if (!$this->hasViewportMeta()) {
            $issues[] = 'Missing viewport meta tag';
        }
        
        // Check touch targets
        if (!$this->checkTouchTargets()) {
            $issues[] = 'Touch targets too small or too close';
        }
        
        // Check font sizes
        if (!$this->checkFontSizes()) {
            $issues[] = 'Font sizes too small for mobile';
        }
        
        // Check responsive images
        if (!$this->checkResponsiveImages()) {
            $issues[] = 'Images not responsive';
        }
        
        return $issues;
    }
    
    // Performance Optimization
    public function optimizePerformance() {
        // Enable GZIP compression
        if (!$this->isGzipEnabled()) {
            $this->enableGzipCompression();
        }
        
        // Configure browser caching
        $this->configureBrowserCaching();
        
        // Minify CSS and JavaScript
        $this->minifyAssets();
        
        // Optimize images
        $this->bulkImageOptimization();
    }
}

// Create SEO-related tables
$seoTables = "
CREATE TABLE IF NOT EXISTS seo_meta (
    id INT PRIMARY KEY AUTO_INCREMENT,
    page_path VARCHAR(255) NOT NULL,
    title VARCHAR(60) NOT NULL,
    description VARCHAR(160) NOT NULL,
    keywords VARCHAR(255),
    og_image VARCHAR(255),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY idx_page_path (page_path)
);

CREATE TABLE IF NOT EXISTS image_meta (
    id INT PRIMARY KEY AUTO_INCREMENT,
    image_path VARCHAR(255) NOT NULL,
    alt_text VARCHAR(255) NOT NULL,
    caption TEXT,
    dimensions JSON,
    optimization_status ENUM('pending', 'optimized', 'failed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY idx_image_path (image_path)
);

CREATE TABLE IF NOT EXISTS url_redirects (
    id INT PRIMARY KEY AUTO_INCREMENT,
    old_url VARCHAR(255) NOT NULL,
    new_url VARCHAR(255) NOT NULL,
    redirect_type ENUM('301', '302') DEFAULT '301',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY idx_old_url (old_url)
);

CREATE TABLE IF NOT EXISTS seo_performance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    page_path VARCHAR(255) NOT NULL,
    mobile_score INT,
    desktop_score INT,
    load_time DECIMAL(5,2),
    issues JSON,
    checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_page_path (page_path)
);
";
