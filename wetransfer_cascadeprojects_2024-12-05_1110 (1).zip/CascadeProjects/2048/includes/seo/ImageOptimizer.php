<?php
class ImageOptimizer {
    private $conn;
    private $uploadDir;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->uploadDir = __DIR__ . '/../../uploads/images/';
    }
    
    public function optimizeAndSaveImage($file, $altText, $caption = '') {
        try {
            // Validate image
            $this->validateImage($file);
            
            // Get image info
            $imageInfo = getimagesize($file['tmp_name']);
            $mime = $imageInfo['mime'];
            $width = $imageInfo[0];
            $height = $imageInfo[1];
            
            // Generate unique filename
            $filename = $this->generateUniqueFilename($file['name']);
            $path = $this->uploadDir . $filename;
            
            // Create image variations
            $variations = $this->createImageVariations($file['tmp_name'], $filename, $mime);
            
            // Move original file
            move_uploaded_file($file['tmp_name'], $path);
            
            // Save metadata to database
            $this->saveImageMetadata($filename, $altText, $caption, $variations, $width, $height);
            
            return [
                'success' => true,
                'filename' => $filename,
                'variations' => $variations,
                'dimensions' => ['width' => $width, 'height' => $height]
            ];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    private function validateImage($file) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
        $maxSize = 5 * 1024 * 1024; // 5MB
        
        if (!in_array($file['type'], $allowedTypes)) {
            throw new Exception('Invalid image type. Allowed types: JPG, PNG, WebP');
        }
        
        if ($file['size'] > $maxSize) {
            throw new Exception('File size too large. Maximum size: 5MB');
        }
        
        if (!is_uploaded_file($file['tmp_name'])) {
            throw new Exception('Invalid file upload');
        }
    }
    
    private function createImageVariations($sourcePath, $filename, $mime) {
        $variations = [];
        $sizes = [
            'thumbnail' => ['width' => 150, 'height' => 150],
            'small' => ['width' => 400, 'height' => null],
            'medium' => ['width' => 800, 'height' => null],
            'large' => ['width' => 1200, 'height' => null]
        ];
        
        foreach ($sizes as $size => $dimensions) {
            $variations[$size] = $this->resizeImage(
                $sourcePath,
                $this->uploadDir . $size . '_' . $filename,
                $dimensions['width'],
                $dimensions['height'],
                $mime
            );
        }
        
        // Create WebP versions
        if ($mime !== 'image/webp') {
            foreach ($sizes as $size => $dimensions) {
                $webpFilename = pathinfo($filename, PATHINFO_FILENAME) . '.webp';
                $variations[$size . '_webp'] = $this->convertToWebP(
                    $this->uploadDir . $size . '_' . $filename,
                    $this->uploadDir . $size . '_' . $webpFilename
                );
            }
        }
        
        return $variations;
    }
    
    private function resizeImage($source, $destination, $width, $height, $mime) {
        list($origWidth, $origHeight) = getimagesize($source);
        
        // Calculate new dimensions
        if ($height === null) {
            $height = round($origHeight * ($width / $origWidth));
        }
        
        // Create new image
        $new = imagecreatetruecolor($width, $height);
        
        // Handle transparency for PNG
        if ($mime === 'image/png') {
            imagealphablending($new, false);
            imagesavealpha($new, true);
        }
        
        // Load source image
        switch ($mime) {
            case 'image/jpeg':
                $source = imagecreatefromjpeg($source);
                break;
            case 'image/png':
                $source = imagecreatefrompng($source);
                break;
            case 'image/webp':
                $source = imagecreatefromwebp($source);
                break;
        }
        
        // Resize
        imagecopyresampled(
            $new, $source,
            0, 0, 0, 0,
            $width, $height,
            $origWidth, $origHeight
        );
        
        // Save
        switch ($mime) {
            case 'image/jpeg':
                imagejpeg($new, $destination, 85);
                break;
            case 'image/png':
                imagepng($new, $destination, 8);
                break;
            case 'image/webp':
                imagewebp($new, $destination, 85);
                break;
        }
        
        // Clean up
        imagedestroy($new);
        imagedestroy($source);
        
        return basename($destination);
    }
    
    private function convertToWebP($source, $destination) {
        $info = getimagesize($source);
        $mime = $info['mime'];
        
        switch ($mime) {
            case 'image/jpeg':
                $image = imagecreatefromjpeg($source);
                break;
            case 'image/png':
                $image = imagecreatefrompng($source);
                break;
            default:
                return false;
        }
        
        imagewebp($image, $destination, 85);
        imagedestroy($image);
        
        return basename($destination);
    }
    
    private function generateUniqueFilename($originalName) {
        $info = pathinfo($originalName);
        $ext = $info['extension'];
        $filename = $info['filename'];
        
        // Clean filename
        $filename = preg_replace('/[^a-z0-9]+/', '-', strtolower($filename));
        
        // Add timestamp and random string
        $unique = time() . '-' . substr(md5(uniqid()), 0, 8);
        
        return "{$filename}-{$unique}.{$ext}";
    }
    
    private function saveImageMetadata($filename, $altText, $caption, $variations, $width, $height) {
        $stmt = $this->conn->prepare("
            INSERT INTO image_meta (
                image_path,
                alt_text,
                caption,
                dimensions,
                variations,
                optimization_status
            ) VALUES (?, ?, ?, ?, ?, 'optimized')
        ");
        
        $dimensionsJson = json_encode(['width' => $width, 'height' => $height]);
        $variationsJson = json_encode($variations);
        
        $stmt->bind_param('sssss',
            $filename,
            $altText,
            $caption,
            $dimensionsJson,
            $variationsJson
        );
        
        $stmt->execute();
    }
    
    public function generateImageMarkup($imageId, $size = 'medium', $lazy = true) {
        $stmt = $this->conn->prepare("
            SELECT * FROM image_meta WHERE id = ?
        ");
        $stmt->bind_param('i', $imageId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        if (!$result) {
            return '';
        }
        
        $variations = json_decode($result['variations'], true);
        $dimensions = json_decode($result['dimensions'], true);
        
        // Generate srcset
        $srcset = [];
        foreach (['small', 'medium', 'large'] as $sizeKey) {
            if (isset($variations[$sizeKey])) {
                $srcset[] = "/uploads/images/{$variations[$sizeKey]} " . $this->getSizeWidth($sizeKey) . 'w';
            }
            if (isset($variations[$sizeKey . '_webp'])) {
                $webpSrcset[] = "/uploads/images/{$variations[$sizeKey . '_webp']} " . $this->getSizeWidth($sizeKey) . 'w';
            }
        }
        
        // Build image markup
        $markup = '<picture>';
        
        // Add WebP source if available
        if (!empty($webpSrcset)) {
            $markup .= sprintf(
                '<source type="image/webp" srcset="%s" sizes="%s">',
                implode(', ', $webpSrcset),
                $this->getSizesAttribute()
            );
        }
        
        // Add default source
        $markup .= sprintf(
            '<source srcset="%s" sizes="%s">',
            implode(', ', $srcset),
            $this->getSizesAttribute()
        );
        
        // Add img tag
        $markup .= sprintf(
            '<img src="/uploads/images/%s" alt="%s" width="%d" height="%d" %s>',
            $variations[$size],
            htmlspecialchars($result['alt_text']),
            $dimensions['width'],
            $dimensions['height'],
            $lazy ? 'loading="lazy"' : ''
        );
        
        $markup .= '</picture>';
        
        return $markup;
    }
    
    private function getSizeWidth($size) {
        switch ($size) {
            case 'small': return 400;
            case 'medium': return 800;
            case 'large': return 1200;
            default: return 800;
        }
    }
    
    private function getSizesAttribute() {
        return '(max-width: 400px) 400px, (max-width: 800px) 800px, 1200px';
    }
}
?>
