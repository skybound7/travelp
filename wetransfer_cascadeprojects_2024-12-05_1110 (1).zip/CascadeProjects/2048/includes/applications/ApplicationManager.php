<?php
require_once __DIR__ . '/../config.php';

class ApplicationManager {
    private $conn;
    
    public function __construct() {
        $this->conn = getDBConnection();
    }
    
    public function submitApplication($userId, $serviceType, $applicationData, $documents) {
        try {
            $this->conn->begin_transaction();
            
            // Insert application
            $stmt = $this->conn->prepare("
                INSERT INTO service_applications 
                (user_id, service_type, application_data, submitted_documents) 
                VALUES (?, ?, ?, ?)
            ");
            
            $applicationDataJson = json_encode($applicationData);
            $documentsJson = json_encode($documents);
            
            $stmt->bind_param("isss", 
                $userId,
                $serviceType,
                $applicationDataJson,
                $documentsJson
            );
            
            $stmt->execute();
            $applicationId = $this->conn->insert_id;
            
            // Handle file uploads
            $uploadPath = __DIR__ . '/../../uploads/applications/' . $applicationId;
            if (!file_exists($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            
            foreach ($documents as $docType => $fileInfo) {
                $targetPath = $uploadPath . '/' . $docType . '_' . basename($fileInfo['name']);
                move_uploaded_file($fileInfo['tmp_name'], $targetPath);
                
                // Update document path in database
                $documents[$docType]['path'] = $targetPath;
            }
            
            // Update application with final document paths
            $stmt = $this->conn->prepare("
                UPDATE service_applications 
                SET submitted_documents = ? 
                WHERE id = ?
            ");
            
            $updatedDocumentsJson = json_encode($documents);
            $stmt->bind_param("si", $updatedDocumentsJson, $applicationId);
            $stmt->execute();
            
            $this->conn->commit();
            return $applicationId;
            
        } catch (Exception $e) {
            $this->conn->rollback();
            throw $e;
        }
    }
    
    public function getApplication($applicationId) {
        $stmt = $this->conn->prepare("
            SELECT * FROM service_applications 
            WHERE id = ?
        ");
        
        $stmt->bind_param("i", $applicationId);
        $stmt->execute();
        
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    public function updateApplicationStatus($applicationId, $status, $adminNotes = '') {
        $stmt = $this->conn->prepare("
            UPDATE service_applications 
            SET status = ?, admin_notes = ? 
            WHERE id = ?
        ");
        
        $stmt->bind_param("ssi", $status, $adminNotes, $applicationId);
        return $stmt->execute();
    }
    
    public function getApplicationsByUser($userId) {
        $stmt = $this->conn->prepare("
            SELECT * FROM service_applications 
            WHERE user_id = ? 
            ORDER BY created_at DESC
        ");
        
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    public function getApplicationsByStatus($status) {
        $stmt = $this->conn->prepare("
            SELECT sa.*, u.name as applicant_name, u.email as applicant_email 
            FROM service_applications sa 
            JOIN users u ON sa.user_id = u.id 
            WHERE sa.status = ? 
            ORDER BY sa.created_at DESC
        ");
        
        $stmt->bind_param("s", $status);
        $stmt->execute();
        
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    public function addApplicationReview($applicationId, $reviewerId, $status, $comments) {
        $stmt = $this->conn->prepare("
            INSERT INTO application_reviews 
            (application_id, reviewer_id, review_status, comments) 
            VALUES (?, ?, ?, ?)
        ");
        
        $stmt->bind_param("iiss", 
            $applicationId,
            $reviewerId,
            $status,
            $comments
        );
        
        if ($stmt->execute()) {
            // Update main application status based on review
            $this->updateApplicationStatus($applicationId, $status);
            return $stmt->insert_id;
        }
        
        return false;
    }
    
    public function getApplicationReviews($applicationId) {
        $stmt = $this->conn->prepare("
            SELECT ar.*, u.name as reviewer_name 
            FROM application_reviews ar 
            JOIN users u ON ar.reviewer_id = u.id 
            WHERE ar.application_id = ? 
            ORDER BY ar.created_at DESC
        ");
        
        $stmt->bind_param("i", $applicationId);
        $stmt->execute();
        
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
}
