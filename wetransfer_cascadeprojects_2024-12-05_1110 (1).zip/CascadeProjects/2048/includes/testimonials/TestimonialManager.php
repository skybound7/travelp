<?php
require_once __DIR__ . '/../config.php';

class TestimonialManager {
    private $conn;
    
    public function __construct() {
        $this->conn = getDBConnection();
    }
    
    public function getTestimonials($limit = 10, $offset = 0) {
        $query = "
            SELECT t.*, 
                   u.name as guest_name,
                   u.location as guest_location,
                   p.title as property_title,
                   p.location as property_location,
                   GROUP_CONCAT(tp.photo_url) as experience_photos
            FROM testimonials t
            JOIN users u ON t.user_id = u.id
            JOIN properties p ON t.property_id = p.id
            LEFT JOIN testimonial_photos tp ON t.id = tp.testimonial_id
            WHERE t.status = 'approved'
            GROUP BY t.id
            ORDER BY t.created_at DESC
            LIMIT ? OFFSET ?
        ";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $limit, $offset);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    public function getFeaturedTestimonials($limit = 3) {
        $query = "
            SELECT t.*, 
                   u.name as guest_name,
                   u.location as guest_location,
                   p.title as property_title,
                   p.location as property_location,
                   GROUP_CONCAT(tp.photo_url) as experience_photos
            FROM testimonials t
            JOIN users u ON t.user_id = u.id
            JOIN properties p ON t.property_id = p.id
            LEFT JOIN testimonial_photos tp ON t.id = tp.testimonial_id
            WHERE t.status = 'approved'
            AND t.is_featured = 1
            GROUP BY t.id
            ORDER BY t.rating DESC, t.created_at DESC
            LIMIT ?
        ";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    public function addTestimonial($data) {
        $this->conn->begin_transaction();
        
        try {
            // Insert testimonial
            $stmt = $this->conn->prepare("
                INSERT INTO testimonials 
                (user_id, property_id, rating, content, stay_date, status) 
                VALUES (?, ?, ?, ?, ?, 'pending')
            ");
            
            $stmt->bind_param("iidss",
                $data['user_id'],
                $data['property_id'],
                $data['rating'],
                $data['content'],
                $data['stay_date']
            );
            
            $stmt->execute();
            $testimonialId = $this->conn->insert_id;
            
            // Handle photos if provided
            if (!empty($data['photos'])) {
                $photoStmt = $this->conn->prepare("
                    INSERT INTO testimonial_photos 
                    (testimonial_id, photo_url, display_order) 
                    VALUES (?, ?, ?)
                ");
                
                foreach ($data['photos'] as $index => $photo) {
                    $photoStmt->bind_param("isi",
                        $testimonialId,
                        $photo['url'],
                        $index
                    );
                    $photoStmt->execute();
                }
            }
            
            $this->conn->commit();
            return $testimonialId;
        } catch (Exception $e) {
            $this->conn->rollback();
            throw $e;
        }
    }
    
    public function getTestimonialStats() {
        $stats = [
            'average_rating' => 0,
            'total_guests' => 0,
            'return_rate' => 0,
            'total_destinations' => 0
        ];
        
        // Get average rating
        $query = "SELECT AVG(rating) as avg_rating FROM testimonials WHERE status = 'approved'";
        $result = $this->conn->query($query);
        $stats['average_rating'] = round($result->fetch_assoc()['avg_rating'], 1);
        
        // Get total guests
        $query = "SELECT COUNT(DISTINCT user_id) as total_guests FROM testimonials";
        $result = $this->conn->query($query);
        $stats['total_guests'] = $result->fetch_assoc()['total_guests'];
        
        // Calculate return rate
        $query = "
            SELECT 
                (COUNT(DISTINCT CASE WHEN booking_count > 1 THEN user_id END) * 100.0 / 
                COUNT(DISTINCT user_id)) as return_rate
            FROM (
                SELECT user_id, COUNT(*) as booking_count
                FROM bookings
                GROUP BY user_id
            ) user_bookings
        ";
        $result = $this->conn->query($query);
        $stats['return_rate'] = round($result->fetch_assoc()['return_rate']);
        
        // Get total destinations
        $query = "SELECT COUNT(DISTINCT city) as total_destinations FROM properties";
        $result = $this->conn->query($query);
        $stats['total_destinations'] = $result->fetch_assoc()['total_destinations'];
        
        return $stats;
    }
    
    public function moderateTestimonial($testimonialId, $action) {
        $validActions = ['approve', 'reject', 'feature', 'unfeature'];
        if (!in_array($action, $validActions)) {
            throw new InvalidArgumentException('Invalid moderation action');
        }
        
        switch ($action) {
            case 'approve':
            case 'reject':
                $stmt = $this->conn->prepare("
                    UPDATE testimonials 
                    SET status = ? 
                    WHERE id = ?
                ");
                $status = $action === 'approve' ? 'approved' : 'rejected';
                $stmt->bind_param("si", $status, $testimonialId);
                break;
                
            case 'feature':
            case 'unfeature':
                $stmt = $this->conn->prepare("
                    UPDATE testimonials 
                    SET is_featured = ? 
                    WHERE id = ?
                ");
                $featured = $action === 'feature' ? 1 : 0;
                $stmt->bind_param("ii", $featured, $testimonialId);
                break;
        }
        
        return $stmt->execute();
    }
}
