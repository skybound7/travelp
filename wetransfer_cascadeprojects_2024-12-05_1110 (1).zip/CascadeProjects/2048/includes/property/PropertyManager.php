<?php
require_once __DIR__ . '/../config.php';

class PropertyManager {
    private $conn;
    
    public function __construct() {
        $this->conn = getDBConnection();
    }
    
    public function registerPropertyOwner($userData) {
        $stmt = $this->conn->prepare("
            INSERT INTO property_owners 
            (user_id, business_name, tax_id, contact_phone, contact_email) 
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $stmt->bind_param("issss", 
            $userData['user_id'],
            $userData['business_name'],
            $userData['tax_id'],
            $userData['contact_phone'],
            $userData['contact_email']
        );
        
        return $stmt->execute();
    }
    
    public function listProperty($propertyData) {
        $this->conn->begin_transaction();
        
        try {
            // Insert property details
            $stmt = $this->conn->prepare("
                INSERT INTO properties 
                (owner_id, property_type, title, description, address, city, 
                country, postal_code, latitude, longitude, price_per_night, 
                capacity, bedrooms, bathrooms, amenities, rules, availability_calendar) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $amenitiesJson = json_encode($propertyData['amenities']);
            $rulesText = implode("\n", $propertyData['rules']);
            $availabilityJson = json_encode($propertyData['availability']);
            
            $stmt->bind_param("isssssssdddiiissr",
                $propertyData['owner_id'],
                $propertyData['property_type'],
                $propertyData['title'],
                $propertyData['description'],
                $propertyData['address'],
                $propertyData['city'],
                $propertyData['country'],
                $propertyData['postal_code'],
                $propertyData['latitude'],
                $propertyData['longitude'],
                $propertyData['price_per_night'],
                $propertyData['capacity'],
                $propertyData['bedrooms'],
                $propertyData['bathrooms'],
                $amenitiesJson,
                $rulesText,
                $availabilityJson
            );
            
            $stmt->execute();
            $propertyId = $this->conn->insert_id;
            
            // Handle photos
            if (!empty($propertyData['photos'])) {
                $photoStmt = $this->conn->prepare("
                    INSERT INTO property_photos 
                    (property_id, photo_url, is_primary, display_order) 
                    VALUES (?, ?, ?, ?)
                ");
                
                foreach ($propertyData['photos'] as $index => $photo) {
                    $isPrimary = $index === 0 ? 1 : 0;
                    $photoStmt->bind_param("isii",
                        $propertyId,
                        $photo['url'],
                        $isPrimary,
                        $index
                    );
                    $photoStmt->execute();
                }
            }
            
            // Handle rental car specific details
            if ($propertyData['property_type'] === 'rental_car') {
                $carStmt = $this->conn->prepare("
                    INSERT INTO rental_cars 
                    (property_id, make, model, year, transmission, fuel_type, 
                    seats, price_per_day, insurance_details) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $insuranceJson = json_encode($propertyData['insurance_details']);
                
                $carStmt->bind_param("ississids",
                    $propertyId,
                    $propertyData['make'],
                    $propertyData['model'],
                    $propertyData['year'],
                    $propertyData['transmission'],
                    $propertyData['fuel_type'],
                    $propertyData['seats'],
                    $propertyData['price_per_day'],
                    $insuranceJson
                );
                
                $carStmt->execute();
            }
            
            $this->conn->commit();
            return $propertyId;
        } catch (Exception $e) {
            $this->conn->rollback();
            throw $e;
        }
    }
    
    public function searchProperties($filters) {
        $query = "
            SELECT p.*, pp.photo_url as primary_photo
            FROM properties p
            LEFT JOIN property_photos pp ON p.id = pp.property_id AND pp.is_primary = 1
            WHERE p.status = 'active'
        ";
        
        $params = [];
        $types = "";
        
        if (!empty($filters['property_type'])) {
            $query .= " AND p.property_type = ?";
            $params[] = $filters['property_type'];
            $types .= "s";
        }
        
        if (!empty($filters['city'])) {
            $query .= " AND p.city LIKE ?";
            $params[] = "%{$filters['city']}%";
            $types .= "s";
        }
        
        if (!empty($filters['max_price'])) {
            $query .= " AND p.price_per_night <= ?";
            $params[] = $filters['max_price'];
            $types .= "d";
        }
        
        if (!empty($filters['min_bedrooms'])) {
            $query .= " AND p.bedrooms >= ?";
            $params[] = $filters['min_bedrooms'];
            $types .= "i";
        }
        
        $stmt = $this->conn->prepare($query);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $properties = [];
        while ($row = $result->fetch_assoc()) {
            $properties[] = $row;
        }
        
        return $properties;
    }
    
    public function getPropertyDetails($propertyId) {
        $query = "
            SELECT p.*, 
                   GROUP_CONCAT(pp.photo_url) as photos,
                   po.business_name as owner_business_name,
                   po.contact_phone as owner_contact_phone,
                   po.contact_email as owner_contact_email,
                   CASE 
                       WHEN p.property_type = 'rental_car' 
                       THEN (SELECT JSON_OBJECT(
                           'make', rc.make,
                           'model', rc.model,
                           'year', rc.year,
                           'transmission', rc.transmission,
                           'fuel_type', rc.fuel_type,
                           'seats', rc.seats,
                           'price_per_day', rc.price_per_day,
                           'insurance_details', rc.insurance_details
                       ) FROM rental_cars rc WHERE rc.property_id = p.id)
                       ELSE NULL
                   END as vehicle_details
            FROM properties p
            LEFT JOIN property_photos pp ON p.id = pp.property_id
            LEFT JOIN property_owners po ON p.owner_id = po.id
            WHERE p.id = ?
            GROUP BY p.id
        ";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $propertyId);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_assoc();
    }
    
    public function updateAvailability($propertyId, $availability) {
        $stmt = $this->conn->prepare("
            UPDATE properties 
            SET availability_calendar = ?
            WHERE id = ?
        ");
        
        $availabilityJson = json_encode($availability);
        $stmt->bind_param("si", $availabilityJson, $propertyId);
        
        return $stmt->execute();
    }
}
