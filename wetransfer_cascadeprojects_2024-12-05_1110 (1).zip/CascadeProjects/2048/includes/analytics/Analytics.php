<?php
class Analytics {
    private $conn;
    private $config;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->config = [
            'ga_id' => 'G-XXXXXXXXXX',  // Replace with actual GA4 ID
            'gtm_id' => 'GTM-XXXXXX',   // Replace with actual GTM ID
            'fb_pixel' => 'XXXXXXXXXX'   // Replace with actual FB Pixel ID
        ];
    }
    
    public function getTrackingCode() {
        return <<<EOT
<!-- Google Analytics 4 -->
<script async src="https://www.googletagmanager.com/gtag/js?id={$this->config['ga_id']}"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '{$this->config['ga_id']}', {
        'send_page_view': true,
        'page_title': document.title,
        'page_path': window.location.pathname,
        'user_properties': {
            'user_type': '{$this->getUserType()}',
            'user_id': '{$this->getUserId()}'
        }
    });
</script>

<!-- Google Tag Manager -->
<script>
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','{$this->config['gtm_id']}');</script>

<!-- Facebook Pixel -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '{$this->config['fb_pixel']}');
fbq('track', 'PageView');
</script>
EOT;
    }
    
    public function trackConversion($data) {
        // Log conversion to database
        $this->logConversion($data);
        
        // Generate tracking code
        return <<<EOT
<script>
// Google Analytics Conversion
gtag('event', 'conversion', {
    'send_to': '{$this->config['ga_id']}/conversion',
    'value': {$data['value']},
    'currency': 'USD',
    'transaction_id': '{$data['transaction_id']}'
});

// Facebook Pixel Conversion
fbq('track', 'Purchase', {
    value: {$data['value']},
    currency: 'USD',
    content_ids: [{$data['product_ids']}],
    content_type: 'product'
});

// Custom Event
dataLayer.push({
    'event': 'purchase',
    'ecommerce': {
        'transaction_id': '{$data['transaction_id']}',
        'value': {$data['value']},
        'currency': 'USD',
        'items': {$this->formatItems($data['items'])}
    }
});
</script>
EOT;
    }
    
    public function trackEvent($category, $action, $label = null, $value = null) {
        // Log event to database
        $this->logEvent($category, $action, $label, $value);
        
        return <<<EOT
<script>
// Google Analytics Event
gtag('event', '$action', {
    'event_category': '$category',
    'event_label': '$label',
    'value': $value
});

// Facebook Pixel Custom Event
fbq('trackCustom', '$action', {
    category: '$category',
    label: '$label',
    value: $value
});

// DataLayer Push
dataLayer.push({
    'event': '$action',
    'event_category': '$category',
    'event_label': '$label',
    'event_value': $value
});
</script>
EOT;
    }
    
    private function logConversion($data) {
        $stmt = $this->conn->prepare("
            INSERT INTO conversions (
                user_id,
                transaction_id,
                conversion_type,
                value,
                currency,
                metadata,
                created_at
            ) VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $userId = $this->getUserId();
        $metadata = json_encode($data);
        
        $stmt->bind_param('issdss',
            $userId,
            $data['transaction_id'],
            $data['type'],
            $data['value'],
            'USD',
            $metadata
        );
        
        $stmt->execute();
    }
    
    private function logEvent($category, $action, $label, $value) {
        $stmt = $this->conn->prepare("
            INSERT INTO analytics_events (
                user_id,
                event_category,
                event_action,
                event_label,
                event_value,
                page_url,
                created_at
            ) VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $userId = $this->getUserId();
        $pageUrl = $_SERVER['REQUEST_URI'];
        
        $stmt->bind_param('isssds',
            $userId,
            $category,
            $action,
            $label,
            $value,
            $pageUrl
        );
        
        $stmt->execute();
    }
    
    private function formatItems($items) {
        return json_encode(array_map(function($item) {
            return [
                'item_id' => $item['id'],
                'item_name' => $item['name'],
                'price' => $item['price'],
                'quantity' => $item['quantity']
            ];
        }, $items));
    }
    
    private function getUserId() {
        return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    }
    
    private function getUserType() {
        return isset($_SESSION['user_type']) ? $_SESSION['user_type'] : 'guest';
    }
}

// Create analytics tables
$analyticsTables = "
CREATE TABLE IF NOT EXISTS conversions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    transaction_id VARCHAR(50) NOT NULL,
    conversion_type VARCHAR(50) NOT NULL,
    value DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'USD',
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_transaction (transaction_id),
    INDEX idx_type (conversion_type)
);

CREATE TABLE IF NOT EXISTS analytics_events (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    event_category VARCHAR(50) NOT NULL,
    event_action VARCHAR(50) NOT NULL,
    event_label VARCHAR(255),
    event_value DECIMAL(10,2),
    page_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_event (user_id, event_category, event_action),
    INDEX idx_created (created_at)
);
";
?>
