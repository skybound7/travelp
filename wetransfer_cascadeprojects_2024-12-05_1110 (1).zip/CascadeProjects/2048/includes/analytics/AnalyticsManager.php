<?php
class AnalyticsManager {
    private $conn;
    private $config;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->config = [
            'ga_id' => 'G-XXXXXXXXXX', // Google Analytics ID
            'gtm_id' => 'GTM-XXXXXX', // Google Tag Manager ID
            'fb_pixel_id' => 'XXXXXXXXXX', // Facebook Pixel ID
            'hotjar_id' => 'XXXXXXX' // Hotjar ID
        ];
    }
    
    // Analytics Script Generation
    public function generateTrackingScripts() {
        $scripts = [];
        
        // Google Analytics 4
        $scripts[] = <<<EOT
<!-- Google Analytics 4 -->
<script async src="https://www.googletagmanager.com/gtag/js?id={$this->config['ga_id']}"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '{$this->config['ga_id']}', {
        'send_page_view': true,
        'page_title': document.title,
        'user_id': '{$this->getUserId()}',
        'custom_map': {
            'dimension1': 'user_type',
            'dimension2': 'booking_value',
            'dimension3': 'service_category'
        }
    });
</script>
EOT;

        // Google Tag Manager
        $scripts[] = <<<EOT
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','{$this->config['gtm_id']}');</script>
<!-- End Google Tag Manager -->
EOT;

        // Facebook Pixel
        $scripts[] = <<<EOT
<!-- Facebook Pixel -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '{$this->config['fb_pixel_id']}');
fbq('track', 'PageView');
</script>
EOT;

        // Hotjar
        $scripts[] = <<<EOT
<!-- Hotjar -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:{$this->config['hotjar_id']},hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
EOT;

        return implode("\n", $scripts);
    }
    
    // Custom Event Tracking
    public function trackEvent($category, $action, $label = null, $value = null) {
        $script = <<<EOT
<script>
    gtag('event', '$action', {
        'event_category': '$category',
        'event_label': '$label',
        'value': $value
    });
    
    // Facebook Pixel event
    fbq('trackCustom', '$action', {
        category: '$category',
        label: '$label',
        value: $value
    });
</script>
EOT;

        return $script;
    }
    
    // E-commerce Tracking
    public function trackPurchase($transactionData) {
        $script = <<<EOT
<script>
    // Google Analytics E-commerce
    gtag('event', 'purchase', {
        transaction_id: '{$transactionData['id']}',
        value: {$transactionData['value']},
        currency: 'USD',
        items: {$this->formatItems($transactionData['items'])}
    });
    
    // Facebook Pixel Purchase
    fbq('track', 'Purchase', {
        value: {$transactionData['value']},
        currency: 'USD',
        content_ids: {$this->getContentIds($transactionData['items'])},
        content_type: 'product'
    });
</script>
EOT;

        return $script;
    }
    
    // User Behavior Analytics
    public function trackUserBehavior($userId, $behavior) {
        $stmt = $this->conn->prepare("
            INSERT INTO user_analytics (
                user_id,
                behavior_type,
                page_url,
                interaction_data,
                session_id
            ) VALUES (?, ?, ?, ?, ?)
        ");
        
        $sessionId = session_id();
        $pageUrl = $_SERVER['REQUEST_URI'];
        $interactionData = json_encode($behavior);
        
        $stmt->bind_param('issss',
            $userId,
            $behavior['type'],
            $pageUrl,
            $interactionData,
            $sessionId
        );
        
        $stmt->execute();
    }
    
    // Performance Tracking
    public function trackPerformance() {
        $script = <<<EOT
<script>
    window.addEventListener('load', function() {
        // Performance timing
        let timing = performance.timing;
        let pageLoadTime = timing.loadEventEnd - timing.navigationStart;
        let dnsTime = timing.domainLookupEnd - timing.domainLookupStart;
        let tcpTime = timing.connectEnd - timing.connectStart;
        let serverTime = timing.responseEnd - timing.requestStart;
        let domLoadTime = timing.domComplete - timing.domLoading;
        
        // Send to Google Analytics
        gtag('event', 'performance', {
            'event_category': 'Performance',
            'event_label': 'Page Load',
            'value': pageLoadTime,
            'metric1': dnsTime,
            'metric2': tcpTime,
            'metric3': serverTime,
            'metric4': domLoadTime
        });
        
        // Log to server
        fetch('/includes/analytics/log-performance.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                pageLoadTime: pageLoadTime,
                dnsTime: dnsTime,
                tcpTime: tcpTime,
                serverTime: serverTime,
                domLoadTime: domLoadTime,
                url: window.location.pathname
            })
        });
    });
</script>
EOT;

        return $script;
    }
    
    // Heatmap Integration
    public function enableHeatmap() {
        $script = <<<EOT
<script>
    hj('trigger', 'heatmap');
    
    // Custom heatmap events
    document.addEventListener('click', function(e) {
        if (e.target.matches('.booking-btn, .cta-btn')) {
            hj('trigger', 'booking_button_click');
        }
    });
</script>
EOT;

        return $script;
    }
    
    // Session Recording
    public function enableSessionRecording() {
        $script = <<<EOT
<script>
    hj('trigger', 'session_recording');
    
    // Mask sensitive data
    hj('identify', null, {
        masked_email: '***@***.com',
        masked_phone: '***-***-****'
    });
</script>
EOT;

        return $script;
    }
    
    // Conversion Funnel Tracking
    public function trackFunnelStep($step, $data) {
        $script = <<<EOT
<script>
    // Google Analytics
    gtag('event', 'funnel_step', {
        'event_category': 'Funnel',
        'event_label': '$step',
        'value': {$data['value']}
    });
    
    // Facebook Pixel
    fbq('trackCustom', 'FunnelStep', {
        step: '$step',
        value: {$data['value']}
    });
    
    // Save to database
    fetch('/includes/analytics/track-funnel.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            step: '$step',
            data: {$this->jsonEncode($data)}
        })
    });
</script>
EOT;

        return $script;
    }
    
    // Helper Methods
    private function formatItems($items) {
        return json_encode(array_map(function($item) {
            return [
                'id' => $item['id'],
                'name' => $item['name'],
                'price' => $item['price'],
                'quantity' => $item['quantity']
            ];
        }, $items));
    }
    
    private function getContentIds($items) {
        return json_encode(array_map(function($item) {
            return $item['id'];
        }, $items));
    }
    
    private function getUserId() {
        return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '';
    }
    
    private function jsonEncode($data) {
        return json_encode($data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
    }
}

// Create analytics tables
$analyticsTables = "
CREATE TABLE IF NOT EXISTS user_analytics (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    behavior_type VARCHAR(50) NOT NULL,
    page_url VARCHAR(255) NOT NULL,
    interaction_data JSON,
    session_id VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_behavior (user_id, behavior_type),
    INDEX idx_session (session_id)
);

CREATE TABLE IF NOT EXISTS performance_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    page_url VARCHAR(255) NOT NULL,
    page_load_time INT,
    dns_time INT,
    tcp_time INT,
    server_time INT,
    dom_load_time INT,
    user_agent VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_url_time (page_url, created_at)
);

CREATE TABLE IF NOT EXISTS conversion_funnels (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    funnel_step VARCHAR(50) NOT NULL,
    step_data JSON,
    session_id VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_funnel (user_id, funnel_step),
    INDEX idx_session_funnel (session_id, funnel_step)
);
";
