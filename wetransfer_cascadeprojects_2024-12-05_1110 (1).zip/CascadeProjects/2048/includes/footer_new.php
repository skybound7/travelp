<footer class="luxury-footer bg-gradient-dark text-light mt-5">
    <div class="footer-top py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-3 col-md-6">
                    <h5 class="luxury-text mb-4">Quick Links</h5>
                    <ul class="list-unstyled footer-links">
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                        <li><a href="terms.php">Terms & Conditions</a></li>
                        <li><a href="privacy.php">Privacy Policy</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h5 class="luxury-text mb-4">Premium Services</h5>
                    <ul class="list-unstyled footer-links">
                        <li><a href="flight-search.php">First Class Flights</a></li>
                        <li><a href="train-search.php">Luxury Train Journeys</a></li>
                        <li><a href="bus-search.php">Premium Bus Travel</a></li>
                        <li><a href="hotels.php">5-Star Hotels</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h5 class="luxury-text mb-4">Exclusive Services</h5>
                    <ul class="list-unstyled footer-links">
                        <li><a href="travel-insurance.php">Premium Insurance</a></li>
                        <li><a href="forex.php">VIP Forex Services</a></li>
                        <li><a href="visa.php">Priority Visa Services</a></li>
                        <li><a href="blog.php">Luxury Travel Blog</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h5 class="luxury-text mb-4">Connect With Us</h5>
                    <div class="social-links mb-4">
                        <a href="#" class="social-link"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                    <div class="newsletter-box">
                        <h6 class="luxury-text mb-3">Subscribe to Our Newsletter</h6>
                        <form class="newsletter-form">
                            <div class="input-group">
                                <input type="email" class="form-control luxury-input" placeholder="Your Email Address">
                                <button class="btn btn-primary luxury-btn" type="submit">
                                    <i class="fas fa-paper-plane"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom py-3">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="mb-0 text-center text-md-start">
                        &copy; <?php echo date('Y'); ?> Luxury Travel Portal. All rights reserved.
                    </p>
                </div>
                <div class="col-md-6">
                    <div class="payment-methods text-center text-md-end">
                        <i class="fab fa-cc-visa luxury-text"></i>
                        <i class="fab fa-cc-mastercard luxury-text"></i>
                        <i class="fab fa-cc-amex luxury-text"></i>
                        <i class="fab fa-cc-discover luxury-text"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://kit.fontawesome.com/your-kit-code.js"></script>
<script src="js/main.js"></script>
</body>
</html>
