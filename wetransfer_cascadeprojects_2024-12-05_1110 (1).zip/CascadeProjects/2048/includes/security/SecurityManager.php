<?php
class SecurityManager {
    private $config;
    private static $instance = null;
    
    private function __construct() {
        $this->config = require_once __DIR__ . '/../../config/config.php';
        $this->initializeSecurity();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function initializeSecurity() {
        // Set security-related PHP settings
        ini_set('session.cookie_httponly', 1);
        ini_set('session.cookie_secure', 1);
        ini_set('session.use_only_cookies', 1);
        ini_set('session.cookie_samesite', 'Strict');
        
        // Set session handler
        session_set_cookie_params([
            'lifetime' => 3600,
            'path' => '/',
            'domain' => $_SERVER['HTTP_HOST'],
            'secure' => true,
            'httponly' => true,
            'samesite' => 'Strict'
        ]);
        
        // Start session if not already started
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // Regenerate session ID periodically
        if (!isset($_SESSION['last_regeneration'])) {
            $_SESSION['last_regeneration'] = time();
        } elseif (time() - $_SESSION['last_regeneration'] > 300) {
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = time();
        }
    }
    
    public function validateInput($input, $type = 'text') {
        switch ($type) {
            case 'email':
                return filter_var($input, FILTER_VALIDATE_EMAIL);
            case 'url':
                return filter_var($input, FILTER_VALIDATE_URL);
            case 'int':
                return filter_var($input, FILTER_VALIDATE_INT);
            case 'float':
                return filter_var($input, FILTER_VALIDATE_FLOAT);
            case 'ip':
                return filter_var($input, FILTER_VALIDATE_IP);
            case 'text':
                return htmlspecialchars(strip_tags($input), ENT_QUOTES, 'UTF-8');
            default:
                return false;
        }
    }
    
    public function generateCSRFToken() {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    
    public function validateCSRFToken($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
    
    public function sanitizeSQL($string, $conn) {
        if (!is_string($string)) {
            return $string;
        }
        return mysqli_real_escape_string($conn, $string);
    }
    
    public function validatePassword($password) {
        $requirements = [
            'length' => strlen($password) >= 12,
            'uppercase' => preg_match('/[A-Z]/', $password),
            'lowercase' => preg_match('/[a-z]/', $password),
            'numbers' => preg_match('/[0-9]/', $password),
            'special' => preg_match('/[^A-Za-z0-9]/', $password)
        ];
        
        return !in_array(false, $requirements, true);
    }
    
    public function hashPassword($password) {
        return password_hash($password, PASSWORD_ARGON2ID, [
            'memory_cost' => 65536,
            'time_cost' => 4,
            'threads' => 3
        ]);
    }
    
    public function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }
    
    public function generateSecureFilename($filename) {
        $info = pathinfo($filename);
        return bin2hex(random_bytes(16)) . '.' . $info['extension'];
    }
    
    public function validateFileUpload($file, $allowedTypes = [], $maxSize = 5242880) {
        $errors = [];
        
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'Upload failed with error code: ' . $file['error'];
            return $errors;
        }
        
        if ($file['size'] > $maxSize) {
            $errors[] = 'File size exceeds limit';
        }
        
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mimeType = $finfo->file($file['tmp_name']);
        
        if (!empty($allowedTypes) && !in_array($mimeType, $allowedTypes)) {
            $errors[] = 'Invalid file type';
        }
        
        return $errors;
    }
    
    public function logSecurityEvent($type, $details, $severity = 'medium') {
        $data = [
            'type' => $type,
            'details' => $details,
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'],
            'user_id' => $_SESSION['user_id'] ?? null,
            'severity' => $severity,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        error_log(json_encode($data));
        
        // Log to database if critical
        if ($severity === 'high' || $severity === 'critical') {
            $this->logToDatabase($data);
        }
        
        // Alert admin if critical
        if ($severity === 'critical') {
            $this->alertAdmin($data);
        }
    }
    
    private function logToDatabase($data) {
        $query = "INSERT INTO security_logs (type, details, ip_address, user_agent, user_id, severity) 
                 VALUES (?, ?, ?, ?, ?, ?)";
        
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, 'ssssss', 
            $data['type'],
            $data['details'],
            $data['ip'],
            $data['user_agent'],
            $data['user_id'],
            $data['severity']
        );
        mysqli_stmt_execute($stmt);
    }
    
    private function alertAdmin($data) {
        $subject = "Security Alert: {$data['type']}";
        $message = "Critical security event detected:\n\n";
        $message .= "Type: {$data['type']}\n";
        $message .= "Details: {$data['details']}\n";
        $message .= "IP: {$data['ip']}\n";
        $message .= "Time: {$data['timestamp']}\n";
        
        mail($this->config['admin_email'], $subject, $message);
    }
    
    public function validateRequest() {
        // Check request method
        if (!in_array($_SERVER['REQUEST_METHOD'], ['GET', 'POST'])) {
            $this->logSecurityEvent('invalid_method', $_SERVER['REQUEST_METHOD'], 'high');
            return false;
        }
        
        // Check referer for POST requests
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!isset($_SERVER['HTTP_REFERER']) || 
                parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST) !== $_SERVER['HTTP_HOST']) {
                $this->logSecurityEvent('invalid_referer', $_SERVER['HTTP_REFERER'] ?? 'none', 'high');
                return false;
            }
        }
        
        // Rate limiting
        if (!$this->checkRateLimit()) {
            $this->logSecurityEvent('rate_limit_exceeded', $_SERVER['REMOTE_ADDR'], 'medium');
            return false;
        }
        
        return true;
    }
    
    private function checkRateLimit() {
        $ip = $_SERVER['REMOTE_ADDR'];
        $key = "rate_limit:$ip";
        
        if (isset($_SESSION[$key])) {
            $limit = $_SESSION[$key];
            if ($limit['count'] > 100 && (time() - $limit['start']) < 60) {
                return false;
            }
            if ((time() - $limit['start']) >= 60) {
                $_SESSION[$key] = ['count' => 1, 'start' => time()];
            } else {
                $_SESSION[$key]['count']++;
            }
        } else {
            $_SESSION[$key] = ['count' => 1, 'start' => time()];
        }
        
        return true;
    }
}
