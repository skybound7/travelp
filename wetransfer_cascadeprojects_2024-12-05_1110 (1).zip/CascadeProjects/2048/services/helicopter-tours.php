<?php
require_once '../includes/header.php';
?>

<main class="service-page">
    <!-- Hero Section -->
    <section class="service-hero" style="background-image: url('../assets/images/services/helicopter-hero.jpg');">
        <div class="container">
            <div class="row min-vh-50 align-items-center">
                <div class="col-lg-8" data-aos="fade-right">
                    <h1 class="display-4 luxury-text mb-4">Helicopter Tours</h1>
                    <p class="lead mb-4">Experience breathtaking aerial views of the world's most stunning destinations from the comfort of luxury helicopters.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Service Details -->
    <section class="service-details py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="service-content" data-aos="fade-up">
                        <h2 class="mb-4">Elevate Your Journey</h2>
                        <p class="mb-4">Our helicopter tours offer an unparalleled perspective of iconic landscapes and cityscapes. With state-of-the-art aircraft and expert pilots, we ensure both safety and luxury in every flight.</p>
                        
                        <div class="features-grid mb-5">
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="100">
                                <i class="fas fa-helicopter"></i>
                                <h4>Premium Fleet</h4>
                                <p>Latest luxury helicopters</p>
                            </div>
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="200">
                                <i class="fas fa-user-tie"></i>
                                <h4>Expert Pilots</h4>
                                <p>Highly experienced crew</p>
                            </div>
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="300">
                                <i class="fas fa-camera"></i>
                                <h4>Photo Ops</h4>
                                <p>Perfect aerial shots</p>
                            </div>
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="400">
                                <i class="fas fa-glass-cheers"></i>
                                <h4>VIP Service</h4>
                                <p>Champagne flights</p>
                            </div>
                        </div>

                        <h3 class="mb-4">Featured Tours</h3>
                        <div class="tours-grid mb-5">
                            <div class="tour-item" data-aos="fade-up">
                                <img src="../assets/images/services/helicopter/dubai-tour.jpg" alt="Dubai Aerial Tour">
                                <div class="tour-content">
                                    <h4>Dubai Skyline Tour</h4>
                                    <p>Duration: 30 minutes</p>
                                    <ul class="list-unstyled">
                                        <li><i class="fas fa-check me-2"></i>Burj Khalifa view</li>
                                        <li><i class="fas fa-check me-2"></i>Palm Jumeirah</li>
                                        <li><i class="fas fa-check me-2"></i>World Islands</li>
                                    </ul>
                                    <div class="price">From $599 per person</div>
                                </div>
                            </div>

                            <div class="tour-item" data-aos="fade-up">
                                <img src="../assets/images/services/helicopter/grand-canyon.jpg" alt="Grand Canyon Tour">
                                <div class="tour-content">
                                    <h4>Grand Canyon Adventure</h4>
                                    <p>Duration: 4 hours</p>
                                    <ul class="list-unstyled">
                                        <li><i class="fas fa-check me-2"></i>Canyon landing</li>
                                        <li><i class="fas fa-check me-2"></i>Champagne picnic</li>
                                        <li><i class="fas fa-check me-2"></i>Photo opportunities</li>
                                    </ul>
                                    <div class="price">From $1,299 per person</div>
                                </div>
                            </div>
                        </div>

                        <h3 class="mb-4">Safety & Comfort</h3>
                        <div class="safety-features mb-5">
                            <div class="safety-item" data-aos="fade-up">
                                <i class="fas fa-shield-alt"></i>
                                <div>
                                    <h5>Safety First</h5>
                                    <p>Regular maintenance checks and certified pilots with thousands of flight hours</p>
                                </div>
                            </div>
                            <div class="safety-item" data-aos="fade-up">
                                <i class="fas fa-couch"></i>
                                <div>
                                    <h5>Premium Comfort</h5>
                                    <p>Leather seating, noise-canceling headsets, and climate control</p>
                                </div>
                            </div>
                            <div class="safety-item" data-aos="fade-up">
                                <i class="fas fa-headset"></i>
                                <div>
                                    <h5>Live Commentary</h5>
                                    <p>Expert narration of landmarks and history during flight</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <!-- Booking Widget -->
                    <div class="booking-widget sticky-top" data-aos="fade-left">
                        <h3>Book Your Tour</h3>
                        <form action="#" method="POST" class="booking-form">
                            <div class="mb-3">
                                <label class="form-label">Select Tour</label>
                                <select class="form-select">
                                    <option>Dubai Skyline Tour</option>
                                    <option>Grand Canyon Adventure</option>
                                    <option>New York City Tour</option>
                                    <option>Custom Route</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Date</label>
                                <input type="date" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Time</label>
                                <select class="form-select">
                                    <option>Sunrise (Best Light)</option>
                                    <option>Morning</option>
                                    <option>Afternoon</option>
                                    <option>Sunset (Most Popular)</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Passengers</label>
                                <select class="form-select">
                                    <option>1-2 passengers</option>
                                    <option>3-4 passengers</option>
                                    <option>5-6 passengers</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Check Availability</button>
                        </form>
                    </div>

                    <!-- Special Experiences -->
                    <div class="special-experiences mt-4" data-aos="fade-up">
                        <h4>Special Experiences</h4>
                        <div class="experience-card mb-3">
                            <div class="experience-tag">Exclusive</div>
                            <h5>Proposal Package</h5>
                            <p>Make your proposal unforgettable with our special romantic flight</p>
                            <button class="btn btn-outline-primary btn-sm">Learn More</button>
                        </div>
                        <div class="experience-card">
                            <div class="experience-tag">Limited</div>
                            <h5>Photography Flight</h5>
                            <p>Special routes and hovering for perfect aerial photography</p>
                            <button class="btn btn-outline-primary btn-sm">Learn More</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Photo Gallery -->
    <section class="photo-gallery py-5 bg-light">
        <div class="container">
            <h3 class="text-center mb-5">Captured Moments</h3>
            <div class="row g-4">
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="gallery-item">
                        <img src="../assets/images/services/helicopter/gallery1.jpg" alt="Aerial View">
                        <div class="gallery-caption">
                            <h5>Sunset Flight</h5>
                            <p>Golden hour over iconic landmarks</p>
                        </div>
                    </div>
                </div>
                <!-- Add more gallery items -->
            </div>
        </div>
    </section>
</main>

<?php
require_once '../includes/footer_new.php';
?>
