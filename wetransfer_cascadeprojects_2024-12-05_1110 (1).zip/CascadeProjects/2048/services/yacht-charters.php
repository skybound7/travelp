<?php
require_once '../includes/header.php';
?>

<main class="service-page">
    <!-- Hero Section -->
    <section class="service-hero" style="background-image: url('../assets/images/services/yacht-hero.jpg');">
        <div class="container">
            <div class="row min-vh-50 align-items-center">
                <div class="col-lg-8" data-aos="fade-right">
                    <h1 class="display-4 luxury-text mb-4">Luxury Yacht Charters</h1>
                    <p class="lead mb-4">Set sail in ultimate luxury. Experience the world's most prestigious yachts and unforgettable maritime journeys.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Service Details -->
    <section class="service-details py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="service-content" data-aos="fade-up">
                        <h2 class="mb-4">Your Private Ocean Paradise</h2>
                        <p class="mb-4">Our luxury yacht charter service offers an unparalleled maritime experience. From intimate vessels to superyachts, each charter is tailored to exceed your expectations.</p>
                        
                        <div class="features-grid mb-5">
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="100">
                                <i class="fas fa-ship"></i>
                                <h4>Elite Fleet</h4>
                                <p>World-class yachts</p>
                            </div>
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="200">
                                <i class="fas fa-users"></i>
                                <h4>Expert Crew</h4>
                                <p>Professional staff</p>
                            </div>
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="300">
                                <i class="fas fa-map-marked-alt"></i>
                                <h4>Custom Routes</h4>
                                <p>Personalized itineraries</p>
                            </div>
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="400">
                                <i class="fas fa-cocktail"></i>
                                <h4>Fine Dining</h4>
                                <p>Gourmet experience</p>
                            </div>
                        </div>

                        <h3 class="mb-4">Featured Yachts</h3>
                        <div class="yacht-carousel mb-5">
                            <div class="yacht-item" data-aos="fade-up">
                                <img src="../assets/images/services/yachts/superyacht.jpg" alt="Luxury Superyacht">
                                <h4>Ocean Paradise</h4>
                                <ul class="list-unstyled">
                                    <li><i class="fas fa-ruler-combined me-2"></i>55 meters</li>
                                    <li><i class="fas fa-users me-2"></i>12 guests</li>
                                    <li><i class="fas fa-bed me-2"></i>6 cabins</li>
                                </ul>
                            </div>
                            <!-- Add more yacht items -->
                        </div>

                        <h3 class="mb-4">Popular Destinations</h3>
                        <div class="destinations-grid mb-5">
                            <div class="destination-item" data-aos="fade-up">
                                <img src="../assets/images/services/yachts/mediterranean.jpg" alt="Mediterranean">
                                <div class="destination-content">
                                    <h4>Mediterranean</h4>
                                    <p>French Riviera, Amalfi Coast, Greek Islands</p>
                                </div>
                            </div>
                            <div class="destination-item" data-aos="fade-up">
                                <img src="../assets/images/services/yachts/caribbean.jpg" alt="Caribbean">
                                <div class="destination-content">
                                    <h4>Caribbean</h4>
                                    <p>British Virgin Islands, Bahamas, St. Barts</p>
                                </div>
                            </div>
                            <!-- Add more destinations -->
                        </div>

                        <h3 class="mb-4">Onboard Experience</h3>
                        <div class="experience-list mb-5">
                            <div class="experience-item" data-aos="fade-up">
                                <i class="fas fa-swimming-pool"></i>
                                <div>
                                    <h5>Water Activities</h5>
                                    <p>Jet skis, water skiing, diving equipment</p>
                                </div>
                            </div>
                            <div class="experience-item" data-aos="fade-up">
                                <i class="fas fa-spa"></i>
                                <div>
                                    <h5>Wellness</h5>
                                    <p>Onboard spa, gym, massage services</p>
                                </div>
                            </div>
                            <div class="experience-item" data-aos="fade-up">
                                <i class="fas fa-film"></i>
                                <div>
                                    <h5>Entertainment</h5>
                                    <p>Cinema room, sound system, satellite TV</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <!-- Booking Widget -->
                    <div class="booking-widget sticky-top" data-aos="fade-left">
                        <h3>Charter Your Yacht</h3>
                        <form action="#" method="POST" class="booking-form">
                            <div class="mb-3">
                                <label class="form-label">Destination</label>
                                <select class="form-select">
                                    <option>Mediterranean</option>
                                    <option>Caribbean</option>
                                    <option>South Pacific</option>
                                    <option>Indian Ocean</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Charter Start</label>
                                <input type="date" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Duration</label>
                                <select class="form-select">
                                    <option>1 week</option>
                                    <option>2 weeks</option>
                                    <option>3 weeks</option>
                                    <option>1 month</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Guests</label>
                                <select class="form-select">
                                    <option>2-4 guests</option>
                                    <option>5-8 guests</option>
                                    <option>9-12 guests</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Request Quote</button>
                        </form>
                    </div>

                    <!-- Special Offers -->
                    <div class="special-offers mt-4" data-aos="fade-up">
                        <h4>Current Offers</h4>
                        <div class="offer-card mb-3">
                            <div class="offer-tag">Early Bird</div>
                            <h5>Mediterranean Summer</h5>
                            <p>15% off for early summer bookings</p>
                            <button class="btn btn-outline-primary btn-sm">Learn More</button>
                        </div>
                        <div class="offer-card">
                            <div class="offer-tag">Last Minute</div>
                            <h5>Caribbean Special</h5>
                            <p>Available next week at special rates</p>
                            <button class="btn btn-outline-primary btn-sm">Learn More</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Gallery -->
    <section class="yacht-gallery py-5 bg-light">
        <div class="container">
            <h3 class="text-center mb-5">Life on Board</h3>
            <div class="row g-4">
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="gallery-item">
                        <img src="../assets/images/services/yachts/gallery1.jpg" alt="Yacht Interior">
                        <div class="gallery-caption">
                            <h5>Master Suite</h5>
                            <p>Luxurious accommodations with ocean views</p>
                        </div>
                    </div>
                </div>
                <!-- Add more gallery items -->
            </div>
        </div>
    </section>
</main>

<?php
require_once '../includes/footer_new.php';
?>
