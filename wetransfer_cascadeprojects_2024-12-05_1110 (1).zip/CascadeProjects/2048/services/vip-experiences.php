<?php
require_once '../includes/header.php';
?>

<main class="service-page">
    <!-- Hero Section -->
    <section class="service-hero" style="background-image: url('../assets/images/services/vip-hero.jpg');">
        <div class="container">
            <div class="row min-vh-50 align-items-center">
                <div class="col-lg-8" data-aos="fade-right">
                    <h1 class="display-4 luxury-text mb-4">VIP Experiences</h1>
                    <p class="lead mb-4">Curated, exclusive experiences that define luxury and create unforgettable memories.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Service Details -->
    <section class="service-details py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="service-content" data-aos="fade-up">
                        <h2 class="mb-4">Extraordinary Moments Await</h2>
                        <p class="mb-4">Our VIP experiences offer unprecedented access to the world's most exclusive events, venues, and activities. Each experience is meticulously crafted to exceed the expectations of our discerning clientele.</p>
                        
                        <div class="features-grid mb-5">
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="100">
                                <i class="fas fa-key"></i>
                                <h4>Exclusive Access</h4>
                                <p>Private venues & events</p>
                            </div>
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="200">
                                <i class="fas fa-concierge-bell"></i>
                                <h4>Personal Concierge</h4>
                                <p>24/7 dedicated service</p>
                            </div>
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="300">
                                <i class="fas fa-star"></i>
                                <h4>Luxury Treatment</h4>
                                <p>VIP status everywhere</p>
                            </div>
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="400">
                                <i class="fas fa-camera-retro"></i>
                                <h4>Memory Capture</h4>
                                <p>Professional photography</p>
                            </div>
                        </div>

                        <h3 class="mb-4">Featured Experiences</h3>
                        <div class="experiences-grid mb-5">
                            <div class="experience-item" data-aos="fade-up">
                                <img src="../assets/images/services/vip/fashion-week.jpg" alt="Fashion Week VIP">
                                <div class="experience-content">
                                    <h4>Fashion Week Front Row</h4>
                                    <p>Duration: 3-5 days</p>
                                    <ul class="list-unstyled">
                                        <li><i class="fas fa-check me-2"></i>Front row seating</li>
                                        <li><i class="fas fa-check me-2"></i>Designer meet & greets</li>
                                        <li><i class="fas fa-check me-2"></i>Exclusive after-parties</li>
                                    </ul>
                                    <div class="price">From $25,000 per person</div>
                                </div>
                            </div>

                            <div class="experience-item" data-aos="fade-up">
                                <img src="../assets/images/services/vip/monaco-gp.jpg" alt="Monaco Grand Prix">
                                <div class="experience-content">
                                    <h4>Monaco Grand Prix Ultimate</h4>
                                    <p>Duration: 4 days</p>
                                    <ul class="list-unstyled">
                                        <li><i class="fas fa-check me-2"></i>Yacht hospitality</li>
                                        <li><i class="fas fa-check me-2"></i>Paddock access</li>
                                        <li><i class="fas fa-check me-2"></i>Driver meetings</li>
                                    </ul>
                                    <div class="price">From $50,000 per person</div>
                                </div>
                            </div>
                        </div>

                        <h3 class="mb-4">Categories</h3>
                        <div class="categories-grid mb-5">
                            <div class="category-item" data-aos="fade-up">
                                <i class="fas fa-music"></i>
                                <h5>Entertainment</h5>
                                <ul class="list-unstyled">
                                    <li>Private concerts</li>
                                    <li>Award shows</li>
                                    <li>Movie premieres</li>
                                </ul>
                            </div>
                            <div class="category-item" data-aos="fade-up">
                                <i class="fas fa-trophy"></i>
                                <h5>Sports</h5>
                                <ul class="list-unstyled">
                                    <li>Championship finals</li>
                                    <li>Player meet & greets</li>
                                    <li>VIP box access</li>
                                </ul>
                            </div>
                            <div class="category-item" data-aos="fade-up">
                                <i class="fas fa-glass-cheers"></i>
                                <h5>Cultural</h5>
                                <ul class="list-unstyled">
                                    <li>Private museum tours</li>
                                    <li>Exclusive exhibitions</li>
                                    <li>Culinary experiences</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <!-- Booking Widget -->
                    <div class="booking-widget sticky-top" data-aos="fade-left">
                        <h3>Request Experience</h3>
                        <form action="#" method="POST" class="booking-form">
                            <div class="mb-3">
                                <label class="form-label">Experience Type</label>
                                <select class="form-select">
                                    <option>Fashion & Style</option>
                                    <option>Sports & Racing</option>
                                    <option>Entertainment</option>
                                    <option>Cultural</option>
                                    <option>Custom Experience</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Preferred Date</label>
                                <input type="date" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Duration</label>
                                <select class="form-select">
                                    <option>1 day</option>
                                    <option>2-3 days</option>
                                    <option>4-7 days</option>
                                    <option>Custom duration</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Group Size</label>
                                <select class="form-select">
                                    <option>1-2 people</option>
                                    <option>3-5 people</option>
                                    <option>6-10 people</option>
                                    <option>Custom group</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Inquire Now</button>
                        </form>
                    </div>

                    <!-- Upcoming Events -->
                    <div class="upcoming-events mt-4" data-aos="fade-up">
                        <h4>Upcoming Events</h4>
                        <div class="event-card mb-3">
                            <div class="event-tag">Hot</div>
                            <h5>Met Gala 2024</h5>
                            <p>Exclusive access to fashion's biggest night</p>
                            <button class="btn btn-outline-primary btn-sm">Learn More</button>
                        </div>
                        <div class="event-card">
                            <div class="event-tag">Limited</div>
                            <h5>Cannes Film Festival</h5>
                            <p>Red carpet & private screenings package</p>
                            <button class="btn btn-outline-primary btn-sm">Learn More</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="testimonials py-5 bg-light">
        <div class="container">
            <h3 class="text-center mb-5">Client Stories</h3>
            <div class="row">
                <div class="col-md-4 mb-4" data-aos="fade-up">
                    <div class="testimonial-card">
                        <div class="rating mb-3">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="mb-3">"An absolutely incredible experience. The attention to detail and exclusive access made our Monaco Grand Prix weekend unforgettable."</p>
                        <div class="client-info">
                            <img src="../assets/images/testimonials/client2.jpg" alt="Client">
                            <div>
                                <h5>Sarah Mitchell</h5>
                                <span>Luxury Lifestyle Blogger</span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Add more testimonials -->
            </div>
        </div>
    </section>
</main>

<?php
require_once '../includes/footer_new.php';
?>
