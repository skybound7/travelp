<?php
require_once '../includes/header.php';
?>

<main class="service-page">
    <!-- Hero Section -->
    <section class="service-hero" style="background-image: url('../assets/images/services/private-jets-hero.jpg');">
        <div class="container">
            <div class="row min-vh-50 align-items-center">
                <div class="col-lg-8" data-aos="fade-right">
                    <h1 class="display-4 luxury-text mb-4">Private Jet Charters</h1>
                    <p class="lead mb-4">Experience the pinnacle of air travel with our exclusive private jet services. Travel in unparalleled comfort and style.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Service Details -->
    <section class="service-details py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="service-content" data-aos="fade-up">
                        <h2 class="mb-4">Luxury in the Skies</h2>
                        <p class="mb-4">Our private jet charter service offers the ultimate in luxury air travel. With access to a fleet of world-class aircraft and dedicated crew, your journey will be nothing short of exceptional.</p>
                        
                        <div class="features-grid mb-5">
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="100">
                                <i class="fas fa-plane-departure"></i>
                                <h4>Global Access</h4>
                                <p>Fly to over 3,000 airports worldwide</p>
                            </div>
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="200">
                                <i class="fas fa-clock"></i>
                                <h4>24/7 Service</h4>
                                <p>Available any time, any day</p>
                            </div>
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="300">
                                <i class="fas fa-user-tie"></i>
                                <h4>Personal Concierge</h4>
                                <p>Dedicated flight coordinator</p>
                            </div>
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="400">
                                <i class="fas fa-glass-martini-alt"></i>
                                <h4>Luxury Catering</h4>
                                <p>Gourmet meals and premium beverages</p>
                            </div>
                        </div>

                        <h3 class="mb-4">Our Fleet</h3>
                        <div class="fleet-carousel mb-5">
                            <div class="fleet-item" data-aos="fade-up">
                                <img src="../assets/images/services/jets/gulfstream.jpg" alt="Gulfstream G650">
                                <h4>Gulfstream G650</h4>
                                <ul class="list-unstyled">
                                    <li><i class="fas fa-users me-2"></i>Up to 19 passengers</li>
                                    <li><i class="fas fa-route me-2"></i>7,000 nautical mile range</li>
                                    <li><i class="fas fa-bed me-2"></i>Sleeping capacity: 10</li>
                                </ul>
                            </div>
                            <!-- Add more fleet items as needed -->
                        </div>

                        <h3 class="mb-4">Booking Process</h3>
                        <div class="booking-steps mb-5">
                            <div class="step" data-aos="fade-up" data-aos-delay="100">
                                <span class="step-number">1</span>
                                <h5>Contact Us</h5>
                                <p>Reach out to our private aviation team</p>
                            </div>
                            <div class="step" data-aos="fade-up" data-aos-delay="200">
                                <span class="step-number">2</span>
                                <h5>Customize</h5>
                                <p>Tailor your flight experience</p>
                            </div>
                            <div class="step" data-aos="fade-up" data-aos-delay="300">
                                <span class="step-number">3</span>
                                <h5>Confirm</h5>
                                <p>Review and secure your booking</p>
                            </div>
                            <div class="step" data-aos="fade-up" data-aos-delay="400">
                                <span class="step-number">4</span>
                                <h5>Fly</h5>
                                <p>Experience luxury in the skies</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <!-- Booking Widget -->
                    <div class="booking-widget sticky-top" data-aos="fade-left">
                        <h3>Book Your Private Jet</h3>
                        <form action="#" method="POST" class="booking-form">
                            <div class="mb-3">
                                <label class="form-label">Departure</label>
                                <input type="text" class="form-control" placeholder="City or Airport" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Arrival</label>
                                <input type="text" class="form-control" placeholder="City or Airport" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Date</label>
                                <input type="date" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Passengers</label>
                                <select class="form-select">
                                    <option>1-4 passengers</option>
                                    <option>5-8 passengers</option>
                                    <option>9-12 passengers</option>
                                    <option>13+ passengers</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Request Quote</button>
                        </form>
                    </div>

                    <!-- Additional Services -->
                    <div class="additional-services mt-4" data-aos="fade-up">
                        <h4>Additional Services</h4>
                        <ul class="list-unstyled">
                            <li><i class="fas fa-check me-2"></i>Ground Transportation</li>
                            <li><i class="fas fa-check me-2"></i>Custom Catering</li>
                            <li><i class="fas fa-check me-2"></i>Security Services</li>
                            <li><i class="fas fa-check me-2"></i>Pet Transportation</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="testimonials py-5 bg-light">
        <div class="container">
            <h3 class="text-center mb-5">What Our Clients Say</h3>
            <div class="row">
                <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="testimonial-card">
                        <div class="rating mb-3">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="mb-3">"Exceptional service from start to finish. The attention to detail and personalization made our journey unforgettable."</p>
                        <div class="client-info">
                            <img src="../assets/images/testimonials/client1.jpg" alt="Client">
                            <div>
                                <h5>James Wilson</h5>
                                <span>CEO, Global Ventures</span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Add more testimonials -->
            </div>
        </div>
    </section>
</main>

<?php
require_once '../includes/footer_new.php';
?>
