<?php
require_once '../includes/header.php';
?>

<main class="service-page">
    <!-- Hero Section -->
    <section class="service-hero" style="background-image: url('../assets/images/services/luxury-stays-hero.jpg');">
        <div class="container">
            <div class="row min-vh-50 align-items-center">
                <div class="col-lg-8" data-aos="fade-right">
                    <h1 class="display-4 luxury-text mb-4">Ultra-Luxury Stays</h1>
                    <p class="lead mb-4">Discover the world's most exclusive accommodations, where luxury knows no bounds and every detail is perfection.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Service Details -->
    <section class="service-details py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="service-content" data-aos="fade-up">
                        <h2 class="mb-4">Unparalleled Luxury Accommodations</h2>
                        <p class="mb-4">Our collection of ultra-luxury stays represents the pinnacle of hospitality. From private islands to historic palaces, each property is handpicked to deliver an extraordinary experience.</p>
                        
                        <div class="features-grid mb-5">
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="100">
                                <i class="fas fa-concierge-bell"></i>
                                <h4>Butler Service</h4>
                                <p>24/7 dedicated personal butler</p>
                            </div>
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="200">
                                <i class="fas fa-spa"></i>
                                <h4>Private Spa</h4>
                                <p>In-suite wellness treatments</p>
                            </div>
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="300">
                                <i class="fas fa-utensils"></i>
                                <h4>Personal Chef</h4>
                                <p>Customized gourmet dining</p>
                            </div>
                            <div class="feature-item" data-aos="fade-up" data-aos-delay="400">
                                <i class="fas fa-car"></i>
                                <h4>Luxury Transport</h4>
                                <p>Chauffeur-driven vehicles</p>
                            </div>
                        </div>

                        <h3 class="mb-4">Featured Properties</h3>
                        <div class="properties-carousel mb-5">
                            <div class="property-item" data-aos="fade-up">
                                <img src="../assets/images/services/stays/overwater-villa.jpg" alt="Maldives Overwater Villa">
                                <h4>Royal Overwater Villa</h4>
                                <p class="location"><i class="fas fa-map-marker-alt me-2"></i>Maldives</p>
                                <ul class="list-unstyled">
                                    <li><i class="fas fa-ruler-combined me-2"></i>800 sq.m living space</li>
                                    <li><i class="fas fa-swimming-pool me-2"></i>Private infinity pool</li>
                                    <li><i class="fas fa-bed me-2"></i>3 bedrooms</li>
                                </ul>
                            </div>
                            <!-- Add more properties -->
                        </div>

                        <h3 class="mb-4">Exclusive Benefits</h3>
                        <div class="benefits-list mb-5">
                            <div class="benefit-item" data-aos="fade-up">
                                <i class="fas fa-check-circle"></i>
                                <div>
                                    <h5>VIP Airport Service</h5>
                                    <p>Skip all queues with fast-track service and private lounge access</p>
                                </div>
                            </div>
                            <div class="benefit-item" data-aos="fade-up">
                                <i class="fas fa-check-circle"></i>
                                <div>
                                    <h5>Luxury Transfers</h5>
                                    <p>Helicopter or luxury vehicle transfers to your accommodation</p>
                                </div>
                            </div>
                            <div class="benefit-item" data-aos="fade-up">
                                <i class="fas fa-check-circle"></i>
                                <div>
                                    <h5>Personal Concierge</h5>
                                    <p>Available 24/7 to fulfill any request</p>
                                </div>
                            </div>
                            <div class="benefit-item" data-aos="fade-up">
                                <i class="fas fa-check-circle"></i>
                                <div>
                                    <h5>Exclusive Access</h5>
                                    <p>Priority reservations at prestigious restaurants and venues</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <!-- Booking Widget -->
                    <div class="booking-widget sticky-top" data-aos="fade-left">
                        <h3>Book Your Luxury Stay</h3>
                        <form action="#" method="POST" class="booking-form">
                            <div class="mb-3">
                                <label class="form-label">Destination</label>
                                <select class="form-select">
                                    <option>Maldives</option>
                                    <option>Dubai</option>
                                    <option>French Riviera</option>
                                    <option>Swiss Alps</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Check-in</label>
                                <input type="date" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Check-out</label>
                                <input type="date" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Guests</label>
                                <select class="form-select">
                                    <option>1-2 guests</option>
                                    <option>3-4 guests</option>
                                    <option>5-6 guests</option>
                                    <option>7+ guests</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Check Availability</button>
                        </form>
                    </div>

                    <!-- Special Offers -->
                    <div class="special-offers mt-4" data-aos="fade-up">
                        <h4>Current Offers</h4>
                        <div class="offer-card mb-3">
                            <div class="offer-tag">Save 25%</div>
                            <h5>Extended Stay Special</h5>
                            <p>Book 7 nights, enjoy 2 additional nights complimentary</p>
                            <button class="btn btn-outline-primary btn-sm">Learn More</button>
                        </div>
                        <div class="offer-card">
                            <div class="offer-tag">Exclusive</div>
                            <h5>Honeymoon Package</h5>
                            <p>Includes spa treatments, romantic dinners, and more</p>
                            <button class="btn btn-outline-primary btn-sm">Learn More</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Experience Gallery -->
    <section class="experience-gallery py-5 bg-light">
        <div class="container">
            <h3 class="text-center mb-5">Experience the Extraordinary</h3>
            <div class="row g-4">
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="gallery-item">
                        <img src="../assets/images/services/stays/experience1.jpg" alt="Luxury Experience">
                        <div class="gallery-caption">
                            <h5>Private Beach Dining</h5>
                            <p>Exclusive culinary experiences under the stars</p>
                        </div>
                    </div>
                </div>
                <!-- Add more gallery items -->
            </div>
        </div>
    </section>
</main>

<?php
require_once '../includes/footer_new.php';
?>
