<?php
require_once '../config/database.php';
require_once '../includes/legal/CookieManager.php';
require_once '../includes/legal/DataRequestManager.php';
require_once '../includes/analytics/Analytics.php';
require_once '../includes/performance/PerformanceOptimizer.php';
require_once '../includes/mobile/MobileOptimizer.php';

class SystemVerification {
    private $conn;
    private $results = [];
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    public function verifyAll() {
        $this->verifyDatabaseTables();
        $this->verifyCookieManager();
        $this->verifyDataRequests();
        $this->verifyAnalytics();
        $this->verifyPerformance();
        $this->verifyMobileOptimization();
        $this->verifySecurityHeaders();
        $this->verifyFilePermissions();
        
        return $this->results;
    }
    
    private function verifyDatabaseTables() {
        $requiredTables = [
            'data_requests',
            'login_history',
            'marketing_preferences',
            'consent_logs',
            'analytics_events',
            'performance_metrics'
        ];
        
        foreach ($requiredTables as $table) {
            try {
                $result = $this->conn->query("SHOW TABLES LIKE '$table'");
                $exists = $result->num_rows > 0;
                $this->results['database'][$table] = $exists ? 'OK' : 'Missing';
                
                if ($exists) {
                    // Verify table structure
                    $columns = $this->conn->query("SHOW COLUMNS FROM $table");
                    $this->results['database'][$table . '_columns'] = $columns->num_rows;
                }
            } catch (Exception $e) {
                $this->results['database'][$table] = 'Error: ' . $e->getMessage();
            }
        }
    }
    
    private function verifyCookieManager() {
        try {
            $cookieManager = new CookieManager();
            $banner = $cookieManager->getCookieConsentBanner();
            
            $this->results['cookie_manager'] = [
                'banner_generated' => !empty($banner) ? 'OK' : 'Failed',
                'contains_required_elements' => $this->verifyBannerElements($banner)
            ];
        } catch (Exception $e) {
            $this->results['cookie_manager'] = ['error' => $e->getMessage()];
        }
    }
    
    private function verifyDataRequests() {
        try {
            $dataManager = new DataRequestManager($this->conn);
            $testRequest = $dataManager->createDataRequest(1, 'export', ['test' => true]);
            
            $this->results['data_requests'] = [
                'can_create_request' => !empty($testRequest) ? 'OK' : 'Failed',
                'request_id_generated' => is_numeric($testRequest) ? 'OK' : 'Failed'
            ];
            
            // Cleanup test request
            $this->conn->query("DELETE FROM data_requests WHERE id = $testRequest");
        } catch (Exception $e) {
            $this->results['data_requests'] = ['error' => $e->getMessage()];
        }
    }
    
    private function verifyAnalytics() {
        try {
            $analytics = new Analytics();
            $this->results['analytics'] = [
                'ga4_configured' => !empty($analytics->getGA4Id()) ? 'OK' : 'Missing GA4 ID',
                'facebook_pixel' => !empty($analytics->getFacebookPixelId()) ? 'OK' : 'Missing Pixel ID',
                'can_track_events' => method_exists($analytics, 'trackEvent') ? 'OK' : 'Missing tracking method'
            ];
        } catch (Exception $e) {
            $this->results['analytics'] = ['error' => $e->getMessage()];
        }
    }
    
    private function verifyPerformance() {
        try {
            $optimizer = new PerformanceOptimizer();
            $metrics = $optimizer->getCurrentMetrics();
            
            $this->results['performance'] = [
                'metrics_available' => !empty($metrics) ? 'OK' : 'No metrics',
                'optimization_active' => $optimizer->isOptimizationEnabled() ? 'OK' : 'Disabled'
            ];
        } catch (Exception $e) {
            $this->results['performance'] = ['error' => $e->getMessage()];
        }
    }
    
    private function verifyMobileOptimization() {
        try {
            $mobileOptimizer = new MobileOptimizer();
            
            $this->results['mobile'] = [
                'responsive_check' => $mobileOptimizer->checkResponsiveness() ? 'OK' : 'Failed',
                'service_worker' => file_exists('../service-worker.js') ? 'OK' : 'Missing',
                'manifest' => file_exists('../manifest.json') ? 'OK' : 'Missing'
            ];
        } catch (Exception $e) {
            $this->results['mobile'] = ['error' => $e->getMessage()];
        }
    }
    
    private function verifySecurityHeaders() {
        $headers = get_headers($_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'], 1);
        
        $this->results['security'] = [
            'x_frame_options' => isset($headers['X-Frame-Options']) ? 'OK' : 'Missing',
            'x_content_type_options' => isset($headers['X-Content-Type-Options']) ? 'OK' : 'Missing',
            'strict_transport_security' => isset($headers['Strict-Transport-Security']) ? 'OK' : 'Missing',
            'content_security_policy' => isset($headers['Content-Security-Policy']) ? 'OK' : 'Missing'
        ];
    }
    
    private function verifyFilePermissions() {
        $criticalDirs = [
            '../config',
            '../includes',
            '../uploads',
            '../logs'
        ];
        
        foreach ($criticalDirs as $dir) {
            if (file_exists($dir)) {
                $perms = fileperms($dir);
                $this->results['permissions'][$dir] = [
                    'exists' => 'OK',
                    'writable' => is_writable($dir) ? 'OK' : 'Not writable',
                    'mode' => substr(sprintf('%o', $perms), -4)
                ];
            } else {
                $this->results['permissions'][$dir] = ['exists' => 'Missing'];
            }
        }
    }
    
    private function verifyBannerElements($banner) {
        $required = [
            'cookie-consent',
            'cookie-categories',
            'necessary',
            'functional',
            'analytics',
            'marketing',
            'privacy-link'
        ];
        
        $missing = [];
        foreach ($required as $element) {
            if (strpos($banner, $element) === false) {
                $missing[] = $element;
            }
        }
        
        return empty($missing) ? 'OK' : 'Missing: ' . implode(', ', $missing);
    }
}

// Run verification
try {
    $verification = new SystemVerification($conn);
    $results = $verification->verifyAll();
    
    // Output results
    echo "System Verification Results:\n\n";
    echo json_encode($results, JSON_PRETTY_PRINT);
    
    // Check for critical issues
    $criticalIssues = [];
    foreach ($results as $category => $checks) {
        foreach ($checks as $check => $status) {
            if ($status !== 'OK' && !is_array($status)) {
                $criticalIssues[] = "$category: $check ($status)";
            }
        }
    }
    
    if (!empty($criticalIssues)) {
        echo "\n\nCritical Issues Found:\n";
        echo implode("\n", $criticalIssues);
    } else {
        echo "\n\nAll critical checks passed successfully!";
    }
    
} catch (Exception $e) {
    echo "Error running verification: " . $e->getMessage();
}
