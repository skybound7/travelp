// Frontend Verification Script
const verifyFrontend = {
    results: {},
    
    async verifyAll() {
        await this.verifyCookieConsent();
        await this.verifyDataRequestForms();
        await this.verifyResponsiveness();
        await this.verifyPerformance();
        await this.verifyAnalyticsIntegration();
        await this.verifyAccessibility();
        
        return this.results;
    },
    
    async verifyCookieConsent() {
        try {
            const banner = document.getElementById('cookie-consent');
            const tabs = document.querySelectorAll('.cookie-tabs .tab-button');
            const categories = document.querySelectorAll('.cookie-category');
            
            this.results.cookieConsent = {
                bannerExists: !!banner,
                tabsWorking: tabs.length === 2,
                categoriesPresent: categories.length === 4,
                togglesWorking: await this.verifyToggles(),
                styleCheck: this.verifyBannerStyle(banner)
            };
        } catch (e) {
            this.results.cookieConsent = { error: e.message };
        }
    },
    
    async verifyDataRequestForms() {
        try {
            const forms = {
                export: document.getElementById('form-export'),
                delete: document.getElementById('form-delete'),
                update: document.getElementById('form-update'),
                restrict: document.getElementById('form-restrict')
            };
            
            this.results.dataRequests = {
                formsPresent: Object.values(forms).every(form => !!form),
                validationWorking: await this.verifyFormValidation(forms),
                submitHandling: await this.verifyFormSubmission(forms)
            };
        } catch (e) {
            this.results.dataRequests = { error: e.message };
        }
    },
    
    async verifyResponsiveness() {
        try {
            const breakpoints = [320, 768, 1024, 1440];
            const results = {};
            
            for (const width of breakpoints) {
                const issues = await this.checkBreakpoint(width);
                results[`width_${width}`] = issues.length ? issues : 'OK';
            }
            
            this.results.responsive = results;
        } catch (e) {
            this.results.responsive = { error: e.message };
        }
    },
    
    async verifyPerformance() {
        try {
            const metrics = await this.getPerformanceMetrics();
            this.results.performance = {
                loadTime: metrics.loadTime < 3000 ? 'OK' : 'Slow',
                firstPaint: metrics.firstPaint < 1000 ? 'OK' : 'Slow',
                resourceCount: metrics.resourceCount,
                cacheEnabled: this.checkCacheHeaders()
            };
        } catch (e) {
            this.results.performance = { error: e.message };
        }
    },
    
    async verifyAnalyticsIntegration() {
        try {
            this.results.analytics = {
                ga4Present: !!window.gtag,
                fbPixelPresent: !!window.fbq,
                eventsWorking: await this.testAnalyticsEvents()
            };
        } catch (e) {
            this.results.analytics = { error: e.message };
        }
    },
    
    async verifyAccessibility() {
        try {
            const issues = [];
            
            // Check for basic accessibility features
            const images = document.querySelectorAll('img');
            const links = document.querySelectorAll('a');
            const forms = document.querySelectorAll('form');
            
            images.forEach(img => {
                if (!img.alt) issues.push(`Missing alt text: ${img.src}`);
            });
            
            links.forEach(link => {
                if (!link.textContent.trim()) issues.push(`Empty link text: ${link.href}`);
            });
            
            forms.forEach(form => {
                const labels = form.querySelectorAll('label');
                const inputs = form.querySelectorAll('input:not([type="hidden"])');
                if (labels.length !== inputs.length) {
                    issues.push(`Mismatched labels in form: ${form.id}`);
                }
            });
            
            this.results.accessibility = {
                issues: issues.length ? issues : 'OK',
                ariaLabels: this.checkAriaLabels(),
                contrast: await this.checkColorContrast()
            };
        } catch (e) {
            this.results.accessibility = { error: e.message };
        }
    },
    
    // Helper methods
    async verifyToggles() {
        const toggles = document.querySelectorAll('.switch input[type="checkbox"]');
        let working = true;
        
        for (const toggle of toggles) {
            const initialState = toggle.checked;
            toggle.click();
            working = working && (toggle.checked !== initialState);
            toggle.checked = initialState; // Reset state
        }
        
        return working;
    },
    
    verifyBannerStyle(banner) {
        if (!banner) return false;
        const style = window.getComputedStyle(banner);
        return {
            position: style.position === 'fixed',
            zIndex: parseInt(style.zIndex) > 1000,
            background: style.background.includes('rgba') || style.background.includes('#')
        };
    },
    
    async verifyFormValidation(forms) {
        const results = {};
        
        for (const [type, form] of Object.entries(forms)) {
            if (!form) continue;
            
            const submitButton = form.querySelector('button[type="submit"]');
            const required = form.querySelectorAll('[required]');
            
            results[type] = {
                hasRequired: required.length > 0,
                preventsEmptySubmit: await this.testFormSubmission(form)
            };
        }
        
        return results;
    },
    
    async verifyFormSubmission(forms) {
        // Simulate form submission with test data
        const testData = {
            export: { data_types: ['personal'] },
            delete: { confirm_deletion: true },
            update: { update_details: 'Test update' },
            restrict: { restriction_reason: 'accuracy' }
        };
        
        const results = {};
        
        for (const [type, form] of Object.entries(forms)) {
            if (!form) continue;
            
            try {
                const response = await fetch(form.action, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(testData[type])
                });
                
                results[type] = response.ok;
            } catch (e) {
                results[type] = false;
            }
        }
        
        return results;
    },
    
    async checkBreakpoint(width) {
        const issues = [];
        
        // Simulate viewport width
        const meta = document.querySelector('meta[name="viewport"]');
        if (!meta || !meta.content.includes('width=device-width')) {
            issues.push('Missing or incorrect viewport meta tag');
        }
        
        // Check for horizontal scrolling
        if (document.documentElement.scrollWidth > width) {
            issues.push('Horizontal scrolling detected');
        }
        
        // Check for touch targets on mobile
        if (width <= 768) {
            const smallTargets = Array.from(document.querySelectorAll('a, button, input, select, textarea'))
                .filter(el => {
                    const rect = el.getBoundingClientRect();
                    return (rect.width < 44 || rect.height < 44);
                });
            
            if (smallTargets.length > 0) {
                issues.push(`${smallTargets.length} elements have insufficient touch target size`);
            }
        }
        
        return issues;
    },
    
    async getPerformanceMetrics() {
        const navigation = performance.getEntriesByType('navigation')[0];
        const paint = performance.getEntriesByType('paint');
        const resources = performance.getEntriesByType('resource');
        
        return {
            loadTime: navigation.loadEventEnd - navigation.startTime,
            firstPaint: paint.find(entry => entry.name === 'first-paint')?.startTime || 0,
            resourceCount: resources.length
        };
    },
    
    checkCacheHeaders() {
        const resources = performance.getEntriesByType('resource');
        let cacheEnabled = false;
        
        for (const resource of resources) {
            const headers = resource.responseHeaders;
            if (headers && (headers['cache-control'] || headers['expires'])) {
                cacheEnabled = true;
                break;
            }
        }
        
        return cacheEnabled;
    },
    
    async testAnalyticsEvents() {
        let success = true;
        
        try {
            // Test GA4 event
            if (window.gtag) {
                window.gtag('event', 'test_event', {
                    event_category: 'test',
                    event_label: 'test'
                });
            } else {
                success = false;
            }
            
            // Test Facebook Pixel event
            if (window.fbq) {
                window.fbq('track', 'test_event');
            } else {
                success = false;
            }
        } catch (e) {
            success = false;
        }
        
        return success;
    },
    
    checkAriaLabels() {
        const interactive = document.querySelectorAll('button, [role="button"], [role="tab"], [role="dialog"]');
        let valid = true;
        
        interactive.forEach(el => {
            if (!el.getAttribute('aria-label') && !el.getAttribute('aria-labelledby')) {
                valid = false;
            }
        });
        
        return valid;
    },
    
    async checkColorContrast() {
        const textElements = document.querySelectorAll('p, h1, h2, h3, h4, h5, h6, span, a');
        let validContrast = true;
        
        for (const el of textElements) {
            const style = window.getComputedStyle(el);
            const backgroundColor = style.backgroundColor;
            const color = style.color;
            
            // Simple contrast check (this is a basic implementation)
            const contrast = this.calculateContrast(backgroundColor, color);
            if (contrast < 4.5) { // WCAG AA standard for normal text
                validContrast = false;
                break;
            }
        }
        
        return validContrast;
    },
    
    calculateContrast(bg, fg) {
        // This is a simplified version. In production, use a proper color contrast library
        const getBrightness = (color) => {
            const rgb = color.match(/\d+/g);
            if (!rgb) return 0;
            return (parseInt(rgb[0]) * 299 + parseInt(rgb[1]) * 587 + parseInt(rgb[2]) * 114) / 1000;
        };
        
        const brightness1 = getBrightness(bg);
        const brightness2 = getBrightness(fg);
        
        return Math.abs(brightness1 - brightness2);
    }
};

// Run verification and output results
(async () => {
    try {
        const results = await verifyFrontend.verifyAll();
        console.log('Frontend Verification Results:', results);
        
        // Check for critical issues
        const criticalIssues = [];
        for (const [category, checks] of Object.entries(results)) {
            for (const [check, status] of Object.entries(checks)) {
                if (status !== 'OK' && typeof status !== 'object') {
                    criticalIssues.push(`${category}: ${check} (${status})`);
                }
            }
        }
        
        if (criticalIssues.length > 0) {
            console.error('Critical Issues Found:', criticalIssues);
        } else {
            console.log('All frontend checks passed successfully!');
        }
        
    } catch (e) {
        console.error('Error running frontend verification:', e);
    }
})();
