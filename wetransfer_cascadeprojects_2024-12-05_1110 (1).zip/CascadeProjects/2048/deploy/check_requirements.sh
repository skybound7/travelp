#!/bin/bash

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "Checking system requirements..."

# Check PHP version
echo -n "PHP version: "
if command -v php > /dev/null; then
    PHP_VERSION=$(php -v | head -n 1 | cut -d " " -f 2 | cut -d "." -f 1,2)
    if (( $(echo "$PHP_VERSION >= 7.4" | bc -l) )); then
        echo -e "${GREEN}$PHP_VERSION${NC} ✓"
    else
        echo -e "${RED}$PHP_VERSION${NC} ✗"
        echo "PHP 7.4 or higher is required"
    fi
else
    echo -e "${RED}Not installed${NC} ✗"
    echo "Please install PHP 7.4 or higher"
fi

# Check MySQL/MariaDB
echo -n "MySQL/MariaDB: "
if command -v mysql > /dev/null; then
    MYSQL_VERSION=$(mysql --version | cut -d " " -f 3 | cut -d "." -f 1,2)
    echo -e "${GREEN}$MYSQL_VERSION${NC} ✓"
else
    echo -e "${RED}Not installed${NC} ✗"
    echo "Please install MySQL or MariaDB"
fi

# Check required PHP extensions
echo "PHP Extensions:"
REQUIRED_EXTENSIONS=("mysqli" "json" "mbstring" "zip" "gd" "xml" "curl")
for ext in "${REQUIRED_EXTENSIONS[@]}"; do
    echo -n "  $ext: "
    if php -m | grep -q "^$ext$"; then
        echo -e "${GREEN}Installed${NC} ✓"
    else
        echo -e "${RED}Not installed${NC} ✗"
        echo "    Please install php-$ext"
    fi
done

# Check web server
echo -n "Web Server: "
if command -v apache2 > /dev/null; then
    APACHE_VERSION=$(apache2 -v | head -n 1 | cut -d "/" -f 2 | cut -d " " -f 1)
    echo -e "${GREEN}Apache $APACHE_VERSION${NC} ✓"
elif command -v nginx > /dev/null; then
    NGINX_VERSION=$(nginx -v 2>&1 | cut -d "/" -f 2)
    echo -e "${GREEN}Nginx $NGINX_VERSION${NC} ✓"
else
    echo -e "${RED}Not installed${NC} ✗"
    echo "Please install Apache or Nginx"
fi

# Check directory permissions
echo "Directory Permissions:"
WEB_ROOT=$(pwd)/..
DIRS_TO_CHECK=("uploads" "logs" "cache" "backups")

for dir in "${DIRS_TO_CHECK[@]}"; do
    echo -n "  $dir: "
    FULL_PATH="$WEB_ROOT/$dir"
    if [ -d "$FULL_PATH" ]; then
        PERMS=$(stat -c "%a" "$FULL_PATH")
        OWNER=$(stat -c "%U" "$FULL_PATH")
        if [ "$PERMS" = "775" ] && [ "$OWNER" = "www-data" ]; then
            echo -e "${GREEN}Correct${NC} ✓"
        else
            echo -e "${YELLOW}Incorrect${NC} !"
            echo "    Should be: owner=www-data, permissions=775"
            echo "    Current: owner=$OWNER, permissions=$PERMS"
        fi
    else
        echo -e "${RED}Directory not found${NC} ✗"
    fi
done

# Check SELinux if it exists
echo -n "SELinux: "
if command -v getenforce > /dev/null; then
    SELINUX_STATUS=$(getenforce)
    if [ "$SELINUX_STATUS" = "Enforcing" ]; then
        echo -e "${YELLOW}Enforcing${NC} !"
        echo "  Make sure to set proper context for web directories:"
        echo "  sudo semanage fcontext -a -t httpd_sys_rw_content_t \"$WEB_ROOT/(uploads|logs|cache|backups)(/.*)?\" "
        echo "  sudo restorecon -Rv $WEB_ROOT"
    else
        echo -e "${GREEN}$SELINUX_STATUS${NC} ✓"
    fi
else
    echo -e "${GREEN}Not installed${NC} ✓"
fi

# Summary
echo -e "\nSystem Requirements Summary:"
echo "1. Install any missing PHP extensions"
echo "2. Ensure web server is configured properly"
echo "3. Set correct directory permissions"
echo "4. Configure SELinux contexts if necessary"
