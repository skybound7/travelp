#!/bin/bash

# Configuration
LOG_DIR="/var/www/luxury-travel/logs"
ERROR_LOG="$LOG_DIR/error.log"
ACCESS_LOG="$LOG_DIR/access.log"
MYSQL_LOG="/var/log/mysql/error.log"
PHP_LOG="/var/log/php/error.log"
APACHE_ERROR_LOG="/var/log/apache2/error.log"
NGINX_ERROR_LOG="/var/log/nginx/error.log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Create logs directory if it doesn't exist
mkdir -p "$LOG_DIR"
chmod 775 "$LOG_DIR"
chown www-data:www-data "$LOG_DIR"

# Function to check and fix permissions
check_fix_permissions() {
    echo "Checking and fixing permissions..."
    
    # Web root permissions
    find /var/www/luxury-travel -type d -not -perm 755 -exec chmod 755 {} \;
    find /var/www/luxury-travel -type f -not -perm 644 -exec chmod 644 {} \;
    
    # Special directories
    chmod 775 "$LOG_DIR" /var/www/luxury-travel/{uploads,cache,backups}
    
    # Configuration files
    chmod 640 /var/www/luxury-travel/includes/config.php
    
    # Shell scripts
    chmod 755 /var/www/luxury-travel/deploy/*.sh
    
    echo -e "${GREEN}Permissions fixed${NC}"
}

# Function to check and fix SELinux contexts
check_fix_selinux() {
    if command -v getenforce >/dev/null; then
        echo "Checking SELinux contexts..."
        semanage fcontext -a -t httpd_sys_rw_content_t "/var/www/luxury-travel/(uploads|logs|cache|backups)(/.*)?"
        restorecon -Rv /var/www/luxury-travel
        echo -e "${GREEN}SELinux contexts updated${NC}"
    fi
}

# Function to check and fix database connection
check_fix_database() {
    echo "Checking database connection..."
    if ! mysql -u luxury_user -p"$DB_PASS" luxury_travel -e "SELECT 1" >/dev/null 2>&1; then
        echo -e "${RED}Database connection failed${NC}"
        echo "Attempting to fix..."
        
        # Restart MySQL
        systemctl restart mysql
        
        # Check if user exists and recreate if necessary
        mysql -u root -p"$MYSQL_ROOT_PASS" <<EOF
CREATE USER IF NOT EXISTS 'luxury_user'@'localhost' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON luxury_travel.* TO 'luxury_user'@'localhost';
FLUSH PRIVILEGES;
EOF
        
        echo -e "${GREEN}Database connection restored${NC}"
    else
        echo -e "${GREEN}Database connection OK${NC}"
    fi
}

# Function to analyze PHP errors
analyze_php_errors() {
    echo "Analyzing PHP error logs..."
    if [ -f "$PHP_LOG" ]; then
        ERRORS=$(tail -n 100 "$PHP_LOG" | grep -i "error\|warning\|notice" | sort | uniq -c | sort -nr)
        if [ ! -z "$ERRORS" ]; then
            echo -e "${YELLOW}Common PHP errors found:${NC}"
            echo "$ERRORS"
            
            # Check for common issues and fix them
            if echo "$ERRORS" | grep -q "memory_limit"; then
                echo "Increasing PHP memory limit..."
                sed -i 's/memory_limit = .*/memory_limit = 256M/' /etc/php/7.4/fpm/php.ini
                systemctl restart php7.4-fpm
            fi
            
            if echo "$ERRORS" | grep -q "max_execution_time"; then
                echo "Increasing max execution time..."
                sed -i 's/max_execution_time = .*/max_execution_time = 300/' /etc/php/7.4/fpm/php.ini
                systemctl restart php7.4-fpm
            fi
        else
            echo -e "${GREEN}No recent PHP errors found${NC}"
        fi
    fi
}

# Function to analyze web server errors
analyze_webserver_errors() {
    echo "Analyzing web server error logs..."
    if [ -f "$APACHE_ERROR_LOG" ]; then
        ERRORS=$(tail -n 100 "$APACHE_ERROR_LOG" | grep -i "error\|warning" | sort | uniq -c | sort -nr)
    elif [ -f "$NGINX_ERROR_LOG" ]; then
        ERRORS=$(tail -n 100 "$NGINX_ERROR_LOG" | grep -i "error\|warning" | sort | uniq -c | sort -nr)
    fi
    
    if [ ! -z "$ERRORS" ]; then
        echo -e "${YELLOW}Common web server errors found:${NC}"
        echo "$ERRORS"
        
        # Fix common issues
        if echo "$ERRORS" | grep -q "Permission denied"; then
            check_fix_permissions
            check_fix_selinux
        fi
        
        if echo "$ERRORS" | grep -q "worker_connections"; then
            echo "Increasing Nginx worker connections..."
            sed -i 's/worker_connections .*/worker_connections 2048;/' /etc/nginx/nginx.conf
            systemctl restart nginx
        fi
    else
        echo -e "${GREEN}No recent web server errors found${NC}"
    fi
}

# Function to check disk space
check_disk_space() {
    echo "Checking disk space..."
    DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
    if [ "$DISK_USAGE" -gt 90 ]; then
        echo -e "${RED}Disk space critical: ${DISK_USAGE}%${NC}"
        echo "Cleaning up old logs and cache..."
        
        # Clean old logs
        find "$LOG_DIR" -type f -name "*.log" -mtime +30 -delete
        
        # Clean cache
        rm -rf /var/www/luxury-travel/cache/*
        
        echo -e "${GREEN}Cleanup completed${NC}"
    else
        echo -e "${GREEN}Disk space OK: ${DISK_USAGE}%${NC}"
    fi
}

# Main monitoring loop
echo "Starting system monitoring..."
while true; do
    echo "=== $(date) ==="
    
    # Check system components
    check_disk_space
    check_fix_database
    analyze_php_errors
    analyze_webserver_errors
    
    # Fix permissions if needed
    check_fix_permissions
    
    # Wait 5 minutes before next check
    echo "Sleeping for 5 minutes..."
    sleep 300
done
