#!/bin/bash

# Configuration
WEB_ROOT="/var/www/html/luxury-travel"
WEB_USER="www-data"
WEB_GROUP="www-data"
BACKUP_DIR="/var/backups/luxury-travel"
LOG_DIR="/var/log/luxury-travel"

# Create necessary directories
echo "Creating directories..."
mkdir -p "$WEB_ROOT"
mkdir -p "$BACKUP_DIR"
mkdir -p "$LOG_DIR"

# Set proper ownership
echo "Setting ownership..."
chown -R "$WEB_USER:$WEB_GROUP" "$WEB_ROOT"
chown -R "$WEB_USER:$WEB_GROUP" "$BACKUP_DIR"
chown -R "$WEB_USER:$WEB_GROUP" "$LOG_DIR"

# Set directory permissions
echo "Setting directory permissions..."
find "$WEB_ROOT" -type d -exec chmod 755 {} \;

# Set file permissions
echo "Setting file permissions..."
find "$WEB_ROOT" -type f -exec chmod 644 {} \;

# Make specific directories writable
echo "Setting writable permissions for specific directories..."
chmod -R 775 "$WEB_ROOT/uploads"
chmod -R 775 "$WEB_ROOT/cache"
chmod -R 775 "$WEB_ROOT/backups"
chmod -R 775 "$WEB_ROOT/logs"
chmod -R 775 "$LOG_DIR"
chmod -R 775 "$BACKUP_DIR"

# Set specific file permissions
echo "Setting specific file permissions..."
chmod 400 "$WEB_ROOT/.env"
chmod 644 "$WEB_ROOT/.htaccess"
chmod 755 "$WEB_ROOT/scripts/"*.sh
chmod 755 "$WEB_ROOT/scripts/"*.php

# Create log files with proper permissions
echo "Setting up log files..."
touch "$LOG_DIR/error.log"
touch "$LOG_DIR/access.log"
touch "$LOG_DIR/security.log"
touch "$LOG_DIR/performance.log"
chown "$WEB_USER:$WEB_GROUP" "$LOG_DIR"/*.log
chmod 664 "$LOG_DIR"/*.log

# Set up cron jobs for maintenance tasks
echo "Setting up cron jobs..."
CRON_FILE="/etc/cron.d/luxury-travel"
echo "# Luxury Travel Website Maintenance Tasks" > "$CRON_FILE"
echo "0 2 * * * $WEB_USER php $WEB_ROOT/scripts/perform_backup.php >> $LOG_DIR/backup.log 2>&1" >> "$CRON_FILE"
echo "*/5 * * * * $WEB_USER php $WEB_ROOT/scripts/monitor_health.php >> $LOG_DIR/monitor.log 2>&1" >> "$CRON_FILE"
echo "0 1 * * * $WEB_USER php $WEB_ROOT/scripts/cleanup_old_logs.php >> $LOG_DIR/cleanup.log 2>&1" >> "$CRON_FILE"
chmod 644 "$CRON_FILE"

# Create PHP-FPM configuration
echo "Setting up PHP-FPM configuration..."
PHP_FPM_CONF="/etc/php/7.4/fpm/pool.d/luxury-travel.conf"
cat > "$PHP_FPM_CONF" << EOL
[luxury-travel]
user = $WEB_USER
group = $WEB_GROUP
listen = /run/php/php7.4-fpm-luxury-travel.sock
listen.owner = $WEB_USER
listen.group = $WEB_GROUP
pm = dynamic
pm.max_children = 50
pm.start_servers = 5
pm.min_spare_servers = 5
pm.max_spare_servers = 35
php_admin_value[error_log] = $LOG_DIR/php-error.log
php_admin_value[upload_max_filesize] = 64M
php_admin_value[post_max_size] = 64M
php_admin_value[memory_limit] = 256M
php_admin_value[max_execution_time] = 300
EOL
chmod 644 "$PHP_FPM_CONF"

# Create Nginx configuration
echo "Setting up Nginx configuration..."
NGINX_CONF="/etc/nginx/sites-available/luxury-travel"
cat > "$NGINX_CONF" << EOL
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    root $WEB_ROOT;
    index index.php index.html;

    access_log $LOG_DIR/access.log;
    error_log $LOG_DIR/error.log;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-XSS-Protection "1; mode=block";
    add_header X-Content-Type-Options "nosniff";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
    add_header Content-Security-Policy "default-src 'self' https: data: 'unsafe-inline' 'unsafe-eval';";

    # Gzip compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    # Cache static files
    location ~* \.(jpg|jpeg|png|gif|ico|css|js)$ {
        expires 30d;
        add_header Cache-Control "public, no-transform";
    }

    # PHP handling
    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass unix:/run/php/php7.4-fpm-luxury-travel.sock;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_intercept_errors on;
        fastcgi_buffer_size 128k;
        fastcgi_buffers 4 256k;
        fastcgi_busy_buffers_size 256k;
    }

    # Deny access to sensitive files
    location ~ /\. {
        deny all;
    }

    location ~ ^/(uploads|backups)/.+\.(php|phar|phtml|php3|php4|php5|php7|phps)$ {
        deny all;
    }

    # Custom error pages
    error_page 404 /404.php;
    error_page 500 502 503 504 /50x.php;
}
EOL
chmod 644 "$NGINX_CONF"

# Create symbolic link to enable the site
ln -sf "$NGINX_CONF" "/etc/nginx/sites-enabled/luxury-travel"

echo "Deployment configuration completed!"
echo "Please review and adjust the configurations as needed."
echo "Don't forget to:"
echo "1. Update the server_name in Nginx configuration"
echo "2. Install SSL certificate and configure HTTPS"
echo "3. Update database credentials in .env file"
echo "4. Restart Nginx and PHP-FPM services"
