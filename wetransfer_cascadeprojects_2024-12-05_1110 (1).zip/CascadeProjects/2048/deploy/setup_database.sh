#!/bin/bash

# Database configuration
DB_NAME="luxury_travel"
DB_USER="luxury_user"
DB_PASS="your_secure_password"  # Change this to a secure password
MYSQL_ROOT_PASS="your_root_password"  # Change this to your MySQL root password

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo "Setting up database for Luxury Travel Website..."

# Create database and user
echo "Creating database and user..."
mysql -u root -p$MYSQL_ROOT_PASS <<EOF
CREATE DATABASE IF NOT EXISTS $DB_NAME CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON $DB_NAME.* TO '$DB_USER'@'localhost';
FLUSH PRIVILEGES;
EOF

if [ $? -eq 0 ]; then
    echo -e "${GREEN}Database and user created successfully!${NC}"
else
    echo -e "${RED}Error creating database and user${NC}"
    exit 1
fi

# Import schema
echo "Importing database schema..."
mysql -u $DB_USER -p$DB_PASS $DB_NAME < ../sql/combo_itinerary.sql

if [ $? -eq 0 ]; then
    echo -e "${GREEN}Schema imported successfully!${NC}"
else
    echo -e "${RED}Error importing schema${NC}"
    exit 1
fi

# Import sample data
echo "Importing sample data..."
mysql -u $DB_USER -p$DB_PASS $DB_NAME < ../sql/sample_data.sql

if [ $? -eq 0 ]; then
    echo -e "${GREEN}Sample data imported successfully!${NC}"
else
    echo -e "${RED}Error importing sample data${NC}"
    exit 1
fi

# Update config.php with new credentials
echo "Updating config.php..."
CONFIG_FILE="../includes/config.php"
sed -i "s/define('DB_USER', 'root')/define('DB_USER', '$DB_USER')/" $CONFIG_FILE
sed -i "s/define('DB_PASS', '')/define('DB_PASS', '$DB_PASS')/" $CONFIG_FILE

if [ $? -eq 0 ]; then
    echo -e "${GREEN}Configuration updated successfully!${NC}"
else
    echo -e "${RED}Error updating configuration${NC}"
    exit 1
fi

# Set proper permissions
echo "Setting file permissions..."
cd ..
sudo chown -R www-data:www-data .
sudo find . -type d -exec chmod 755 {} \;
sudo find . -type f -exec chmod 644 {} \;
sudo chmod 755 deploy/*.sh
sudo chmod 640 includes/config.php

if [ $? -eq 0 ]; then
    echo -e "${GREEN}Permissions set successfully!${NC}"
else
    echo -e "${RED}Error setting permissions${NC}"
    exit 1
fi

echo -e "${GREEN}Database setup completed successfully!${NC}"
echo "Please make note of these credentials:"
echo "Database Name: $DB_NAME"
echo "Database User: $DB_USER"
echo "Database Password: $DB_PASS"
