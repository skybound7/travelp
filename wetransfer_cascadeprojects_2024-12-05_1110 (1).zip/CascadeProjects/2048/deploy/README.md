# Linux Deployment Guide

## Prerequisites
- Linux server (Ubuntu/Debian recommended)
- PHP 7.4 or higher
- MySQL 5.7 or higher / MariaDB 10.3 or higher
- Apache2 or Nginx
- Required PHP extensions: mysqli, json, mbstring, zip, gd, xml, curl

## Installation Steps

1. **Check System Requirements**
   ```bash
   cd deploy
   chmod +x check_requirements.sh
   ./check_requirements.sh
   ```

2. **Create Required Directories**
   ```bash
   mkdir -p ../uploads ../logs ../cache ../backups
   chmod 775 ../uploads ../logs ../cache ../backups
   chown -R www-data:www-data ../uploads ../logs ../cache ../backups
   ```

3. **Set Up Database**
   ```bash
   # Edit database credentials in setup_database.sh first
   chmod +x setup_database.sh
   ./setup_database.sh
   ```

4. **Configure Web Server**

   For Apache2:
   ```apache
   <VirtualHost *:80>
       ServerName yourdomain.com
       DocumentRoot /var/www/luxury-travel
       
       <Directory /var/www/luxury-travel>
           Options -Indexes +FollowSymLinks
           AllowOverride All
           Require all granted
       </Directory>
       
       ErrorLog ${APACHE_LOG_DIR}/luxury-travel-error.log
       CustomLog ${APACHE_LOG_DIR}/luxury-travel-access.log combined
   </VirtualHost>
   ```

   For Nginx:
   ```nginx
   server {
       listen 80;
       server_name yourdomain.com;
       root /var/www/luxury-travel;
       index index.php index.html;
       
       location / {
           try_files $uri $uri/ /index.php?$query_string;
       }
       
       location ~ \.php$ {
           include snippets/fastcgi-php.conf;
           fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
       }
       
       location ~ /\. {
           deny all;
       }
   }
   ```

5. **Set File Permissions**
   ```bash
   # Set proper ownership
   chown -R www-data:www-data /var/www/luxury-travel
   
   # Set directory permissions
   find /var/www/luxury-travel -type d -exec chmod 755 {} \;
   
   # Set file permissions
   find /var/www/luxury-travel -type f -exec chmod 644 {} \;
   
   # Make scripts executable
   chmod 755 /var/www/luxury-travel/deploy/*.sh
   
   # Protect configuration
   chmod 640 /var/www/luxury-travel/includes/config.php
   ```

6. **Configure SELinux (if enabled)**
   ```bash
   # Set proper context for web directories
   semanage fcontext -a -t httpd_sys_rw_content_t "/var/www/luxury-travel/(uploads|logs|cache|backups)(/.*)?"
   restorecon -Rv /var/www/luxury-travel
   ```

## Security Considerations

1. **File Permissions**
   - Regular files: 644
   - Directories: 755
   - Writable directories: 775
   - Configuration files: 640
   - Shell scripts: 755

2. **Database Security**
   - Use a strong password
   - Limit database user privileges
   - Regular backups
   - Secure connection (SSL/TLS)

3. **Web Server Security**
   - Enable HTTPS
   - Set security headers
   - Disable directory listing
   - Protect sensitive files

4. **PHP Security**
   - Keep PHP updated
   - Secure php.ini settings
   - Enable error logging
   - Disable expose_php

## Maintenance

1. **Regular Updates**
   ```bash
   # Update system packages
   apt update && apt upgrade
   
   # Update PHP packages
   apt update php*
   ```

2. **Backup Schedule**
   ```bash
   # Add to crontab
   0 2 * * * /var/www/luxury-travel/deploy/backup.sh
   ```

3. **Log Rotation**
   ```bash
   # Configure logrotate
   cat > /etc/logrotate.d/luxury-travel << EOF
   /var/www/luxury-travel/logs/*.log {
       daily
       missingok
       rotate 14
       compress
       delaycompress
       notifempty
       create 0640 www-data www-data
   }
   EOF
   ```

## Troubleshooting

1. **Check Logs**
   ```bash
   tail -f /var/www/luxury-travel/logs/error.log
   tail -f /var/log/apache2/luxury-travel-error.log  # or nginx error log
   ```

2. **Check Permissions**
   ```bash
   ls -la /var/www/luxury-travel
   namei -l /var/www/luxury-travel/includes/config.php
   ```

3. **Check PHP Configuration**
   ```bash
   php -i | grep "Loaded Configuration File"
   php -i | grep "error_log"
   ```

4. **Database Issues**
   ```bash
   # Check MySQL status
   systemctl status mysql
   
   # Check MySQL logs
   tail -f /var/log/mysql/error.log
   ```

## Support
For issues or assistance:
- System Administrator: admin@yourdomain.com
- Emergency Contact: emergency@yourdomain.com
