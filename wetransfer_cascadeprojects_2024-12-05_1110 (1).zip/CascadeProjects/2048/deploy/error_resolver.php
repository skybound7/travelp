<?php
/**
 * Automatic Error Resolution System
 */
class ErrorResolver {
    private $logDir;
    private $errorLog;
    private $accessLog;
    private $dbConnection;
    private $errorPatterns;
    
    public function __construct($logDir, $dbConnection) {
        $this->logDir = $logDir;
        $this->errorLog = "$logDir/error.log";
        $this->accessLog = "$logDir/access.log";
        $this->dbConnection = $dbConnection;
        
        $this->errorPatterns = [
            // Database Errors
            '/Connection refused/' => 'checkDatabaseConnection',
            '/Unknown column/' => 'fixDatabaseSchema',
            '/Table.*doesn\'t exist/' => 'createMissingTable',
            '/Lock wait timeout exceeded/' => 'handleDeadlock',
            '/Too many connections/' => 'optimizeConnections',
            '/Duplicate entry/' => 'handleDuplicateEntry',
            '/Foreign key constraint fails/' => 'handleForeignKeyViolation',
            
            // File System Errors
            '/Permission denied/' => 'fixFilePermissions',
            '/failed to open stream/' => 'checkFileExistence',
            '/Disk quota exceeded/' => 'handleDiskQuota',
            '/No space left on device/' => 'cleanupDiskSpace',
            '/Input\/output error/' => 'checkFileSystemHealth',
            
            // PHP Errors
            '/Undefined index/' => 'logUndefinedIndex',
            '/Maximum execution time/' => 'increaseExecutionTime',
            '/Memory limit reached/' => 'increaseMemoryLimit',
            '/Call to undefined function/' => 'checkMissingExtension',
            '/Class.*not found/' => 'handleAutoloaderIssue',
            '/Allowed memory size of/' => 'handleMemoryExhaustion',
            '/Maximum function nesting level/' => 'handleRecursionLimit',
            
            // Security Issues
            '/SQL injection attempt/' => 'blockIPAddress',
            '/XSS attempt detected/' => 'blockIPAddress',
            '/Directory traversal attempt/' => 'blockIPAddress',
            '/File inclusion attempt/' => 'blockIPAddress',
            '/Brute force attempt/' => 'handleBruteForce',
            '/Invalid SSL certificate/' => 'checkSSLCertificate',
            '/Session hijacking attempt/' => 'handleSessionSecurity',
            
            // Performance Issues
            '/Slow query/' => 'optimizeQuery',
            '/High server load/' => 'checkServerLoad',
            '/Cache miss rate high/' => 'optimizeCache',
            '/Connection pool exhausted/' => 'optimizeConnectionPool',
            '/Deadlock found/' => 'handleDeadlock',
            '/Query cache is fragmented/' => 'optimizeQueryCache',
            
            // Network Issues
            '/Connection timed out/' => 'checkNetworkConnectivity',
            '/DNS lookup failed/' => 'checkDNSConfiguration',
            '/SSL handshake failed/' => 'troubleshootSSL',
            '/Network is unreachable/' => 'checkNetworkStatus',
            
            // Session Errors
            '/Session save path not writable/' => 'fixSessionPath',
            '/Session expired/' => 'handleSessionExpiry',
            '/Invalid session ID/' => 'cleanInvalidSessions',
            
            // Upload Errors
            '/Upload file size exceeds/' => 'handleUploadLimit',
            '/Invalid upload directory/' => 'fixUploadDirectory',
            '/Insecure upload attempt/' => 'blockMaliciousUpload',
            
            // API Errors
            '/Rate limit exceeded/' => 'handleRateLimit',
            '/API endpoint not responding/' => 'checkAPIHealth',
            '/Invalid API response/' => 'logAPIError',
            
            // Cache Errors
            '/Cache write failed/' => 'troubleshootCache',
            '/Redis connection failed/' => 'checkRedisConnection',
            '/Memcached connection failed/' => 'checkMemcachedConnection',
            
            // Email Errors
            '/SMTP connect failed/' => 'checkSMTPConnection',
            '/Invalid email format/' => 'handleEmailValidation',
            '/Email sending failed/' => 'troubleshootEmailDelivery',
            
            // Payment Gateway Errors
            '/Payment gateway timeout/' => 'checkPaymentGateway',
            '/Invalid payment response/' => 'handlePaymentError',
            '/Duplicate transaction/' => 'handleDuplicatePayment'
        ];
    }
    
    /**
     * Monitor and resolve errors
     */
    public function monitor() {
        $this->checkLogDirectory();
        $this->analyzeErrorLog();
        $this->analyzeDatabaseErrors();
        $this->checkPerformance();
        $this->cleanOldLogs();
    }
    
    /**
     * Analyze error log for patterns
     */
    private function analyzeErrorLog() {
        if (!file_exists($this->errorLog)) {
            return;
        }
        
        $errors = file($this->errorLog, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($errors as $error) {
            foreach ($this->errorPatterns as $pattern => $handler) {
                if (preg_match($pattern, $error)) {
                    $this->$handler($error);
                }
            }
        }
    }
    
    /**
     * Check and create log directory
     */
    private function checkLogDirectory() {
        if (!is_dir($this->logDir)) {
            mkdir($this->logDir, 0775, true);
            chown($this->logDir, 'www-data');
            chgrp($this->logDir, 'www-data');
        }
    }
    
    /**
     * Fix database connection issues
     */
    private function checkDatabaseConnection($error) {
        try {
            $this->dbConnection->ping();
        } catch (Exception $e) {
            // Try to reconnect
            $this->dbConnection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            $this->logResolution("Database reconnection attempted");
        }
    }
    
    /**
     * Fix missing database tables
     */
    private function createMissingTable($error) {
        if (preg_match('/Table \'(.+)\'/', $error, $matches)) {
            $tableName = $matches[1];
            $schemaFile = __DIR__ . '/../sql/combo_itinerary.sql';
            
            if (file_exists($schemaFile)) {
                $sql = file_get_contents($schemaFile);
                $this->dbConnection->multi_query($sql);
                $this->logResolution("Attempted to recreate missing table: $tableName");
            }
        }
    }
    
    /**
     * Fix file permissions
     */
    private function fixFilePermissions($error) {
        if (preg_match('/\'(.+)\'/', $error, $matches)) {
            $file = $matches[1];
            if (file_exists($file)) {
                chmod($file, 0644);
                $this->logResolution("Fixed permissions for: $file");
            }
        }
    }
    
    /**
     * Increase PHP execution time
     */
    private function increaseExecutionTime($error) {
        $currentLimit = ini_get('max_execution_time');
        $newLimit = $currentLimit + 30;
        ini_set('max_execution_time', $newLimit);
        $this->logResolution("Increased max_execution_time to $newLimit seconds");
    }
    
    /**
     * Increase PHP memory limit
     */
    private function increaseMemoryLimit($error) {
        $currentLimit = ini_get('memory_limit');
        $newLimit = intval($currentLimit) + 64;
        ini_set('memory_limit', $newLimit . 'M');
        $this->logResolution("Increased memory_limit to {$newLimit}M");
    }
    
    /**
     * Block malicious IP addresses
     */
    private function blockIPAddress($error) {
        if (preg_match('/IP: ([0-9.]+)/', $error, $matches)) {
            $ip = $matches[1];
            $stmt = $this->dbConnection->prepare("
                INSERT INTO blocked_ips (ip_address, reason, blocked_at)
                VALUES (?, ?, NOW())
            ");
            $stmt->bind_param('ss', $ip, $error);
            $stmt->execute();
            $this->logResolution("Blocked IP address: $ip");
        }
    }
    
    /**
     * Optimize slow queries
     */
    private function optimizeQuery($error) {
        if (preg_match('/Query: (.+)/', $error, $matches)) {
            $query = $matches[1];
            $this->logResolution("Slow query detected: $query");
            // Add query to optimization log for later analysis
        }
    }
    
    /**
     * Check server load
     */
    private function checkServerLoad($error) {
        $load = sys_getloadavg();
        if ($load[0] > 5) {
            // High load detected
            $this->logResolution("High server load detected: {$load[0]}");
        }
    }
    
    /**
     * Clean old log files
     */
    private function cleanOldLogs() {
        $files = glob($this->logDir . '/*.log');
        foreach ($files as $file) {
            if (filemtime($file) < strtotime('-30 days')) {
                unlink($file);
                $this->logResolution("Removed old log file: $file");
            }
        }
    }
    
    /**
     * Log resolution attempts
     */
    private function logResolution($message) {
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[$timestamp] RESOLUTION: $message\n";
        file_put_contents($this->logDir . '/resolutions.log', $logMessage, FILE_APPEND);
    }
    
    /**
     * Check database performance
     */
    private function analyzeDatabaseErrors() {
        $stmt = $this->dbConnection->prepare("
            SELECT TABLE_NAME, TABLE_ROWS, DATA_LENGTH, INDEX_LENGTH
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = ?
        ");
        
        $dbName = DB_NAME;
        $stmt->bind_param('s', $dbName);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            if ($row['TABLE_ROWS'] > 1000000) {
                $this->logResolution("Large table detected: {$row['TABLE_NAME']}");
            }
        }
    }
    
    /**
     * Check system performance
     */
    private function checkPerformance() {
        // Check disk space
        $df = disk_free_space('/');
        $dt = disk_total_space('/');
        $du = ($dt - $df) / $dt * 100;
        
        if ($du > 90) {
            $this->logResolution("Disk usage critical: {$du}%");
        }
        
        // Check memory usage
        $memInfo = file_get_contents('/proc/meminfo');
        if (preg_match('/MemFree:\s+(\d+)/', $memInfo, $matches)) {
            $memFree = $matches[1] / 1024;
            if ($memFree < 100) {
                $this->logResolution("Low memory: {$memFree}MB free");
            }
        }
    }
    
    /**
     * Handle database deadlocks
     */
    private function handleDeadlock($error) {
        $this->logResolution("Detected deadlock, analyzing transactions...");
        $stmt = $this->dbConnection->prepare("SHOW ENGINE INNODB STATUS");
        $stmt->execute();
        $result = $stmt->get_result();
        $status = $result->fetch_assoc();
        
        // Analyze deadlock information
        if (strpos($status['Status'], 'LATEST DETECTED DEADLOCK') !== false) {
            // Kill long-running transactions
            $stmt = $this->dbConnection->prepare("
                SELECT trx_id, trx_started
                FROM information_schema.innodb_trx
                WHERE trx_started < NOW() - INTERVAL 60 SECOND
            ");
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $this->dbConnection->query("KILL TRANSACTION " . $row['trx_id']);
            }
        }
    }
    
    /**
     * Handle brute force attempts
     */
    private function handleBruteForce($error) {
        if (preg_match('/IP: ([0-9.]+)/', $error, $matches)) {
            $ip = $matches[1];
            
            // Check failed attempts
            $stmt = $this->dbConnection->prepare("
                SELECT COUNT(*) as attempts
                FROM login_attempts
                WHERE ip_address = ?
                AND attempt_time > NOW() - INTERVAL 15 MINUTE
            ");
            $stmt->bind_param('s', $ip);
            $stmt->execute();
            $result = $stmt->get_result();
            $attempts = $result->fetch_assoc()['attempts'];
            
            if ($attempts > 5) {
                $this->blockIPAddress($error);
                $this->notifyAdmin("Brute force attempt blocked from IP: $ip");
            }
        }
    }
    
    /**
     * Handle SSL certificate issues
     */
    private function checkSSLCertificate($error) {
        $domain = $_SERVER['SERVER_NAME'];
        $cert = openssl_x509_parse(openssl_x509_read(file_get_contents("/etc/ssl/certs/$domain.crt")));
        
        if ($cert['validTo_time_t'] < strtotime('+30 days')) {
            $this->notifyAdmin("SSL Certificate expiring soon for $domain");
        }
    }
    
    /**
     * Handle cache optimization
     */
    private function optimizeCache($error) {
        // Clear old cache entries
        $cacheDir = __DIR__ . '/../cache';
        $files = glob("$cacheDir/*");
        foreach ($files as $file) {
            if (filemtime($file) < strtotime('-7 days')) {
                unlink($file);
            }
        }
        
        // Analyze cache hit ratio
        $this->analyzeCacheEfficiency();
    }
    
    /**
     * Handle upload directory issues
     */
    private function fixUploadDirectory($error) {
        $uploadDir = __DIR__ . '/../uploads';
        
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0775, true);
        }
        
        chmod($uploadDir, 0775);
        chown($uploadDir, 'www-data');
        chgrp($uploadDir, 'www-data');
        
        // Clean old temporary files
        $tempFiles = glob("$uploadDir/temp/*");
        foreach ($tempFiles as $file) {
            if (filemtime($file) < strtotime('-24 hours')) {
                unlink($file);
            }
        }
    }
    
    /**
     * Handle payment gateway issues
     */
    private function checkPaymentGateway($error) {
        // Test payment gateway connection
        $gatewayStatus = $this->testPaymentGatewayConnection();
        
        if (!$gatewayStatus) {
            $this->notifyAdmin("Payment gateway connection failed");
            // Switch to backup gateway if configured
            $this->switchToBackupGateway();
        }
    }
    
    /**
     * Notify admin of critical issues
     */
    private function notifyAdmin($message) {
        $to = ADMIN_EMAIL;
        $subject = "Critical System Alert - Luxury Travel";
        $headers = "From: system@" . $_SERVER['SERVER_NAME'] . "\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        
        mail($to, $subject, $message, $headers);
    }
}
