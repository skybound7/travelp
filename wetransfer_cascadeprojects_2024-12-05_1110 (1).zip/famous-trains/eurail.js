document.addEventListener('DOMContentLoaded', () => {
    const passTypeSelect = document.getElementById('pass-type');
    const durationSelect = document.getElementById('duration');
    const classSelect = document.getElementById('class');
    const travelersInput = document.getElementById('travelers');
    const totalPriceDisplay = document.getElementById('total-price');
    const bookingForm = document.getElementById('eurail-booking-form');

    // Base prices for different pass types
    const prices = {
        'global': {
            '3-days': { first: 320, second: 251 },
            '5-days': { first: 388, second: 305 },
            '7-days': { first: 474, second: 366 },
            '15-days': { first: 673, second: 515 },
            '1-month': { first: 884, second: 675 }
        },
        'one-country': {
            '3-days': { first: 230, second: 168 },
            '5-days': { first: 290, second: 215 },
            '7-days': { first: 348, second: 255 },
            '15-days': { first: 449, second: 329 },
            '1-month': { first: 554, second: 405 }
        },
        'select': {
            '3-days': { first: 250, second: 185 },
            '5-days': { first: 310, second: 235 },
            '7-days': { first: 368, second: 275 },
            '15-days': { first: 469, second: 349 },
            '1-month': { first: 574, second: 425 }
        }
    };

    // Calculate and update total price
    function updatePrice() {
        const passType = passTypeSelect.value;
        const duration = durationSelect.value;
        const travelClass = classSelect.value;
        const travelers = parseInt(travelersInput.value) || 1;

        if (passType && duration && prices[passType] && prices[passType][duration]) {
            const basePrice = prices[passType][duration][travelClass];
            const totalPrice = basePrice * travelers;
            totalPriceDisplay.textContent = `Total Price: €${totalPrice}`;
        }
    }

    // Add event listeners for price updates
    passTypeSelect.addEventListener('change', updatePrice);
    durationSelect.addEventListener('change', updatePrice);
    classSelect.addEventListener('change', updatePrice);
    travelersInput.addEventListener('input', updatePrice);

    // Handle form submission
    bookingForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Check policy acceptance
        const policyCheckbox = bookingForm.querySelector('input[name="policy_accepted"]');
        if (!policyCheckbox.checked) {
            alert('Please read and accept the Eurail Pass policies to proceed.');
            policyCheckbox.focus();
            return;
        }
        
        const formData = new FormData(bookingForm);
        const submitButton = bookingForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        
        try {
            const response = await fetch('/api/book-eurail.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                if (result.payment_data.redirect_url) {
                    window.location.href = result.payment_data.redirect_url;
                } else {
                    window.location.href = '/booking-success.html';
                }
            } else {
                throw new Error(result.error || 'Booking failed');
            }
        } catch (error) {
            alert('Error: ' + error.message);
            submitButton.disabled = false;
        }
    });

    // Add smooth scroll for booking button
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});
