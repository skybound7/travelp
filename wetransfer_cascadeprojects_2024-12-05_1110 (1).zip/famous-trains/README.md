# Famous Trains - Luxury Train Experiences

A comprehensive web application for exploring and booking luxury train experiences worldwide.

## 🚂 Features

- Interactive train archive with advanced filtering
- Real-time price updates and availability
- Detailed train information and amenities
- User reviews and ratings
- Secure booking system
- Admin dashboard for content management

## 🛠️ Technical Stack

- Frontend: HTML5, JavaScript, CSS3
- Backend: PHP 7.4+
- Database: MySQL 5.7+
- Dependencies: 
  - noUiSlider (for price range slider)
  - Font Awesome (for icons)

## 📦 Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/famous-trains.git
cd famous-trains
```

2. Configure your database:
   - Create a new MySQL database
   - Import the SQL files from `database/migrations/` in order:
     ```bash
     mysql -u your_username -p your_database < database/migrations/001_create_users_table.sql
     mysql -u your_username -p your_database < database/migrations/002_create_trains_tables.sql
     ```

3. Configure the application:
   - Copy `config/config.example.php` to `config/config.php`
   - Update the database credentials and other settings in `config/config.php`

4. Set up your web server:
   - Point your web server to the project's root directory
   - Ensure PHP has write permissions for the `uploads/` directory
   - Configure URL rewriting (sample .htaccess provided)

## 🔧 Configuration

Update the following files according to your environment:

1. `config/config.php`:
   - Database credentials
   - API settings
   - Environment settings
   - Security settings

2. `config/database.php`:
   - Database connection settings
   - PDO options

## 🚀 Usage

1. Access the main application:
   ```
   http://your-domain.com/famous-trains.html
   ```

2. Admin Dashboard:
   ```
   http://your-domain.com/admin/login.js
   ```
   Default admin credentials:
   - Username: admin
   - Password: admin123 (change this immediately)

## 💡 Development

- Use the development environment for testing
- Enable debug mode in config.php
- Follow the coding standards in .editorconfig
- Run tests before submitting pull requests

## 🔒 Security

- Update the JWT secret key in config.php
- Use HTTPS in production
- Implement rate limiting for API endpoints
- Sanitize user inputs
- Follow security best practices

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 👥 Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a new Pull Request

## 📞 Support

For support and questions, please:
- Open an issue
- Contact the development team
- Check the documentation