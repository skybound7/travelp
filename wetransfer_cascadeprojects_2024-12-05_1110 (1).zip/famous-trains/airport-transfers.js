// Vehicle Data
const vehicles = [
    {
        id: 1,
        name: "Executive Sedan",
        description: "Perfect for 1-3 passengers with standard luggage",
        capacity: 3,
        luggage: 3,
        image: "sedan.jpg",
        basePrice: 80
    },
    {
        id: 2,
        name: "Business Van",
        description: "Ideal for 4-6 passengers with extra luggage space",
        capacity: 6,
        luggage: 6,
        image: "van.jpg",
        basePrice: 120
    },
    {
        id: 3,
        name: "Luxury SUV",
        description: "Premium travel for 4 passengers with ample luggage",
        capacity: 4,
        luggage: 4,
        image: "suv.jpg",
        basePrice: 150
    },
    {
        id: 4,
        name: "VIP Minibus",
        description: "Group travel for up to 8 passengers with large luggage capacity",
        capacity: 8,
        luggage: 8,
        image: "minibus.jpg",
        basePrice: 200
    }
];

// Airport Data with Distances
const airports = {
    heathrow: {
        name: "London Heathrow (LHR)",
        cityCenter: {
            distance: 24,
            baseRate: 1.5
        }
    },
    gatwick: {
        name: "London Gatwick (LGW)",
        cityCenter: {
            distance: 45,
            baseRate: 1.8
        }
    },
    charles: {
        name: "Paris Charles de Gaulle (CDG)",
        cityCenter: {
            distance: 30,
            baseRate: 1.6
        }
    }
};

// State Management
let selectedVehicle = null;
let selectedServices = new Set();
let currentPrice = 0;

// Performance Monitoring and Debugging
const DEBUG = {
    enabled: true,
    performanceMetrics: new Map(),
    eventListeners: new Set(),
    memoryUsage: new Map(),
    errors: [],
    warnings: []
};

// Performance Monitoring
class PerformanceMonitor {
    static start(operationName) {
        if (!DEBUG.enabled) return;
        DEBUG.performanceMetrics.set(operationName, performance.now());
    }

    static end(operationName) {
        if (!DEBUG.enabled) return;
        const startTime = DEBUG.performanceMetrics.get(operationName);
        if (startTime) {
            const duration = performance.now() - startTime;
            console.debug(`${operationName} took ${duration.toFixed(2)}ms`);
            if (duration > 1000) {
                DEBUG.warnings.push(`Performance warning: ${operationName} took ${duration.toFixed(2)}ms`);
            }
        }
    }

    static async measure(operationName, operation) {
        PerformanceMonitor.start(operationName);
        try {
            const result = await operation();
            return result;
        } finally {
            PerformanceMonitor.end(operationName);
        }
    }
}

// Error Handling and Logging
class ErrorHandler {
    static handle(error, context) {
        DEBUG.errors.push({ error, context, timestamp: new Date() });
        console.error(`Error in ${context}:`, error);
        
        // Report to monitoring service if in production
        if (!DEBUG.enabled) {
            reportErrorToMonitoring(error, context);
        }
        
        showUserFriendlyError(context);
    }

    static showUserFriendlyError(context) {
        const messages = {
            'price-calculation': 'Unable to calculate price. Please try again.',
            'flight-tracking': 'Flight tracking is temporarily unavailable.',
            'booking-creation': 'Unable to complete booking. Please try again.',
            'api-request': 'Network connection issue. Please check your connection.'
        };

        showError(messages[context] || 'An unexpected error occurred. Please try again.');
    }
}

// Memory Management
class MemoryManager {
    static track(resourceName, resource) {
        if (!DEBUG.enabled) return;
        DEBUG.memoryUsage.set(resourceName, resource);
    }

    static release(resourceName) {
        if (!DEBUG.enabled) return;
        if (DEBUG.memoryUsage.has(resourceName)) {
            DEBUG.memoryUsage.delete(resourceName);
        }
    }

    static checkMemoryLeaks() {
        if (!DEBUG.enabled) return;
        console.debug('Current tracked resources:', Array.from(DEBUG.memoryUsage.keys()));
    }
}

// Event Listener Management
class EventManager {
    static addListener(element, event, handler, options = {}) {
        if (!element) {
            console.warn('Attempted to add event listener to non-existent element');
            return;
        }

        const wrappedHandler = async (...args) => {
            try {
                await PerformanceMonitor.measure(
                    `event-${event}-handler`,
                    () => handler(...args)
                );
            } catch (error) {
                ErrorHandler.handle(error, `event-${event}-handler`);
            }
        };

        element.addEventListener(event, wrappedHandler, options);
        DEBUG.eventListeners.add({ element, event, handler: wrappedHandler });
    }

    static removeAllListeners() {
        DEBUG.eventListeners.forEach(({ element, event, handler }) => {
            element.removeEventListener(event, handler);
        });
        DEBUG.eventListeners.clear();
    }
}

// API Request Optimization
class ApiManager {
    static requestQueue = new Map();
    static cache = new Map();

    static async request(endpoint, options = {}) {
        const cacheKey = `${endpoint}-${JSON.stringify(options)}`;
        
        // Check cache first
        if (options.method === 'GET' && this.cache.has(cacheKey)) {
            const cached = this.cache.get(cacheKey);
            if (Date.now() - cached.timestamp < cached.ttl) {
                return cached.data;
            }
        }

        // Queue similar requests
        if (this.requestQueue.has(cacheKey)) {
            return this.requestQueue.get(cacheKey);
        }

        const requestPromise = PerformanceMonitor.measure(
            `api-${endpoint}`,
            async () => {
                try {
                    const response = await fetch(endpoint, {
                        ...options,
                        headers: {
                            'Content-Type': 'application/json',
                            ...options.headers
                        }
                    });

                    if (!response.ok) {
                        throw new Error(`API request failed: ${response.statusText}`);
                    }

                    const data = await response.json();

                    // Cache successful GET requests
                    if (options.method === 'GET') {
                        this.cache.set(cacheKey, {
                            data,
                            timestamp: Date.now(),
                            ttl: options.cacheTTL || 60000 // Default 1 minute TTL
                        });
                    }

                    return data;
                } finally {
                    this.requestQueue.delete(cacheKey);
                }
            }
        );

        this.requestQueue.set(cacheKey, requestPromise);
        return requestPromise;
    }

    static clearCache() {
        this.cache.clear();
    }
}

// DOM Updates Optimization
class DomManager {
    static pendingUpdates = new Map();
    static updateScheduled = false;

    static scheduleUpdate(elementId, updateFn) {
        this.pendingUpdates.set(elementId, updateFn);
        
        if (!this.updateScheduled) {
            this.updateScheduled = true;
            requestAnimationFrame(() => this.processUpdates());
        }
    }

    static processUpdates() {
        PerformanceMonitor.start('dom-batch-update');
        
        this.pendingUpdates.forEach((updateFn, elementId) => {
            const element = document.getElementById(elementId);
            if (element) {
                updateFn(element);
            }
        });
        
        this.pendingUpdates.clear();
        this.updateScheduled = false;
        
        PerformanceMonitor.end('dom-batch-update');
    }
}

// Resource Loading Optimization
class ResourceLoader {
    static loadedResources = new Set();
    static loadQueue = [];
    static loading = false;

    static async loadScript(src, options = {}) {
        if (this.loadedResources.has(src)) {
            return;
        }

        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = src;
            script.async = options.async ?? true;
            
            script.onload = () => {
                this.loadedResources.add(src);
                resolve();
            };
            
            script.onerror = () => {
                reject(new Error(`Failed to load script: ${src}`));
            };

            document.head.appendChild(script);
        });
    }

    static async loadStylesheet(href) {
        if (this.loadedResources.has(href)) {
            return;
        }

        return new Promise((resolve, reject) => {
            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = href;
            
            link.onload = () => {
                this.loadedResources.add(href);
                resolve();
            };
            
            link.onerror = () => {
                reject(new Error(`Failed to load stylesheet: ${href}`));
            };

            document.head.appendChild(link);
        });
    }
}

// Service Class Management with Performance Optimization
async function initializeServiceClassCarousel() {
    return PerformanceMonitor.measure('service-class-init', async () => {
        try {
            const services = await ApiManager.request('/api/service-classes', {
                cacheTTL: 3600000 // 1 hour cache
            });
            
            DomManager.scheduleUpdate('service-class-carousel', element => {
                element.innerHTML = createServiceClassHTML(services);
                setupCarouselInteraction(element);
            });
        } catch (error) {
            ErrorHandler.handle(error, 'service-class-init');
        }
    });
}

function setupCarouselInteraction(carousel) {
    let isDown = false;
    let startX;
    let scrollLeft;

    const handlers = {
        mousedown: (e) => {
            isDown = true;
            carousel.classList.add('active');
            startX = e.pageX - carousel.offsetLeft;
            scrollLeft = carousel.scrollLeft;
        },
        mouseleave: () => {
            isDown = false;
            carousel.classList.remove('active');
        },
        mouseup: () => {
            isDown = false;
            carousel.classList.remove('active');
        },
        mousemove: throttle((e) => {
            if (!isDown) return;
            e.preventDefault();
            const x = e.pageX - carousel.offsetLeft;
            const walk = (x - startX) * 2;
            carousel.scrollLeft = scrollLeft - walk;
        }, 16) // ~60fps
    };

    Object.entries(handlers).forEach(([event, handler]) => {
        EventManager.addListener(carousel, event, handler);
    });
}

// Location Autocomplete with Performance Optimization
async function initializeLocationAutocomplete() {
    return PerformanceMonitor.measure('location-autocomplete-init', async () => {
        try {
            await ResourceLoader.loadScript(
                'https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places'
            );

            const fields = ['pickup-location', 'dropoff-location'];
            fields.forEach(fieldId => {
                const input = document.getElementById(fieldId);
                if (!input) return;

                const autocomplete = new google.maps.places.Autocomplete(input, {
                    types: fieldId === 'pickup-location' ? ['airport'] : ['address'],
                    fields: ['place_id', 'geometry', 'name', 'formatted_address']
                });

                autocomplete.addListener('place_changed', debounce(() => {
                    const place = autocomplete.getPlace();
                    if (!place.geometry) {
                        input.value = '';
                        return;
                    }
                    updatePrice();
                }, 300));

                MemoryManager.track(`autocomplete-${fieldId}`, autocomplete);
            });
        } catch (error) {
            ErrorHandler.handle(error, 'location-autocomplete-init');
        }
    });
}

// Date and Time Picker Initialization with Performance Optimization
function initializeDateTimePickers() {
    return PerformanceMonitor.measure('datetime-picker-init', () => {
        try {
            const dateInput = document.getElementById('pickup-date');
            const timeInput = document.getElementById('pickup-time');

            if (dateInput) {
                // Set minimum date to today
                const today = new Date().toISOString().split('T')[0];
                dateInput.min = today;
                
                // Set maximum date to 6 months from now
                const maxDate = new Date();
                maxDate.setMonth(maxDate.getMonth() + 6);
                dateInput.max = maxDate.toISOString().split('T')[0];

                EventManager.addListener(dateInput, 'change', validateDateTime);
            }

            if (timeInput) {
                EventManager.addListener(timeInput, 'change', validateDateTime);
            }
        } catch (error) {
            ErrorHandler.handle(error, 'datetime-picker-init');
        }
    });
}

function validateDateTime() {
    return PerformanceMonitor.measure('datetime-validation', () => {
        const dateInput = document.getElementById('pickup-date');
        const timeInput = document.getElementById('pickup-time');
        
        if (!dateInput || !timeInput) return;

        const selectedDate = new Date(dateInput.value + 'T' + timeInput.value);
        const now = new Date();
        const minTime = new Date(now.getTime() + 2 * 60 * 60 * 1000); // 2 hours from now

        if (selectedDate < minTime) {
            showError('Pickup time must be at least 2 hours from now');
            timeInput.value = '';
            return false;
        }

        return true;
    });
}

// Additional Services Management with Performance Optimization
async function initializeAdditionalServices() {
    return PerformanceMonitor.measure('additional-services-init', async () => {
        try {
            const services = await ApiManager.request('/api/additional-services', {
                cacheTTL: 3600000 // 1 hour cache
            });

            DomManager.scheduleUpdate('additional-services', element => {
                element.innerHTML = createAdditionalServicesHTML(services);
                setupServiceListeners(element);
            });
        } catch (error) {
            ErrorHandler.handle(error, 'additional-services-init');
        }
    });
}

function setupServiceListeners(container) {
    const checkboxes = container.querySelectorAll('input[type="checkbox"]');
    checkboxes.forEach(checkbox => {
        EventManager.addListener(checkbox, 'change', () => {
            const service = {
                id: checkbox.id,
                price: parseFloat(checkbox.value),
                selected: checkbox.checked
            };

            if (checkbox.checked) {
                selectedServices.add(service);
            } else {
                selectedServices.delete(service);
            }

            updatePrice();
        });
    });
}

// Analytics Charts Initialization with Performance Optimization
function initializeAnalyticsCharts(analytics) {
    return PerformanceMonitor.measure('charts-init', () => {
        try {
            const charts = {
                bookings: createBookingTrendsChart(analytics.bookingTrends),
                services: createServiceDistributionChart(analytics.serviceDistribution),
                ratings: createRatingsTrendChart(analytics.ratingsTrend)
            };

            Object.entries(charts).forEach(([key, chart]) => {
                MemoryManager.track(`chart-${key}`, chart);
            });

            return charts;
        } catch (error) {
            ErrorHandler.handle(error, 'charts-init');
            return null;
        }
    });
}

// Responsive Design Handler with Performance Optimization
function handleResize() {
    return PerformanceMonitor.measure('resize-handler', () => {
        const width = window.innerWidth;
        const breakpoints = {
            sm: 576,
            md: 768,
            lg: 992,
            xl: 1200
        };

        // Update layout classes based on screen size
        document.body.classList.remove('size-sm', 'size-md', 'size-lg', 'size-xl');
        let currentBreakpoint = 'sm';
        
        Object.entries(breakpoints).forEach(([size, value]) => {
            if (width >= value) {
                currentBreakpoint = size;
            }
        });

        document.body.classList.add(`size-${currentBreakpoint}`);

        // Adjust carousel items visible
        const carousel = document.querySelector('.service-class-carousel');
        if (carousel) {
            const itemsVisible = {
                sm: 1,
                md: 2,
                lg: 3,
                xl: 4
            }[currentBreakpoint];

            carousel.style.setProperty('--items-visible', itemsVisible);
        }
    });
}

// Initialize page with performance monitoring
window.addEventListener('load', () => {
    PerformanceMonitor.measure('page-load', () => {
        console.debug('Page fully loaded');
        lazyLoadImages();
    });
});

// Initialize Performance Monitoring
document.addEventListener('DOMContentLoaded', async () => {
    PerformanceMonitor.start('page-load');
    
    try {
        // Load required resources
        await Promise.all([
            ResourceLoader.loadScript('https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places'),
            ResourceLoader.loadStylesheet('/css/airport-transfers.css')
        ]);

        // Initialize components with performance monitoring
        await PerformanceMonitor.measure(
            'initialization',
            async () => {
                await initializeComponents();
            }
        );

        // Set up event listeners
        setupEventListeners();

        // Initial data load
        await loadInitialData();

    } catch (error) {
        ErrorHandler.handle(error, 'initialization');
    } finally {
        PerformanceMonitor.end('page-load');
    }
});

// Component Initialization
async function initializeComponents() {
    await Promise.all([
        initializeLocationAutocomplete(),
        initializeServiceClassCarousel(),
        initializeAdditionalServices(),
        initializeDateTimePickers()
    ]);
}

// Event Listener Setup
function setupEventListeners() {
    const form = document.getElementById('transfer-booking-form');
    
    EventManager.addListener(form, 'submit', handleBookingSubmit);
    EventManager.addListener(window, 'resize', debounce(handleResize, 250));
    
    // Add input event listeners with debouncing
    const inputs = form.querySelectorAll('input, select');
    inputs.forEach(input => {
        EventManager.addListener(
            input,
            'input',
            debounce(handleInputChange, 300)
        );
    });
}

// Utility Functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function executedFunction(...args) {
        if (!inThrottle) {
            func(...args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Cleanup on page unload
window.addEventListener('unload', () => {
    EventManager.removeAllListeners();
    ApiManager.clearCache();
    MemoryManager.checkMemoryLeaks();
});

// DOM Elements
document.addEventListener('DOMContentLoaded', () => {
    initializeForm();
    renderVehicles();
    setupEventListeners();
    initializeFormValidation();
    initializeCarousel();
    initializeLocationAutocomplete();
});

function initializeForm() {
    // Set minimum date to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('pickup-date').min = today;

    // Initialize form validation
    const form = document.getElementById('transfer-booking-form');
    form.addEventListener('submit', handleBooking);
}

function renderVehicles() {
    const vehicleList = document.getElementById('vehicle-list');
    vehicleList.innerHTML = vehicles.map(vehicle => `
        <div class="col-md-6 mb-3">
            <div class="card vehicle-card" data-vehicle-id="${vehicle.id}">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h4 class="card-title">${vehicle.name}</h4>
                            <p class="card-text">${vehicle.description}</p>
                            <ul class="list-unstyled">
                                <li><i class="fas fa-users"></i> Up to ${vehicle.capacity} passengers</li>
                                <li><i class="fas fa-suitcase"></i> ${vehicle.luggage} pieces of luggage</li>
                            </ul>
                            <div class="vehicle-price">
                                From $${vehicle.basePrice}
                            </div>
                        </div>
                        <div class="vehicle-select">
                            <button class="btn btn-outline-primary select-vehicle" 
                                onclick="selectVehicle(${vehicle.id})">
                                Select
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

function setupEventListeners() {
    // Location change listener
    document.getElementById('pickup-location').addEventListener('change', updatePrice);
    
    // Additional services listeners
    ['meet-greet', 'child-seat', 'wifi'].forEach(service => {
        document.getElementById(service).addEventListener('change', (e) => {
            if (e.target.checked) {
                selectedServices.add(service);
            } else {
                selectedServices.delete(service);
            }
            updatePrice();
        });
    });

    // Real-time validation
    const form = document.getElementById('transfer-booking-form');
    const inputs = form.querySelectorAll('input[required], select[required]');
    inputs.forEach(input => {
        input.addEventListener('input', () => {
            validateInput(input);
        });
    });
}

function selectVehicle(vehicleId) {
    // Remove previous selection
    document.querySelectorAll('.vehicle-card').forEach(card => {
        card.classList.remove('selected');
    });

    // Add new selection
    const vehicleCard = document.querySelector(`.vehicle-card[data-vehicle-id="${vehicleId}"]`);
    if (vehicleCard) {
        vehicleCard.classList.add('selected');
        selectedVehicle = vehicles.find(v => v.id === vehicleId);
        updatePrice();
    }
}

function calculateDistance(airport, dropoffLocation) {
    // In a real application, this would use a mapping API
    // For now, we'll use base airport distances
    return airports[airport]?.cityCenter.distance || 30;
}

function updatePrice() {
    if (!selectedVehicle) return;

    const airport = document.getElementById('pickup-location').value;
    const dropoff = document.getElementById('dropoff-location').value;
    
    // Base price calculation
    let total = selectedVehicle.basePrice;
    
    // Distance price
    if (airport && dropoff) {
        const distance = calculateDistance(airport, dropoff);
        const ratePerKm = airports[airport]?.cityCenter.baseRate || 1.5;
        total += distance * ratePerKm;
    }

    // Additional services
    const servicesPrices = {
        'meet-greet': 50,
        'child-seat': 10,
        'wifi': 15
    };

    selectedServices.forEach(service => {
        total += servicesPrices[service];
    });

    // Update price breakdown
    const breakdown = document.getElementById('price-breakdown');
    breakdown.innerHTML = `
        <div class="d-flex justify-content-between mb-2">
            <span>Base Rate:</span>
            <span>$${selectedVehicle.basePrice}</span>
        </div>
        ${airport && dropoff ? `
            <div class="d-flex justify-content-between mb-2">
                <span>Distance Rate:</span>
                <span>$${(calculateDistance(airport, dropoff) * (airports[airport]?.cityCenter.baseRate || 1.5)).toFixed(2)}</span>
            </div>
        ` : ''}
        ${Array.from(selectedServices).map(service => `
            <div class="d-flex justify-content-between mb-2">
                <span>${service.replace('-', ' ').toUpperCase()}:</span>
                <span>$${servicesPrices[service]}</span>
            </div>
        `).join('')}
    `;

    // Update total price
    document.getElementById('total-price').textContent = `$${total.toFixed(2)}`;
    currentPrice = total;
}

function validateInput(input) {
    if (input.checkValidity()) {
        input.classList.remove('is-invalid');
        input.classList.add('is-valid');
    } else {
        input.classList.remove('is-valid');
        input.classList.add('is-invalid');
    }
}

function validateForm() {
    const form = document.getElementById('transfer-booking-form');
    const inputs = form.querySelectorAll('input[required], select[required]');
    let isValid = true;

    inputs.forEach(input => {
        if (!input.checkValidity()) {
            isValid = false;
            input.classList.add('is-invalid');
        }
    });

    if (!selectedVehicle) {
        alert('Please select a vehicle');
        isValid = false;
    }

    return isValid;
}

async function handleBooking(event) {
    event.preventDefault();

    if (!validateForm()) {
        return;
    }

    try {
        // Prepare booking data
        const bookingData = {
            pickup: {
                location: document.getElementById('pickup-location').value,
                date: document.getElementById('pickup-date').value,
                time: document.getElementById('pickup-time').value,
                flightNumber: document.getElementById('flight-number').value
            },
            dropoff: {
                location: document.getElementById('dropoff-location').value,
                instructions: document.getElementById('special-instructions').value
            },
            vehicle: selectedVehicle,
            services: Array.from(selectedServices),
            customer: {
                name: document.getElementById('customer-name').value,
                email: document.getElementById('customer-email').value,
                phone: document.getElementById('customer-phone').value
            },
            totalPrice: currentPrice
        };

        // Create payment intent
        const response = await fetch('/api/create-transfer-payment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(bookingData)
        });

        if (!response.ok) {
            throw new Error('Payment failed');
        }

        const result = await response.json();
        
        if (result.error) {
            throw new Error(result.error);
        }

        // Redirect to success page
        window.location.href = '/booking-confirmation.html';

    } catch (error) {
        console.error('Booking error:', error);
        alert('Failed to process booking. Please try again.');
    }
}

// Tab Switching
function tabSwitching() {
    const oneWayTab = document.getElementById('oneWayTab');
    const hourlyTab = document.getElementById('hourlyTab');
    const oneWayForm = document.getElementById('oneWayForm');
    const hourlyForm = document.getElementById('hourlyForm');

    oneWayTab.addEventListener('click', () => {
        oneWayTab.classList.add('active');
        hourlyTab.classList.remove('active');
        oneWayForm.classList.add('active');
        hourlyForm.classList.remove('active');
        hourlyForm.hidden = true;
        oneWayForm.hidden = false;
    });

    hourlyTab.addEventListener('click', () => {
        hourlyTab.classList.add('active');
        oneWayTab.classList.remove('active');
        hourlyForm.classList.add('active');
        oneWayForm.classList.remove('active');
        oneWayForm.hidden = true;
        hourlyForm.hidden = false;
    });
}

// Form Validation
function initializeFormValidation() {
    const form = document.getElementById('transfer-booking-form');
    const inputs = form.querySelectorAll('input[required]');

    inputs.forEach(input => {
        input.addEventListener('blur', () => validateInput(input));
        input.addEventListener('input', () => validateInput(input));
    });

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        if (validateForm()) {
            handleBooking();
        }
    });
}

function validateInput(input) {
    const isValid = input.checkValidity();
    input.classList.toggle('is-invalid', !isValid);
    input.classList.toggle('is-valid', isValid);
    return isValid;
}

function validateForm() {
    const form = document.getElementById('transfer-booking-form');
    const inputs = form.querySelectorAll('input[required]');
    let isValid = true;

    inputs.forEach(input => {
        if (!validateInput(input)) {
            isValid = false;
        }
    });

    return isValid;
}

// Service Class Carousel
function initializeCarousel() {
    const carousel = document.querySelector('.service-class-carousel');
    let isDown = false;
    let startX;
    let scrollLeft;

    carousel.addEventListener('mousedown', (e) => {
        isDown = true;
        carousel.classList.add('active');
        startX = e.pageX - carousel.offsetLeft;
        scrollLeft = carousel.scrollLeft;
    });

    carousel.addEventListener('mouseleave', () => {
        isDown = false;
        carousel.classList.remove('active');
    });

    carousel.addEventListener('mouseup', () => {
        isDown = false;
        carousel.classList.remove('active');
    });

    carousel.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - carousel.offsetLeft;
        const walk = (x - startX) * 2;
        carousel.scrollLeft = scrollLeft - walk;
    });
}

// Booking Handler
async function handleBooking() {
    const form = document.getElementById('transfer-booking-form');
    const formData = new FormData(form);
    
    try {
        const response = await fetch('/api/book-transfer', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(Object.fromEntries(formData)),
        });

        if (!response.ok) {
            throw new Error('Booking failed');
        }

        const result = await response.json();
        
        if (result.success) {
            window.location.href = `/booking-confirmation?id=${result.bookingId}`;
        } else {
            showError(result.message || 'Booking failed. Please try again.');
        }
    } catch (error) {
        console.error('Booking error:', error);
        showError('An error occurred while processing your booking. Please try again.');
    }
}

// Error Handler
function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'alert alert-danger mt-3';
    errorDiv.textContent = message;
    
    const form = document.getElementById('transfer-booking-form');
    form.insertAdjacentElement('beforebegin', errorDiv);
    
    setTimeout(() => {
        errorDiv.remove();
    }, 5000);
}

// Autocomplete for Locations
function initializeLocationAutocomplete() {
    const pickupInput = document.getElementById('pickup-location');
    const dropoffInput = document.getElementById('dropoff-location');

    // Initialize Google Places Autocomplete
    const pickupAutocomplete = new google.maps.places.Autocomplete(pickupInput, {
        types: ['airport', 'establishment'],
        fields: ['place_id', 'geometry', 'name']
    });

    const dropoffAutocomplete = new google.maps.places.Autocomplete(dropoffInput, {
        types: ['address', 'establishment'],
        fields: ['place_id', 'geometry', 'name']
    });

    // Handle place selection
    pickupAutocomplete.addListener('place_changed', () => {
        const place = pickupAutocomplete.getPlace();
        if (!place.geometry) {
            pickupInput.value = '';
            return;
        }
        updatePrice();
    });

    dropoffAutocomplete.addListener('place_changed', () => {
        const place = dropoffAutocomplete.getPlace();
        if (!place.geometry) {
            dropoffInput.value = '';
            return;
        }
        updatePrice();
    });
}

// Price Calculator
function updatePrice() {
    // Implement price calculation based on:
    // - Distance between pickup and dropoff
    // - Selected vehicle class
    // - Additional services
    // This is a placeholder for the actual implementation
    console.log('Price update triggered');
}

// Flight tracking simulation
function trackFlight(flightNumber) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve({
                status: 'On Time',
                estimatedArrival: '14:30',
                terminal: 'Terminal 5'
            });
        }, 1000);
    });
}

// Real-time driver tracking simulation
function initializeDriverTracking(bookingId) {
    return {
        driverName: 'John Smith',
        vehicleNumber: 'LX21 ABC',
        estimatedArrival: '10 minutes',
        currentLocation: {
            lat: 51.4700,
            lng: -0.4543
        }
    };
}

// Weather monitoring simulation
function checkWeatherConditions(location) {
    return {
        temperature: 18,
        condition: 'Clear',
        traffic: 'Normal'
    };
}

// Price Calculator with Distance Matrix
async function updatePrice() {
    const pickupInput = document.getElementById('pickup-location');
    const dropoffInput = document.getElementById('dropoff-location');
    const serviceClass = document.querySelector('input[name="service-class"]:checked').value;
    const priceDisplay = document.getElementById('price-display');
    
    if (!pickupInput.value || !dropoffInput.value) return;

    try {
        const service = new google.maps.DistanceMatrixService();
        const response = await service.getDistanceMatrix({
            origins: [pickupInput.value],
            destinations: [dropoffInput.value],
            travelMode: google.maps.TravelMode.DRIVING,
            unitSystem: google.maps.UnitSystem.METRIC
        });

        if (response.rows[0].elements[0].status === 'OK') {
            const distance = response.rows[0].elements[0].distance.value / 1000; // Convert to km
            const duration = response.rows[0].elements[0].duration.value / 60; // Convert to minutes
            
            const baseRates = {
                'business': 2.5,
                'first-class': 3.5,
                'business-van': 4.0
            };

            const basePrice = distance * baseRates[serviceClass];
            const surcharges = calculateSurcharges(duration);
            const totalPrice = basePrice + surcharges;

            updatePriceDisplay(totalPrice, surcharges, {
                distance,
                duration
            });
        }
    } catch (error) {
        console.error('Price calculation error:', error);
        priceDisplay.textContent = 'Price calculation failed';
    }
}

function calculateSurcharges(duration) {
    let surcharge = 0;
    const hour = new Date().getHours();
    
    // Night surcharge (22:00 - 06:00)
    if (hour >= 22 || hour < 6) {
        surcharge += 15;
    }
    
    // Peak hours surcharge (07:00 - 09:00 and 16:00 - 19:00)
    if ((hour >= 7 && hour < 9) || (hour >= 16 && hour < 19)) {
        surcharge += 10;
    }
    
    // Long duration surcharge
    if (duration > 60) {
        surcharge += 20;
    }
    
    return surcharge;
}

function updatePriceDisplay(totalPrice, surcharges, tripDetails) {
    const priceDisplay = document.getElementById('price-display');
    const breakdown = document.getElementById('price-breakdown');
    
    priceDisplay.textContent = `€${totalPrice.toFixed(2)}`;
    
    breakdown.innerHTML = `
        <div class="d-flex justify-content-between mb-2">
            <span>Base Rate:</span>
            <span>€${tripDetails.distance * 2.5}</span>
        </div>
        <div class="d-flex justify-content-between mb-2">
            <span>Distance Rate:</span>
            <span>€${tripDetails.distance * 2.5}</span>
        </div>
        <div class="d-flex justify-content-between mb-2">
            <span>Surcharges:</span>
            <span>€${surcharges}</span>
        </div>
        <div class="d-flex justify-content-between mb-2">
            <span>Total:</span>
            <span>€${totalPrice.toFixed(2)}</span>
        </div>
    `;
}

// Real-time Flight Tracking
async function trackFlight(flightNumber) {
    const trackingDisplay = document.getElementById('flight-tracking');
    
    try {
        // Simulate API call to flight tracking service
        const response = await fetch(`/api/flight-status/${flightNumber}`);
        const flightData = await response.json();
        
        if (flightData.status === 'success') {
            updateFlightInfo(flightData);
            adjustPickupTime(flightData);
        } else {
            trackingDisplay.innerHTML = 'Flight information not available';
        }
    } catch (error) {
        console.error('Flight tracking error:', error);
        trackingDisplay.innerHTML = 'Flight tracking temporarily unavailable';
    }
}

function updateFlightInfo(flightData) {
    const trackingDisplay = document.getElementById('flight-tracking');
    trackingDisplay.innerHTML = `
        <div class="flight-info">
            <p>Flight: ${flightData.flightNumber}</p>
            <p>Status: ${flightData.status}</p>
            <p>Scheduled Arrival: ${flightData.scheduledArrival}</p>
            <p>Estimated Arrival: ${flightData.estimatedArrival}</p>
        </div>
    `;
}

function adjustPickupTime(flightData) {
    const pickupTime = document.getElementById('pickup-time');
    if (flightData.estimatedArrival) {
        const arrivalTime = new Date(flightData.estimatedArrival);
        // Add 30 minutes for baggage claim and customs
        arrivalTime.setMinutes(arrivalTime.getMinutes() + 30);
        pickupTime.value = arrivalTime.toISOString().substr(11, 5);
    }
}

// Additional Services Handler
function initializeAdditionalServices() {
    const servicesContainer = document.getElementById('additional-services');
    const services = [
        { id: 'meet-greet', name: 'Meet & Greet', price: 25 },
        { id: 'child-seat', name: 'Child Seat', price: 10 },
        { id: 'extra-stop', name: 'Extra Stop', price: 15 },
        { id: 'wait-return', name: 'Wait & Return', price: 30 }
    ];

    services.forEach(service => {
        const serviceElement = createServiceElement(service);
        servicesContainer.appendChild(serviceElement);
    });
}

function createServiceElement(service) {
    const div = document.createElement('div');
    div.className = 'service-option';
    div.innerHTML = `
        <input type="checkbox" id="${service.id}" name="additional-services" value="${service.price}">
        <label for="${service.id}">
            ${service.name} (+€${service.price})
            <small class="service-description">${getServiceDescription(service.id)}</small>
        </label>
    `;
    
    div.querySelector('input').addEventListener('change', () => {
        updateTotalPrice();
    });
    
    return div;
}

function getServiceDescription(serviceId) {
    const descriptions = {
        'meet-greet': 'Driver will meet you at arrivals with a name sign',
        'child-seat': 'Certified child seat appropriate for age',
        'extra-stop': 'Additional stop during your journey',
        'wait-return': 'Driver waits and returns you to original location'
    };
    return descriptions[serviceId] || '';
}

// Booking History
async function loadBookingHistory() {
    try {
        const response = await fetch('/api/booking-history');
        const bookings = await response.json();
        
        const historyContainer = document.getElementById('booking-history');
        historyContainer.innerHTML = '';
        
        bookings.forEach(booking => {
            const bookingElement = createBookingElement(booking);
            historyContainer.appendChild(bookingElement);
        });
    } catch (error) {
        console.error('Error loading booking history:', error);
    }
}

function createBookingElement(booking) {
    const div = document.createElement('div');
    div.className = 'booking-item';
    div.innerHTML = `
        <div class="booking-header">
            <span class="booking-date">${new Date(booking.date).toLocaleDateString()}</span>
            <span class="booking-status ${booking.status.toLowerCase()}">${booking.status}</span>
        </div>
        <div class="booking-details">
            <p>From: ${booking.pickup}</p>
            <p>To: ${booking.dropoff}</p>
            <p>Vehicle: ${booking.vehicleClass}</p>
            <p>Price: €${booking.price}</p>
        </div>
        <div class="booking-actions">
            <button onclick="rebookTransfer('${booking.id}')">Book Again</button>
            ${booking.status === 'UPCOMING' ? 
                `<button onclick="cancelBooking('${booking.id}')">Cancel</button>` : ''}
        </div>
    `;
    return div;
}

async function rebookTransfer(bookingId) {
    try {
        const response = await fetch(`/api/booking/${bookingId}`);
        const booking = await response.json();
        
        // Pre-fill booking form with previous booking details
        document.getElementById('pickup-location').value = booking.pickup;
        document.getElementById('dropoff-location').value = booking.dropoff;
        document.getElementById('pickup-date').value = booking.date;
        document.getElementById('pickup-time').value = booking.time;
        
        // Select vehicle class
        document.querySelector(`input[name="service-class"][value="${booking.vehicleClass}"]`).checked = true;
        
        // Scroll to booking form
        document.getElementById('booking-widget').scrollIntoView({ behavior: 'smooth' });
    } catch (error) {
        console.error('Error rebooking transfer:', error);
        showError('Failed to load booking details');
    }
}

async function cancelBooking(bookingId) {
    if (!confirm('Are you sure you want to cancel this booking?')) return;
    
    try {
        const response = await fetch(`/api/booking/${bookingId}/cancel`, {
            method: 'POST'
        });
        
        if (response.ok) {
            showSuccess('Booking cancelled successfully');
            loadBookingHistory();
        } else {
            throw new Error('Failed to cancel booking');
        }
    } catch (error) {
        console.error('Error cancelling booking:', error);
        showError('Failed to cancel booking');
    }
}

// Success message handler
function showSuccess(message) {
    const successDiv = document.createElement('div');
    successDiv.className = 'alert alert-success mt-3';
    successDiv.textContent = message;
    
    const form = document.getElementById('transfer-booking-form');
    form.insertAdjacentElement('beforebegin', successDiv);
    
    setTimeout(() => {
        successDiv.remove();
    }, 5000);
}

// Enhanced Price Calculator with Advanced Features
async function updatePrice() {
    const pickupInput = document.getElementById('pickup-location');
    const dropoffInput = document.getElementById('dropoff-location');
    const serviceClass = document.querySelector('input[name="service-class"]:checked').value;
    const priceDisplay = document.getElementById('price-display');
    const passengerCount = parseInt(document.getElementById('passenger-count').value) || 1;
    const luggageCount = parseInt(document.getElementById('luggage-count').value) || 0;
    
    if (!pickupInput.value || !dropoffInput.value) return;

    try {
        const service = new google.maps.DistanceMatrixService();
        const response = await service.getDistanceMatrix({
            origins: [pickupInput.value],
            destinations: [dropoffInput.value],
            travelMode: google.maps.TravelMode.DRIVING,
            unitSystem: google.maps.UnitSystem.METRIC,
            drivingOptions: {
                departureTime: new Date(document.getElementById('pickup-date').value + 'T' + document.getElementById('pickup-time').value),
                trafficModel: google.maps.TrafficModel.BEST_GUESS
            }
        });

        if (response.rows[0].elements[0].status === 'OK') {
            const distance = response.rows[0].elements[0].distance.value / 1000; // Convert to km
            const duration = response.rows[0].elements[0].duration.value / 60; // Convert to minutes
            
            const baseRates = {
                'business': { base: 2.5, min: 35 },
                'first-class': { base: 3.5, min: 50 },
                'business-van': { base: 4.0, min: 60 }
            };

            let basePrice = Math.max(
                distance * baseRates[serviceClass].base,
                baseRates[serviceClass].min
            );

            // Apply dynamic pricing factors
            const pricingFactors = calculatePricingFactors({
                distance,
                duration: duration,
                passengers: passengerCount,
                luggage: luggageCount,
                serviceClass,
                pickupTime: document.getElementById('pickup-time').value,
                pickupDate: document.getElementById('pickup-date').value
            });

            const totalPrice = basePrice * pricingFactors.multiplier + pricingFactors.surcharges;

            updatePriceDisplay(totalPrice, pricingFactors, {
                distance,
                duration
            });
        }
    } catch (error) {
        console.error('Price calculation error:', error);
        showError('Price calculation failed. Please try again.');
    }
}

function calculatePricingFactors({ distance, duration, passengers, luggage, serviceClass, pickupTime, pickupDate }) {
    let multiplier = 1.0;
    let surcharges = 0;
    const factors = {
        details: []
    };

    // Time-based factors
    const pickupDateTime = new Date(pickupDate + 'T' + pickupTime);
    const hour = pickupDateTime.getHours();
    const day = pickupDateTime.getDay();

    // Night hours (22:00 - 06:00)
    if (hour >= 22 || hour < 6) {
        multiplier *= 1.25;
        factors.details.push({ type: 'Night Service', effect: '+25%' });
    }

    // Peak hours
    if ((hour >= 7 && hour < 9) || (hour >= 16 && hour < 19)) {
        multiplier *= 1.15;
        factors.details.push({ type: 'Peak Hours', effect: '+15%' });
    }

    // Weekend rates
    if (day === 0 || day === 6) {
        multiplier *= 1.1;
        factors.details.push({ type: 'Weekend Rate', effect: '+10%' });
    }

    // Holiday season (simplified example)
    const month = pickupDateTime.getMonth();
    if (month === 11 || month === 6 || month === 7) { // December, July, August
        multiplier *= 1.2;
        factors.details.push({ type: 'Holiday Season', effect: '+20%' });
    }

    // Distance factors
    if (distance > 100) {
        multiplier *= 0.9; // Long distance discount
        factors.details.push({ type: 'Long Distance Discount', effect: '-10%' });
    }

    // Passenger and luggage surcharges
    if (passengers > 4) {
        surcharges += (passengers - 4) * 10;
        factors.details.push({ type: 'Extra Passengers', effect: `+€${(passengers - 4) * 10}` });
    }

    if (luggage > passengers) {
        surcharges += (luggage - passengers) * 5;
        factors.details.push({ type: 'Extra Luggage', effect: `+€${(luggage - passengers) * 5}` });
    }

    // Duration factors
    if (duration > 60) {
        surcharges += Math.floor(duration / 60) * 15;
        factors.details.push({ type: 'Extended Duration', effect: `+€${Math.floor(duration / 60) * 15}` });
    }

    return {
        multiplier,
        surcharges,
        factors: factors.details
    };
}

function updatePriceDisplay(totalPrice, pricingFactors, tripDetails) {
    const priceDisplay = document.getElementById('price-display');
    const priceBreakdown = document.getElementById('price-breakdown');
    
    // Update main price display
    priceDisplay.textContent = `€${totalPrice.toFixed(2)}`;
    
    // Create detailed breakdown
    const breakdownHTML = `
        <div class="price-breakdown-details">
            <h4>Trip Details</h4>
            <p>Distance: ${tripDetails.distance.toFixed(1)} km</p>
            <p>Estimated Duration: ${Math.ceil(tripDetails.duration)} min</p>
            <p>Base Price: €${tripDetails.basePrice.toFixed(2)}</p>
            
            <h4>Price Factors</h4>
            <ul>
                ${pricingFactors.factors.map(factor => `
                    <li>
                        <span>${factor.type}</span>
                        <span class="factor-effect">${factor.effect}</span>
                    </li>
                `).join('')}
            </ul>
            
            <div class="total-price">
                <span>Final Price:</span>
                <span class="price">€${totalPrice.toFixed(2)}</span>
            </div>
        </div>
    `;
    
    priceBreakdown.innerHTML = breakdownHTML;
}

// Enhanced Flight Tracking with Proactive Updates
let flightTrackingInterval;

async function trackFlight(flightNumber) {
    const trackingDisplay = document.getElementById('flight-tracking');
    clearInterval(flightTrackingInterval);
    
    const updateFlightStatus = async () => {
        try {
            // Simulate API call to flight tracking service
            const response = await fetch(`/api/flight-status/${flightNumber}`);
            const flightData = await response.json();
            
            if (flightData.status === 'success') {
                updateFlightInfo(flightData);
                adjustPickupTime(flightData);
                
                // Determine update frequency based on flight status
                const updateInterval = getUpdateInterval(flightData);
                if (flightTrackingInterval) clearInterval(flightTrackingInterval);
                flightTrackingInterval = setInterval(() => updateFlightStatus(), updateInterval);
                
                // Show notifications for significant changes
                checkFlightChanges(flightData);
            } else {
                trackingDisplay.innerHTML = createErrorDisplay('Flight information not available');
            }
        } catch (error) {
            console.error('Flight tracking error:', error);
            trackingDisplay.innerHTML = createErrorDisplay('Flight tracking temporarily unavailable');
        }
    };
    
    await updateFlightStatus();
}

function getUpdateInterval(flightData) {
    const timeToArrival = new Date(flightData.estimatedArrival) - new Date();
    
    if (timeToArrival <= 30 * 60 * 1000) { // Less than 30 minutes
        return 2 * 60 * 1000; // Update every 2 minutes
    } else if (timeToArrival <= 2 * 60 * 60 * 1000) { // Less than 2 hours
        return 5 * 60 * 1000; // Update every 5 minutes
    } else {
        return 15 * 60 * 1000; // Update every 15 minutes
    }
}

function updateFlightInfo(flightData) {
    const trackingDisplay = document.getElementById('flight-tracking');
    const status = getFlightStatus(flightData);
    
    trackingDisplay.innerHTML = `
        <div class="flight-info ${status.className}">
            <div class="flight-header">
                <h3>Flight ${flightData.flightNumber}</h3>
                <span class="status-badge ${status.className}">${status.label}</span>
            </div>
            
            <div class="flight-times">
                <div class="scheduled-time">
                    <span class="label">Scheduled Arrival:</span>
                    <span class="time">${formatDateTime(flightData.scheduledArrival)}</span>
                </div>
                <div class="estimated-time">
                    <span class="label">Estimated Arrival:</span>
                    <span class="time">${formatDateTime(flightData.estimatedArrival)}</span>
                </div>
            </div>
            
            <div class="flight-details">
                <p>Terminal: ${flightData.terminal || 'TBA'}</p>
                <p>Gate: ${flightData.gate || 'TBA'}</p>
                ${flightData.delay ? `<p class="delay-info">Delay: ${formatDelay(flightData.delay)}</p>` : ''}
            </div>
            
            <div class="pickup-adjustment">
                <p>Recommended pickup time: ${formatTime(calculatePickupTime(flightData))}</p>
                <button onclick="applyRecommendedPickupTime('${flightData.id}')" class="btn btn-primary">
                    Apply Recommended Time
                </button>
            </div>
        </div>
    `;
}

function getFlightStatus(flightData) {
    const status = flightData.status.toLowerCase();
    const statusMap = {
        'on-time': { label: 'On Time', className: 'status-on-time' },
        'delayed': { label: 'Delayed', className: 'status-delayed' },
        'boarding': { label: 'Boarding', className: 'status-boarding' },
        'departed': { label: 'Departed', className: 'status-departed' },
        'landed': { label: 'Landed', className: 'status-landed' },
        'cancelled': { label: 'Cancelled', className: 'status-cancelled' }
    };
    
    return statusMap[status] || { label: 'Unknown', className: 'status-unknown' };
}

function calculatePickupTime(flightData) {
    const arrivalTime = new Date(flightData.estimatedArrival);
    const bufferTime = getBufferTime(flightData);
    arrivalTime.setMinutes(arrivalTime.getMinutes() + bufferTime);
    return arrivalTime;
}

function getBufferTime(flightData) {
    let buffer = 30; // Base buffer time
    
    // Add extra time for international flights
    if (flightData.isInternational) buffer += 15;
    
    // Add extra time during peak hours
    const hour = new Date(flightData.estimatedArrival).getHours();
    if ((hour >= 7 && hour < 9) || (hour >= 16 && hour < 19)) buffer += 10;
    
    // Add extra time for terminal distance
    if (flightData.terminal === 'T5') buffer += 10;
    
    return buffer;
}

// Enhanced Booking History with Analytics
async function loadBookingHistory() {
    try {
        const [bookingsResponse, analyticsResponse] = await Promise.all([
            fetch('/api/booking-history'),
            fetch('/api/booking-analytics')
        ]);
        
        const bookings = await bookingsResponse.json();
        const analytics = await analyticsResponse.json();
        
        updateBookingHistory(bookings);
        updateBookingAnalytics(analytics);
    } catch (error) {
        console.error('Error loading booking history:', error);
        showError('Failed to load booking history');
    }
}

function updateBookingHistory(bookings) {
    const historyContainer = document.getElementById('booking-history');
    historyContainer.innerHTML = '';
    
    const groupedBookings = groupBookingsByMonth(bookings);
    
    Object.entries(groupedBookings).forEach(([month, monthBookings]) => {
        const monthSection = createMonthSection(month, monthBookings);
        historyContainer.appendChild(monthSection);
    });
}

function groupBookingsByMonth(bookings) {
    return bookings.reduce((groups, booking) => {
        const date = new Date(booking.date);
        const month = date.toLocaleString('default', { month: 'long', year: 'numeric' });
        
        if (!groups[month]) {
            groups[month] = [];
        }
        groups[month].push(booking);
        return groups;
    }, {});
}

function createMonthSection(month, bookings) {
    const section = document.createElement('div');
    section.className = 'booking-month-section';
    
    const monthHeader = document.createElement('h3');
    monthHeader.className = 'month-header';
    monthHeader.textContent = month;
    
    const bookingsList = document.createElement('div');
    bookingsList.className = 'bookings-list';
    
    bookings.forEach(booking => {
        const bookingElement = createEnhancedBookingElement(booking);
        bookingsList.appendChild(bookingElement);
    });
    
    section.appendChild(monthHeader);
    section.appendChild(bookingsList);
    return section;
}

function createEnhancedBookingElement(booking) {
    const div = document.createElement('div');
    div.className = `booking-item ${booking.status.toLowerCase()}`;
    
    const bookingDate = new Date(booking.date);
    const isUpcoming = bookingDate > new Date();
    const isPast = bookingDate < new Date();
    
    div.innerHTML = `
        <div class="booking-header">
            <div class="booking-date-time">
                <span class="booking-date">${bookingDate.toLocaleDateString('default', { weekday: 'short', day: 'numeric', month: 'short' })}</span>
                <span class="booking-time">${bookingDate.toLocaleTimeString('default', { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
            <span class="booking-status ${booking.status.toLowerCase()}">${booking.status}</span>
        </div>
        
        <div class="booking-details">
            <div class="route-info">
                <div class="pickup">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>${booking.pickup}</span>
                </div>
                <div class="route-arrow">
                    <i class="fas fa-arrow-right"></i>
                </div>
                <div class="dropoff">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>${booking.dropoff}</span>
                </div>
            </div>
            
            <div class="service-info">
                <div class="vehicle">
                    <i class="fas fa-car"></i>
                    <span>${booking.vehicleClass}</span>
                </div>
                <div class="price">
                    <i class="fas fa-tag"></i>
                    <span>€${booking.price}</span>
                </div>
            </div>
            
            ${booking.flightNumber ? `
                <div class="flight-info">
                    <i class="fas fa-plane"></i>
                    <span>Flight: ${booking.flightNumber}</span>
                </div>
            ` : ''}
            
            ${booking.additionalServices?.length > 0 ? `
                <div class="additional-services">
                    <i class="fas fa-plus-circle"></i>
                    <span>${booking.additionalServices.join(', ')}</span>
                </div>
            ` : ''}
        </div>
        
        <div class="booking-actions">
            ${isUpcoming ? `
                <button onclick="editBooking('${booking.id}')" class="btn btn-outline-primary">
                    <i class="fas fa-edit"></i> Edit
                </button>
                <button onclick="cancelBooking('${booking.id}')" class="btn btn-outline-danger">
                    <i class="fas fa-times"></i> Cancel
                </button>
            ` : ''}
            ${isPast ? `
                <button onclick="rebookTransfer('${booking.id}')" class="btn btn-outline-success">
                    <i class="fas fa-redo"></i> Book Again
                </button>
                <button onclick="leaveReview('${booking.id}')" class="btn btn-outline-secondary">
                    <i class="fas fa-star"></i> Review
                </button>
            ` : ''}
        </div>
    `;
    
    return div;
}

function updateBookingAnalytics(analytics) {
    const analyticsContainer = document.getElementById('booking-analytics');
    
    analyticsContainer.innerHTML = `
        <div class="analytics-summary">
            <div class="analytics-card">
                <h4>Total Bookings</h4>
                <p class="number">${analytics.totalBookings}</p>
                <p class="trend ${analytics.bookingTrend > 0 ? 'positive' : 'negative'}">
                    <i class="fas fa-arrow-${analytics.bookingTrend > 0 ? 'up' : 'down'}"></i>
                    ${Math.abs(analytics.bookingTrend)}% from last month
                </p>
            </div>
            
            <div class="analytics-card">
                <h4>Average Rating</h4>
                <p class="rating">
                    ${createStarRating(analytics.averageRating)}
                    <span class="rating-number">${analytics.averageRating.toFixed(1)}</span>
                </p>
                <p>Based on ${analytics.totalReviews} reviews</p>
            </div>
            
            <div class="analytics-card">
                <h4>Most Used Service</h4>
                <p class="service">${analytics.mostUsedService}</p>
                <p>${analytics.serviceUsagePercentage}% of all bookings</p>
            </div>
        </div>
        
        <div class="analytics-charts">
            <canvas id="bookingTrendsChart"></canvas>
            <canvas id="serviceDistributionChart"></canvas>
        </div>
    `;
    
    initializeAnalyticsCharts(analytics);
}
