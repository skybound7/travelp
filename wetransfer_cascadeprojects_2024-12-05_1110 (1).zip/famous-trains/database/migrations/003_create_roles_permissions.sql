-- Roles table
CREATE TABLE roles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Permissions table
CREATE TABLE permissions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    category VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Role permissions mapping
CREATE TABLE role_permissions (
    role_id INT NOT NULL,
    permission_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (role_id, permission_id),
    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
    FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
);

-- User roles mapping
CREATE TABLE user_roles (
    user_id INT NOT NULL,
    role_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, role_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE
);

-- Insert default roles
INSERT INTO roles (name, description) VALUES
('admin', 'Full system access with all privileges'),
('staff', 'Regular staff members with standard access'),
('senior_staff', 'Senior staff members with elevated privileges'),
('vendor', 'External service providers and vendors'),
('visitor', 'Temporary visitors with limited access');

-- Insert default permissions
INSERT INTO permissions (name, description, category) VALUES
-- Booking Management
('booking.view', 'View booking details', 'booking'),
('booking.create', 'Create new bookings', 'booking'),
('booking.edit', 'Edit existing bookings', 'booking'),
('booking.delete', 'Delete bookings', 'booking'),
('booking.approve', 'Approve booking requests', 'booking'),

-- User Management
('user.view', 'View user profiles', 'user'),
('user.create', 'Create new users', 'user'),
('user.edit', 'Edit user profiles', 'user'),
('user.delete', 'Delete users', 'user'),
('user.manage_roles', 'Manage user roles', 'user'),

-- Report Management
('report.view', 'View reports', 'report'),
('report.create', 'Create new reports', 'report'),
('report.export', 'Export reports', 'report'),
('report.analytics', 'Access analytics dashboard', 'report'),

-- Vendor Management
('vendor.profile', 'Manage vendor profile', 'vendor'),
('vendor.services', 'Manage vendor services', 'vendor'),
('vendor.pricing', 'Manage service pricing', 'vendor'),
('vendor.schedule', 'Manage availability schedule', 'vendor'),

-- System Settings
('settings.view', 'View system settings', 'settings'),
('settings.edit', 'Edit system settings', 'settings'),
('settings.security', 'Manage security settings', 'settings');

-- Assign permissions to roles
-- Admin role (all permissions)
INSERT INTO role_permissions (role_id, permission_id)
SELECT 
    (SELECT id FROM roles WHERE name = 'admin'),
    id
FROM permissions;

-- Staff role
INSERT INTO role_permissions (role_id, permission_id)
SELECT 
    (SELECT id FROM roles WHERE name = 'staff'),
    id
FROM permissions 
WHERE name IN (
    'booking.view',
    'booking.create',
    'booking.edit',
    'report.view',
    'user.view'
);

-- Senior Staff role
INSERT INTO role_permissions (role_id, permission_id)
SELECT 
    (SELECT id FROM roles WHERE name = 'senior_staff'),
    id
FROM permissions 
WHERE name IN (
    'booking.view',
    'booking.create',
    'booking.edit',
    'booking.approve',
    'report.view',
    'report.create',
    'report.export',
    'user.view',
    'user.edit'
);

-- Vendor role
INSERT INTO role_permissions (role_id, permission_id)
SELECT 
    (SELECT id FROM roles WHERE name = 'vendor'),
    id
FROM permissions 
WHERE name IN (
    'vendor.profile',
    'vendor.services',
    'vendor.pricing',
    'vendor.schedule',
    'booking.view'
);

-- Visitor role
INSERT INTO role_permissions (role_id, permission_id)
SELECT 
    (SELECT id FROM roles WHERE name = 'visitor'),
    id
FROM permissions 
WHERE name IN (
    'booking.view',
    'booking.create'
);
