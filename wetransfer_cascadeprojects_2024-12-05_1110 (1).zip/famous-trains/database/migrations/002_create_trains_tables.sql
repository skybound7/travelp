-- Create trains table
CREATE TABLE IF NOT EXISTS trains (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    description TEXT,
    destination VARCHAR(255) NOT NULL,
    duration VARCHAR(50) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    capacity INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_destination (destination),
    INDEX idx_price (price)
);

-- Create amenities table
CREATE TABLE IF NOT EXISTS amenities (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL UNIQUE,
    icon VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create train_amenities junction table
CREATE TABLE IF NOT EXISTS train_amenities (
    train_id INT NOT NULL,
    amenity_id INT NOT NULL,
    PRIMARY KEY (train_id, amenity_id),
    FOREIGN KEY (train_id) REFERENCES trains(id) ON DELETE CASCADE,
    FOREIGN KEY (amenity_id) REFERENCES amenities(id) ON DELETE CASCADE
);

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    train_id INT NOT NULL,
    user_id INT NOT NULL,
    rating TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (train_id) REFERENCES trains(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_train_rating (train_id, rating)
);

-- Insert sample amenities
INSERT INTO amenities (name, icon) VALUES
    ('Wi-Fi', 'wifi'),
    ('Fine Dining', 'restaurant'),
    ('Bar Service', 'wine-glass'),
    ('Private Cabin', 'door-closed'),
    ('Observation Car', 'binoculars'),
    ('Shower', 'shower'),
    ('Butler Service', 'concierge-bell'),
    ('Live Entertainment', 'music'),
    ('Spa Services', 'spa'),
    ('Guided Tours', 'map-marked');

-- Insert sample trains
INSERT INTO trains (name, slug, description, destination, duration, price, capacity) VALUES
    ('Orient Express', 'orient-express', 'The legendary Venice Simplon-Orient-Express luxury train', 'Paris to Istanbul', '6 days', 18000.00, 188),
    ('Royal Scotsman', 'royal-scotsman', 'Scotland\'s luxury touring train', 'Edinburgh to Highlands', '5 days', 12000.00, 36),
    ('Golden Eagle', 'golden-eagle', 'Trans-Siberian luxury rail journey', 'Moscow to Vladivostok', '15 days', 25000.00, 120),
    ('Maharajas Express', 'maharajas-express', 'India\'s most luxurious train', 'Delhi to Mumbai', '7 days', 15000.00, 88),
    ('Rocky Mountaineer', 'rocky-mountaineer', 'Luxury rail through Canadian Rockies', 'Vancouver to Banff', '2 days', 5000.00, 200);

-- Add amenities to trains
INSERT INTO train_amenities (train_id, amenity_id)
SELECT t.id, a.id
FROM trains t
CROSS JOIN amenities a
WHERE t.name = 'Orient Express' AND a.name IN ('Wi-Fi', 'Fine Dining', 'Bar Service', 'Private Cabin', 'Butler Service')
   OR t.name = 'Royal Scotsman' AND a.name IN ('Fine Dining', 'Bar Service', 'Private Cabin', 'Spa Services', 'Guided Tours')
   OR t.name = 'Golden Eagle' AND a.name IN ('Wi-Fi', 'Fine Dining', 'Bar Service', 'Private Cabin', 'Observation Car')
   OR t.name = 'Maharajas Express' AND a.name IN ('Wi-Fi', 'Fine Dining', 'Bar Service', 'Butler Service', 'Live Entertainment')
   OR t.name = 'Rocky Mountaineer' AND a.name IN ('Wi-Fi', 'Fine Dining', 'Observation Car', 'Guided Tours', 'Live Entertainment');
