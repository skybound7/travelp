-- Create vendors table
CREATE TABLE IF NOT EXISTS vendors (
    id INT PRIMARY KEY AUTO_INCREMENT,
    company_name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    description TEXT,
    logo_url VARCHAR(255),
    website VARCHAR(255),
    contact_email VARCHAR(255) NOT NULL,
    contact_phone VARCHAR(50),
    address TEXT,
    country VARCHAR(100),
    status ENUM('active', 'pending', 'suspended') DEFAULT 'pending',
    commission_rate DECIMAL(5,2) DEFAULT 10.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_country (country)
);

-- Create vendor_users table for vendor staff
CREATE TABLE IF NOT EXISTS vendor_users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    vendor_id INT NOT NULL,
    user_id INT NOT NULL,
    role ENUM('owner', 'manager', 'staff') NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_vendor_user (vendor_id, user_id)
);

-- Add vendor_id to trains table
ALTER TABLE trains
ADD COLUMN vendor_id INT,
ADD FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE SET NULL;

-- Create vendor_documents table
CREATE TABLE IF NOT EXISTS vendor_documents (
    id INT PRIMARY KEY AUTO_INCREMENT,
    vendor_id INT NOT NULL,
    document_type ENUM('license', 'insurance', 'certification', 'contract', 'other') NOT NULL,
    file_url VARCHAR(255) NOT NULL,
    expiry_date DATE,
    status ENUM('valid', 'expired', 'pending') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE CASCADE
);

-- Create vendor_payments table
CREATE TABLE IF NOT EXISTS vendor_payments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    vendor_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_method VARCHAR(50),
    transaction_id VARCHAR(255),
    status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE CASCADE
);

-- Create vendor_reviews table
CREATE TABLE IF NOT EXISTS vendor_reviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    vendor_id INT NOT NULL,
    rating TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE CASCADE
);

-- Insert sample vendors
INSERT INTO vendors (company_name, slug, description, contact_email, country, status) VALUES
    ('Orient Express Ltd.', 'orient-express-ltd', 'Luxury train operator specializing in European routes', 'contact@orientexpress.com', 'France', 'active'),
    ('Royal Scotsman Co.', 'royal-scotsman-co', 'Premium Scottish Highland train experiences', 'info@royalscotsman.com', 'United Kingdom', 'active'),
    ('Golden Eagle Luxury Trains', 'golden-eagle-luxury', 'Trans-Siberian railway specialists', 'bookings@goldeneagle.com', 'Russia', 'active'),
    ('Maharajas Express Company', 'maharajas-express-co', 'Indian luxury rail journeys', 'support@maharajasexpress.com', 'India', 'active'),
    ('Rocky Mountaineer Railways', 'rocky-mountaineer', 'Canadian Rockies train adventures', 'info@rockymountaineer.com', 'Canada', 'active');

-- Update existing trains with vendor IDs
UPDATE trains t
JOIN vendors v ON 
    CASE 
        WHEN t.name LIKE '%Orient Express%' THEN v.slug = 'orient-express-ltd'
        WHEN t.name LIKE '%Royal Scotsman%' THEN v.slug = 'royal-scotsman-co'
        WHEN t.name LIKE '%Golden Eagle%' THEN v.slug = 'golden-eagle-luxury'
        WHEN t.name LIKE '%Maharajas%' THEN v.slug = 'maharajas-express-co'
        WHEN t.name LIKE '%Rocky Mountaineer%' THEN v.slug = 'rocky-mountaineer'
    END
SET t.vendor_id = v.id;
