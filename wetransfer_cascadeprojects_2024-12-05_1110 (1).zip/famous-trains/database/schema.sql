CREATE DATABASE IF NOT EXISTS famous_trains;
USE famous_trains;

CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    train_id VARCHAR(50) NOT NULL,
    journey_date DATE NOT NULL,
    passengers INT NOT NULL,
    class VARCHAR(20) NOT NULL,
    customer_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    payment_status VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS eurail_bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pass_type VARCHAR(50) NOT NULL,
    duration VARCHAR(20) NOT NULL,
    travel_class VARCHAR(20) NOT NULL,
    start_date DATE NOT NULL,
    travelers INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    payment_status VARCHAR(20) NOT NULL,
    policy_accepted BOOLEAN NOT NULL DEFAULT FALSE,
    policy_accepted_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    policy_version VARCHAR(10) NOT NULL DEFAULT '1.0',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS policy_versions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    version VARCHAR(10) NOT NULL,
    policy_type ENUM('eurail', 'general') NOT NULL,
    effective_date TIMESTAMP NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_version (version, policy_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    payment_method VARCHAR(20) NOT NULL,
    payment_id VARCHAR(100) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Routes and Stations Tables
CREATE TABLE IF NOT EXISTS `routes` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `description` TEXT,
    `duration_minutes` INT NOT NULL,
    `distance_km` DECIMAL(10,2) NOT NULL,
    `country` VARCHAR(100) NOT NULL,
    `image_url` VARCHAR(255),
    `highlights` JSON,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `stations` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `city` VARCHAR(255) NOT NULL,
    `country` VARCHAR(100) NOT NULL,
    `latitude` DECIMAL(10,8),
    `longitude` DECIMAL(11,8),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `route_stations` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `route_id` INT NOT NULL,
    `station_id` INT NOT NULL,
    `stop_order` INT NOT NULL,
    `arrival_time` TIME,
    `departure_time` TIME,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE CASCADE,
    FOREIGN KEY (station_id) REFERENCES stations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample route data
INSERT INTO `routes` (`name`, `description`, `duration_minutes`, `distance_km`, `country`, `image_url`, `highlights`) VALUES
('Glacier Express', 'Journey between Zermatt and St. Moritz through stunning Alpine scenery', 450, 291, 'Switzerland', 'images/glacier-express.jpg', '["169 bridges", "91 tunnels", "Panoramic windows", "Gourmet dining"]'),
('Bernina Express', 'UNESCO World Heritage route through the Swiss Alps to Italy', 240, 144, 'Switzerland', 'images/bernina-express.jpg', '["55 tunnels", "196 bridges", "2,253m altitude", "Panoramic cars"]'),
('Paris to Nice', 'High-speed journey from the City of Light to the French Riviera', 345, 975, 'France', 'images/tgv-paris-nice.jpg', '["Up to 320 km/h", "First class option", "Dining car", "Scenic route"]'),
('Venice to Florence', 'Connect two of Italy''s most beautiful cities by high-speed rail', 135, 260, 'Italy', 'images/venice-florence.jpg', '["Frecciarossa service", "Business class", "Wi-Fi onboard", "City center stations"]');

-- Insert sample station data
INSERT INTO `stations` (`name`, `city`, `country`, `latitude`, `longitude`) VALUES
('Zermatt', 'Zermatt', 'Switzerland', 46.0207, 7.7491),
('St. Moritz', 'St. Moritz', 'Switzerland', 46.4908, 9.8355),
('Chur', 'Chur', 'Switzerland', 46.8519, 9.5320),
('Tirano', 'Tirano', 'Italy', 46.2159, 10.1679),
('Paris Gare de Lyon', 'Paris', 'France', 48.8448, 2.3735),
('Nice Ville', 'Nice', 'France', 43.7044, 7.2615),
('Venezia Santa Lucia', 'Venice', 'Italy', 45.4415, 12.3197),
('Firenze Santa Maria Novella', 'Florence', 'Italy', 43.7764, 11.2478);

-- Connect routes with stations
INSERT INTO `route_stations` (`route_id`, `station_id`, `stop_order`) VALUES
(1, 1, 1), -- Glacier Express: Zermatt
(1, 2, 2), -- Glacier Express: St. Moritz
(2, 3, 1), -- Bernina Express: Chur
(2, 2, 2), -- Bernina Express: St. Moritz
(2, 4, 3), -- Bernina Express: Tirano
(3, 5, 1), -- Paris to Nice: Paris
(3, 6, 2), -- Paris to Nice: Nice
(4, 7, 1), -- Venice to Florence: Venice
(4, 8, 2); -- Venice to Florence: Florence
