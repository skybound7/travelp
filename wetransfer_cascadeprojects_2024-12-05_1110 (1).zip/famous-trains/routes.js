document.addEventListener('DOMContentLoaded', function() {
    loadRoutes();

    // Add event listeners for country filters if they exist
    const countryFilters = document.querySelectorAll('.country-filter');
    countryFilters.forEach(filter => {
        filter.addEventListener('click', function(e) {
            e.preventDefault();
            const country = this.dataset.country;
            loadRoutes(country);
            
            // Update active state
            countryFilters.forEach(f => f.classList.remove('active'));
            this.classList.add('active');
        });
    });
});

async function loadRoutes(country = null) {
    try {
        const url = new URL('/api/get-routes.php', window.location.origin);
        if (country) {
            url.searchParams.append('country', country);
        }

        const response = await fetch(url);
        const data = await response.json();

        if (!data.success) {
            throw new Error(data.error || 'Failed to load routes');
        }

        displayRoutes(data.routes);
    } catch (error) {
        console.error('Error loading routes:', error);
        showError('Failed to load route information. Please try again later.');
    }
}

function displayRoutes(routes) {
    const routeSections = {};

    // Group routes by country
    routes.forEach(route => {
        if (!routeSections[route.country]) {
            routeSections[route.country] = [];
        }
        routeSections[route.country].push(route);
    });

    const mainContent = document.querySelector('.main-content');
    mainContent.innerHTML = ''; // Clear existing content

    // Create sections for each country
    Object.entries(routeSections).forEach(([country, countryRoutes]) => {
        const section = createRouteSection(country, countryRoutes);
        mainContent.appendChild(section);
    });
}

function createRouteSection(country, routes) {
    const section = document.createElement('section');
    section.className = 'route-section';
    
    section.innerHTML = `
        <h2>${country}</h2>
        <div class="route-grid">
            ${routes.map(route => createRouteCard(route)).join('')}
        </div>
    `;
    
    return section;
}

function createRouteCard(route) {
    const stationsHtml = route.stations
        .sort((a, b) => a.order - b.order)
        .map(station => `<span>${station.name}</span>`)
        .join('<span class="route-arrow">→</span>');

    return `
        <article class="route-card">
            <div class="route-image">
                <img src="${route.image_url}" alt="${route.name}" loading="lazy">
            </div>
            <div class="route-content">
                <h3>${route.name}</h3>
                <div class="route-info">
                    <span class="route-duration">${route.duration.formatted}</span>
                    <span class="route-distance">${route.distance.formatted}</span>
                </div>
                <p>${route.description}</p>
                <ul class="route-highlights">
                    ${route.highlights.map(highlight => 
                        `<li>${highlight}</li>`
                    ).join('')}
                </ul>
                <div class="route-stations">
                    ${stationsHtml}
                </div>
            </div>
        </article>
    `;
}

function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    
    const mainContent = document.querySelector('.main-content');
    mainContent.innerHTML = '';
    mainContent.appendChild(errorDiv);
}
