/**
 * Performance Utility for Famous Trains Frontend
 */
const Performance = {
    metrics: {
        pageLoadTime: 0,
        resourceLoadTimes: {},
        apiCallTimes: {},
        renderTimes: {},
        memoryUsage: {}
    },

    cache: {
        data: new Map(),
        maxAge: 5 * 60 * 1000, // 5 minutes default
    },

    config: {
        enableMetrics: true,
        logLevel: 'warning', // 'debug' | 'warning' | 'error'
        apiTimeout: 30000, // 30 seconds
        imageLazyLoadOffset: 100, // pixels
    },

    /**
     * Initialize performance monitoring
     */
    init() {
        // Record page load time
        this.metrics.pageLoadTime = performance.now();

        // Setup performance observers
        this.setupObservers();

        // Initialize lazy loading
        this.initLazyLoading();

        // Setup error tracking
        this.setupErrorTracking();

        // Monitor memory usage
        this.startMemoryMonitoring();
    },

    /**
     * Setup Performance Observers
     */
    setupObservers() {
        // Resource timing
        new PerformanceObserver((list) => {
            for (const entry of list.getEntries()) {
                this.metrics.resourceLoadTimes[entry.name] = entry.duration;
                this.logPerformanceIssue(entry);
            }
        }).observe({ entryTypes: ['resource'] });

        // Long task monitoring
        new PerformanceObserver((list) => {
            for (const entry of list.getEntries()) {
                if (entry.duration > 50) { // 50ms threshold
                    this.log('warning', `Long task detected: ${entry.duration}ms`);
                }
            }
        }).observe({ entryTypes: ['longtask'] });
    },

    /**
     * Initialize lazy loading for images and iframes
     */
    initLazyLoading() {
        const options = {
            root: null,
            rootMargin: `${this.config.imageLazyLoadOffset}px`,
            threshold: 0.1
        };

        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const element = entry.target;
                    if (element.dataset.src) {
                        element.src = element.dataset.src;
                        element.removeAttribute('data-src');
                        observer.unobserve(element);
                    }
                }
            });
        }, options);

        // Observe all images and iframes with data-src
        document.querySelectorAll('img[data-src], iframe[data-src]')
            .forEach(element => observer.observe(element));
    },

    /**
     * Cache management
     */
    setCache(key, data, maxAge = null) {
        this.cache.data.set(key, {
            data,
            timestamp: Date.now(),
            maxAge: maxAge || this.cache.maxAge
        });
    },

    getCache(key) {
        const cached = this.cache.data.get(key);
        if (!cached) return null;

        const age = Date.now() - cached.timestamp;
        if (age > cached.maxAge) {
            this.cache.data.delete(key);
            return null;
        }

        return cached.data;
    },

    clearCache(key = null) {
        if (key) {
            this.cache.data.delete(key);
        } else {
            this.cache.data.clear();
        }
    },

    /**
     * API call optimization
     */
    async fetchWithTimeout(url, options = {}) {
        const controller = new AbortController();
        const timeout = options.timeout || this.config.apiTimeout;
        const id = Math.random().toString(36).substring(7);

        const timeoutId = setTimeout(() => {
            controller.abort();
        }, timeout);

        const startTime = performance.now();

        try {
            const response = await fetch(url, {
                ...options,
                signal: controller.signal
            });

            const duration = performance.now() - startTime;
            this.metrics.apiCallTimes[url] = duration;

            if (duration > 1000) { // 1 second threshold
                this.log('warning', `Slow API call to ${url}: ${duration}ms`);
            }

            return response;
        } catch (error) {
            this.log('error', `API call failed: ${error.message}`);
            throw error;
        } finally {
            clearTimeout(timeoutId);
        }
    },

    /**
     * Memory monitoring
     */
    startMemoryMonitoring() {
        if (performance.memory) {
            setInterval(() => {
                const memory = performance.memory;
                this.metrics.memoryUsage = {
                    total: memory.totalJSHeapSize,
                    used: memory.usedJSHeapSize,
                    limit: memory.jsHeapSizeLimit
                };

                if (memory.usedJSHeapSize > memory.jsHeapSizeLimit * 0.8) {
                    this.log('warning', 'High memory usage detected');
                }
            }, 10000); // Check every 10 seconds
        }
    },

    /**
     * Error tracking
     */
    setupErrorTracking() {
        window.addEventListener('error', (event) => {
            this.log('error', {
                message: event.message,
                source: event.filename,
                line: event.lineno,
                column: event.colno,
                error: event.error
            });
        });

        window.addEventListener('unhandledrejection', (event) => {
            this.log('error', {
                message: 'Unhandled Promise Rejection',
                reason: event.reason
            });
        });
    },

    /**
     * Performance issue detection
     */
    logPerformanceIssue(entry) {
        if (entry.duration > 1000) { // 1 second threshold
            this.log('warning', `Slow resource load: ${entry.name} (${entry.duration}ms)`);
        }

        if (entry.transferSize > 1000000) { // 1MB threshold
            this.log('warning', `Large resource: ${entry.name} (${Math.round(entry.transferSize / 1024)}KB)`);
        }
    },

    /**
     * Logging utility
     */
    log(level, message) {
        const levels = {
            debug: 0,
            warning: 1,
            error: 2
        };

        if (levels[level] >= levels[this.config.logLevel]) {
            console[level === 'debug' ? 'log' : level](
                `[Performance ${level.toUpperCase()}]`,
                message
            );
        }
    },

    /**
     * Get performance report
     */
    getReport() {
        return {
            pageLoad: this.metrics.pageLoadTime,
            resources: this.metrics.resourceLoadTimes,
            apiCalls: this.metrics.apiCallTimes,
            memory: this.metrics.memoryUsage,
            renders: this.metrics.renderTimes
        };
    }
};

// Initialize performance monitoring
document.addEventListener('DOMContentLoaded', () => {
    Performance.init();
});
