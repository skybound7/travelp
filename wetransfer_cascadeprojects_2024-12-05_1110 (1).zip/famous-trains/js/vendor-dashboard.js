class VendorDashboard {
    constructor() {
        this.vendorId = this.getVendorId();
        this.initializeElements();
        this.bindEvents();
        this.loadDashboardData();
        this.initializeCharts();
    }

    initializeElements() {
        // Stats elements
        this.bookingsCount = document.querySelector('.stat-card .bookings + .stat-details .stat-number');
        this.revenueAmount = document.querySelector('.stat-card .revenue + .stat-details .stat-number');
        this.averageRating = document.querySelector('.stat-card .reviews + .stat-details .stat-number');
        this.activeTrains = document.querySelector('.stat-card .trains + .stat-details .stat-number');

        // Tables and grids
        this.recentBookingsTable = document.getElementById('recentBookings');
        this.latestReviewsGrid = document.getElementById('latestReviews');

        // Chart elements
        this.chartMetricSelect = document.getElementById('chartMetric');
        this.chartPeriodSelect = document.getElementById('chartPeriod');
        this.performanceChart = document.getElementById('performanceChart').getContext('2d');

        // Modals
        this.bookingDetailsModal = document.getElementById('bookingDetailsModal');
        this.reviewResponseModal = document.getElementById('reviewResponseModal');
    }

    bindEvents() {
        // Chart control events
        this.chartMetricSelect.addEventListener('change', () => this.updateChart());
        this.chartPeriodSelect.addEventListener('change', () => this.updateChart());

        // Navigation events
        document.querySelectorAll('.sidebar-nav a').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleNavigation(e.target.getAttribute('href').substring(1));
            });
        });

        // Modal events
        document.querySelectorAll('[data-action="viewBooking"]').forEach(btn => {
            btn.addEventListener('click', (e) => this.showBookingDetails(e.target.dataset.id));
        });

        document.querySelectorAll('[data-action="respondReview"]').forEach(btn => {
            btn.addEventListener('click', (e) => this.showReviewResponse(e.target.dataset.id));
        });
    }

    async loadDashboardData() {
        try {
            // Load vendor stats
            const stats = await this.fetchVendorStats();
            this.updateStats(stats);

            // Load recent bookings
            const bookings = await this.fetchRecentBookings();
            this.updateRecentBookings(bookings);

            // Load latest reviews
            const reviews = await this.fetchLatestReviews();
            this.updateLatestReviews(reviews);

        } catch (error) {
            console.error('Error loading dashboard data:', error);
            this.showError('Failed to load dashboard data');
        }
    }

    async fetchVendorStats() {
        const response = await fetch(`/api/vendor/${this.vendorId}/stats`);
        return await response.json();
    }

    async fetchRecentBookings() {
        const response = await fetch(`/api/vendor/${this.vendorId}/bookings/recent`);
        return await response.json();
    }

    async fetchLatestReviews() {
        const response = await fetch(`/api/vendor/${this.vendorId}/reviews/latest`);
        return await response.json();
    }

    updateStats(stats) {
        this.bookingsCount.textContent = stats.totalBookings.toLocaleString();
        this.revenueAmount.textContent = `$${stats.totalRevenue.toLocaleString()}`;
        this.averageRating.textContent = stats.averageRating.toFixed(1);
        this.activeTrains.textContent = stats.activeTrains;

        // Update trends
        this.updateTrend('.bookings', stats.bookingsTrend);
        this.updateTrend('.revenue', stats.revenueTrend);
        this.updateTrend('.reviews', stats.ratingTrend);
    }

    updateTrend(selector, trend) {
        const trendElement = document.querySelector(`${selector} + .stat-details .trend`);
        const trendIcon = trendElement.querySelector('i');
        
        trendElement.className = `trend ${trend > 0 ? 'up' : trend < 0 ? 'down' : 'neutral'}`;
        trendIcon.className = `fas fa-arrow-${trend > 0 ? 'up' : trend < 0 ? 'down' : 'minus'}`;
        trendElement.textContent = `${Math.abs(trend)}% `;
        trendElement.appendChild(trendIcon);
    }

    updateRecentBookings(bookings) {
        this.recentBookingsTable.innerHTML = bookings.map(booking => `
            <tr>
                <td>#${booking.id}</td>
                <td>${booking.trainName}</td>
                <td>${booking.customerName}</td>
                <td>${new Date(booking.date).toLocaleDateString()}</td>
                <td>$${booking.amount.toLocaleString()}</td>
                <td><span class="status ${booking.status.toLowerCase()}">${booking.status}</span></td>
                <td>
                    <button class="btn-action" data-action="viewBooking" data-id="${booking.id}">
                        <i class="fas fa-eye"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    }

    updateLatestReviews(reviews) {
        this.latestReviewsGrid.innerHTML = reviews.map(review => `
            <div class="review-card">
                <div class="review-header">
                    <div class="reviewer-info">
                        <img src="${review.customerAvatar}" alt="${review.customerName}" class="avatar">
                        <div>
                            <h4>${review.customerName}</h4>
                            <div class="rating">
                                ${this.generateStars(review.rating)}
                            </div>
                        </div>
                    </div>
                    <div class="review-date">
                        ${new Date(review.date).toLocaleDateString()}
                    </div>
                </div>
                <p class="review-text">${review.comment}</p>
                <div class="review-actions">
                    <button class="btn-action" data-action="respondReview" data-id="${review.id}">
                        <i class="fas fa-reply"></i> Respond
                    </button>
                </div>
            </div>
        `).join('');
    }

    generateStars(rating) {
        return Array(5).fill('').map((_, index) => `
            <i class="fas fa-star ${index < rating ? 'filled' : ''}"></i>
        `).join('');
    }

    initializeCharts() {
        this.chart = new Chart(this.performanceChart, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Performance',
                    data: [],
                    borderColor: '#3498db',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        this.updateChart();
    }

    async updateChart() {
        const metric = this.chartMetricSelect.value;
        const period = this.chartPeriodSelect.value;

        try {
            const response = await fetch(`/api/vendor/${this.vendorId}/performance?metric=${metric}&period=${period}`);
            const data = await response.json();

            this.chart.data.labels = data.labels;
            this.chart.data.datasets[0].data = data.values;
            this.chart.data.datasets[0].label = this.getMetricLabel(metric);
            this.chart.update();
        } catch (error) {
            console.error('Error updating chart:', error);
            this.showError('Failed to update performance chart');
        }
    }

    getMetricLabel(metric) {
        const labels = {
            bookings: 'Total Bookings',
            revenue: 'Revenue',
            ratings: 'Average Rating'
        };
        return labels[metric] || metric;
    }

    async showBookingDetails(bookingId) {
        try {
            const response = await fetch(`/api/vendor/${this.vendorId}/bookings/${bookingId}`);
            const booking = await response.json();
            
            this.bookingDetailsModal.innerHTML = this.generateBookingModalContent(booking);
            this.bookingDetailsModal.classList.add('active');
        } catch (error) {
            console.error('Error loading booking details:', error);
            this.showError('Failed to load booking details');
        }
    }

    async showReviewResponse(reviewId) {
        try {
            const response = await fetch(`/api/vendor/${this.vendorId}/reviews/${reviewId}`);
            const review = await response.json();
            
            this.reviewResponseModal.innerHTML = this.generateReviewModalContent(review);
            this.reviewResponseModal.classList.add('active');
        } catch (error) {
            console.error('Error loading review details:', error);
            this.showError('Failed to load review details');
        }
    }

    generateBookingModalContent(booking) {
        return `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Booking Details #${booking.id}</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <!-- Booking details content -->
                </div>
            </div>
        `;
    }

    generateReviewModalContent(review) {
        return `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Respond to Review</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <!-- Review response form -->
                </div>
            </div>
        `;
    }

    showError(message) {
        // Implement error notification
    }

    getVendorId() {
        // Implement vendor ID retrieval from session/storage
        return 1; // Temporary
    }

    handleNavigation(section) {
        // Implement section navigation
    }
}

// Initialize dashboard
document.addEventListener('DOMContentLoaded', () => {
    new VendorDashboard();
});
