class LoginManager {
    constructor() {
        this.form = document.getElementById('login-form');
        this.roleOptions = document.querySelectorAll('.role-option');
        this.selectedRoleInput = document.getElementById('selected-role');
        this.passwordToggle = document.getElementById('toggle-password');
        this.passwordInput = document.getElementById('password');
        
        this.initializeEventListeners();
        this.initializeRoleSelector();
    }

    initializeEventListeners() {
        // Form submission
        this.form.addEventListener('submit', (e) => this.handleLogin(e));

        // Password visibility toggle
        this.passwordToggle.addEventListener('click', () => this.togglePasswordVisibility());

        // Role selection
        this.roleOptions.forEach(option => {
            option.addEventListener('click', () => this.selectRole(option));
        });
    }

    initializeRoleSelector() {
        this.roleOptions.forEach(option => {
            option.addEventListener('click', () => {
                // Remove active class from all options
                this.roleOptions.forEach(opt => opt.classList.remove('active'));
                // Add active class to selected option
                option.classList.add('active');
                // Update hidden input
                this.selectedRoleInput.value = option.dataset.role;
            });
        });
    }

    togglePasswordVisibility() {
        const type = this.passwordInput.type === 'password' ? 'text' : 'password';
        this.passwordInput.type = type;
        
        const icon = this.passwordToggle.querySelector('i');
        icon.classList.toggle('fa-eye');
        icon.classList.toggle('fa-eye-slash');
    }

    async handleLogin(e) {
        e.preventDefault();

        if (!this.selectedRoleInput.value) {
            this.showError('Please select your role');
            return;
        }

        const formData = {
            username: document.getElementById('username').value,
            password: document.getElementById('password').value,
            role: this.selectedRoleInput.value,
            remember: document.getElementById('remember-me').checked
        };

        try {
            const response = await fetch('/api/auth/login.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            const data = await response.json();

            if (data.status === 'success') {
                // Store auth token
                if (formData.remember) {
                    localStorage.setItem('auth_token', data.token);
                } else {
                    sessionStorage.setItem('auth_token', data.token);
                }

                // Store user role and permissions
                localStorage.setItem('user_role', data.role);
                localStorage.setItem('user_permissions', JSON.stringify(data.permissions));

                // Redirect based on role
                this.redirectToDashboard(data.role);
            } else {
                this.showError(data.message || 'Login failed');
            }
        } catch (error) {
            console.error('Login error:', error);
            this.showError('Network error occurred');
        }
    }

    redirectToDashboard(role) {
        const dashboards = {
            'admin': '/admin/dashboard.html',
            'staff': '/staff/dashboard.html',
            'senior_staff': '/staff/senior/dashboard.html',
            'vendor': '/vendor/dashboard.html',
            'visitor': '/visitor/dashboard.html'
        };

        window.location.href = dashboards[role] || '/dashboard.html';
    }

    showError(message) {
        let errorDiv = document.querySelector('.alert-danger');
        if (!errorDiv) {
            errorDiv = document.createElement('div');
            errorDiv.className = 'alert alert-danger mt-3';
            this.form.insertBefore(errorDiv, this.form.firstChild);
        }
        errorDiv.textContent = message;

        // Auto-hide after 5 seconds
        setTimeout(() => {
            errorDiv.remove();
        }, 5000);
    }
}

// Initialize login manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new LoginManager();
});
