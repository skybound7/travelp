class StaffDashboard {
    constructor() {
        this.currentUser = null;
        this.permissions = [];
        this.charts = {};
        
        this.initializeEventListeners();
        this.loadUserData();
        this.initializeNotifications();
    }

    async initializeEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                this.loadPage(e.currentTarget.dataset.page);
            });
        });

        // Sidebar toggle
        document.getElementById('sidebar-toggle').addEventListener('click', () => {
            document.querySelector('.dashboard-container').classList.toggle('sidebar-collapsed');
        });

        // Logout handler
        document.getElementById('logout-link').addEventListener('click', (e) => {
            e.preventDefault();
            this.handleLogout();
        });
    }

    async loadUserData() {
        try {
            const token = localStorage.getItem('auth_token') || sessionStorage.getItem('auth_token');
            if (!token) {
                window.location.href = '/login';
                return;
            }

            const response = await fetch('/api/staff/profile.php', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.currentUser = data.user;
                this.permissions = data.permissions;
                this.updateUI();
                this.loadDashboardData();
            } else {
                window.location.href = '/login';
            }
        } catch (error) {
            console.error('Error loading user data:', error);
            window.location.href = '/login';
        }
    }

    async loadDashboardData() {
        await Promise.all([
            this.loadQuickStats(),
            this.loadTodaysTasks(),
            this.loadActiveTransfers(),
            this.initializeCharts()
        ]);
    }

    async loadQuickStats() {
        try {
            const response = await fetch('/api/staff/stats.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                document.getElementById('today-bookings').textContent = data.stats.today_bookings;
                document.getElementById('pending-tasks').textContent = data.stats.pending_tasks;
                document.getElementById('active-transfers').textContent = data.stats.active_transfers;
                document.getElementById('customer-rating').textContent = data.stats.average_rating.toFixed(1);
            }
        } catch (error) {
            console.error('Error loading stats:', error);
        }
    }

    async loadPage(page) {
        const contentArea = document.getElementById('main-content-area');
        
        // Update active nav link
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
            if (link.dataset.page === page) {
                link.classList.add('active');
            }
        });

        try {
            const response = await fetch(`/api/staff/pages/${page}.php`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                contentArea.innerHTML = data.content;
                this.initializePageScripts(page);
            }
        } catch (error) {
            console.error(`Error loading ${page}:`, error);
            contentArea.innerHTML = '<div class="alert alert-danger">Error loading content</div>';
        }
    }

    initializePageScripts(page) {
        switch (page) {
            case 'bookings':
                this.initializeBookingsTable();
                break;
            case 'schedule':
                this.initializeScheduleCalendar();
                break;
            case 'tasks':
                this.initializeTasksManager();
                break;
            case 'reports':
                this.initializeReports();
                break;
        }
    }

    async initializeCharts() {
        // Bookings Timeline Chart
        const bookingsCtx = document.getElementById('bookings-timeline');
        if (bookingsCtx) {
            this.charts.bookings = new Chart(bookingsCtx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Bookings',
                        data: [],
                        borderColor: '#3498db',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
            await this.updateBookingsChart();
        }
    }

    async updateBookingsChart() {
        try {
            const response = await fetch('/api/staff/charts/bookings.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success' && this.charts.bookings) {
                this.charts.bookings.data.labels = data.labels;
                this.charts.bookings.data.datasets[0].data = data.values;
                this.charts.bookings.update();
            }
        } catch (error) {
            console.error('Error updating bookings chart:', error);
        }
    }

    initializeNotifications() {
        // WebSocket connection for real-time notifications
        const ws = new WebSocket('ws://your-websocket-server/staff-notifications');
        
        ws.onmessage = (event) => {
            const notification = JSON.parse(event.data);
            this.showNotification(notification);
        };

        ws.onerror = (error) => {
            console.error('WebSocket error:', error);
        };
    }

    showNotification(notification) {
        const container = document.querySelector('.notification-dropdown');
        const notificationHTML = `
            <div class="dropdown-item">
                <small class="text-muted">${notification.type}</small>
                <p class="mb-0">${notification.message}</p>
            </div>
        `;
        
        container.insertAdjacentHTML('afterbegin', notificationHTML);
        
        // Update badge count
        const badge = document.querySelector('.notifications .badge');
        const count = parseInt(badge.textContent) + 1;
        badge.textContent = count;
    }

    async handleLogout() {
        try {
            await fetch('/api/auth/logout.php', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });
        } catch (error) {
            console.error('Logout error:', error);
        } finally {
            localStorage.removeItem('auth_token');
            sessionStorage.removeItem('auth_token');
            window.location.href = '/login';
        }
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new StaffDashboard();
});
