class Dashboard {
    constructor() {
        this.currentUser = null;
        this.permissions = [];
        this.menuConfig = {
            staff: [
                { id: 'bookings', icon: 'fa-calendar-check', text: 'Bookings' },
                { id: 'schedule', icon: 'fa-clock', text: 'Schedule' },
                { id: 'reports', icon: 'fa-chart-bar', text: 'Reports' }
            ],
            senior_staff: [
                { id: 'bookings', icon: 'fa-calendar-check', text: 'Bookings' },
                { id: 'schedule', icon: 'fa-clock', text: 'Schedule' },
                { id: 'reports', icon: 'fa-chart-bar', text: 'Reports' },
                { id: 'staff', icon: 'fa-users', text: 'Staff Management' },
                { id: 'analytics', icon: 'fa-chart-line', text: 'Analytics' }
            ],
            vendor: [
                { id: 'services', icon: 'fa-cog', text: 'Services' },
                { id: 'schedule', icon: 'fa-calendar', text: 'Availability' },
                { id: 'bookings', icon: 'fa-calendar-check', text: 'Bookings' },
                { id: 'earnings', icon: 'fa-dollar-sign', text: 'Earnings' }
            ],
            visitor: [
                { id: 'bookings', icon: 'fa-calendar-check', text: 'My Bookings' },
                { id: 'services', icon: 'fa-train', text: 'Available Services' },
                { id: 'profile', icon: 'fa-user', text: 'Profile' }
            ]
        };

        this.initializeEventListeners();
        this.loadUserData();
    }

    async initializeEventListeners() {
        // Sidebar toggle
        document.getElementById('sidebar-toggle').addEventListener('click', () => {
            document.querySelector('.dashboard-container').classList.toggle('sidebar-collapsed');
        });

        // Logout handler
        document.getElementById('logout-link').addEventListener('click', (e) => {
            e.preventDefault();
            this.handleLogout();
        });

        // Profile modal handlers
        document.getElementById('profile-link').addEventListener('click', (e) => {
            e.preventDefault();
            this.showProfileModal();
        });

        document.getElementById('save-profile').addEventListener('click', () => {
            this.saveProfile();
        });
    }

    async loadUserData() {
        try {
            const token = localStorage.getItem('auth_token') || sessionStorage.getItem('auth_token');
            if (!token) {
                window.location.href = '/login';
                return;
            }

            const response = await fetch('/api/auth/user.php', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.currentUser = data.user;
                this.permissions = data.permissions;
                this.updateUI();
            } else {
                window.location.href = '/login';
            }
        } catch (error) {
            console.error('Error loading user data:', error);
            window.location.href = '/login';
        }
    }

    updateUI() {
        // Update user info
        document.getElementById('user-name').textContent = this.currentUser.username;
        document.getElementById('user-role').textContent = this.currentUser.role;

        // Load menu items based on role
        this.loadMenu();

        // Load quick stats based on role
        this.loadQuickStats();

        // Load initial content
        this.loadContent('dashboard');
    }

    loadMenu() {
        const menuContainer = document.getElementById('menu-container');
        const menuItems = this.menuConfig[this.currentUser.role] || [];

        menuContainer.innerHTML = menuItems.map(item => `
            <li class="nav-item">
                <a class="nav-link" href="#" data-page="${item.id}">
                    <i class="fas ${item.icon}"></i>
                    <span>${item.text}</span>
                </a>
            </li>
        `).join('');

        // Add click handlers
        menuContainer.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                this.loadContent(e.currentTarget.dataset.page);
            });
        });
    }

    async loadQuickStats() {
        try {
            const response = await fetch('/api/dashboard/stats.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                const statsContainer = document.getElementById('quick-stats');
                statsContainer.innerHTML = this.generateStatsHTML(data.stats);
            }
        } catch (error) {
            console.error('Error loading stats:', error);
        }
    }

    generateStatsHTML(stats) {
        return Object.entries(stats).map(([key, value]) => `
            <div class="col-md-3 col-sm-6 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">${this.formatStatTitle(key)}</h5>
                        <h3 class="card-text">${value}</h3>
                    </div>
                </div>
            </div>
        `).join('');
    }

    formatStatTitle(key) {
        return key.split('_').map(word => 
            word.charAt(0).toUpperCase() + word.slice(1)
        ).join(' ');
    }

    async loadContent(page) {
        const contentArea = document.getElementById('main-content-area');
        document.getElementById('current-page').textContent = this.formatStatTitle(page);

        try {
            const response = await fetch(`/api/dashboard/content/${page}.php`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                contentArea.innerHTML = data.content;
                this.initializePageScripts(page);
            }
        } catch (error) {
            console.error(`Error loading ${page} content:`, error);
            contentArea.innerHTML = '<div class="alert alert-danger">Error loading content</div>';
        }
    }

    initializePageScripts(page) {
        // Initialize page-specific functionality
        switch (page) {
            case 'bookings':
                this.initializeBookingsPage();
                break;
            case 'analytics':
                this.initializeAnalyticsPage();
                break;
            // Add more page initializations as needed
        }
    }

    async handleLogout() {
        try {
            await fetch('/api/auth/logout.php', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });
        } catch (error) {
            console.error('Logout error:', error);
        } finally {
            localStorage.removeItem('auth_token');
            sessionStorage.removeItem('auth_token');
            window.location.href = '/login';
        }
    }

    showProfileModal() {
        const modal = new bootstrap.Modal(document.getElementById('profileModal'));
        document.getElementById('profile-username').value = this.currentUser.username;
        document.getElementById('profile-email').value = this.currentUser.email;
        modal.show();
    }

    async saveProfile() {
        const email = document.getElementById('profile-email').value;
        const newPassword = document.getElementById('profile-new-password').value;

        try {
            const response = await fetch('/api/auth/update-profile.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({
                    email,
                    new_password: newPassword || undefined
                })
            });

            const data = await response.json();
            if (data.status === 'success') {
                bootstrap.Modal.getInstance(document.getElementById('profileModal')).hide();
                this.showAlert('Profile updated successfully', 'success');
            } else {
                this.showAlert(data.message, 'danger');
            }
        } catch (error) {
            console.error('Profile update error:', error);
            this.showAlert('Error updating profile', 'danger');
        }
    }

    showAlert(message, type) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        document.querySelector('.content').insertBefore(alertDiv, document.querySelector('.content').firstChild);
        
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new Dashboard();
});
