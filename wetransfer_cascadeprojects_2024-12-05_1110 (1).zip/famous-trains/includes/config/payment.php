<?php
// Payment Gateway Configurations
define('PAYPAL_CLIENT_ID', 'YOUR_PAYPAL_CLIENT_ID');
define('PAYPAL_SECRET', 'YOUR_PAYPAL_SECRET');
define('PAYPAL_MODE', 'sandbox'); // Change to 'live' for production

define('PHONEPE_MERCHANT_ID', 'YOUR_PHONEPE_MERCHANT_ID');
define('PHONEPE_API_KEY', 'YOUR_PHONEPE_API_KEY');
define('PHONEPE_MODE', 'test'); // Change to 'prod' for production

// Payment Status Constants
define('PAYMENT_STATUS_PENDING', 'pending');
define('PAYMENT_STATUS_COMPLETED', 'completed');
define('PAYMENT_STATUS_FAILED', 'failed');
?>
