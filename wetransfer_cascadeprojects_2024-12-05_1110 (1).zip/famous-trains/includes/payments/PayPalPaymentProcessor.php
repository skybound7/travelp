<?php
class PayPalPaymentProcessor {
    private $client_id;
    private $secret;
    private $mode;

    public function __construct() {
        $this->client_id = PAYPAL_CLIENT_ID;
        $this->secret = PAYPAL_SECRET;
        $this->mode = PAYPAL_MODE;
    }

    public function initiate($data) {
        $api_url = $this->mode === 'sandbox' 
            ? 'https://api-m.sandbox.paypal.com/v2/checkout/orders'
            : 'https://api-m.paypal.com/v2/checkout/orders';

        $payload = [
            'intent' => 'CAPTURE',
            'purchase_units' => [[
                'reference_id' => $data['booking_id'],
                'description' => $data['description'],
                'amount' => [
                    'currency_code' => $data['currency'],
                    'value' => number_format($data['amount'], 2, '.', '')
                ]
            ]],
            'application_context' => [
                'return_url' => 'https://your-domain.com/api/payment/callback/paypal.php?booking_id=' . $data['booking_id'],
                'cancel_url' => 'https://your-domain.com/booking-failed.html'
            ]
        ];

        $ch = curl_init($api_url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Basic ' . base64_encode($this->client_id . ':' . $this->secret)
        ]);

        $response = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($status !== 201) {
            throw new Exception('Failed to create PayPal order');
        }

        $result = json_decode($response, true);
        return [
            'payment_id' => $result['id'],
            'approval_url' => $this->getApprovalUrl($result['links'])
        ];
    }

    private function getApprovalUrl($links) {
        foreach ($links as $link) {
            if ($link['rel'] === 'approve') {
                return $link['href'];
            }
        }
        throw new Exception('Approval URL not found in PayPal response');
    }

    public function verify($payment_id) {
        $api_url = $this->mode === 'sandbox' 
            ? "https://api-m.sandbox.paypal.com/v2/checkout/orders/{$payment_id}/capture"
            : "https://api-m.paypal.com/v2/checkout/orders/{$payment_id}/capture";

        $ch = curl_init($api_url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Basic ' . base64_encode($this->client_id . ':' . $this->secret)
        ]);

        $response = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($status !== 201) {
            throw new Exception('Failed to capture PayPal payment');
        }

        return json_decode($response, true);
    }
}
?>
