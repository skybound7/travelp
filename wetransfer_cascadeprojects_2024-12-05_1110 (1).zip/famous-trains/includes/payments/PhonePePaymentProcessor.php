<?php
class PhonePePaymentProcessor {
    private $merchant_id;
    private $api_key;
    private $mode;

    public function __construct() {
        $this->merchant_id = PHONEPE_MERCHANT_ID;
        $this->api_key = PHONEPE_API_KEY;
        $this->mode = PHONEPE_MODE;
    }

    public function initiate($data) {
        $api_url = $this->mode === 'test' 
            ? 'https://api-test.phonepe.com/apis/hermes/pg/v1/pay'
            : 'https://api.phonepe.com/apis/hermes/pg/v1/pay';

        $payload = [
            'merchantId' => $this->merchant_id,
            'merchantTransactionId' => 'TR_' . $data['booking_id'] . '_' . time(),
            'merchantUserId' => 'MUID_' . time(),
            'amount' => $data['amount'] * 100, // Convert to paisa
            'redirectUrl' => 'https://your-domain.com/api/payment/callback/phonepe.php',
            'redirectMode' => 'POST',
            'callbackUrl' => 'https://your-domain.com/api/payment/callback/phonepe.php',
            'paymentInstrument' => [
                'type' => 'PAY_PAGE'
            ]
        ];

        $base64_payload = base64_encode(json_encode($payload));
        $checksum = hash('sha256', $base64_payload . '/pg/v1/pay' . $this->api_key);

        $request_payload = [
            'request' => $base64_payload,
            'X-VERIFY' => $checksum
        ];

        $ch = curl_init($api_url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($request_payload));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'X-MERCHANT-ID: ' . $this->merchant_id
        ]);

        $response = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($status !== 200) {
            throw new Exception('Failed to create PhonePe payment');
        }

        $result = json_decode($response, true);
        
        if ($result['success'] !== true) {
            throw new Exception($result['message'] ?? 'PhonePe payment initialization failed');
        }

        return [
            'payment_id' => $result['data']['merchantTransactionId'],
            'redirect_url' => $result['data']['instrumentResponse']['redirectInfo']['url']
        ];
    }

    public function verify($payment_id) {
        $api_url = $this->mode === 'test'
            ? "https://api-test.phonepe.com/apis/hermes/pg/v1/status/{$this->merchant_id}/{$payment_id}"
            : "https://api.phonepe.com/apis/hermes/pg/v1/status/{$this->merchant_id}/{$payment_id}";

        $checksum = hash('sha256', '/pg/v1/status/' . $this->merchant_id . '/' . $payment_id . $this->api_key);

        $ch = curl_init($api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'X-MERCHANT-ID: ' . $this->merchant_id,
            'X-VERIFY: ' . $checksum
        ]);

        $response = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($status !== 200) {
            throw new Exception('Failed to verify PhonePe payment');
        }

        return json_decode($response, true);
    }
}
?>
