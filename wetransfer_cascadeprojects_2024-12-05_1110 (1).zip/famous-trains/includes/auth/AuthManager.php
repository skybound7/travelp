<?php
class AuthManager {
    private $conn;
    private $table = 'users';

    public function __construct() {
        require_once __DIR__ . '/../config/database.php';
        $this->conn = $conn;
    }

    public function register($data) {
        // Validate input
        if (empty($data['email']) || empty($data['password']) || empty($data['name'])) {
            throw new Exception('All fields are required');
        }

        // Check if email already exists
        $stmt = $this->conn->prepare("SELECT id FROM {$this->table} WHERE email = ?");
        $stmt->bind_param("s", $data['email']);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            throw new Exception('Email already registered');
        }

        // Hash password
        $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);

        // Insert user
        $stmt = $this->conn->prepare("
            INSERT INTO {$this->table} (name, email, password, created_at)
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->bind_param("sss", $data['name'], $data['email'], $hashedPassword);

        if (!$stmt->execute()) {
            throw new Exception('Registration failed');
        }

        return $stmt->insert_id;
    }

    public function login($email, $password) {
        // Validate input
        if (empty($email) || empty($password)) {
            throw new Exception('Email and password are required');
        }

        // Get user
        $stmt = $this->conn->prepare("
            SELECT id, name, email, password, status
            FROM {$this->table}
            WHERE email = ?
        ");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            throw new Exception('Invalid credentials');
        }

        $user = $result->fetch_assoc();

        // Verify password
        if (!password_verify($password, $user['password'])) {
            throw new Exception('Invalid credentials');
        }

        // Check if account is active
        if ($user['status'] !== 'active') {
            throw new Exception('Account is not active');
        }

        // Create session
        session_start();
        $_SESSION['user'] = [
            'id' => $user['id'],
            'name' => $user['name'],
            'email' => $user['email']
        ];

        return $_SESSION['user'];
    }

    public function getCurrentUser() {
        session_start();
        return $_SESSION['user'] ?? null;
    }

    public function logout() {
        session_start();
        session_destroy();
    }

    public function updateProfile($userId, $data) {
        $allowedFields = ['name', 'phone', 'address', 'preferences'];
        $updates = [];
        $types = "";
        $values = [];

        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updates[] = "{$field} = ?";
                $types .= "s";
                $values[] = $data[$field];
            }
        }

        if (empty($updates)) {
            return true;
        }

        $values[] = $userId;
        $types .= "i";

        $sql = "UPDATE {$this->table} SET " . implode(", ", $updates) . " WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param($types, ...$values);

        return $stmt->execute();
    }

    public function changePassword($userId, $currentPassword, $newPassword) {
        // Get current user
        $stmt = $this->conn->prepare("SELECT password FROM {$this->table} WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        // Verify current password
        if (!password_verify($currentPassword, $user['password'])) {
            throw new Exception('Current password is incorrect');
        }

        // Hash new password
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        // Update password
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $hashedPassword, $userId);

        return $stmt->execute();
    }

    public function resetPasswordRequest($email) {
        // Generate token
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

        // Store reset token
        $stmt = $this->conn->prepare("
            UPDATE {$this->table}
            SET reset_token = ?, reset_token_expiry = ?
            WHERE email = ?
        ");
        $stmt->bind_param("sss", $token, $expiry, $email);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to create reset token');
        }

        return $token;
    }

    public function resetPassword($token, $newPassword) {
        // Verify token and expiry
        $stmt = $this->conn->prepare("
            SELECT id
            FROM {$this->table}
            WHERE reset_token = ? AND reset_token_expiry > NOW()
        ");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            throw new Exception('Invalid or expired reset token');
        }

        $user = $result->fetch_assoc();
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        // Update password and clear token
        $stmt = $this->conn->prepare("
            UPDATE {$this->table}
            SET password = ?, reset_token = NULL, reset_token_expiry = NULL
            WHERE id = ?
        ");
        $stmt->bind_param("si", $hashedPassword, $user['id']);

        return $stmt->execute();
    }
}
