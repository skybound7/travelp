// Train Data
const trainData = [
    {
        id: 1,
        name: "Orient Express",
        route: "Paris to Istanbul",
        description: "Experience the world's most iconic luxury train journey through Europe.",
        destination: "Europe",
        image: "orient-express.jpg",
        price: 9000,
        duration: "6 days",
        distance: 3000
    },
    {
        id: 2,
        name: "Rocky Mountaineer",
        route: "Vancouver to Banff",
        description: "Discover the majestic Canadian Rockies in unparalleled luxury.",
        destination: "North America",
        image: "rocky-mountaineer.jpg",
        price: 3000,
        duration: "2 days",
        distance: 1000
    },
    {
        id: 3,
        name: "Palace on Wheels",
        route: "Delhi to Rajasthan",
        description: "Experience the royal heritage of India in ultimate luxury.",
        destination: "Asia",
        image: "palace-wheels.jpg",
        price: 5000,
        duration: "7 days",
        distance: 2500
    }
];

// State Management
let selectedTrains = [];
let activeFilters = [];
let currentSort = 'featured';
const maxComboTrains = 5;

// DOM Elements - Initialize after DOM content is loaded
let trainListings;
let filterCheckboxes;
let sortOptions;
let resetButton;
let trainSelect;
let proceedComboButton;
let bookingForm;
let stripe;
let elements;
let paymentElement;

// Initialize all DOM elements
function initializeElements() {
    try {
        trainListings = document.getElementById('trainListings');
        filterCheckboxes = document.querySelectorAll('.trains-archive-sidebar__checkbox');
        sortOptions = document.querySelectorAll('.trains-archive__header-sort-values li');
        resetButton = document.querySelector('.trains-archive-sidebar__reset');
        trainSelect = document.getElementById('trainSelect');
        proceedComboButton = document.getElementById('proceed-combo');
        bookingForm = document.getElementById('train-booking-form');

        if (!trainListings || !filterCheckboxes || !sortOptions || !resetButton || 
            !trainSelect || !proceedComboButton || !bookingForm) {
            throw new Error('Required DOM elements not found');
        }

        // Initialize Stripe
        stripe = Stripe('your_publishable_key'); // Replace with your key
        elements = stripe.elements();
        paymentElement = elements.create('payment');
        paymentElement.mount('#payment-element');

        return true;
    } catch (error) {
        console.error('Initialization error:', error);
        return false;
    }
}

// Combo Functions
function addToItinerary(trainId) {
    try {
        const train = trainData.find(t => t.id === trainId);
        if (!train) {
            throw new Error('Train not found');
        }

        if (selectedTrains.length >= maxComboTrains) {
            alert(`Maximum ${maxComboTrains} trains allowed in a combo itinerary`);
            return;
        }

        if (selectedTrains.some(t => t.id === trainId)) {
            alert('This train is already in your itinerary');
            return;
        }

        selectedTrains.push(train);
        updateItinerarySummary();
        renderSelectedTrains();
    } catch (error) {
        console.error('Error adding to itinerary:', error);
        alert('Failed to add train to itinerary');
    }
}

function removeFromItinerary(trainId) {
    try {
        selectedTrains = selectedTrains.filter(t => t.id !== trainId);
        updateItinerarySummary();
        renderSelectedTrains();
    } catch (error) {
        console.error('Error removing from itinerary:', error);
    }
}

function renderSelectedTrains() {
    try {
        const container = document.querySelector('.selected-trains-list');
        if (!container) return;

        if (selectedTrains.length === 0) {
            container.innerHTML = '<p class="text-muted">No trains selected. Click "Add to Itinerary" on any train to start building your combo journey.</p>';
            return;
        }

        container.innerHTML = selectedTrains.map((train, index) => `
            <div class="selected-train-item card mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h4 class="h6 mb-1">${index + 1}. ${train.name}</h4>
                            <p class="small text-muted mb-1">${train.route}</p>
                            <p class="small mb-0">$${train.price.toLocaleString()}</p>
                        </div>
                        <button class="btn btn-sm btn-outline-danger" onclick="removeFromItinerary(${train.id})">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error rendering selected trains:', error);
    }
}

function updateItinerarySummary() {
    try {
        const totalPrice = calculateTotalPrice();
        const discountedPrice = applyComboDiscount(totalPrice);
        const destinations = new Set(selectedTrains.map(t => t.destination));
        const totalDistance = selectedTrains.reduce((total, train) => total + train.distance, 0);
        const totalDuration = selectedTrains.reduce((total, train) => {
            const days = parseInt(train.duration);
            return total + (isNaN(days) ? 0 : days);
        }, 0);

        document.getElementById('total-duration').textContent = `${totalDuration} days`;
        document.getElementById('total-distance').textContent = `${totalDistance.toLocaleString()} km`;
        document.getElementById('total-price').textContent = `$${discountedPrice.toLocaleString()}`;
        document.getElementById('destination-count').textContent = destinations.size;

        if (proceedComboButton) {
            proceedComboButton.disabled = selectedTrains.length === 0;
        }
    } catch (error) {
        console.error('Error updating itinerary summary:', error);
    }
}

function calculateTotalPrice() {
    return selectedTrains.reduce((total, train) => total + train.price, 0);
}

function applyComboDiscount(totalPrice) {
    let discount = 0;
    if (selectedTrains.length >= 4) discount = 0.20;
    else if (selectedTrains.length === 3) discount = 0.15;
    else if (selectedTrains.length === 2) discount = 0.10;
    return totalPrice * (1 - discount);
}

function handleComboBooking() {
    try {
        if (selectedTrains.length === 0) {
            alert('Please select at least one train for your itinerary');
            return;
        }

        // Prepare booking data
        const bookingData = {
            trains: selectedTrains.map(train => ({
                id: train.id,
                name: train.name,
                price: train.price
            })),
            totalPrice: applyComboDiscount(calculateTotalPrice()),
            destinations: Array.from(new Set(selectedTrains.map(t => t.destination)))
        };

        // Update form for combo booking
        trainSelect.innerHTML = selectedTrains.map(train => 
            `<option value="${train.id}" selected disabled>${train.name}</option>`
        ).join('');
        
        // Update price display and scroll to form
        document.getElementById('total-price').textContent = 
            `$${bookingData.totalPrice.toLocaleString()}`;
        document.getElementById('booking-form').scrollIntoView({ behavior: 'smooth' });
    } catch (error) {
        console.error('Error handling combo booking:', error);
        alert('Failed to process combo booking');
    }
}

// Initialize everything after DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    try {
        // Initialize DOM elements
        if (!initializeElements()) {
            throw new Error('Failed to initialize application');
        }

        // Render initial train listings
        renderTrains(trainData);
        updateTrainCount(trainData.length);

        // Add event listeners
        filterCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('click', () => {
                const destination = checkbox.getAttribute('data-slug');
                
                if (activeFilters.includes(destination)) {
                    activeFilters = activeFilters.filter(f => f !== destination);
                    checkbox.classList.remove('active');
                } else {
                    activeFilters.push(destination);
                    checkbox.classList.add('active');
                }
                
                filterTrains();
            });
        });

        sortOptions.forEach(option => {
            option.addEventListener('click', () => {
                currentSort = option.getAttribute('data-value');
                sortOptions.forEach(opt => opt.classList.remove('active'));
                option.classList.add('active');
                
                const sortValue = document.querySelector('.trains-archive__header-sort-value');
                if (sortValue) {
                    sortValue.textContent = option.textContent;
                }
                
                filterTrains();
            });
        });

        resetButton.addEventListener('click', () => {
            activeFilters = [];
            currentSort = 'featured';
            filterCheckboxes.forEach(checkbox => checkbox.classList.remove('active'));
            sortOptions[0].click();
            filterTrains();
        });

        proceedComboButton.addEventListener('click', handleComboBooking);
        bookingForm.addEventListener('submit', handleBooking);
        
        // Add event listeners for price updates
        trainSelect.addEventListener('change', updatePrice);
        document.getElementById('passengers')?.addEventListener('change', updatePrice);
        document.getElementById('class')?.addEventListener('change', updatePrice);

    } catch (error) {
        console.error('Application initialization error:', error);
        alert('Failed to initialize the application. Please refresh the page.');
    }
});

// Utility Functions
function filterTrains() {
    try {
        let filteredTrains = trainData;
        
        if (activeFilters.length > 0) {
            filteredTrains = trainData.filter(train => 
                activeFilters.includes(train.destination.toLowerCase())
            );
        }

        switch(currentSort) {
            case 'title-asc':
                filteredTrains.sort((a, b) => a.name.localeCompare(b.name));
                break;
            case 'title-desc':
                filteredTrains.sort((a, b) => b.name.localeCompare(a.name));
                break;
        }

        renderTrains(filteredTrains);
        updateTrainCount(filteredTrains.length);
    } catch (error) {
        console.error('Error filtering trains:', error);
    }
}

function updateTrainCount(count) {
    try {
        const countElement = document.querySelector('.trains-archive__header-count');
        if (countElement) {
            countElement.textContent = `Showing ${count} of ${trainData.length} Trains`;
        }
    } catch (error) {
        console.error('Error updating train count:', error);
    }
}

function updatePrice() {
    try {
        const selectedTrain = trainData.find(t => t.id === parseInt(trainSelect.value));
        const passengers = parseInt(document.getElementById('passengers').value) || 1;
        const classMultiplier = {
            'first': 1.5,
            'second': 1.0,
            'sleeper': 1.3
        }[document.getElementById('class').value] || 1.0;

        if (selectedTrain) {
            const totalPrice = selectedTrain.price * passengers * classMultiplier;
            document.getElementById('total-price').textContent = 
                `Total: $${totalPrice.toLocaleString()}`;
        }
    } catch (error) {
        console.error('Error updating price:', error);
    }
}

// Handle form submission
async function handleBooking(event) {
    try {
        event.preventDefault();
        
        if (!validateForm()) {
            return;
        }

        const response = await fetch('/api/create-payment-intent.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                trainId: trainSelect.value,
                passengers: document.getElementById('passengers').value,
                class: document.getElementById('class').value,
                totalPrice: document.getElementById('total-price').textContent
            })
        });

        if (!response.ok) {
            throw new Error('Payment failed');
        }

        const result = await response.json();
        
        if (result.error) {
            throw new Error(result.error);
        }

        alert('Booking successful! Confirmation email will be sent shortly.');
        window.location.href = '/booking-confirmation.html';

    } catch (error) {
        console.error('Booking error:', error);
        alert('Failed to process booking. Please try again.');
    }
}

function validateForm() {
    const requiredFields = ['name', 'email', 'phone', 'passengers', 'class', 'journeyDate'];
    let isValid = true;

    requiredFields.forEach(field => {
        const element = document.getElementById(field);
        if (!element || !element.value.trim()) {
            isValid = false;
            element?.classList.add('is-invalid');
        } else {
            element?.classList.remove('is-invalid');
        }
    });

    return isValid;
}

function renderTrains(trains) {
    try {
        trainListings.innerHTML = trains.map(train => `
            <div class="trains-archive-post">
                <div class="trains-archive-post__content">
                    <div class="trains-archive-post__thumbnail" style="background-image: url(images/${train.image});">
                        <div class="trains-archive-post__thumbnail-badge"></div>
                    </div>
                    <h2 class="trains-archive-post__title">${train.name}</h2>
                    <p>${train.description}</p>
                    <div class="trains-archive-post__value trains-archive-post__value--destination">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 13.33 13.33">
                            <path fill="#022e4d" d="M10.68,10.26a1.33,1.33,0,0,0-1.27-.93H8.75v-2a.67.67,0,0,0-.67-.66h-4V5.33H5.41a.66.66,0,0,0,.67-.66V3.33H7.41A1.33,1.33,0,0,0,8.75,2V1.73a5.33,5.33,0,0,1,2.93,7A5.23,5.23,0,0,1,10.68,10.26ZM6.08,12A5.34,5.34,0,0,1,1.41,6.67a6.14,6.14,0,0,1,.14-1.2l3.2,3.2v.66a1.34,1.34,0,0,0,1.33,1.34ZM6.75,0a6.67,6.67,0,1,0-.16,13.33h.16A6.67,6.67,0,0,0,6.75,0Z"></path>
                        </svg>
                        <span>${train.destination}</span>
                    </div>
                    <div class="trains-archive-post__actions mt-3">
                        <button class="btn btn-primary me-2" onclick="addToItinerary(${train.id})">
                            Add to Itinerary
                        </button>
                        <button class="btn btn-outline-primary" onclick="scrollToBooking(${train.id})">
                            Book Now
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error rendering trains:', error);
    }
}

function scrollToBooking(trainId) {
    trainSelect.value = trainId;
    document.getElementById('booking-form').scrollIntoView({ behavior: 'smooth' });
}
