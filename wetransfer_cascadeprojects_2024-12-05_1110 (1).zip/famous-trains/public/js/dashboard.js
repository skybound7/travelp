class Dashboard {
    constructor() {
        this.user = null;
        this.bookings = [];
        this.passes = [];
        
        this.initializeEventListeners();
        this.checkAuth();
    }

    async checkAuth() {
        try {
            const response = await fetch('/api/auth/check.php');
            if (!response.ok) {
                window.location.href = '/login.html';
                return;
            }
            
            this.user = await response.json();
            this.loadUserData();
            this.loadDashboard();
        } catch (error) {
            console.error('Auth check failed:', error);
            window.location.href = '/login.html';
        }
    }

    initializeEventListeners() {
        // Profile form submission
        document.getElementById('profileForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.updateProfile();
        });

        // Password form submission
        document.getElementById('passwordForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.updatePassword();
        });
    }

    loadUserData() {
        // Update user information in the UI
        document.getElementById('userGreeting').textContent = `Welcome, ${this.user.name}`;
        document.getElementById('userName').textContent = this.user.name;
        document.getElementById('userEmail').textContent = this.user.email;

        // Populate profile form
        const profileForm = document.getElementById('profileForm');
        profileForm.elements['name'].value = this.user.name;
        profileForm.elements['email'].value = this.user.email;
        profileForm.elements['phone'].value = this.user.phone || '';
        profileForm.elements['address'].value = this.user.address || '';
    }

    async loadDashboard() {
        await Promise.all([
            this.loadBookings(),
            this.loadPasses(),
            this.loadStats()
        ]);
    }

    async loadBookings() {
        try {
            const response = await fetch('/api/bookings/list.php');
            if (!response.ok) throw new Error('Failed to load bookings');
            
            this.bookings = await response.json();
            this.renderBookings();
            this.renderUpcomingJourneys();
        } catch (error) {
            console.error('Error loading bookings:', error);
            this.showError('Failed to load bookings');
        }
    }

    async loadPasses() {
        try {
            const response = await fetch('/api/passes/list.php');
            if (!response.ok) throw new Error('Failed to load passes');
            
            this.passes = await response.json();
            this.renderPasses();
        } catch (error) {
            console.error('Error loading passes:', error);
            this.showError('Failed to load passes');
        }
    }

    async loadStats() {
        try {
            const response = await fetch('/api/user/stats.php');
            if (!response.ok) throw new Error('Failed to load statistics');
            
            const stats = await response.json();
            
            document.getElementById('activeBookingsCount').textContent = stats.active_bookings;
            document.getElementById('validPassesCount').textContent = stats.valid_passes;
            document.getElementById('totalTripsCount').textContent = stats.total_trips;
        } catch (error) {
            console.error('Error loading stats:', error);
        }
    }

    renderBookings(filter = 'all') {
        const bookingsList = document.getElementById('bookingsList');
        const filteredBookings = this.filterBookings(this.bookings, filter);

        bookingsList.innerHTML = filteredBookings.map(booking => `
            <div class="col-md-6">
                <div class="card booking-card h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="card-title mb-0">${booking.route_name}</h5>
                            <span class="badge bg-${this.getStatusBadgeClass(booking.status)}">
                                ${booking.status}
                            </span>
                        </div>
                        
                        <p class="card-text text-muted mb-3">
                            <i class="bi bi-calendar-event me-2"></i>${new Date(booking.journey_date).toLocaleDateString()}
                        </p>
                        
                        <div class="d-flex justify-content-between mb-3">
                            <span>
                                <i class="bi bi-people me-2"></i>${booking.passengers} passenger(s)
                            </span>
                            <span>
                                <i class="bi bi-tag me-2"></i>€${booking.total_amount}
                            </span>
                        </div>

                        <div class="d-grid gap-2">
                            <button class="btn btn-outline-primary btn-sm" onclick="dashboard.viewBookingDetails(${booking.id})">
                                View Details
                            </button>
                            ${this.getBookingActions(booking)}
                        </div>
                    </div>
                </div>
            </div>
        `).join('');
    }

    renderPasses() {
        const passesList = document.getElementById('passesList');
        passesList.innerHTML = this.passes.map(pass => `
            <div class="col-md-6">
                <div class="card booking-card h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="card-title mb-0">${pass.pass_type} Pass</h5>
                            <span class="badge bg-${this.getPassStatusBadgeClass(pass.status)}">
                                ${pass.status}
                            </span>
                        </div>
                        
                        <p class="card-text text-muted mb-3">
                            <i class="bi bi-calendar-event me-2"></i>Valid: ${new Date(pass.start_date).toLocaleDateString()} - ${new Date(pass.end_date).toLocaleDateString()}
                        </p>
                        
                        <div class="mb-3">
                            <span class="badge bg-light text-dark me-2">
                                ${pass.duration}
                            </span>
                            <span class="badge bg-light text-dark">
                                ${pass.travel_class} Class
                            </span>
                        </div>

                        <div class="d-grid">
                            <button class="btn btn-outline-primary btn-sm" onclick="dashboard.viewPassDetails(${pass.id})">
                                View Details
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');
    }

    renderUpcomingJourneys() {
        const upcomingJourneys = document.getElementById('upcomingJourneys');
        const journeys = this.bookings
            .filter(booking => new Date(booking.journey_date) > new Date() && booking.status === 'confirmed')
            .sort((a, b) => new Date(a.journey_date) - new Date(b.journey_date))
            .slice(0, 3);

        if (journeys.length === 0) {
            upcomingJourneys.innerHTML = `
                <div class="text-center py-4">
                    <p class="text-muted mb-0">No upcoming journeys</p>
                </div>
            `;
            return;
        }

        upcomingJourneys.innerHTML = journeys.map(journey => `
            <div class="d-flex align-items-center p-3 border-bottom">
                <div class="flex-grow-1">
                    <h6 class="mb-1">${journey.route_name}</h6>
                    <p class="text-muted small mb-0">
                        <i class="bi bi-calendar-event me-2"></i>${new Date(journey.journey_date).toLocaleDateString()}
                    </p>
                </div>
                <button class="btn btn-sm btn-outline-primary" onclick="dashboard.viewBookingDetails(${journey.id})">
                    Details
                </button>
            </div>
        `).join('');
    }

    filterBookings(bookings, filter) {
        const now = new Date();
        switch (filter) {
            case 'upcoming':
                return bookings.filter(booking => new Date(booking.journey_date) > now);
            case 'past':
                return bookings.filter(booking => new Date(booking.journey_date) <= now);
            default:
                return bookings;
        }
    }

    getStatusBadgeClass(status) {
        switch (status.toLowerCase()) {
            case 'confirmed': return 'success';
            case 'pending': return 'warning';
            case 'cancelled': return 'danger';
            default: return 'secondary';
        }
    }

    getPassStatusBadgeClass(status) {
        switch (status.toLowerCase()) {
            case 'active': return 'success';
            case 'expired': return 'secondary';
            case 'pending': return 'warning';
            default: return 'secondary';
        }
    }

    getBookingActions(booking) {
        const journeyDate = new Date(booking.journey_date);
        const now = new Date();
        
        if (journeyDate > now && booking.status === 'confirmed') {
            return `
                <button class="btn btn-outline-danger btn-sm" onclick="dashboard.cancelBooking(${booking.id})">
                    Cancel Booking
                </button>
            `;
        }
        return '';
    }

    async viewBookingDetails(bookingId) {
        // Implement booking details view
        window.location.href = `/booking-details.html?id=${bookingId}`;
    }

    async viewPassDetails(passId) {
        // Implement pass details view
        window.location.href = `/pass-details.html?id=${passId}`;
    }

    async cancelBooking(bookingId) {
        if (!confirm('Are you sure you want to cancel this booking?')) {
            return;
        }

        try {
            const response = await fetch(`/api/bookings/cancel.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ booking_id: bookingId })
            });

            if (!response.ok) throw new Error('Failed to cancel booking');

            this.showSuccess('Booking cancelled successfully');
            this.loadBookings();
        } catch (error) {
            console.error('Error cancelling booking:', error);
            this.showError('Failed to cancel booking');
        }
    }

    async updateProfile() {
        const form = document.getElementById('profileForm');
        const formData = new FormData(form);

        try {
            const response = await fetch('/api/user/update-profile.php', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) throw new Error('Failed to update profile');

            this.showSuccess('Profile updated successfully');
            this.user = await response.json();
            this.loadUserData();
        } catch (error) {
            console.error('Error updating profile:', error);
            this.showError('Failed to update profile');
        }
    }

    async updatePassword() {
        const form = document.getElementById('passwordForm');
        const formData = new FormData(form);

        if (formData.get('newPassword') !== formData.get('confirmPassword')) {
            this.showError('New passwords do not match');
            return;
        }

        try {
            const response = await fetch('/api/user/change-password.php', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) throw new Error('Failed to update password');

            this.showSuccess('Password updated successfully');
            form.reset();
        } catch (error) {
            console.error('Error updating password:', error);
            this.showError('Failed to update password');
        }
    }

    async logout() {
        try {
            await fetch('/api/auth/logout.php');
            window.location.href = '/login.html';
        } catch (error) {
            console.error('Error logging out:', error);
        }
    }

    showError(message) {
        // Implement error notification
        alert(message);
    }

    showSuccess(message) {
        // Implement success notification
        alert(message);
    }
}

// Initialize dashboard
const dashboard = new Dashboard();
