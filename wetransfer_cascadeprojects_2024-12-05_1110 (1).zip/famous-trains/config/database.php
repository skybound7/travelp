<?php
require_once __DIR__ . '/../utils/Debug.php';

class Database {
    private static $instance = null;
    private $pdo;
    private $inTransaction = false;
    private $transactionLevel = 0;
    private static $queryCount = 0;

    private function __construct() {
        try {
            $dsn = sprintf(
                "mysql:host=%s;dbname=%s;charset=utf8mb4",
                getenv('DB_HOST') ?: 'localhost',
                getenv('DB_NAME') ?: 'famous_trains'
            );

            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
            ];

            $this->pdo = new PDO(
                $dsn,
                getenv('DB_USER') ?: 'root',
                getenv('DB_PASS') ?: '',
                $options
            );

            // Enable query logging in debug mode
            if (Debug::isDebugMode()) {
                $this->pdo->setAttribute(PDO::ATTR_STATEMENT_CLASS, ['DebugPDOStatement', [$this->pdo]]);
            }

        } catch (PDOException $e) {
            Debug::logError('Database connection failed', [
                'error' => $e->getMessage(),
                'dsn' => $dsn
            ]);
            throw new Exception('Database connection failed');
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public static function getConnection() {
        return self::getInstance()->pdo;
    }

    public function prepare($query) {
        $startTime = microtime(true);
        try {
            $stmt = $this->pdo->prepare($query);
            $executionTime = microtime(true) - $startTime;
            
            Debug::logQuery($query, [], $executionTime);
            self::$queryCount++;
            
            return $stmt;
        } catch (PDOException $e) {
            Debug::logError('Query preparation failed', [
                'query' => $query,
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }

    public function beginTransaction() {
        if (!$this->inTransaction) {
            $this->pdo->beginTransaction();
            $this->inTransaction = true;
        }
        $this->transactionLevel++;
    }

    public function commit() {
        if ($this->inTransaction && $this->transactionLevel === 1) {
            $this->pdo->commit();
            $this->inTransaction = false;
        }
        $this->transactionLevel--;
    }

    public function rollBack() {
        if ($this->inTransaction) {
            $this->pdo->rollBack();
            $this->inTransaction = false;
            $this->transactionLevel = 0;
        }
    }

    public static function getQueryCount() {
        return self::$queryCount;
    }

    public function __destruct() {
        // Log final database statistics
        if (Debug::isDebugMode()) {
            Debug::logWarning('Database statistics', [
                'query_count' => self::$queryCount,
                'in_transaction' => $this->inTransaction,
                'transaction_level' => $this->transactionLevel
            ]);
        }
    }
}

// Custom PDOStatement class for query debugging
class DebugPDOStatement extends PDOStatement {
    protected $pdo;
    
    protected function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function execute($params = null) {
        $startTime = microtime(true);
        
        try {
            $result = parent::execute($params);
            $executionTime = microtime(true) - $startTime;
            
            Debug::logQuery($this->queryString, $params, $executionTime);
            return $result;
            
        } catch (PDOException $e) {
            Debug::logError('Query execution failed', [
                'query' => $this->queryString,
                'params' => $params,
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }
}
