<?php
return [
    'database' => [
        'host' => 'localhost',
        'name' => 'famous_trains',
        'user' => 'root',  // Change this to your database username
        'password' => ''   // Change this to your database password
    ],
    'api' => [
        'version' => '1.0',
        'base_url' => '/api'
    ],
    'app' => [
        'name' => 'Famous Trains',
        'environment' => 'development',  // Change to 'production' for live environment
        'debug' => true,                // Set to false in production
        'timezone' => 'UTC'
    ],
    'security' => [
        'jwt_secret' => 'your-secret-key',  // Change this to a secure secret key
        'token_expiry' => 86400  // 24 hours in seconds
    ]
];
