<?php
require_once '../../../includes/config/database.php';
require_once '../../../includes/config/payment.php';
require_once '../../../includes/payments/PayPalPaymentProcessor.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET' || empty($_GET['token']) || empty($_GET['booking_id'])) {
    header('Location: /booking-failed.html');
    exit;
}

try {
    $payment = new PayPalPaymentProcessor();
    $result = $payment->verify($_GET['token']);

    if ($result['status'] === 'COMPLETED') {
        // Update booking status
        $stmt = $conn->prepare("UPDATE bookings SET payment_status = ? WHERE id = ?");
        $status = PAYMENT_STATUS_COMPLETED;
        $stmt->bind_param("si", $status, $_GET['booking_id']);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to update booking status');
        }

        // Send confirmation email
        $booking_stmt = $conn->prepare("SELECT * FROM bookings WHERE id = ?");
        $booking_stmt->bind_param("i", $_GET['booking_id']);
        $booking_stmt->execute();
        $booking = $booking_stmt->get_result()->fetch_assoc();

        $to = $booking['email'];
        $subject = "Train Booking Confirmation - Booking #{$_GET['booking_id']}";
        $message = "Dear {$booking['customer_name']},\n\n";
        $message .= "Your train booking has been confirmed!\n\n";
        $message .= "Booking Details:\n";
        $message .= "Train: {$booking['train_id']}\n";
        $message .= "Date: {$booking['journey_date']}\n";
        $message .= "Class: {$booking['class']}\n";
        $message .= "Passengers: {$booking['passengers']}\n";
        $message .= "Amount Paid: $" . number_format($booking['total_amount'], 2) . "\n\n";
        $message .= "Thank you for choosing our service!\n";
        
        $headers = "From: bookings@your-domain.com";
        
        mail($to, $subject, $message, $headers);

        header('Location: /booking-success.html');
    } else {
        throw new Exception('Payment not completed');
    }
} catch (Exception $e) {
    error_log("PayPal callback error: " . $e->getMessage());
    header('Location: /booking-failed.html');
}
?>
