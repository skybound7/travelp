<?php
class Authorization {
    private $db;
    private $userId;
    private $userRoles;
    private $userPermissions;
    
    public function __construct($userId = null) {
        $this->db = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME,
            DB_USER,
            DB_PASS
        );
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        if ($userId) {
            $this->userId = $userId;
            $this->loadUserRolesAndPermissions();
        }
    }
    
    private function loadUserRolesAndPermissions() {
        try {
            // Load user roles
            $stmt = $this->db->prepare(
                "SELECT r.name as role_name 
                 FROM roles r 
                 JOIN user_roles ur ON r.id = ur.role_id 
                 WHERE ur.user_id = ?"
            );
            $stmt->execute([$this->userId]);
            $this->userRoles = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            // Load user permissions
            $stmt = $this->db->prepare(
                "SELECT DISTINCT p.name as permission_name 
                 FROM permissions p 
                 JOIN role_permissions rp ON p.id = rp.permission_id 
                 JOIN user_roles ur ON rp.role_id = ur.role_id 
                 WHERE ur.user_id = ?"
            );
            $stmt->execute([$this->userId]);
            $this->userPermissions = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
        } catch (Exception $e) {
            error_log("Error loading user roles and permissions: " . $e->getMessage());
            throw $e;
        }
    }
    
    public function hasRole($role) {
        return in_array($role, $this->userRoles);
    }
    
    public function hasPermission($permission) {
        return in_array($permission, $this->userPermissions);
    }
    
    public function requirePermission($permission) {
        if (!$this->hasPermission($permission)) {
            http_response_code(403);
            echo json_encode([
                'status' => 'error',
                'message' => 'Access denied: Insufficient permissions'
            ]);
            exit;
        }
    }
    
    public function requireRole($role) {
        if (!$this->hasRole($role)) {
            http_response_code(403);
            echo json_encode([
                'status' => 'error',
                'message' => 'Access denied: Insufficient role'
            ]);
            exit;
        }
    }
    
    public function getUserPermissions() {
        return $this->userPermissions;
    }
    
    public function getUserRoles() {
        return $this->userRoles;
    }
}

// Example usage in protected routes:
/*
require_once 'authorization.php';

// Initialize authorization with user ID
$auth = new Authorization($_REQUEST['user_id']);

// Check specific permission
$auth->requirePermission('booking.create');

// Check role
$auth->requireRole('staff');

// Continue with route logic...
*/
