<?php
require_once '../includes/config/database.php';
require_once '../includes/config/payment.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);
if (!$data) {
    $data = $_POST;
}

// Validate required fields
$required_fields = ['pass-type', 'duration', 'class', 'start-date', 'travelers', 'payment_method', 'policy_accepted'];
foreach ($required_fields as $field) {
    if (empty($data[$field])) {
        http_response_code(400);
        echo json_encode(['error' => "Missing required field: {$field}"]);
        exit;
    }
}

// Validate policy acceptance
if (!isset($data['policy_accepted']) || $data['policy_accepted'] !== 'on') {
    http_response_code(400);
    echo json_encode(['error' => 'You must accept the Eurail Pass policies to proceed with booking']);
    exit;
}

// Price calculation logic
$prices = [
    'global' => [
        '3-days' => ['first' => 320, 'second' => 251],
        '5-days' => ['first' => 388, 'second' => 305],
        '7-days' => ['first' => 474, 'second' => 366],
        '15-days' => ['first' => 673, 'second' => 515],
        '1-month' => ['first' => 884, 'second' => 675]
    ],
    'one-country' => [
        '3-days' => ['first' => 230, 'second' => 168],
        '5-days' => ['first' => 290, 'second' => 215],
        '7-days' => ['first' => 348, 'second' => 255],
        '15-days' => ['first' => 449, 'second' => 329],
        '1-month' => ['first' => 554, 'second' => 405]
    ],
    'select' => [
        '3-days' => ['first' => 250, 'second' => 185],
        '5-days' => ['first' => 310, 'second' => 235],
        '7-days' => ['first' => 368, 'second' => 275],
        '15-days' => ['first' => 469, 'second' => 349],
        '1-month' => ['first' => 574, 'second' => 425]
    ]
];

$base_price = $prices[$data['pass-type']][$data['duration']][$data['class']];
$total_price = $base_price * intval($data['travelers']);

// Create booking record
$stmt = $conn->prepare("INSERT INTO eurail_bookings (
    pass_type, 
    duration, 
    travel_class, 
    start_date, 
    travelers, 
    total_amount, 
    payment_status,
    policy_accepted,
    policy_version
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param("ssssidsss", 
    $data['pass-type'],
    $data['duration'],
    $data['class'],
    $data['start-date'],
    $data['travelers'],
    $total_price,
    $payment_status,
    $policy_accepted,
    $policy_version
);

$payment_status = PAYMENT_STATUS_PENDING;
$policy_accepted = true;
$policy_version = '1.0'; // Current policy version

if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to create booking']);
    exit;
}

$booking_id = $stmt->insert_id;

// Initialize payment based on selected method
switch ($data['payment_method']) {
    case 'paypal':
        require_once '../includes/payments/PayPalPaymentProcessor.php';
        $payment = new PayPalPaymentProcessor();
        break;
    case 'card':
        require_once '../includes/payments/StripePaymentProcessor.php';
        $payment = new StripePaymentProcessor();
        break;
    default:
        http_response_code(400);
        echo json_encode(['error' => 'Invalid payment method']);
        exit;
}

try {
    $payment_data = $payment->initiate([
        'amount' => $total_price,
        'currency' => 'EUR',
        'booking_id' => $booking_id,
        'description' => "Eurail {$data['pass-type']} Pass - {$data['duration']} ({$data['class']} class)",
        'customer_email' => $data['email'] ?? ''
    ]);

    echo json_encode([
        'success' => true,
        'booking_id' => $booking_id,
        'payment_data' => $payment_data
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
