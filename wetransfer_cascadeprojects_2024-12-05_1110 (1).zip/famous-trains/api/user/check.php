<?php
require_once __DIR__ . '/../../includes/auth/AuthManager.php';

header('Content-Type: application/json');

$auth = new AuthManager();
$user = $auth->getCurrentUser();

if (!$user) {
    http_response_code(401);
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}

echo json_encode($user);
