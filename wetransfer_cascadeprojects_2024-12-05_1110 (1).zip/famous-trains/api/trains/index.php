<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

require_once __DIR__ . '/../../config/database.php';

try {
    $pdo = Database::getConnection();
    
    // Get query parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    $sort = isset($_GET['sort']) ? $_GET['sort'] : 'popular';
    $destination = isset($_GET['destination']) ? $_GET['destination'] : null;
    $minPrice = isset($_GET['minPrice']) ? (float)$_GET['minPrice'] : null;
    $maxPrice = isset($_GET['maxPrice']) ? (float)$_GET['maxPrice'] : null;
    
    // Base query
    $query = "SELECT t.*, 
              GROUP_CONCAT(DISTINCT a.name) as amenities,
              COUNT(DISTINCT r.id) as review_count,
              AVG(r.rating) as average_rating
              FROM trains t
              LEFT JOIN train_amenities ta ON t.id = ta.train_id
              LEFT JOIN amenities a ON ta.amenity_id = a.id
              LEFT JOIN reviews r ON t.id = r.train_id
              WHERE 1=1";
    
    $params = [];
    
    // Apply filters
    if ($destination) {
        $query .= " AND t.destination = ?";
        $params[] = $destination;
    }
    
    if ($minPrice !== null) {
        $query .= " AND t.price >= ?";
        $params[] = $minPrice;
    }
    
    if ($maxPrice !== null) {
        $query .= " AND t.price <= ?";
        $params[] = $maxPrice;
    }
    
    $query .= " GROUP BY t.id";
    
    // Apply sorting
    switch ($sort) {
        case 'price-low':
            $query .= " ORDER BY t.price ASC";
            break;
        case 'price-high':
            $query .= " ORDER BY t.price DESC";
            break;
        case 'duration':
            $query .= " ORDER BY t.duration ASC";
            break;
        case 'popular':
        default:
            $query .= " ORDER BY review_count DESC, average_rating DESC";
            break;
    }
    
    // Apply pagination
    $offset = ($page - 1) * $limit;
    $query .= " LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    
    // Execute query
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $trains = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Process results
    foreach ($trains as &$train) {
        // Convert amenities string to array
        $train['amenities'] = $train['amenities'] ? explode(',', $train['amenities']) : [];
        
        // Format numbers
        $train['average_rating'] = round((float)$train['average_rating'], 1);
        $train['price'] = (float)$train['price'];
        
        // Add image URL
        $train['image'] = "/assets/images/trains/{$train['slug']}.jpg";
    }
    
    // Get total count for pagination
    $countQuery = "SELECT COUNT(DISTINCT t.id) as total FROM trains t WHERE 1=1";
    if ($destination) {
        $countQuery .= " AND t.destination = ?";
    }
    if ($minPrice !== null) {
        $countQuery .= " AND t.price >= ?";
    }
    if ($maxPrice !== null) {
        $countQuery .= " AND t.price <= ?";
    }
    
    $countStmt = $pdo->prepare($countQuery);
    $countStmt->execute(array_slice($params, 0, -2)); // Remove limit and offset params
    $totalCount = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Prepare response
    $response = [
        'data' => $trains,
        'pagination' => [
            'current_page' => $page,
            'total_pages' => ceil($totalCount / $limit),
            'total_items' => $totalCount,
            'items_per_page' => $limit
        ]
    ];
    
    echo json_encode($response);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => true,
        'message' => 'An error occurred while fetching train data'
    ]);
}
