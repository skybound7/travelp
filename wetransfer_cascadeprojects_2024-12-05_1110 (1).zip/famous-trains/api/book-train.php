<?php
require_once '../includes/config/database.php';
require_once '../includes/config/payment.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);
if (!$data) {
    $data = $_POST;
}

// Validate required fields
$required_fields = ['train', 'date', 'passengers', 'class', 'name', 'email', 'phone', 'payment_method'];
foreach ($required_fields as $field) {
    if (empty($data[$field])) {
        http_response_code(400);
        echo json_encode(['error' => "Missing required field: {$field}"]);
        exit;
    }
}

// Calculate price based on train and class
$prices = [
    'orient-express' => ['standard' => 1000, 'business' => 2000, 'luxury' => 3000],
    'flying-scotsman' => ['standard' => 800, 'business' => 1500, 'luxury' => 2500],
    'shinkansen' => ['standard' => 500, 'business' => 1000, 'luxury' => 1800],
    'palace-on-wheels' => ['standard' => 1200, 'business' => 2200, 'luxury' => 3500]
];

$price_per_person = $prices[$data['train']][$data['class']] ?? 0;
$total_price = $price_per_person * intval($data['passengers']);

// Create booking record
$stmt = $conn->prepare("INSERT INTO bookings (train_id, journey_date, passengers, class, customer_name, email, phone, total_amount, payment_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssissssds", 
    $data['train'],
    $data['date'],
    $data['passengers'],
    $data['class'],
    $data['name'],
    $data['email'],
    $data['phone'],
    $total_price,
    $payment_status
);

$payment_status = PAYMENT_STATUS_PENDING;

if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to create booking']);
    exit;
}

$booking_id = $stmt->insert_id;

// Initialize payment based on selected method
switch ($data['payment_method']) {
    case 'paypal':
        require_once '../includes/payments/PayPalPaymentProcessor.php';
        $payment = new PayPalPaymentProcessor();
        break;
    case 'phonepe':
        require_once '../includes/payments/PhonePePaymentProcessor.php';
        $payment = new PhonePePaymentProcessor();
        break;
    default:
        http_response_code(400);
        echo json_encode(['error' => 'Invalid payment method']);
        exit;
}

try {
    $payment_data = $payment->initiate([
        'amount' => $total_price,
        'currency' => 'USD',
        'booking_id' => $booking_id,
        'description' => "Train Booking - {$data['train']} ({$data['class']} class)",
        'customer_email' => $data['email']
    ]);

    echo json_encode([
        'success' => true,
        'booking_id' => $booking_id,
        'payment_data' => $payment_data
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
