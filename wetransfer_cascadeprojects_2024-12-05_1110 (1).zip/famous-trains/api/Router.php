<?php
require_once __DIR__ . '/../utils/ApiResponse.php';
require_once __DIR__ . '/../utils/Debug.php';
require_once __DIR__ . '/../utils/Performance.php';
require_once __DIR__ . '/../config/database.php';

class Router {
    private static $routes = [];
    private static $middlewares = [];
    private static $prefix = '';
    
    /**
     * Register route with middleware
     */
    public static function add($method, $path, $handler, $middlewares = []) {
        self::$routes[] = [
            'method' => strtoupper($method),
            'path' => self::$prefix . $path,
            'handler' => $handler,
            'middlewares' => $middlewares
        ];
    }
    
    /**
     * Group routes with prefix and middleware
     */
    public static function group($prefix, $callback, $middlewares = []) {
        $previousPrefix = self::$prefix;
        $previousMiddlewares = self::$middlewares;
        
        self::$prefix .= $prefix;
        self::$middlewares = array_merge(self::$middlewares, $middlewares);
        
        call_user_func($callback);
        
        self::$prefix = $previousPrefix;
        self::$middlewares = $previousMiddlewares;
    }
    
    /**
     * Handle incoming request
     */
    public static function handle() {
        $method = $_SERVER['REQUEST_METHOD'];
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        
        // Start performance monitoring
        Performance::getInstance();
        
        try {
            // Handle CORS
            ApiResponse::handleCors();
            
            // Find matching route
            foreach (self::$routes as $route) {
                if ($route['method'] === $method && self::matchPath($route['path'], $path)) {
                    // Apply middlewares
                    foreach (array_merge(self::$middlewares, $route['middlewares']) as $middleware) {
                        $result = call_user_func($middleware);
                        if ($result === false) {
                            ApiResponse::unauthorized('Access denied');
                            return;
                        }
                    }
                    
                    // Get request data
                    $data = self::getRequestData();
                    
                    // Execute handler
                    $response = call_user_func($route['handler'], $data);
                    
                    // Send response
                    if (is_array($response)) {
                        ApiResponse::success($response);
                    }
                    return;
                }
            }
            
            // No route found
            ApiResponse::notFound('Endpoint not found');
            
        } catch (Exception $e) {
            Debug::logError('Router error', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            ApiResponse::serverError('Internal server error');
        }
    }
    
    /**
     * Match route path with wildcards
     */
    private static function matchPath($routePath, $requestPath) {
        $routeParts = explode('/', trim($routePath, '/'));
        $requestParts = explode('/', trim($requestPath, '/'));
        
        if (count($routeParts) !== count($requestParts)) {
            return false;
        }
        
        foreach ($routeParts as $i => $routePart) {
            if ($routePart[0] === ':') {
                $_GET[substr($routePart, 1)] = $requestParts[$i];
                continue;
            }
            
            if ($routePart !== $requestParts[$i]) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Get request data from various sources
     */
    private static function getRequestData() {
        $data = [];
        
        // GET parameters
        $data = array_merge($data, $_GET);
        
        // POST/PUT data
        $input = file_get_contents('php://input');
        if ($input) {
            $jsonData = json_decode($input, true);
            if ($jsonData) {
                $data = array_merge($data, $jsonData);
            }
        }
        
        // POST form data
        $data = array_merge($data, $_POST);
        
        return $data;
    }
    
    /**
     * Common HTTP method shortcuts
     */
    public static function get($path, $handler, $middlewares = []) {
        self::add('GET', $path, $handler, $middlewares);
    }
    
    public static function post($path, $handler, $middlewares = []) {
        self::add('POST', $path, $handler, $middlewares);
    }
    
    public static function put($path, $handler, $middlewares = []) {
        self::add('PUT', $path, $handler, $middlewares);
    }
    
    public static function delete($path, $handler, $middlewares = []) {
        self::add('DELETE', $path, $handler, $middlewares);
    }
    
    /**
     * Error handling
     */
    public static function handleError($errno, $errstr, $errfile, $errline) {
        Debug::logError('PHP Error', [
            'number' => $errno,
            'message' => $errstr,
            'file' => $errfile,
            'line' => $errline
        ]);
        
        return true;
    }
    
    /**
     * Exception handling
     */
    public static function handleException($exception) {
        Debug::logError('Uncaught Exception', [
            'message' => $exception->getMessage(),
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'trace' => $exception->getTraceAsString()
        ]);
        
        ApiResponse::serverError('Internal server error');
    }
}

// Set error handlers
set_error_handler([Router::class, 'handleError']);
set_exception_handler([Router::class, 'handleException']);

// Example usage:
/*
Router::group('/api', function() {
    // Auth routes
    Router::group('/auth', function() {
        Router::post('/login', 'AuthController::login');
        Router::post('/register', 'AuthController::register');
        Router::post('/logout', 'AuthController::logout', ['auth']);
    });
    
    // Protected routes
    Router::group('/user', function() {
        Router::get('/profile', 'UserController::getProfile');
        Router::put('/profile', 'UserController::updateProfile');
    }, ['auth']);
    
    // Service routes
    Router::group('/services', function() {
        Router::get('/trains', 'TrainController::list');
        Router::post('/trains/book', 'TrainController::book', ['auth']);
        Router::get('/cruises', 'CruiseController::list');
        Router::post('/cruises/book', 'CruiseController::book', ['auth']);
    });
});
*/
