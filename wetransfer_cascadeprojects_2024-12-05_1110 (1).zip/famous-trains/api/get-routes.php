<?php
require_once '../includes/config/database.php';

header('Content-Type: application/json');

try {
    $db = new PDO(
        "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4",
        $config['db_user'],
        $config['db_password']
    );
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get query parameters
    $country = isset($_GET['country']) ? $_GET['country'] : null;
    
    // Build the query
    $query = "
        SELECT 
            r.id,
            r.name,
            r.description,
            r.duration_minutes,
            r.distance_km,
            r.country,
            r.image_url,
            r.highlights,
            GROUP_CONCAT(
                CONCAT(s.name, '|', s.city, '|', s.country, '|', rs.stop_order)
                ORDER BY rs.stop_order
                SEPARATOR ';'
            ) as stations
        FROM routes r
        LEFT JOIN route_stations rs ON r.id = rs.route_id
        LEFT JOIN stations s ON rs.station_id = s.id
    ";
    
    $params = [];
    if ($country) {
        $query .= " WHERE r.country = ?";
        $params[] = $country;
    }
    
    $query .= " GROUP BY r.id ORDER BY r.name";
    
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    
    $routes = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        // Process stations
        $stationsList = [];
        if ($row['stations']) {
            $stationsData = explode(';', $row['stations']);
            foreach ($stationsData as $stationData) {
                list($name, $city, $country, $order) = explode('|', $stationData);
                $stationsList[] = [
                    'name' => $name,
                    'city' => $city,
                    'country' => $country,
                    'order' => (int)$order
                ];
            }
        }
        
        // Format the route data
        $routes[] = [
            'id' => (int)$row['id'],
            'name' => $row['name'],
            'description' => $row['description'],
            'duration' => [
                'minutes' => (int)$row['duration_minutes'],
                'formatted' => sprintf(
                    '%dh %dm',
                    floor($row['duration_minutes'] / 60),
                    $row['duration_minutes'] % 60
                )
            ],
            'distance' => [
                'km' => (float)$row['distance_km'],
                'formatted' => number_format($row['distance_km']) . ' km'
            ],
            'country' => $row['country'],
            'image_url' => $row['image_url'],
            'highlights' => json_decode($row['highlights']),
            'stations' => $stationsList
        ];
    }
    
    echo json_encode([
        'success' => true,
        'routes' => $routes
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Server error: ' . $e->getMessage()
    ]);
}
