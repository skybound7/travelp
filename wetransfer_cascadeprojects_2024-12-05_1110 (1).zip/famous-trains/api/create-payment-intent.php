<?php
require_once '../vendor/autoload.php';
require_once '../config.php';

header('Content-Type: application/json');

try {
    \Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);

    $jsonData = json_decode(file_get_contents('php://input'), true);
    
    // Validate input
    if (!isset($jsonData['trainId']) || !isset($jsonData['passengers'])) {
        throw new Exception('Missing required booking information');
    }

    // Calculate amount based on train and passengers
    $amount = calculateBookingAmount($jsonData);

    // Create payment intent
    $paymentIntent = \Stripe\PaymentIntent::create([
        'amount' => $amount * 100, // Convert to cents
        'currency' => 'usd',
        'automatic_payment_methods' => [
            'enabled' => true,
        ],
        'metadata' => [
            'train_id' => $jsonData['trainId'],
            'journey_date' => $jsonData['journeyDate'],
            'passengers' => $jsonData['passengers'],
            'customer_email' => $jsonData['email']
        ]
    ]);

    echo json_encode([
        'clientSecret' => $paymentIntent->client_secret,
        'amount' => $amount
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

function calculateBookingAmount($bookingData) {
    // This is a simplified version. In production, you'd want to fetch prices from a database
    $basePrices = [
        1 => 9000, // Orient Express
        2 => 3000, // Rocky Mountaineer
        3 => 5000  // Palace on Wheels
    ];

    $classMultipliers = [
        'first' => 1.5,
        'second' => 1.0,
        'sleeper' => 1.2
    ];

    $basePrice = $basePrices[$bookingData['trainId']] ?? 0;
    $passengers = intval($bookingData['passengers']);
    $classMultiplier = $classMultipliers[$bookingData['class']] ?? 1.0;

    return $basePrice * $passengers * $classMultiplier;
}
