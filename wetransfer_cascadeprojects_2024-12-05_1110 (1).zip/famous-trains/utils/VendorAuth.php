<?php
class VendorAuth {
    /**
     * Check if a vendor is authenticated
     * @return bool
     */
    public static function isAuthenticated() {
        session_start();
        return isset($_SESSION['vendor_id']) && isset($_SESSION['vendor_user_id']);
    }

    /**
     * Get the current vendor ID
     * @return int|null
     */
    public static function getVendorId() {
        return $_SESSION['vendor_id'] ?? null;
    }

    /**
     * Get the current vendor user ID
     * @return int|null
     */
    public static function getVendorUserId() {
        return $_SESSION['vendor_user_id'] ?? null;
    }

    /**
     * Get the current vendor name
     * @return string|null
     */
    public static function getVendorName() {
        return $_SESSION['vendor_name'] ?? null;
    }

    /**
     * Get the current vendor email
     * @return string|null
     */
    public static function getVendorEmail() {
        return $_SESSION['vendor_email'] ?? null;
    }

    /**
     * Check if vendor has required permissions
     * @param array $requiredPermissions
     * @return bool
     */
    public static function hasPermissions($requiredPermissions) {
        if (!self::isAuthenticated()) {
            return false;
        }

        // Get vendor permissions from database
        try {
            $pdo = Database::getConnection();
            $vendorId = self::getVendorId();
            
            $query = "
                SELECT permission_name 
                FROM vendor_permissions 
                WHERE vendor_id = ?
            ";
            
            $stmt = $pdo->prepare($query);
            $stmt->execute([$vendorId]);
            $permissions = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            // Check if vendor has all required permissions
            return empty(array_diff($requiredPermissions, $permissions));
            
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Require authentication for a route
     * If not authenticated, sends error response and exits
     */
    public static function requireAuth() {
        if (!self::isAuthenticated()) {
            ApiResponse::error('Unauthorized access', 401);
            exit;
        }
    }

    /**
     * Require specific permissions for a route
     * @param array $permissions
     */
    public static function requirePermissions($permissions) {
        self::requireAuth();
        
        if (!self::hasPermissions($permissions)) {
            ApiResponse::error('Insufficient permissions', 403);
            exit;
        }
    }

    /**
     * Log out the current vendor
     */
    public static function logout() {
        session_start();
        
        // Clear all vendor-related session variables
        unset($_SESSION['vendor_id']);
        unset($_SESSION['vendor_user_id']);
        unset($_SESSION['vendor_name']);
        unset($_SESSION['vendor_email']);
        
        // Destroy session
        session_destroy();
    }

    /**
     * Create a new session for a vendor
     * @param array $vendorData
     */
    public static function createSession($vendorData) {
        session_start();
        
        $_SESSION['vendor_id'] = $vendorData['vendor_id'];
        $_SESSION['vendor_user_id'] = $vendorData['user_id'];
        $_SESSION['vendor_name'] = $vendorData['vendor_name'];
        $_SESSION['vendor_email'] = $vendorData['email'];
    }

    /**
     * Refresh vendor session data
     * @return bool
     */
    public static function refreshSession() {
        if (!self::isAuthenticated()) {
            return false;
        }

        try {
            $pdo = Database::getConnection();
            $vendorId = self::getVendorId();
            $userId = self::getVendorUserId();
            
            $query = "
                SELECT 
                    vu.id as user_id,
                    vu.vendor_id,
                    vu.email,
                    vu.status as user_status,
                    v.name as vendor_name,
                    v.status as vendor_status
                FROM vendor_users vu
                JOIN vendors v ON vu.vendor_id = v.id
                WHERE vu.id = ? AND vu.vendor_id = ?
            ";
            
            $stmt = $pdo->prepare($query);
            $stmt->execute([$userId, $vendorId]);
            $vendorData = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$vendorData || 
                $vendorData['user_status'] !== 'active' || 
                $vendorData['vendor_status'] !== 'active') {
                self::logout();
                return false;
            }
            
            self::createSession($vendorData);
            return true;
            
        } catch (Exception $e) {
            return false;
        }
    }
}
