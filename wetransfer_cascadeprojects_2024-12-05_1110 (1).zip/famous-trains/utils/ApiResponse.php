<?php
require_once __DIR__ . '/Debug.php';

class ApiResponse {
    /**
     * Send a success response
     * @param mixed $data Response data
     * @param int $status HTTP status code
     */
    public static function success($data, $status = 200) {
        self::send([
            'success' => true,
            'data' => $data
        ], $status);
    }

    /**
     * Send an error response
     * @param string $message Error message
     * @param int $status HTTP status code
     * @param array $errors Additional error details
     */
    public static function error($message, $status = 400, $errors = []) {
        // Log error for debugging
        Debug::logError($message, [
            'status' => $status,
            'errors' => $errors,
            'request_data' => [
                'method' => $_SERVER['REQUEST_METHOD'] ?? 'unknown',
                'path' => $_SERVER['REQUEST_URI'] ?? 'unknown',
                'query' => $_GET ?? [],
                'body' => self::getRequestBody()
            ]
        ]);

        self::send([
            'success' => false,
            'message' => $message,
            'errors' => $errors
        ], $status);
    }

    /**
     * Handle CORS headers
     */
    public static function handleCors() {
        // Allow requests from our frontend domains
        $allowedOrigins = [
            'http://localhost',
            'http://localhost:8080',
            'https://famous-trains.com'
        ];

        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        
        if (in_array($origin, $allowedOrigins)) {
            header("Access-Control-Allow-Origin: $origin");
            header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
            header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
            header("Access-Control-Allow-Credentials: true");
            header("Access-Control-Max-Age: 86400"); // 24 hours cache
        }

        // Handle preflight requests
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            header("HTTP/1.1 200 OK");
            exit();
        }
    }

    /**
     * Send the response
     * @param array $data Response data
     * @param int $status HTTP status code
     */
    private static function send($data, $status) {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');

        // Add debug information in debug mode
        if (Debug::isDebugMode()) {
            $data['debug'] = [
                'execution_time' => Debug::getExecutionTime(),
                'memory_usage' => Debug::getMemoryUsage(),
                'query_count' => Database::getQueryCount(),
                'request_id' => self::getRequestId()
            ];
        }

        // Add request ID to response headers for tracking
        header('X-Request-ID: ' . self::getRequestId());

        // Add cache control headers for non-error responses
        if ($status < 400) {
            self::setCacheHeaders();
        }

        echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit();
    }

    /**
     * Get request body data
     * @return array
     */
    private static function getRequestBody() {
        $input = file_get_contents('php://input');
        return json_decode($input, true) ?? [];
    }

    /**
     * Generate or get request ID
     * @return string
     */
    private static function getRequestId() {
        if (!isset($GLOBALS['request_id'])) {
            $GLOBALS['request_id'] = uniqid('req_', true);
        }
        return $GLOBALS['request_id'];
    }

    /**
     * Set appropriate cache headers
     */
    private static function setCacheHeaders() {
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        
        if ($method === 'GET') {
            // Cache GET requests for 5 minutes
            header('Cache-Control: public, max-age=300');
            header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 300) . ' GMT');
        } else {
            // No caching for other methods
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: ' . gmdate('D, d M Y H:i:s', time() - 1) . ' GMT');
        }
    }

    /**
     * Handle validation errors
     * @param array $errors Validation errors
     */
    public static function validationError($errors) {
        self::error('Validation failed', 422, $errors);
    }

    /**
     * Send a redirect response
     * @param string $url URL to redirect to
     * @param string $message Optional message
     */
    public static function redirect($url, $message = '') {
        self::send([
            'success' => true,
            'redirect' => $url,
            'message' => $message
        ], 302);
    }

    /**
     * Send a not found response
     * @param string $message Custom message
     */
    public static function notFound($message = 'Resource not found') {
        self::error($message, 404);
    }

    /**
     * Send an unauthorized response
     * @param string $message Custom message
     */
    public static function unauthorized($message = 'Unauthorized access') {
        self::error($message, 401);
    }

    /**
     * Send a forbidden response
     * @param string $message Custom message
     */
    public static function forbidden($message = 'Access forbidden') {
        self::error($message, 403);
    }

    /**
     * Send a server error response
     * @param string $message Custom message
     * @param Exception $exception Optional exception
     */
    public static function serverError($message = 'Internal server error', $exception = null) {
        if ($exception) {
            Debug::logError($exception->getMessage(), [
                'trace' => $exception->getTraceAsString(),
                'file' => $exception->getFile(),
                'line' => $exception->getLine()
            ]);
        }
        self::error($message, 500);
    }
}
