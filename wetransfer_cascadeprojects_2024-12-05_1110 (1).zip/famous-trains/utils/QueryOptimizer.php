<?php

class QueryOptimizer {
    private static $queryLog = [];
    private static $slowQueries = [];
    private static $queryCache = [];
    private static $indexSuggestions = [];
    
    // Configuration
    private static $slowQueryThreshold = 1.0; // seconds
    private static $cacheTimeout = 300; // 5 minutes
    private static $maxCacheSize = 100; // entries
    
    /**
     * Log and analyze a query
     */
    public static function logQuery($sql, $params, $duration) {
        $queryHash = self::generateQueryHash($sql, $params);
        
        self::$queryLog[] = [
            'sql' => $sql,
            'params' => $params,
            'duration' => $duration,
            'timestamp' => microtime(true),
            'hash' => $queryHash
        ];
        
        // Check for slow queries
        if ($duration >= self::$slowQueryThreshold) {
            self::$slowQueries[] = [
                'sql' => $sql,
                'duration' => $duration,
                'timestamp' => time()
            ];
            self::analyzeSlowQuery($sql);
        }
        
        // Analyze for potential optimizations
        self::analyzeQuery($sql);
    }
    
    /**
     * Cache management
     */
    public static function getCachedResult($sql, $params) {
        $queryHash = self::generateQueryHash($sql, $params);
        
        if (isset(self::$queryCache[$queryHash])) {
            $cache = self::$queryCache[$queryHash];
            if (time() - $cache['timestamp'] < self::$cacheTimeout) {
                return $cache['data'];
            }
            unset(self::$queryCache[$queryHash]);
        }
        
        return null;
    }
    
    public static function cacheResult($sql, $params, $data) {
        $queryHash = self::generateQueryHash($sql, $params);
        
        // Implement LRU cache if size limit reached
        if (count(self::$queryCache) >= self::$maxCacheSize) {
            array_shift(self::$queryCache);
        }
        
        self::$queryCache[$queryHash] = [
            'data' => $data,
            'timestamp' => time()
        ];
    }
    
    /**
     * Query analysis and optimization suggestions
     */
    private static function analyzeQuery($sql) {
        // Check for common inefficient patterns
        if (stripos($sql, 'SELECT *') !== false) {
            self::addSuggestion('Specify needed columns instead of SELECT *');
        }
        
        if (stripos($sql, 'ORDER BY') !== false && stripos($sql, 'LIMIT') === false) {
            self::addSuggestion('Consider adding LIMIT to ORDER BY queries');
        }
        
        if (preg_match('/WHERE\s+\w+\s+LIKE\s+[\'"]%/i', $sql)) {
            self::addSuggestion('Leading wildcard in LIKE clause prevents index usage');
        }
        
        // Check for potential missing indexes
        if (preg_match('/WHERE\s+(\w+)\s*=/i', $sql, $matches)) {
            $column = $matches[1];
            self::checkIndexRecommendation($column);
        }
    }
    
    /**
     * Analyze slow queries for optimization opportunities
     */
    private static function analyzeSlowQuery($sql) {
        $suggestions = [];
        
        // Check for JOIN optimizations
        if (stripos($sql, 'JOIN') !== false) {
            if (!preg_match('/ON\s+\w+\.\w+\s*=\s*\w+\.\w+/i', $sql)) {
                $suggestions[] = 'Ensure proper JOIN conditions and indexes';
            }
        }
        
        // Check for subqueries
        if (stripos($sql, 'SELECT') > stripos($sql, 'FROM')) {
            $suggestions[] = 'Consider replacing subquery with JOIN';
        }
        
        // Check for GROUP BY without index
        if (stripos($sql, 'GROUP BY') !== false) {
            $suggestions[] = 'Ensure GROUP BY columns are indexed';
        }
        
        foreach ($suggestions as $suggestion) {
            self::addSuggestion($suggestion);
        }
    }
    
    /**
     * Index recommendations
     */
    private static function checkIndexRecommendation($column) {
        if (!isset(self::$indexSuggestions[$column])) {
            self::$indexSuggestions[$column] = 1;
        } else {
            self::$indexSuggestions[$column]++;
            
            // If column is frequently used in WHERE clause, suggest index
            if (self::$indexSuggestions[$column] > 10) {
                self::addSuggestion("Consider adding index for frequently filtered column: $column");
            }
        }
    }
    
    /**
     * Query pattern detection
     */
    private static function generateQueryHash($sql, $params) {
        // Normalize query by replacing literal values
        $normalized = preg_replace('/\b\d+\b/', '?', $sql);
        $normalized = preg_replace('/\'[^\']*\'/', '?', $normalized);
        
        return md5($normalized . serialize($params));
    }
    
    /**
     * Performance reporting
     */
    public static function getPerformanceReport() {
        $totalQueries = count(self::$queryLog);
        $totalDuration = 0;
        $queryPatterns = [];
        
        foreach (self::$queryLog as $query) {
            $totalDuration += $query['duration'];
            $queryPatterns[$query['hash']] = ($queryPatterns[$query['hash']] ?? 0) + 1;
        }
        
        return [
            'total_queries' => $totalQueries,
            'total_duration' => $totalDuration,
            'avg_duration' => $totalQueries > 0 ? $totalDuration / $totalQueries : 0,
            'slow_queries' => count(self::$slowQueries),
            'repeated_patterns' => array_filter($queryPatterns, fn($count) => $count > 1),
            'cache_hits' => count(self::$queryCache),
            'suggestions' => self::getOptimizationSuggestions()
        ];
    }
    
    /**
     * Get optimization suggestions
     */
    private static function getOptimizationSuggestions() {
        $suggestions = [];
        
        // Analyze query patterns
        $patterns = [];
        foreach (self::$queryLog as $query) {
            $patterns[$query['hash']] = ($patterns[$query['hash']] ?? 0) + 1;
        }
        
        // Suggest caching for frequently repeated queries
        foreach ($patterns as $hash => $count) {
            if ($count > 5) {
                $suggestions[] = "Consider caching frequently repeated query pattern (used $count times)";
            }
        }
        
        return array_unique($suggestions);
    }
    
    /**
     * Add optimization suggestion
     */
    private static function addSuggestion($suggestion) {
        if (!in_array($suggestion, self::getOptimizationSuggestions())) {
            self::$indexSuggestions[] = $suggestion;
        }
    }
    
    /**
     * Reset statistics
     */
    public static function reset() {
        self::$queryLog = [];
        self::$slowQueries = [];
        self::$queryCache = [];
        self::$indexSuggestions = [];
    }
    
    /**
     * Configure optimizer settings
     */
    public static function configure($config = []) {
        if (isset($config['slow_query_threshold'])) {
            self::$slowQueryThreshold = $config['slow_query_threshold'];
        }
        if (isset($config['cache_timeout'])) {
            self::$cacheTimeout = $config['cache_timeout'];
        }
        if (isset($config['max_cache_size'])) {
            self::$maxCacheSize = $config['max_cache_size'];
        }
    }
}
