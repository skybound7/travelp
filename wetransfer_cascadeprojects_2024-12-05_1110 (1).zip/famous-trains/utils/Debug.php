<?php
class Debug {
    private static $logFile = __DIR__ . '/../logs/debug.log';
    private static $isDebugMode = false;
    private static $startTime;
    private static $queries = [];
    private static $errors = [];
    private static $warnings = [];

    /**
     * Initialize debugging
     */
    public static function init($debugMode = false) {
        self::$isDebugMode = $debugMode;
        self::$startTime = microtime(true);
        
        // Create logs directory if it doesn't exist
        $logDir = dirname(self::$logFile);
        if (!file_exists($logDir)) {
            mkdir($logDir, 0755, true);
        }

        // Set error handlers
        set_error_handler([self::class, 'handleError']);
        set_exception_handler([self::class, 'handleException']);
        register_shutdown_function([self::class, 'handleShutdown']);
    }

    /**
     * Log a database query with its execution time
     */
    public static function logQuery($query, $params = [], $executionTime = 0) {
        if (!self::$isDebugMode) return;

        self::$queries[] = [
            'query' => $query,
            'params' => $params,
            'execution_time' => $executionTime,
            'timestamp' => microtime(true)
        ];
    }

    /**
     * Log an error message
     */
    public static function logError($message, $context = []) {
        self::$errors[] = [
            'message' => $message,
            'context' => $context,
            'timestamp' => microtime(true),
            'trace' => debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS)
        ];

        self::writeToLog('ERROR', $message, $context);
    }

    /**
     * Log a warning message
     */
    public static function logWarning($message, $context = []) {
        self::$warnings[] = [
            'message' => $message,
            'context' => $context,
            'timestamp' => microtime(true)
        ];

        self::writeToLog('WARNING', $message, $context);
    }

    /**
     * Write message to log file
     */
    private static function writeToLog($level, $message, $context = []) {
        $timestamp = date('Y-m-d H:i:s');
        $contextStr = !empty($context) ? json_encode($context) : '';
        $logMessage = "[$timestamp] $level: $message $contextStr\n";

        file_put_contents(self::$logFile, $logMessage, FILE_APPEND);
    }

    /**
     * Custom error handler
     */
    public static function handleError($errno, $errstr, $errfile, $errline) {
        if (!(error_reporting() & $errno)) {
            return false;
        }

        $context = [
            'file' => $errfile,
            'line' => $errline,
            'type' => $errno
        ];

        self::logError($errstr, $context);
        return true;
    }

    /**
     * Custom exception handler
     */
    public static function handleException($exception) {
        $context = [
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'trace' => $exception->getTraceAsString()
        ];

        self::logError($exception->getMessage(), $context);

        if (self::$isDebugMode) {
            throw $exception;
        } else {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'An internal error occurred'
            ]);
        }
    }

    /**
     * Shutdown handler to catch fatal errors
     */
    public static function handleShutdown() {
        $error = error_get_last();
        if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
            self::logError($error['message'], [
                'file' => $error['file'],
                'line' => $error['line'],
                'type' => $error['type']
            ]);
        }

        if (self::$isDebugMode) {
            self::outputDebugInfo();
        }
    }

    /**
     * Output debug information
     */
    private static function outputDebugInfo() {
        $executionTime = microtime(true) - self::$startTime;
        $memoryUsage = memory_get_peak_usage(true) / 1024 / 1024; // MB

        $debugInfo = [
            'execution_time' => round($executionTime * 1000, 2) . 'ms',
            'memory_usage' => round($memoryUsage, 2) . 'MB',
            'queries' => self::$queries,
            'errors' => self::$errors,
            'warnings' => self::$warnings
        ];

        if (self::isAjaxRequest()) {
            header('X-Debug-Info: ' . base64_encode(json_encode($debugInfo)));
        }

        self::writeToLog('DEBUG', 'Request completed', $debugInfo);
    }

    /**
     * Check if current request is AJAX
     */
    private static function isAjaxRequest() {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
            strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
    }

    /**
     * Get debug information
     */
    public static function getDebugInfo() {
        return [
            'queries' => self::$queries,
            'errors' => self::$errors,
            'warnings' => self::$warnings,
            'execution_time' => microtime(true) - self::$startTime,
            'memory_usage' => memory_get_peak_usage(true)
        ];
    }
}
