<?php
class Performance {
    private static $startTime;
    private static $memoryUsage;
    private static $queries = [];
    private static $slowQueryThreshold = 1.0; // seconds
    private static $cache = [];
    private static $cacheExpiry = [];
    private static $instance = null;

    public function __construct() {
        self::$startTime = microtime(true);
        self::$memoryUsage = memory_get_usage();
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Start measuring a specific operation
     */
    public static function startMeasure($operation) {
        return [
            'start' => microtime(true),
            'memory_start' => memory_get_usage(),
            'operation' => $operation
        ];
    }

    /**
     * End measuring a specific operation
     */
    public static function endMeasure($measure) {
        $endTime = microtime(true);
        $endMemory = memory_get_usage();
        
        return [
            'operation' => $measure['operation'],
            'duration' => $endTime - $measure['start'],
            'memory_used' => $endMemory - $measure['memory_start']
        ];
    }

    /**
     * Log a slow query
     */
    public static function logSlowQuery($query, $params, $duration) {
        if ($duration >= self::$slowQueryThreshold) {
            error_log(sprintf(
                "Slow Query (%.2fs): %s | Params: %s",
                $duration,
                $query,
                json_encode($params)
            ));
        }
    }

    /**
     * Cache management
     */
    public static function cache($key, $value, $ttl = 300) {
        self::$cache[$key] = $value;
        self::$cacheExpiry[$key] = time() + $ttl;
    }

    public static function getCache($key) {
        if (isset(self::$cache[$key]) && 
            self::$cacheExpiry[$key] > time()) {
            return self::$cache[$key];
        }
        return null;
    }

    public static function clearCache($key = null) {
        if ($key === null) {
            self::$cache = [];
            self::$cacheExpiry = [];
        } else {
            unset(self::$cache[$key]);
            unset(self::$cacheExpiry[$key]);
        }
    }

    /**
     * Memory optimization
     */
    public static function optimizeMemory() {
        // Clear PHP internal caches
        if (function_exists('opcache_reset')) {
            opcache_reset();
        }
        
        // Clear realpath cache
        clearstatcache(true);
        
        // Garbage collection
        if (gc_enabled()) {
            gc_collect_cycles();
        }
    }

    /**
     * Get current performance metrics
     */
    public static function getMetrics() {
        return [
            'execution_time' => microtime(true) - self::$startTime,
            'memory_usage' => memory_get_usage() - self::$memoryUsage,
            'peak_memory' => memory_get_peak_usage(true),
            'query_count' => count(self::$queries)
        ];
    }

    /**
     * Database query optimization suggestions
     */
    public static function analyzeQueryPerformance() {
        $suggestions = [];
        $queryPatterns = [];
        
        foreach (self::$queries as $query) {
            // Detect repeated queries
            $pattern = preg_replace('/\b\d+\b/', 'N', $query['sql']);
            if (!isset($queryPatterns[$pattern])) {
                $queryPatterns[$pattern] = 0;
            }
            $queryPatterns[$pattern]++;
            
            // Check for potential issues
            if (stripos($query['sql'], 'SELECT *') !== false) {
                $suggestions[] = "Consider specifying columns instead of SELECT * in: " . $query['sql'];
            }
            if (stripos($query['sql'], 'ORDER BY') !== false && stripos($query['sql'], 'LIMIT') === false) {
                $suggestions[] = "Consider adding LIMIT to ORDER BY query: " . $query['sql'];
            }
        }
        
        // Identify frequently repeated queries
        foreach ($queryPatterns as $pattern => $count) {
            if ($count > 5) {
                $suggestions[] = "Query pattern repeated $count times, consider caching: $pattern";
            }
        }
        
        return $suggestions;
    }

    /**
     * Resource monitoring
     */
    public static function checkResourceUsage() {
        $metrics = self::getMetrics();
        $warnings = [];
        
        // Memory usage warnings
        if ($metrics['memory_usage'] > 64 * 1024 * 1024) { // 64MB
            $warnings[] = "High memory usage detected";
        }
        
        // Execution time warnings
        if ($metrics['execution_time'] > 5.0) { // 5 seconds
            $warnings[] = "Long execution time detected";
        }
        
        // Query count warnings
        if ($metrics['query_count'] > 50) {
            $warnings[] = "High number of database queries detected";
        }
        
        return $warnings;
    }

    /**
     * Output buffering control
     */
    public static function startOutputBuffering() {
        ob_start();
    }

    public static function endOutputBuffering() {
        if (ob_get_level() > 0) {
            $content = ob_get_clean();
            // Minify HTML output in production
            if (!Debug::isDebugMode()) {
                $content = self::minifyHtml($content);
            }
            echo $content;
        }
    }

    /**
     * Basic HTML minification
     */
    private static function minifyHtml($content) {
        // Remove comments
        $content = preg_replace('/<!--(?!\[if).*?-->/s', '', $content);
        // Remove whitespace
        $content = preg_replace('/\s+/', ' ', $content);
        return trim($content);
    }

    /**
     * Set configuration
     */
    public static function configure($config = []) {
        if (isset($config['slow_query_threshold'])) {
            self::$slowQueryThreshold = $config['slow_query_threshold'];
        }
    }
}
