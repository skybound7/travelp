document.addEventListener('DOMContentLoaded', () => {
    // Initialize payment method handlers
    const paymentMethods = document.querySelectorAll('input[name="payment_method"]');
    const cardElement = document.getElementById('card-element');
    const paypalContainer = document.getElementById('paypal-button-container');
    const bookingForm = document.getElementById('booking-form');

    // Handle payment method selection
    paymentMethods.forEach(method => {
        method.addEventListener('change', () => {
            cardElement.classList.add('hidden');
            paypalContainer.classList.add('hidden');

            if (method.value === 'card') {
                cardElement.classList.remove('hidden');
            } else if (method.value === 'paypal') {
                paypalContainer.classList.remove('hidden');
            }
        });
    });

    // Handle form submission
    bookingForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = new FormData(bookingForm);
        const submitButton = bookingForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        
        try {
            const response = await fetch('/api/book-train.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                if (result.payment_data.redirect_url) {
                    window.location.href = result.payment_data.redirect_url;
                } else {
                    window.location.href = '/booking-success.html';
                }
            } else {
                throw new Error(result.error || 'Booking failed');
            }
        } catch (error) {
            alert('Error: ' + error.message);
            submitButton.disabled = false;
        }
    });

    // Add smooth scroll behavior
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Add lazy loading for images
    const images = document.querySelectorAll('img');
    images.forEach(img => {
        img.loading = 'lazy';
    });

    // Add click event to train cards for future expansion
    const trainCards = document.querySelectorAll('.train-card');
    trainCards.forEach(card => {
        card.addEventListener('click', () => {
            card.classList.toggle('expanded');
        });
    });

    // Calculate and update price when train or class changes
    const trainSelect = document.getElementById('train');
    const classSelect = document.getElementById('class');
    const passengersInput = document.getElementById('passengers');
    
    const prices = {
        'orient-express': { standard: 1000, business: 2000, luxury: 3000 },
        'flying-scotsman': { standard: 800, business: 1500, luxury: 2500 },
        'shinkansen': { standard: 500, business: 1000, luxury: 1800 },
        'palace-on-wheels': { standard: 1200, business: 2200, luxury: 3500 }
    };

    function updatePrice() {
        const train = trainSelect.value;
        const travelClass = classSelect.value;
        const passengers = parseInt(passengersInput.value) || 1;

        if (train && travelClass && prices[train] && prices[train][travelClass]) {
            const pricePerPerson = prices[train][travelClass];
            const totalPrice = pricePerPerson * passengers;
            document.getElementById('total-price').textContent = `Total Price: $${totalPrice}`;
        }
    }

    trainSelect.addEventListener('change', updatePrice);
    classSelect.addEventListener('change', updatePrice);
    passengersInput.addEventListener('input', updatePrice);
});
