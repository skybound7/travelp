-- Create database if not exists
CREATE DATABASE IF NOT EXISTS luxury_travel;
USE luxury_travel;

-- Vendors table
CREATE TABLE IF NOT EXISTS vendors (
    vendor_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    company_name VARCHAR(100),
    contact_number VARCHAR(20),
    address TEXT,
    status ENUM('active', 'inactive', 'pending') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Trains table
CREATE TABLE IF NOT EXISTS trains (
    train_id INT PRIMARY KEY AUTO_INCREMENT,
    vendor_id INT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    capacity INT,
    class_type ENUM('luxury', 'first', 'business', 'standard'),
    route_info TEXT,
    amenities TEXT,
    status ENUM('active', 'inactive', 'maintenance') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id)
);

-- Train Schedules
CREATE TABLE IF NOT EXISTS train_schedules (
    schedule_id INT PRIMARY KEY AUTO_INCREMENT,
    train_id INT,
    departure_station VARCHAR(100),
    arrival_station VARCHAR(100),
    departure_time DATETIME,
    arrival_time DATETIME,
    base_price DECIMAL(10,2),
    available_seats INT,
    status ENUM('scheduled', 'cancelled', 'completed') DEFAULT 'scheduled',
    FOREIGN KEY (train_id) REFERENCES trains(train_id)
);

-- Users table
CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bookings table
CREATE TABLE IF NOT EXISTS bookings (
    booking_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    schedule_id INT,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    passenger_count INT,
    total_amount DECIMAL(10,2),
    status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
    payment_status ENUM('pending', 'paid', 'refunded') DEFAULT 'pending',
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (schedule_id) REFERENCES train_schedules(schedule_id)
);

-- Reviews table
CREATE TABLE IF NOT EXISTS reviews (
    review_id INT PRIMARY KEY AUTO_INCREMENT,
    booking_id INT,
    user_id INT,
    train_id INT,
    rating TINYINT CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (train_id) REFERENCES trains(train_id)
);

-- Promotions table
CREATE TABLE IF NOT EXISTS promotions (
    promotion_id INT PRIMARY KEY AUTO_INCREMENT,
    train_id INT,
    title VARCHAR(100),
    description TEXT,
    discount_percentage DECIMAL(5,2),
    start_date DATE,
    end_date DATE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    FOREIGN KEY (train_id) REFERENCES trains(train_id)
);

-- Payment transactions
CREATE TABLE IF NOT EXISTS payments (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    booking_id INT,
    amount DECIMAL(10,2),
    payment_method VARCHAR(50),
    transaction_id VARCHAR(100),
    status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
);

-- Create indexes for better performance
CREATE INDEX idx_vendor_email ON vendors(email);
CREATE INDEX idx_user_email ON users(email);
CREATE INDEX idx_train_status ON trains(status);
CREATE INDEX idx_schedule_dates ON train_schedules(departure_time, arrival_time);
CREATE INDEX idx_booking_status ON bookings(status);
CREATE INDEX idx_payment_status ON payments(status);

-- Create views for common queries
CREATE VIEW upcoming_schedules AS
SELECT 
    ts.schedule_id,
    t.name AS train_name,
    ts.departure_station,
    ts.arrival_station,
    ts.departure_time,
    ts.arrival_time,
    ts.base_price,
    ts.available_seats
FROM train_schedules ts
JOIN trains t ON ts.train_id = t.train_id
WHERE ts.departure_time > NOW()
AND ts.status = 'scheduled'
ORDER BY ts.departure_time;

CREATE VIEW vendor_performance AS
SELECT 
    v.vendor_id,
    v.name AS vendor_name,
    COUNT(b.booking_id) AS total_bookings,
    AVG(r.rating) AS average_rating,
    SUM(b.total_amount) AS total_revenue
FROM vendors v
LEFT JOIN trains t ON v.vendor_id = t.vendor_id
LEFT JOIN train_schedules ts ON t.train_id = ts.train_id
LEFT JOIN bookings b ON ts.schedule_id = b.schedule_id
LEFT JOIN reviews r ON b.booking_id = r.booking_id
GROUP BY v.vendor_id;
