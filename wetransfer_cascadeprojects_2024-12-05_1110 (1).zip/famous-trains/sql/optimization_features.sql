USE luxury_travel;

DELIMITER //

-- Customer Analytics
-- ================

-- Customer Segmentation
CREATE OR REPLACE VIEW customer_segments AS
SELECT 
    user_id,
    CASE 
        WHEN total_spent >= 10000 AND bookings >= 10 THEN 'VIP'
        WHEN total_spent >= 5000 OR bookings >= 5 THEN 'Regular'
        WHEN last_booking < DATE_SUB(NOW(), INTERVAL 6 MONTH) THEN 'Inactive'
        ELSE 'New'
    END as segment,
    total_spent,
    bookings,
    services_used,
    last_booking
FROM (
    SELECT 
        u.user_id,
        SUM(b.total_amount) as total_spent,
        COUNT(*) as bookings,
        COUNT(DISTINCT b.service_type) as services_used,
        MAX(b.booking_date) as last_booking
    FROM users u
    LEFT JOIN (
        SELECT booking_id, user_id, total_amount, booking_date, 'Train' as service_type 
        FROM train_bookings
        UNION ALL
        SELECT booking_id, user_id, total_amount, booking_date, 'Cruise' 
        FROM cruise_bookings
        UNION ALL
        SELECT rental_id, user_id, total_amount, rental_date, 'Car' 
        FROM car_rentals
    ) b ON u.user_id = b.user_id
    GROUP BY u.user_id
) customer_stats;

-- Revenue Optimization
-- ==================

-- Dynamic Pricing Procedure
CREATE PROCEDURE update_dynamic_pricing()
BEGIN
    DECLARE peak_factor DECIMAL(3,2);
    DECLARE demand_factor DECIMAL(3,2);
    
    -- Calculate peak season factor
    SET peak_factor = CASE
        WHEN MONTH(NOW()) IN (6,7,8,12) THEN 1.2  -- Peak season
        WHEN MONTH(NOW()) IN (3,4,9,10) THEN 1.1  -- Mid season
        ELSE 1.0  -- Off season
    END;
    
    -- Calculate demand factor based on recent bookings
    SELECT 
        CASE
            WHEN COUNT(*) > 100 THEN 1.2
            WHEN COUNT(*) > 50 THEN 1.1
            ELSE 1.0
        END INTO demand_factor
    FROM train_bookings
    WHERE booking_date >= DATE_SUB(NOW(), INTERVAL 7 DAY);
    
    -- Update base prices
    UPDATE train_prices
    SET 
        current_price = base_price * peak_factor * demand_factor,
        last_updated = NOW();
END //

-- Predictive Analytics
-- ==================

-- Booking Forecast
CREATE PROCEDURE forecast_bookings()
BEGIN
    -- Calculate average daily bookings
    SELECT 
        DAYNAME(booking_date) as day_of_week,
        AVG(daily_bookings) as avg_bookings,
        AVG(daily_revenue) as avg_revenue
    FROM (
        SELECT 
            booking_date,
            COUNT(*) as daily_bookings,
            SUM(total_amount) as daily_revenue
        FROM train_bookings
        WHERE booking_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY booking_date
    ) daily_stats
    GROUP BY DAYNAME(booking_date)
    ORDER BY FIELD(
        DAYNAME(booking_date),
        'Monday', 'Tuesday', 'Wednesday', 'Thursday',
        'Friday', 'Saturday', 'Sunday'
    );
END //

-- Maintenance Procedures
-- ===================

-- Database Optimization
CREATE PROCEDURE optimize_database()
BEGIN
    -- Analyze tables
    ANALYZE TABLE train_bookings;
    ANALYZE TABLE cruise_bookings;
    ANALYZE TABLE car_rentals;
    
    -- Optimize tables
    OPTIMIZE TABLE train_bookings;
    OPTIMIZE TABLE cruise_bookings;
    OPTIMIZE TABLE car_rentals;
    
    -- Update statistics
    ANALYZE TABLE performance_metrics;
    ANALYZE TABLE booking_metrics;
END //

-- Data Cleanup
CREATE PROCEDURE cleanup_old_data()
BEGIN
    -- Archive old data
    INSERT INTO archived_bookings
    SELECT * FROM train_bookings
    WHERE booking_date < DATE_SUB(NOW(), INTERVAL 1 YEAR)
    AND status IN ('completed', 'cancelled');
    
    -- Remove archived data
    DELETE FROM train_bookings
    WHERE booking_date < DATE_SUB(NOW(), INTERVAL 1 YEAR)
    AND status IN ('completed', 'cancelled');
    
    -- Clean up metrics
    DELETE FROM performance_metrics
    WHERE metric_date < DATE_SUB(NOW(), INTERVAL 6 MONTH);
    
    -- Clean up alerts
    DELETE FROM service_alerts
    WHERE created_at < DATE_SUB(NOW(), INTERVAL 3 MONTH)
    AND severity != 'HIGH';
END //

-- Required Tables
-- ============

CREATE TABLE IF NOT EXISTS train_prices (
    price_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    train_id BIGINT,
    route_id BIGINT,
    base_price DECIMAL(10,2),
    current_price DECIMAL(10,2),
    last_updated TIMESTAMP,
    INDEX idx_train_route (train_id, route_id)
);

CREATE TABLE IF NOT EXISTS archived_bookings (
    booking_id BIGINT PRIMARY KEY,
    user_id BIGINT,
    train_id BIGINT,
    booking_date DATETIME,
    total_amount DECIMAL(10,2),
    status VARCHAR(50),
    archived_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_date (booking_date)
);

DELIMITER ;
