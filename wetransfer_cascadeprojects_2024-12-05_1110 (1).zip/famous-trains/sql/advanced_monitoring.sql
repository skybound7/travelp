USE luxury_travel;

DELIMITER //

-- Advanced Service Analytics
-- =======================

-- Detailed Train Analytics
CREATE OR REPLACE VIEW train_performance AS
SELECT 
    t.train_id,
    t.train_name,
    COUNT(b.booking_id) as total_bookings,
    SUM(b.total_amount) as revenue,
    AVG(b.total_amount) as avg_ticket_price,
    COUNT(DISTINCT b.user_id) as unique_passengers,
    AVG(r.rating) as avg_rating,
    COUNT(CASE WHEN b.status = 'cancelled' THEN 1 END) as cancellations
FROM trains t
LEFT JOIN train_bookings b ON t.train_id = b.train_id
LEFT JOIN reviews r ON b.booking_id = r.booking_id
GROUP BY t.train_id;

-- Route Analytics
CREATE OR REPLACE VIEW route_analytics AS
SELECT 
    r.route_id,
    r.origin,
    r.destination,
    COUNT(b.booking_id) as total_trips,
    SUM(b.total_amount) as revenue,
    COUNT(DISTINCT b.user_id) as unique_passengers,
    AVG(b.total_amount) as avg_fare
FROM routes r
LEFT JOIN train_bookings b ON r.route_id = b.route_id
GROUP BY r.route_id;

-- Cross-Service Analytics
CREATE OR REPLACE VIEW service_comparison AS
SELECT 
    DATE_FORMAT(booking_date, '%Y-%m') as month,
    service_type,
    COUNT(*) as bookings,
    SUM(total_amount) as revenue,
    COUNT(DISTINCT user_id) as customers,
    AVG(total_amount) as avg_booking_value
FROM (
    SELECT booking_date, total_amount, user_id, 'Train' as service_type 
    FROM train_bookings
    UNION ALL
    SELECT booking_date, total_amount, user_id, 'Cruise' 
    FROM cruise_bookings
    UNION ALL
    SELECT rental_date, total_amount, user_id, 'Car' 
    FROM car_rentals
) all_services
GROUP BY month, service_type;

-- Monitoring Triggers
-- ================

-- Performance Monitor
CREATE TRIGGER monitor_service_performance
AFTER INSERT ON train_bookings
FOR EACH ROW
BEGIN
    -- Track hourly performance
    INSERT INTO performance_metrics (
        service_type,
        metric_date,
        metric_hour,
        bookings,
        revenue,
        avg_response_time
    )
    SELECT 
        'Train',
        CURRENT_DATE,
        HOUR(NOW()),
        COUNT(*),
        SUM(total_amount),
        AVG(TIMESTAMPDIFF(SECOND, created_at, updated_at))
    FROM train_bookings
    WHERE DATE(booking_date) = CURRENT_DATE
    AND HOUR(booking_date) = HOUR(NOW())
    ON DUPLICATE KEY UPDATE
        bookings = VALUES(bookings),
        revenue = VALUES(revenue),
        avg_response_time = VALUES(avg_response_time);
    
    -- Generate alerts if needed
    IF NEW.status = 'error' THEN
        INSERT INTO service_alerts (
            service_type,
            alert_type,
            message,
            severity
        ) VALUES (
            'Train',
            'BOOKING_ERROR',
            CONCAT('Booking failed for train ID: ', NEW.train_id),
            'HIGH'
        );
    END IF;
END //

-- Required Tables
-- ============

CREATE TABLE IF NOT EXISTS performance_metrics (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    metric_date DATE,
    metric_hour INT,
    bookings INT,
    revenue DECIMAL(10,2),
    avg_response_time DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_hourly_metric (service_type, metric_date, metric_hour)
);

-- Maintenance Procedures
-- ===================

-- Archive Old Data
CREATE PROCEDURE archive_old_data(IN months_old INT)
BEGIN
    DECLARE cutoff_date DATE;
    SET cutoff_date = DATE_SUB(CURRENT_DATE, INTERVAL months_old MONTH);
    
    -- Archive old bookings
    INSERT INTO archived_bookings
    SELECT * FROM train_bookings
    WHERE booking_date < cutoff_date
    AND status IN ('completed', 'cancelled');
    
    DELETE FROM train_bookings
    WHERE booking_date < cutoff_date
    AND status IN ('completed', 'cancelled');
    
    -- Archive old metrics
    INSERT INTO archived_metrics
    SELECT * FROM performance_metrics
    WHERE metric_date < cutoff_date;
    
    DELETE FROM performance_metrics
    WHERE metric_date < cutoff_date;
END //

-- Optimization Procedures
-- ====================

-- Analyze Route Performance
CREATE PROCEDURE analyze_route_performance()
BEGIN
    SELECT 
        r.route_id,
        r.origin,
        r.destination,
        COUNT(*) as total_trips,
        SUM(b.total_amount) as revenue,
        AVG(b.total_amount) as avg_fare,
        COUNT(CASE WHEN b.status = 'cancelled' THEN 1 END) as cancellations,
        AVG(r.rating) as avg_rating
    FROM routes r
    LEFT JOIN train_bookings b ON r.route_id = b.route_id
    LEFT JOIN reviews r ON b.booking_id = r.booking_id
    GROUP BY r.route_id
    ORDER BY revenue DESC;
END //

DELIMITER ;
