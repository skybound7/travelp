USE luxury_travel;

DELIMITER //

-- Analytics Framework
-- ================

-- Report Configurations
CREATE TABLE IF NOT EXISTS report_configurations (
    config_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    report_name VARCHAR(100),
    report_type VARCHAR(50),
    metrics JSON,
    filters JSON,
    refresh_interval INT,
    last_updated TIMESTAMP,
    INDEX idx_type_updated (report_type, last_updated)
);

-- Metric Snapshots
CREATE TABLE IF NOT EXISTS metric_snapshots (
    snapshot_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    metric_name VARCHAR(100),
    metric_value JSON,
    dimensions JSON,
    snapshot_time TIMESTAMP,
    INDEX idx_metric_time (metric_name, snapshot_time)
);

-- Dashboard Views
CREATE TABLE IF NOT EXISTS dashboard_views (
    view_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    view_name VARCHAR(100),
    components JSON,
    layout JSON,
    access_roles JSON,
    active BOOLEAN DEFAULT TRUE
);

-- Analytics Functions
-- ===============

-- Generate Report
CREATE PROCEDURE generate_report(
    IN p_report_name VARCHAR(100),
    IN p_start_date DATE,
    IN p_end_date DATE
)
BEGIN
    DECLARE v_metrics JSON;
    DECLARE v_filters JSON;
    
    -- Get report configuration
    SELECT metrics, filters
    INTO v_metrics, v_filters
    FROM report_configurations
    WHERE report_name = p_report_name;
    
    -- Generate report data
    WITH report_data AS (
        -- Bookings Overview
        SELECT 
            'BOOKINGS' as metric_group,
            JSON_OBJECT(
                'total_bookings', COUNT(*),
                'total_revenue', SUM(total_amount),
                'avg_booking_value', AVG(total_amount),
                'service_distribution', JSON_OBJECTAGG(
                    service_type, COUNT(*)
                )
            ) as metric_data
        FROM (
            SELECT * FROM train_bookings
            UNION ALL
            SELECT * FROM cruise_bookings
            UNION ALL
            SELECT * FROM car_rentals
        ) all_bookings
        WHERE created_at BETWEEN p_start_date AND p_end_date
        
        UNION ALL
        
        -- Customer Metrics
        SELECT 
            'CUSTOMERS',
            JSON_OBJECT(
                'active_customers', COUNT(DISTINCT user_id),
                'new_customers', COUNT(DISTINCT CASE 
                    WHEN created_at BETWEEN p_start_date AND p_end_date 
                    THEN user_id END),
                'loyalty_distribution', JSON_OBJECTAGG(
                    JSON_EXTRACT(preferences, '$.loyalty_tier'),
                    COUNT(*)
                )
            )
        FROM customer_profiles
        WHERE last_activity >= p_start_date
        
        UNION ALL
        
        -- Performance Metrics
        SELECT 
            'PERFORMANCE',
            JSON_OBJECT(
                'avg_response_time', AVG(
                    JSON_EXTRACT(metrics, '$.response_time')
                ),
                'system_uptime', MIN(
                    JSON_EXTRACT(metrics, '$.uptime_percentage')
                ),
                'error_rate', AVG(
                    JSON_EXTRACT(metrics, '$.error_rate')
                )
            )
        FROM system_metrics
        WHERE timestamp BETWEEN p_start_date AND p_end_date
    )
    
    -- Store snapshot
    INSERT INTO metric_snapshots (
        metric_name,
        metric_value,
        dimensions,
        snapshot_time
    )
    SELECT 
        metric_group,
        metric_data,
        JSON_OBJECT(
            'report_name', p_report_name,
            'start_date', p_start_date,
            'end_date', p_end_date
        ),
        CURRENT_TIMESTAMP
    FROM report_data;
    
    -- Return report
    SELECT JSON_OBJECT(
        'report_name', p_report_name,
        'generated_at', CURRENT_TIMESTAMP,
        'date_range', JSON_OBJECT(
            'start_date', p_start_date,
            'end_date', p_end_date
        ),
        'metrics', JSON_ARRAYAGG(
            JSON_OBJECT(
                'group', metric_group,
                'data', metric_data
            )
        )
    ) as report
    FROM report_data;
END //

-- Initialize Report Configurations
INSERT IGNORE INTO report_configurations 
(report_name, report_type, metrics, filters, refresh_interval) VALUES 
('Executive Dashboard',
 'SUMMARY',
 '["revenue", "bookings", "customer_satisfaction", "system_performance"]',
 '{"time_range": "DAILY", "service_types": "ALL"}',
 3600),
('Operations Report',
 'OPERATIONAL',
 '["route_performance", "maintenance_status", "service_quality"]',
 '{"time_range": "HOURLY", "critical_only": true}',
 1800),
('Customer Insights',
 'ANALYTICAL',
 '["customer_segments", "loyalty_trends", "booking_patterns"]',
 '{"time_range": "WEEKLY", "segment_type": "ALL"}',
 86400);

-- Initialize Dashboard Views
INSERT IGNORE INTO dashboard_views 
(view_name, components, layout, access_roles) VALUES 
('Executive Overview',
 '[{"type": "REVENUE_CHART", "refresh": 300},
   {"type": "BOOKING_TRENDS", "refresh": 600},
   {"type": "PERFORMANCE_METRICS", "refresh": 60}]',
 '{"layout": "GRID", "columns": 3}',
 '["EXECUTIVE", "MANAGER"]'),
('Operations Center',
 '[{"type": "ROUTE_MAP", "refresh": 30},
   {"type": "ALERT_FEED", "refresh": 15},
   {"type": "SYSTEM_HEALTH", "refresh": 60}]',
 '{"layout": "CUSTOM", "config": "OPERATIONS"}',
 '["OPERATIONS", "SUPPORT"]');

-- Analytics Dashboard
CREATE OR REPLACE VIEW analytics_dashboard AS
SELECT 
    dv.view_name,
    -- View Configuration
    JSON_OBJECT(
        'components', dv.components,
        'layout', dv.layout,
        'access_roles', dv.access_roles
    ) as view_config,
    -- Latest Metrics
    JSON_OBJECT(
        'metrics', (
            SELECT JSON_OBJECTAGG(
                ms.metric_name,
                JSON_OBJECT(
                    'value', ms.metric_value,
                    'dimensions', ms.dimensions,
                    'last_updated', ms.snapshot_time
                )
            )
            FROM metric_snapshots ms
            WHERE ms.snapshot_time = (
                SELECT MAX(snapshot_time)
                FROM metric_snapshots
                WHERE metric_name = ms.metric_name
            )
        )
    ) as current_metrics,
    -- Report Configurations
    JSON_OBJECT(
        'reports', (
            SELECT JSON_ARRAYAGG(
                JSON_OBJECT(
                    'name', rc.report_name,
                    'type', rc.report_type,
                    'metrics', rc.metrics,
                    'refresh_interval', rc.refresh_interval,
                    'last_updated', rc.last_updated
                )
            )
            FROM report_configurations rc
        )
    ) as report_config
FROM dashboard_views dv
WHERE dv.active = TRUE;

DELIMITER ;
