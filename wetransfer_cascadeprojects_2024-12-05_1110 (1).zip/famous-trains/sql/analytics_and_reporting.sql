USE luxury_travel;

DELIMITER //

-- Service Analytics Views
-- =====================

-- Revenue Analytics
CREATE OR REPLACE VIEW revenue_analytics AS
SELECT 
    DATE_FORMAT(booking_date, '%Y-%m') AS month,
    COUNT(*) as total_bookings,
    SUM(total_amount) as total_revenue,
    AVG(total_amount) as avg_booking_value,
    service_type,
    payment_status
FROM (
    SELECT booking_date, total_amount, 'Train' as service_type, payment_status 
    FROM train_bookings
    UNION ALL
    SELECT booking_date, total_amount, 'Cruise' as service_type, payment_status 
    FROM cruise_bookings
    UNION ALL
    SELECT rental_date as booking_date, total_amount, 'Car' as service_type, payment_status 
    FROM car_rentals
) all_bookings
GROUP BY 
    DATE_FORMAT(booking_date, '%Y-%m'),
    service_type,
    payment_status
ORDER BY month DESC;

-- Customer Journey Analytics
CREATE OR REPLACE VIEW customer_journey AS
SELECT 
    u.user_id,
    u.email,
    MIN(b.booking_date) as first_booking,
    MAX(b.booking_date) as last_booking,
    COUNT(*) as total_bookings,
    SUM(b.total_amount) as total_spent,
    COUNT(DISTINCT b.service_type) as services_used,
    ROUND(AVG(r.rating), 2) as avg_rating
FROM users u
LEFT JOIN (
    SELECT user_id, booking_date, total_amount, 'Train' as service_type 
    FROM train_bookings
    UNION ALL
    SELECT user_id, booking_date, total_amount, 'Cruise' as service_type 
    FROM cruise_bookings
    UNION ALL
    SELECT user_id, rental_date, total_amount, 'Car' as service_type 
    FROM car_rentals
) b ON u.user_id = b.user_id
LEFT JOIN reviews r ON u.user_id = r.user_id
GROUP BY u.user_id;

-- Service Performance Triggers
-- =========================

-- Booking Performance Monitor
CREATE TRIGGER after_booking_monitor
AFTER INSERT ON train_bookings
FOR EACH ROW
BEGIN
    -- Calculate daily booking metrics
    INSERT INTO booking_metrics (
        booking_date,
        service_type,
        total_bookings,
        total_revenue,
        avg_booking_value
    )
    SELECT 
        DATE(NEW.booking_date),
        'Train',
        COUNT(*),
        SUM(total_amount),
        AVG(total_amount)
    FROM train_bookings
    WHERE DATE(booking_date) = DATE(NEW.booking_date)
    ON DUPLICATE KEY UPDATE
        total_bookings = VALUES(total_bookings),
        total_revenue = VALUES(total_revenue),
        avg_booking_value = VALUES(avg_booking_value);
END //

-- Cross-Service Integration
-- ======================

-- Bundle Booking Trigger
CREATE TRIGGER after_multi_service_booking
AFTER INSERT ON train_bookings
FOR EACH ROW
BEGIN
    DECLARE has_other_booking BOOLEAN;
    
    -- Check for other service bookings within 7 days
    SELECT EXISTS (
        SELECT 1 FROM (
            SELECT booking_date FROM cruise_bookings
            UNION ALL
            SELECT rental_date FROM car_rentals
        ) other_bookings
        WHERE ABS(DATEDIFF(other_bookings.booking_date, NEW.booking_date)) <= 7
    ) INTO has_other_booking;
    
    -- Apply multi-service discount if applicable
    IF has_other_booking THEN
        INSERT INTO discounts (
            booking_id,
            discount_type,
            amount,
            created_at
        ) VALUES (
            NEW.booking_id,
            'MULTI_SERVICE',
            NEW.total_amount * 0.1,
            NOW()
        );
    END IF;
END //

-- Create Required Tables
-- ===================

CREATE TABLE IF NOT EXISTS booking_metrics (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    booking_date DATE,
    service_type VARCHAR(50),
    total_bookings INT,
    total_revenue DECIMAL(10,2),
    avg_booking_value DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_daily_metric (booking_date, service_type)
);

CREATE TABLE IF NOT EXISTS discounts (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    booking_id BIGINT,
    discount_type VARCHAR(50),
    amount DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Service-Specific Analytics
-- =======================

-- Train Service Analytics
CREATE OR REPLACE VIEW train_service_analytics AS
SELECT 
    t.train_id,
    t.train_name,
    COUNT(b.booking_id) as total_bookings,
    SUM(b.total_amount) as total_revenue,
    AVG(b.total_amount) as avg_booking_value,
    COUNT(DISTINCT b.user_id) as unique_customers,
    ROUND(AVG(r.rating), 2) as avg_rating
FROM trains t
LEFT JOIN train_bookings b ON t.train_id = b.train_id
LEFT JOIN reviews r ON b.booking_id = r.booking_id
GROUP BY t.train_id;

-- Route Performance Analytics
CREATE OR REPLACE VIEW route_analytics AS
SELECT 
    r.route_id,
    r.origin,
    r.destination,
    COUNT(b.booking_id) as total_bookings,
    SUM(b.total_amount) as total_revenue,
    AVG(b.total_amount) as avg_booking_value,
    COUNT(DISTINCT b.user_id) as unique_customers
FROM routes r
LEFT JOIN train_bookings b ON r.route_id = b.route_id
GROUP BY r.route_id;

DELIMITER ;
