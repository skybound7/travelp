USE luxury_travel;

DELIMITER //

-- Advanced Analytics Views
-- ======================

-- Cross-Service Booking Analysis
CREATE OR REPLACE VIEW cross_service_analytics AS
SELECT 
    u.user_id,
    CONCAT(u.first_name, ' ', u.last_name) AS customer_name,
    COUNT(DISTINCT t.booking_id) AS train_bookings,
    COUNT(DISTINCT c.booking_id) AS cruise_bookings,
    COUNT(DISTINCT r.rental_id) AS car_rentals,
    COUNT(DISTINCT h.booking_id) AS homestay_bookings,
    COUNT(DISTINCT i.policy_id) AS insurance_policies,
    ROUND(AVG(t.total_amount), 2) AS avg_train_spend,
    ROUND(AVG(c.total_amount), 2) AS avg_cruise_spend,
    ROUND(AVG(r.total_amount), 2) AS avg_car_rental_spend,
    DATE_FORMAT(MIN(LEAST(
        IFNULL(t.booking_date, '9999-12-31'),
        IFNULL(c.booking_date, '9999-12-31'),
        IFNULL(r.rental_date, '9999-12-31')
    )), '%Y-%m-%d') AS first_booking_date,
    DATEDIFF(NOW(), MIN(LEAST(
        IFNULL(t.booking_date, '9999-12-31'),
        IFNULL(c.booking_date, '9999-12-31'),
        IFNULL(r.rental_date, '9999-12-31')
    ))) AS days_since_first_booking
FROM users u
LEFT JOIN train_bookings t ON u.user_id = t.user_id
LEFT JOIN cruise_bookings c ON u.user_id = c.user_id
LEFT JOIN car_rentals r ON u.user_id = r.user_id
LEFT JOIN homestay_bookings h ON u.user_id = h.user_id
LEFT JOIN insurance_policies i ON u.user_id = i.user_id
GROUP BY u.user_id;

-- Seasonal Trend Analysis
CREATE OR REPLACE VIEW seasonal_trends AS
SELECT 
    YEAR(booking_date) AS year,
    MONTH(booking_date) AS month,
    service_type,
    COUNT(*) AS booking_count,
    ROUND(AVG(total_amount), 2) AS avg_booking_value,
    SUM(total_amount) AS total_revenue
FROM (
    SELECT booking_date, 'Train' AS service_type, total_amount FROM train_bookings
    UNION ALL
    SELECT booking_date, 'Cruise' AS service_type, total_amount FROM cruise_bookings
    UNION ALL
    SELECT rental_date AS booking_date, 'Car Rental' AS service_type, total_amount FROM car_rentals
    UNION ALL
    SELECT booking_date, 'Homestay' AS service_type, total_amount FROM homestay_bookings
) AS combined_bookings
GROUP BY YEAR(booking_date), MONTH(booking_date), service_type
ORDER BY year DESC, month DESC;

-- Customer Segmentation Analysis
CREATE OR REPLACE VIEW customer_segments AS
WITH customer_metrics AS (
    SELECT 
        u.user_id,
        COUNT(DISTINCT b.booking_id) AS total_bookings,
        SUM(b.total_amount) AS total_spent,
        DATEDIFF(NOW(), MIN(b.booking_date)) AS customer_age_days,
        DATEDIFF(NOW(), MAX(b.booking_date)) AS days_since_last_booking
    FROM users u
    LEFT JOIN (
        SELECT booking_id, user_id, total_amount, booking_date FROM train_bookings
        UNION ALL
        SELECT booking_id, user_id, total_amount, booking_date FROM cruise_bookings
        UNION ALL
        SELECT rental_id, user_id, total_amount, rental_date FROM car_rentals
    ) b ON u.user_id = b.user_id
    GROUP BY u.user_id
)
SELECT 
    user_id,
    CASE 
        WHEN total_spent > 10000 AND total_bookings >= 5 THEN 'VIP'
        WHEN total_spent > 5000 OR total_bookings >= 3 THEN 'Regular'
        WHEN days_since_last_booking > 365 THEN 'Inactive'
        ELSE 'New'
    END AS customer_segment,
    total_bookings,
    total_spent,
    customer_age_days,
    days_since_last_booking
FROM customer_metrics;

-- Service Performance Metrics
CREATE OR REPLACE VIEW service_performance AS
SELECT
    service_name,
    total_bookings,
    total_revenue,
    avg_booking_value,
    cancellation_rate,
    avg_rating,
    ROUND(revenue_growth, 2) AS revenue_growth_percent
FROM (
    SELECT 
        'Train' AS service_name,
        COUNT(*) AS total_bookings,
        SUM(total_amount) AS total_revenue,
        AVG(total_amount) AS avg_booking_value,
        COUNT(CASE WHEN status = 'cancelled' THEN 1 END) / COUNT(*) * 100 AS cancellation_rate,
        AVG(rating) AS avg_rating,
        ((SUM(CASE WHEN booking_date >= DATE_SUB(NOW(), INTERVAL 1 MONTH) THEN total_amount END) /
          NULLIF(SUM(CASE WHEN booking_date >= DATE_SUB(NOW(), INTERVAL 2 MONTH) 
                         AND booking_date < DATE_SUB(NOW(), INTERVAL 1 MONTH) 
                    THEN total_amount END), 0)) - 1) * 100 AS revenue_growth
    FROM train_bookings
    LEFT JOIN reviews ON train_bookings.booking_id = reviews.booking_id
    UNION ALL
    SELECT 
        'Cruise' AS service_name,
        COUNT(*),
        SUM(total_amount),
        AVG(total_amount),
        COUNT(CASE WHEN status = 'cancelled' THEN 1 END) / COUNT(*) * 100,
        AVG(rating),
        ((SUM(CASE WHEN booking_date >= DATE_SUB(NOW(), INTERVAL 1 MONTH) THEN total_amount END) /
          NULLIF(SUM(CASE WHEN booking_date >= DATE_SUB(NOW(), INTERVAL 2 MONTH) 
                         AND booking_date < DATE_SUB(NOW(), INTERVAL 1 MONTH) 
                    THEN total_amount END), 0)) - 1) * 100
    FROM cruise_bookings
    LEFT JOIN reviews ON cruise_bookings.booking_id = reviews.booking_id
) AS service_metrics;

-- Automation Triggers
-- =================

-- Automatic VIP Status Update
CREATE TRIGGER after_booking_update_vip_status
AFTER INSERT ON train_bookings
FOR EACH ROW
BEGIN
    DECLARE total_spent DECIMAL(10,2);
    DECLARE booking_count INT;
    
    -- Calculate total spent across all services
    SELECT SUM(total_amount), COUNT(*)
    INTO total_spent, booking_count
    FROM (
        SELECT total_amount FROM train_bookings WHERE user_id = NEW.user_id
        UNION ALL
        SELECT total_amount FROM cruise_bookings WHERE user_id = NEW.user_id
        UNION ALL
        SELECT total_amount FROM car_rentals WHERE user_id = NEW.user_id
    ) AS all_bookings;
    
    -- Update user status if criteria met
    IF total_spent > 10000 AND booking_count >= 5 THEN
        UPDATE users 
        SET status = 'VIP',
            updated_at = NOW()
        WHERE user_id = NEW.user_id;
        
        -- Create notification
        INSERT INTO notifications (user_id, type, message)
        VALUES (NEW.user_id, 'STATUS_UPGRADE', 'Congratulations! You have been upgraded to VIP status.');
    END IF;
END //

-- Automatic Price Optimization
CREATE TRIGGER before_booking_optimize_price
BEFORE INSERT ON train_bookings
FOR EACH ROW
BEGIN
    DECLARE season_factor DECIMAL(3,2);
    DECLARE demand_factor DECIMAL(3,2);
    
    -- Calculate seasonal factor
    SET season_factor = CASE
        WHEN MONTH(NEW.booking_date) IN (6,7,8) THEN 1.2  -- Peak summer
        WHEN MONTH(NEW.booking_date) IN (12,1) THEN 1.15  -- Peak winter
        ELSE 1.0
    END;
    
    -- Calculate demand factor based on recent bookings
    SELECT CASE
        WHEN COUNT(*) > 100 THEN 1.1
        WHEN COUNT(*) > 50 THEN 1.05
        ELSE 1.0
    END INTO demand_factor
    FROM train_bookings
    WHERE booking_date >= DATE_SUB(NEW.booking_date, INTERVAL 7 DAY);
    
    -- Apply price optimization
    SET NEW.total_amount = NEW.total_amount * season_factor * demand_factor;
END //

-- Cross-Service Integration
-- =======================

-- Bundle Discount Trigger
CREATE TRIGGER after_booking_check_bundle
AFTER INSERT ON train_bookings
FOR EACH ROW
BEGIN
    DECLARE has_cruise BOOLEAN;
    DECLARE has_hotel BOOLEAN;
    DECLARE discount_amount DECIMAL(10,2);
    
    -- Check for related bookings within 7 days
    SELECT EXISTS(
        SELECT 1 FROM cruise_bookings 
        WHERE user_id = NEW.user_id 
        AND ABS(DATEDIFF(booking_date, NEW.booking_date)) <= 7
    ) INTO has_cruise;
    
    SELECT EXISTS(
        SELECT 1 FROM homestay_bookings 
        WHERE user_id = NEW.user_id 
        AND ABS(DATEDIFF(booking_date, NEW.booking_date)) <= 7
    ) INTO has_hotel;
    
    -- Apply bundle discount if eligible
    IF has_cruise OR has_hotel THEN
        SET discount_amount = NEW.total_amount * 0.1;  -- 10% discount
        
        -- Create discount record
        INSERT INTO discounts (
            user_id, 
            booking_id, 
            discount_type,
            amount,
            created_at
        ) VALUES (
            NEW.user_id,
            NEW.booking_id,
            'BUNDLE_DISCOUNT',
            discount_amount,
            NOW()
        );
        
        -- Update booking amount
        UPDATE train_bookings 
        SET total_amount = total_amount - discount_amount,
            updated_at = NOW()
        WHERE booking_id = NEW.booking_id;
        
        -- Notify user
        INSERT INTO notifications (
            user_id,
            type,
            message
        ) VALUES (
            NEW.user_id,
            'DISCOUNT_APPLIED',
            CONCAT('Bundle discount of $', discount_amount, ' applied to your booking.')
        );
    END IF;
END //

DELIMITER ;
