USE luxury_travel;

DELIMITER //

-- Security Workflow System
-- =====================

-- Security Workflows
CREATE TABLE IF NOT EXISTS security_workflows (
    workflow_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    workflow_name VARCHAR(100),
    trigger_conditions JSON,
    actions JSON,
    severity ENUM('LOW', 'MEDIUM', 'HIGH', 'CRITICAL'),
    status ENUM('ACTIVE', 'DISABLED', 'TESTING'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_severity (severity)
);

-- Workflow History
CREATE TABLE IF NOT EXISTS workflow_executions (
    execution_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    workflow_id BIGINT,
    trigger_event JSON,
    execution_steps JSON,
    execution_result JSON,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    status ENUM('STARTED', 'COMPLETED', 'FAILED'),
    FOREIGN KEY (workflow_id) REFERENCES security_workflows(workflow_id),
    INDEX idx_status (status)
);

-- Advanced Security Reports
-- =====================

-- Security Risk Score
CREATE OR REPLACE VIEW security_risk_score AS
SELECT 
    CURRENT_TIMESTAMP as assessment_time,
    -- Overall Risk Score (0-100)
    (
        -- Active Threats Weight (40%)
        (SELECT COUNT(*) * 10 FROM threat_incidents 
         WHERE status IN ('NEW', 'INVESTIGATING') 
         AND severity IN ('HIGH', 'CRITICAL')) * 0.4 +
        
        -- Failed Logins Weight (20%)
        (SELECT COUNT(*) FROM failed_login_attempts 
         WHERE attempt_time >= DATE_SUB(NOW(), INTERVAL 1 HOUR)) * 0.2 +
        
        -- Anomaly Score Weight (25%)
        (SELECT COALESCE(AVG(score_value) * 100, 0) FROM anomaly_scores 
         WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)) * 0.25 +
        
        -- Security Alerts Weight (15%)
        (SELECT COUNT(*) * 5 FROM security_alerts 
         WHERE status = 'NEW' 
         AND severity IN ('HIGH', 'CRITICAL')) * 0.15
    ) as risk_score,
    
    -- Risk Factors
    JSON_OBJECT(
        'active_threats', (
            SELECT COUNT(*) FROM threat_incidents 
            WHERE status IN ('NEW', 'INVESTIGATING')
        ),
        'failed_logins', (
            SELECT COUNT(*) FROM failed_login_attempts 
            WHERE attempt_time >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
        ),
        'high_risk_users', (
            SELECT COUNT(DISTINCT user_id) FROM anomaly_scores 
            WHERE score_value > 0.7 
            AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
        )
    ) as risk_factors;

-- Security Workflow Procedures
-- ========================

-- Execute Security Workflow
CREATE PROCEDURE execute_security_workflow(
    IN p_workflow_id BIGINT,
    IN p_trigger_event JSON
)
BEGIN
    DECLARE v_workflow_actions JSON;
    DECLARE v_execution_id BIGINT;
    
    -- Start workflow execution
    INSERT INTO workflow_executions (
        workflow_id,
        trigger_event,
        execution_steps,
        started_at,
        status
    ) VALUES (
        p_workflow_id,
        p_trigger_event,
        JSON_ARRAY(),
        NOW(),
        'STARTED'
    );
    
    SET v_execution_id = LAST_INSERT_ID();
    
    -- Get workflow actions
    SELECT actions INTO v_workflow_actions 
    FROM security_workflows 
    WHERE workflow_id = p_workflow_id;
    
    -- Execute actions
    BEGIN
        DECLARE v_step_result JSON;
        
        -- Account lockout action
        IF JSON_CONTAINS_PATH(v_workflow_actions, 'one', '$.lock_account') THEN
            UPDATE users 
            SET status = 'LOCKED',
                locked_at = NOW()
            WHERE user_id = JSON_EXTRACT(p_trigger_event, '$.user_id');
            
            SET v_step_result = JSON_OBJECT(
                'action', 'ACCOUNT_LOCK',
                'timestamp', NOW(),
                'success', TRUE
            );
        END IF;
        
        -- Alert generation action
        IF JSON_CONTAINS_PATH(v_workflow_actions, 'one', '$.create_alert') THEN
            INSERT INTO security_alerts (
                alert_type,
                severity,
                details,
                status
            ) VALUES (
                JSON_EXTRACT(p_trigger_event, '$.type'),
                JSON_EXTRACT(v_workflow_actions, '$.create_alert.severity'),
                p_trigger_event,
                'NEW'
            );
            
            SET v_step_result = JSON_ARRAY_APPEND(
                COALESCE(v_step_result, JSON_ARRAY()),
                '$',
                JSON_OBJECT(
                    'action', 'CREATE_ALERT',
                    'timestamp', NOW(),
                    'success', TRUE
                )
            );
        END IF;
        
        -- Update execution record
        UPDATE workflow_executions
        SET execution_steps = v_step_result,
            execution_result = JSON_OBJECT(
                'success', TRUE,
                'completed_actions', JSON_LENGTH(v_step_result)
            ),
            completed_at = NOW(),
            status = 'COMPLETED'
        WHERE execution_id = v_execution_id;
    END;
END //

-- Initialize Default Workflows
INSERT IGNORE INTO security_workflows 
(workflow_name, trigger_conditions, actions, severity, status) VALUES
('Account Lockout', 
 '{"type": "failed_login", "threshold": 5, "window_minutes": 15}',
 '{"lock_account": true, "create_alert": {"severity": "HIGH"}}',
 'HIGH', 'ACTIVE'),
('Suspicious Transaction', 
 '{"type": "transaction", "amount_threshold": 5000, "velocity_threshold": 3}',
 '{"create_alert": {"severity": "HIGH"}, "flag_transaction": true}',
 'HIGH', 'ACTIVE'),
('Access Pattern Violation', 
 '{"type": "access_pattern", "location_changes": 3, "window_minutes": 60}',
 '{"create_alert": {"severity": "CRITICAL"}, "require_2fa": true}',
 'CRITICAL', 'ACTIVE');

-- Automated Response System
CREATE EVENT IF NOT EXISTS security_workflow_processor
ON SCHEDULE EVERY 1 MINUTE
DO
BEGIN
    -- Process failed login attempts
    SELECT user_id, ip_address, COUNT(*) as attempt_count
    INTO @user_id, @ip_address, @attempts
    FROM failed_login_attempts
    WHERE attempt_time >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)
    GROUP BY user_id, ip_address
    HAVING COUNT(*) >= 5;
    
    IF @attempts >= 5 THEN
        CALL execute_security_workflow(
            1, -- Account Lockout workflow
            JSON_OBJECT(
                'type', 'failed_login',
                'user_id', @user_id,
                'ip_address', @ip_address,
                'attempt_count', @attempts
            )
        );
    END IF;
    
    -- Process suspicious transactions
    SELECT user_id, COUNT(*) as tx_count, SUM(amount) as total_amount
    INTO @user_id, @tx_count, @total_amount
    FROM transactions
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
    GROUP BY user_id
    HAVING COUNT(*) >= 3 OR SUM(amount) >= 5000;
    
    IF @tx_count >= 3 OR @total_amount >= 5000 THEN
        CALL execute_security_workflow(
            2, -- Suspicious Transaction workflow
            JSON_OBJECT(
                'type', 'transaction',
                'user_id', @user_id,
                'transaction_count', @tx_count,
                'total_amount', @total_amount
            )
        );
    END IF;
END //

DELIMITER ;
