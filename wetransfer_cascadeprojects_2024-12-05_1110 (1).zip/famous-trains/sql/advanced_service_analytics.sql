USE luxury_travel;

DELIMITER //

-- Advanced Service Analytics
-- ========================

-- Cruise Service Analytics
CREATE OR REPLACE VIEW cruise_analytics AS
SELECT 
    c.cruise_id,
    c.cruise_name,
    c.destination,
    COUNT(b.booking_id) as total_bookings,
    SUM(b.total_amount) as total_revenue,
    AVG(b.total_amount) as avg_booking_value,
    COUNT(DISTINCT cabin_type) as cabin_types_booked,
    SUM(CASE WHEN b.status = 'cancelled' THEN 1 ELSE 0 END) as cancellations,
    ROUND(AVG(r.rating), 2) as avg_rating,
    COUNT(DISTINCT b.user_id) as unique_customers
FROM cruises c
LEFT JOIN cruise_bookings b ON c.cruise_id = b.cruise_id
LEFT JOIN reviews r ON b.booking_id = r.booking_id
GROUP BY c.cruise_id;

-- Car Rental Analytics
CREATE OR REPLACE VIEW car_rental_analytics AS
SELECT 
    v.vehicle_id,
    v.model,
    v.category,
    COUNT(r.rental_id) as total_rentals,
    SUM(r.total_amount) as total_revenue,
    AVG(r.total_amount) as avg_rental_value,
    AVG(DATEDIFF(r.end_date, r.start_date)) as avg_rental_duration,
    COUNT(DISTINCT r.user_id) as unique_customers,
    ROUND(AVG(rev.rating), 2) as avg_rating
FROM vehicles v
LEFT JOIN car_rentals r ON v.vehicle_id = r.vehicle_id
LEFT JOIN reviews rev ON r.rental_id = rev.booking_id
GROUP BY v.vehicle_id;

-- Seasonal Performance Analytics
CREATE OR REPLACE VIEW seasonal_analytics AS
SELECT 
    YEAR(booking_date) as year,
    QUARTER(booking_date) as quarter,
    service_type,
    COUNT(*) as total_bookings,
    SUM(total_amount) as total_revenue,
    AVG(total_amount) as avg_booking_value,
    COUNT(DISTINCT user_id) as unique_customers
FROM (
    SELECT booking_date, total_amount, 'Train' as service_type, user_id FROM train_bookings
    UNION ALL
    SELECT booking_date, total_amount, 'Cruise' as service_type, user_id FROM cruise_bookings
    UNION ALL
    SELECT rental_date, total_amount, 'Car' as service_type, user_id FROM car_rentals
) all_services
GROUP BY 
    YEAR(booking_date),
    QUARTER(booking_date),
    service_type
ORDER BY year DESC, quarter DESC;

-- Advanced Automation Triggers
-- =========================

-- Dynamic Pricing Trigger
CREATE TRIGGER before_booking_dynamic_pricing
BEFORE INSERT ON train_bookings
FOR EACH ROW
BEGIN
    DECLARE demand_factor DECIMAL(3,2);
    DECLARE season_factor DECIMAL(3,2);
    DECLARE loyalty_factor DECIMAL(3,2);
    
    -- Calculate demand based on recent bookings
    SELECT 
        CASE 
            WHEN COUNT(*) > 100 THEN 1.2
            WHEN COUNT(*) > 50 THEN 1.1
            ELSE 1.0
        END INTO demand_factor
    FROM train_bookings
    WHERE route_id = NEW.route_id
    AND booking_date >= DATE_SUB(NEW.booking_date, INTERVAL 7 DAY);
    
    -- Seasonal pricing
    SET season_factor = CASE
        WHEN MONTH(NEW.booking_date) IN (6,7,8,12) THEN 1.2  -- Peak season
        WHEN MONTH(NEW.booking_date) IN (3,4,9,10) THEN 1.1  -- Mid season
        ELSE 1.0  -- Off season
    END;
    
    -- Loyalty pricing
    SELECT 
        CASE 
            WHEN COUNT(*) > 10 THEN 0.85  -- 15% discount
            WHEN COUNT(*) > 5 THEN 0.90   -- 10% discount
            WHEN COUNT(*) > 2 THEN 0.95   -- 5% discount
            ELSE 1.0
        END INTO loyalty_factor
    FROM train_bookings
    WHERE user_id = NEW.user_id;
    
    -- Apply pricing factors
    SET NEW.total_amount = NEW.total_amount * demand_factor * season_factor * loyalty_factor;
END //

-- Customer Satisfaction Monitor
CREATE TRIGGER after_review_monitor
AFTER INSERT ON reviews
FOR EACH ROW
BEGIN
    DECLARE avg_rating DECIMAL(3,2);
    DECLARE service_type VARCHAR(20);
    
    -- Determine service type
    SELECT 
        CASE 
            WHEN EXISTS (SELECT 1 FROM train_bookings WHERE booking_id = NEW.booking_id) THEN 'Train'
            WHEN EXISTS (SELECT 1 FROM cruise_bookings WHERE booking_id = NEW.booking_id) THEN 'Cruise'
            WHEN EXISTS (SELECT 1 FROM car_rentals WHERE rental_id = NEW.booking_id) THEN 'Car'
        END 
    INTO service_type;
    
    -- Calculate new average rating
    SELECT AVG(rating) INTO avg_rating
    FROM reviews r
    WHERE EXISTS (
        SELECT 1 
        FROM train_bookings tb 
        WHERE tb.booking_id = r.booking_id
        AND service_type = 'Train'
    );
    
    -- Create alert if rating is low
    IF NEW.rating < 3 THEN
        INSERT INTO service_alerts (
            alert_type,
            service_type,
            reference_id,
            message,
            priority
        ) VALUES (
            'LOW_RATING',
            service_type,
            NEW.booking_id,
            CONCAT('Low rating (', NEW.rating, ') received for booking #', NEW.booking_id),
            'HIGH'
        );
    END IF;
    
    -- Update service metrics
    INSERT INTO service_metrics (
        service_type,
        metric_date,
        avg_rating,
        total_reviews
    )
    SELECT 
        service_type,
        CURRENT_DATE,
        avg_rating,
        COUNT(*)
    FROM reviews r
    WHERE DATE(r.created_at) = CURRENT_DATE
    GROUP BY service_type
    ON DUPLICATE KEY UPDATE
        avg_rating = VALUES(avg_rating),
        total_reviews = VALUES(total_reviews);
END //

-- Cross-Service Integration Features
-- ===============================

-- Package Recommendation Trigger
CREATE TRIGGER after_booking_recommend
AFTER INSERT ON train_bookings
FOR EACH ROW
BEGIN
    DECLARE user_preferences JSON;
    
    -- Gather user preferences
    SELECT 
        JSON_OBJECT(
            'preferred_class', MAX(class),
            'avg_spend', AVG(total_amount),
            'frequent_destinations', JSON_ARRAYAGG(destination)
        )
    INTO user_preferences
    FROM train_bookings
    WHERE user_id = NEW.user_id
    GROUP BY user_id;
    
    -- Create personalized recommendations
    INSERT INTO user_recommendations (
        user_id,
        recommendation_type,
        service_type,
        details,
        priority
    )
    SELECT 
        NEW.user_id,
        'PACKAGE',
        service_type,
        JSON_OBJECT(
            'service_id', id,
            'name', name,
            'price', price,
            'match_score', match_score
        ),
        'HIGH'
    FROM (
        SELECT 
            'Cruise' as service_type,
            cruise_id as id,
            cruise_name as name,
            base_price as price,
            -- Calculate match score based on preferences
            (CASE 
                WHEN base_price BETWEEN 
                    JSON_EXTRACT(user_preferences, '$.avg_spend') * 0.8 AND 
                    JSON_EXTRACT(user_preferences, '$.avg_spend') * 1.2 
                THEN 1 
                ELSE 0 
            END) as match_score
        FROM cruises
        WHERE destination IN (
            SELECT value 
            FROM JSON_TABLE(
                JSON_EXTRACT(user_preferences, '$.frequent_destinations'),
                '$[*]' COLUMNS (value VARCHAR(100) PATH '$')
            ) as dest
        )
    ) recommendations
    WHERE match_score > 0;
END //

-- Create Required Tables
-- ===================

CREATE TABLE IF NOT EXISTS service_alerts (
    alert_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    alert_type VARCHAR(50),
    service_type VARCHAR(50),
    reference_id BIGINT,
    message TEXT,
    priority VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    INDEX idx_service_type (service_type),
    INDEX idx_priority (priority)
);

CREATE TABLE IF NOT EXISTS service_metrics (
    metric_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    metric_date DATE,
    avg_rating DECIMAL(3,2),
    total_reviews INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_daily_service_metric (service_type, metric_date)
);

CREATE TABLE IF NOT EXISTS user_recommendations (
    recommendation_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT,
    recommendation_type VARCHAR(50),
    service_type VARCHAR(50),
    details JSON,
    priority VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_service (user_id, service_type)
);

DELIMITER ;
