USE luxury_travel;

DELIMITER //

-- Route Optimization Framework
-- ========================

-- Routes
CREATE TABLE IF NOT EXISTS routes (
    route_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    route_name VARCHAR(100),
    origin VARCHAR(50),
    destination VARCHAR(50),
    stops JSON,
    distance DECIMAL(10,2),
    typical_duration INT, -- in minutes
    status VARCHAR(20) DEFAULT 'ACTIVE',
    INDEX idx_locations (origin, destination)
);

-- Schedule Templates
CREATE TABLE IF NOT EXISTS schedule_templates (
    template_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    route_id BIGINT,
    day_type VARCHAR(20), -- WEEKDAY, WEEKEND, HOLIDAY
    departure_times JSON,
    capacity_rules JSON,
    active BOOLEAN DEFAULT TRUE,
    INDEX idx_route_day (route_id, day_type)
);

-- Route Performance
CREATE TABLE IF NOT EXISTS route_performance (
    performance_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    route_id BIGINT,
    service_date DATE,
    metrics JSON,
    issues JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_route_date (route_id, service_date)
);

-- Optimization Functions
-- ==================

-- Optimize Route
CREATE PROCEDURE optimize_route(
    IN p_route_id BIGINT,
    IN p_date_range JSON
)
BEGIN
    -- Calculate route metrics
    WITH route_metrics AS (
        SELECT 
            rp.route_id,
            AVG(JSON_EXTRACT(rp.metrics, '$.occupancy_rate')) as avg_occupancy,
            AVG(JSON_EXTRACT(rp.metrics, '$.delay_minutes')) as avg_delay,
            COUNT(DISTINCT JSON_EXTRACT(rp.issues, '$.type')) as issue_types
        FROM route_performance rp
        WHERE rp.route_id = p_route_id
        AND rp.service_date BETWEEN 
            JSON_UNQUOTE(JSON_EXTRACT(p_date_range, '$.start_date'))
            AND JSON_UNQUOTE(JSON_EXTRACT(p_date_range, '$.end_date'))
        GROUP BY rp.route_id
    )
    
    -- Update route status and optimization suggestions
    UPDATE routes r
    JOIN route_metrics rm ON r.route_id = rm.route_id
    SET r.status = CASE
        WHEN rm.avg_occupancy < 0.3 THEN 'REVIEW_NEEDED'
        WHEN rm.avg_delay > 30 THEN 'OPTIMIZE_TIMING'
        WHEN rm.issue_types > 3 THEN 'INVESTIGATE'
        ELSE 'OPTIMIZED'
    END;
    
    -- Generate performance report
    INSERT INTO route_performance (
        route_id,
        service_date,
        metrics,
        issues
    )
    SELECT 
        p_route_id,
        CURRENT_DATE,
        JSON_OBJECT(
            'occupancy_rate', rm.avg_occupancy,
            'delay_minutes', rm.avg_delay,
            'reliability_score', (100 - LEAST(rm.avg_delay * 2, 100)),
            'optimization_status', r.status
        ),
        JSON_OBJECT(
            'issue_count', rm.issue_types,
            'recommendations', CASE
                WHEN rm.avg_occupancy < 0.3 THEN JSON_ARRAY(
                    'Consider reducing frequency',
                    'Analyze pricing strategy',
                    'Review marketing efforts'
                )
                WHEN rm.avg_delay > 30 THEN JSON_ARRAY(
                    'Review schedule buffers',
                    'Analyze delay patterns',
                    'Consider route modifications'
                )
                WHEN rm.issue_types > 3 THEN JSON_ARRAY(
                    'Conduct detailed route audit',
                    'Review maintenance schedules',
                    'Assess staff allocation'
                )
                ELSE JSON_ARRAY('Maintain current optimization')
            END
        )
    FROM route_metrics rm
    JOIN routes r ON rm.route_id = r.route_id;
END //

-- Generate Schedule
CREATE PROCEDURE generate_schedule(
    IN p_route_id BIGINT,
    IN p_service_date DATE
)
BEGIN
    DECLARE v_day_type VARCHAR(20);
    
    -- Determine day type
    SET v_day_type = CASE
        WHEN DAYOFWEEK(p_service_date) IN (1, 7) THEN 'WEEKEND'
        WHEN p_service_date IN (SELECT holiday_date FROM holidays) THEN 'HOLIDAY'
        ELSE 'WEEKDAY'
    END;
    
    -- Generate schedule based on template
    SELECT 
        r.route_id,
        r.route_name,
        r.origin,
        r.destination,
        r.stops,
        st.departure_times,
        JSON_MERGE_PATCH(
            st.capacity_rules,
            JSON_OBJECT(
                'date_specific_rules', (
                    SELECT JSON_ARRAYAGG(
                        JSON_OBJECT(
                            'type', 'CAPACITY_ADJUSTMENT',
                            'factor', CASE
                                WHEN rp.metrics->>'$.occupancy_rate' > 0.9 THEN 1.2
                                WHEN rp.metrics->>'$.occupancy_rate' < 0.3 THEN 0.8
                                ELSE 1.0
                            END,
                            'reason', CASE
                                WHEN rp.metrics->>'$.occupancy_rate' > 0.9 THEN 'HIGH_DEMAND'
                                WHEN rp.metrics->>'$.occupancy_rate' < 0.3 THEN 'LOW_DEMAND'
                                ELSE 'NORMAL_DEMAND'
                            END
                        )
                    )
                    FROM route_performance rp
                    WHERE rp.route_id = r.route_id
                    AND rp.service_date = p_service_date
                )
            )
        ) as adjusted_capacity_rules
    FROM routes r
    JOIN schedule_templates st 
        ON r.route_id = st.route_id
        AND st.day_type = v_day_type
        AND st.active = TRUE
    WHERE r.route_id = p_route_id
    AND r.status != 'INACTIVE';
END //

-- Initialize Routes
INSERT IGNORE INTO routes 
(route_name, origin, destination, stops, distance, typical_duration) VALUES 
('Express North',
 'London',
 'Edinburgh',
 '["York", "Newcastle"]',
 632.5,
 420),
('Coastal Line',
 'Brighton',
 'Portsmouth',
 '["Worthing", "Chichester"]',
 85.3,
 90),
('Mountain Express',
 'Glasgow',
 'Inverness',
 '["Perth", "Aviemore"]',
 251.8,
 180);

-- Initialize Schedule Templates
INSERT IGNORE INTO schedule_templates 
(route_id, day_type, departure_times, capacity_rules) VALUES 
(1, 'WEEKDAY',
 '["06:00", "09:00", "12:00", "15:00", "18:00"]',
 '{"base_capacity": 200, "peak_multiplier": 1.2}'),
(1, 'WEEKEND',
 '["08:00", "12:00", "16:00", "20:00"]',
 '{"base_capacity": 200, "holiday_multiplier": 1.3}');

-- Route Optimization Dashboard
CREATE OR REPLACE VIEW route_optimization_dashboard AS
SELECT 
    r.route_id,
    r.route_name,
    -- Route Details
    JSON_OBJECT(
        'origin', r.origin,
        'destination', r.destination,
        'stops', r.stops,
        'status', r.status
    ) as route_details,
    -- Performance Metrics
    JSON_OBJECT(
        'avg_metrics', (
            SELECT JSON_OBJECT(
                'occupancy_rate', AVG(JSON_EXTRACT(metrics, '$.occupancy_rate')),
                'delay_minutes', AVG(JSON_EXTRACT(metrics, '$.delay_minutes')),
                'reliability_score', AVG(JSON_EXTRACT(metrics, '$.reliability_score'))
            )
            FROM route_performance rp
            WHERE rp.route_id = r.route_id
            AND rp.service_date >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
        )
    ) as performance_metrics,
    -- Schedule Information
    JSON_OBJECT(
        'templates', JSON_ARRAYAGG(
            JSON_OBJECT(
                'day_type', st.day_type,
                'departures', st.departure_times,
                'capacity_rules', st.capacity_rules
            )
        )
    ) as schedule_info,
    -- Optimization Status
    JSON_OBJECT(
        'last_optimized', MAX(rp.created_at),
        'current_issues', (
            SELECT JSON_ARRAYAGG(
                JSON_EXTRACT(issues, '$.recommendations')
            )
            FROM route_performance rp2
            WHERE rp2.route_id = r.route_id
            AND rp2.service_date = CURRENT_DATE
        )
    ) as optimization_status
FROM routes r
LEFT JOIN schedule_templates st ON r.route_id = st.route_id
LEFT JOIN route_performance rp ON r.route_id = rp.route_id
GROUP BY r.route_id, r.route_name;

DELIMITER ;
