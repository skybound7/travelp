USE luxury_travel;

DELIMITER //

-- Cruise Service Procedures
-- ========================

CREATE PROCEDURE book_cruise(
    IN p_itinerary_id INT,
    IN p_user_id INT,
    IN p_cabin_type VARCHAR(20),
    IN p_passenger_count INT
)
BEGIN
    DECLARE v_total_amount DECIMAL(10,2);
    DECLARE v_available_capacity INT;
    
    -- Check availability
    SELECT (cs.capacity - COALESCE(SUM(cb.passenger_count), 0)) INTO v_available_capacity
    FROM cruise_ships cs
    JOIN cruise_itineraries ci ON cs.ship_id = ci.ship_id
    LEFT JOIN cruise_bookings cb ON ci.itinerary_id = cb.itinerary_id
    WHERE ci.itinerary_id = p_itinerary_id
    GROUP BY cs.capacity;
    
    IF v_available_capacity >= p_passenger_count THEN
        -- Calculate total amount based on cabin type and passengers
        SELECT base_price * p_passenger_count * 
            CASE p_cabin_type
                WHEN 'suite' THEN 2.5
                WHEN 'deluxe' THEN 1.8
                ELSE 1.0
            END
        INTO v_total_amount
        FROM cruise_itineraries
        WHERE itinerary_id = p_itinerary_id;
        
        -- Create booking
        INSERT INTO cruise_bookings (
            itinerary_id, user_id, cabin_type, 
            passenger_count, total_amount
        ) VALUES (
            p_itinerary_id, p_user_id, p_cabin_type, 
            p_passenger_count, v_total_amount
        );
        
        SELECT 'Cruise booking successful' AS message;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Insufficient capacity';
    END IF;
END //

-- Car Rental Procedures
-- ====================

CREATE PROCEDURE rent_car(
    IN p_car_id INT,
    IN p_user_id INT,
    IN p_pickup_date DATETIME,
    IN p_return_date DATETIME,
    IN p_pickup_location VARCHAR(100),
    IN p_return_location VARCHAR(100)
)
BEGIN
    DECLARE v_daily_rate DECIMAL(10,2);
    DECLARE v_total_days INT;
    DECLARE v_total_amount DECIMAL(10,2);
    
    -- Check car availability
    IF EXISTS (
        SELECT 1 FROM rental_cars 
        WHERE car_id = p_car_id 
        AND status = 'available'
    ) THEN
        -- Calculate rental duration and amount
        SELECT daily_rate INTO v_daily_rate
        FROM rental_cars WHERE car_id = p_car_id;
        
        SET v_total_days = DATEDIFF(p_return_date, p_pickup_date);
        SET v_total_amount = v_daily_rate * v_total_days;
        
        -- Create rental
        INSERT INTO car_rentals (
            car_id, user_id, pickup_date, return_date,
            pickup_location, return_location, total_amount
        ) VALUES (
            p_car_id, p_user_id, p_pickup_date, p_return_date,
            p_pickup_location, p_return_location, v_total_amount
        );
        
        -- Update car status
        UPDATE rental_cars 
        SET status = 'rented'
        WHERE car_id = p_car_id;
        
        SELECT 'Car rental successful' AS message;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Car not available';
    END IF;
END //

-- Airport Transfer Procedures
-- =========================

CREATE PROCEDURE schedule_transfer(
    IN p_user_id INT,
    IN p_vehicle_type VARCHAR(20),
    IN p_pickup_location VARCHAR(100),
    IN p_dropoff_location VARCHAR(100),
    IN p_pickup_time DATETIME,
    IN p_passenger_count INT,
    IN p_flight_number VARCHAR(20)
)
BEGIN
    DECLARE v_vehicle_id INT;
    DECLARE v_base_rate DECIMAL(10,2);
    DECLARE v_total_amount DECIMAL(10,2);
    
    -- Find available vehicle
    SELECT vehicle_id, base_rate INTO v_vehicle_id, v_base_rate
    FROM transfer_vehicles
    WHERE type = p_vehicle_type
    AND status = 'active'
    AND capacity >= p_passenger_count
    LIMIT 1;
    
    IF v_vehicle_id IS NOT NULL THEN
        -- Calculate transfer amount
        SET v_total_amount = v_base_rate * 
            CASE 
                WHEN p_passenger_count > 4 THEN 1.5
                ELSE 1.0
            END;
        
        -- Create transfer booking
        INSERT INTO airport_transfers (
            user_id, vehicle_id, pickup_location, dropoff_location,
            pickup_time, passenger_count, flight_number, total_amount
        ) VALUES (
            p_user_id, v_vehicle_id, p_pickup_location, p_dropoff_location,
            p_pickup_time, p_passenger_count, p_flight_number, v_total_amount
        );
        
        SELECT 'Transfer scheduled successfully' AS message;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No suitable vehicle available';
    END IF;
END //

-- Insurance Procedures
-- ==================

CREATE PROCEDURE purchase_insurance(
    IN p_user_id INT,
    IN p_plan_id INT,
    IN p_booking_reference VARCHAR(100),
    IN p_start_date DATE,
    IN p_end_date DATE
)
BEGIN
    DECLARE v_base_premium DECIMAL(10,2);
    DECLARE v_total_days INT;
    DECLARE v_premium_amount DECIMAL(10,2);
    
    -- Get plan details
    SELECT base_premium INTO v_base_premium
    FROM insurance_plans
    WHERE plan_id = p_plan_id AND status = 'active';
    
    IF v_base_premium IS NOT NULL THEN
        -- Calculate premium
        SET v_total_days = DATEDIFF(p_end_date, p_start_date);
        SET v_premium_amount = v_base_premium * 
            CASE 
                WHEN v_total_days > 30 THEN 0.9  -- 10% discount for long-term
                ELSE 1.0
            END;
        
        -- Create policy
        INSERT INTO insurance_policies (
            plan_id, user_id, booking_reference,
            start_date, end_date, premium_amount
        ) VALUES (
            p_plan_id, p_user_id, p_booking_reference,
            p_start_date, p_end_date, v_premium_amount
        );
        
        SELECT 'Insurance policy created successfully' AS message;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid insurance plan';
    END IF;
END //

-- Courier Service Procedures
-- ========================

CREATE PROCEDURE create_shipment(
    IN p_service_id INT,
    IN p_user_id INT,
    IN p_pickup_address TEXT,
    IN p_delivery_address TEXT,
    IN p_weight DECIMAL(5,2),
    IN p_dimensions VARCHAR(50)
)
BEGIN
    DECLARE v_base_rate DECIMAL(10,2);
    DECLARE v_total_amount DECIMAL(10,2);
    DECLARE v_tracking_number VARCHAR(50);
    
    -- Get service rate
    SELECT base_rate INTO v_base_rate
    FROM courier_services
    WHERE service_id = p_service_id AND status = 'active';
    
    IF v_base_rate IS NOT NULL THEN
        -- Calculate shipping cost
        SET v_total_amount = v_base_rate * p_weight;
        -- Generate tracking number
        SET v_tracking_number = CONCAT('TRK', UNIX_TIMESTAMP(), p_user_id);
        
        -- Create shipment
        INSERT INTO courier_shipments (
            service_id, user_id, pickup_address, delivery_address,
            weight, dimensions, tracking_number, total_amount
        ) VALUES (
            p_service_id, p_user_id, p_pickup_address, p_delivery_address,
            p_weight, p_dimensions, v_tracking_number, v_total_amount
        );
        
        SELECT 'Shipment created successfully' AS message,
               v_tracking_number AS tracking_number;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid courier service';
    END IF;
END //

-- Homestay Procedures
-- ==================

CREATE PROCEDURE book_homestay(
    IN p_homestay_id INT,
    IN p_user_id INT,
    IN p_check_in_date DATE,
    IN p_check_out_date DATE,
    IN p_guest_count INT
)
BEGIN
    DECLARE v_nightly_rate DECIMAL(10,2);
    DECLARE v_max_guests INT;
    DECLARE v_total_nights INT;
    DECLARE v_total_amount DECIMAL(10,2);
    
    -- Get homestay details
    SELECT nightly_rate, max_guests 
    INTO v_nightly_rate, v_max_guests
    FROM homestays
    WHERE homestay_id = p_homestay_id 
    AND status = 'available';
    
    IF v_nightly_rate IS NOT NULL THEN
        IF p_guest_count <= v_max_guests THEN
            -- Calculate total amount
            SET v_total_nights = DATEDIFF(p_check_out_date, p_check_in_date);
            SET v_total_amount = v_nightly_rate * v_total_nights;
            
            -- Create booking
            INSERT INTO homestay_bookings (
                homestay_id, user_id, check_in_date,
                check_out_date, guest_count, total_amount
            ) VALUES (
                p_homestay_id, p_user_id, p_check_in_date,
                p_check_out_date, p_guest_count, v_total_amount
            );
            
            -- Update homestay status
            UPDATE homestays 
            SET status = 'booked'
            WHERE homestay_id = p_homestay_id;
            
            SELECT 'Homestay booked successfully' AS message;
        ELSE
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Guest count exceeds capacity';
        END IF;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Homestay not available';
    END IF;
END //

-- Eurail Pass Procedures
-- =====================

CREATE PROCEDURE book_eurail_pass(
    IN p_pass_id INT,
    IN p_user_id INT,
    IN p_start_date DATE,
    IN p_passenger_count INT
)
BEGIN
    DECLARE v_base_price DECIMAL(10,2);
    DECLARE v_total_amount DECIMAL(10,2);
    
    -- Get pass details
    SELECT base_price INTO v_base_price
    FROM eurail_passes
    WHERE pass_id = p_pass_id AND status = 'active';
    
    IF v_base_price IS NOT NULL THEN
        -- Calculate total amount
        SET v_total_amount = v_base_price * p_passenger_count;
        
        -- Create booking
        INSERT INTO eurail_bookings (
            pass_id, user_id, start_date,
            passenger_count, total_amount
        ) VALUES (
            p_pass_id, p_user_id, p_start_date,
            p_passenger_count, v_total_amount
        );
        
        SELECT 'Eurail pass booked successfully' AS message;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid pass selection';
    END IF;
END //

-- IRCTC Booking Procedures
-- =======================

CREATE PROCEDURE book_irctc_train(
    IN p_train_id INT,
    IN p_user_id INT,
    IN p_journey_date DATE,
    IN p_class_type VARCHAR(20),
    IN p_passenger_count INT
)
BEGIN
    DECLARE v_total_amount DECIMAL(10,2);
    DECLARE v_pnr_number VARCHAR(20);
    
    -- Generate PNR
    SET v_pnr_number = CONCAT('PNR', UNIX_TIMESTAMP(), p_user_id);
    
    -- Create booking
    INSERT INTO irctc_bookings (
        train_id, user_id, journey_date, class_type,
        passenger_count, pnr_number, total_amount
    ) VALUES (
        p_train_id, p_user_id, p_journey_date, p_class_type,
        p_passenger_count, v_pnr_number, v_total_amount
    );
    
    SELECT 'IRCTC booking successful' AS message,
           v_pnr_number AS pnr_number;
END //

-- Additional Views
-- ==============

CREATE VIEW service_revenue_summary AS
SELECT 
    'Cruise' AS service_type,
    COUNT(*) AS total_bookings,
    SUM(total_amount) AS total_revenue
FROM cruise_bookings
WHERE status = 'confirmed'
UNION ALL
SELECT 
    'Car Rental',
    COUNT(*),
    SUM(total_amount)
FROM car_rentals
WHERE status = 'completed'
UNION ALL
SELECT 
    'Airport Transfer',
    COUNT(*),
    SUM(total_amount)
FROM airport_transfers
WHERE status = 'completed'
UNION ALL
SELECT 
    'Insurance',
    COUNT(*),
    SUM(premium_amount)
FROM insurance_policies
WHERE status = 'active'
UNION ALL
SELECT 
    'Courier',
    COUNT(*),
    SUM(total_amount)
FROM courier_shipments
WHERE status = 'delivered'
UNION ALL
SELECT 
    'Homestay',
    COUNT(*),
    SUM(total_amount)
FROM homestay_bookings
WHERE status = 'completed'
UNION ALL
SELECT 
    'Eurail',
    COUNT(*),
    SUM(total_amount)
FROM eurail_bookings
WHERE status = 'confirmed'
UNION ALL
SELECT 
    'IRCTC',
    COUNT(*),
    SUM(total_amount)
FROM irctc_bookings
WHERE status = 'completed';

-- Triggers
-- =======

-- Cruise Booking Trigger
CREATE TRIGGER after_cruise_booking
AFTER INSERT ON cruise_bookings
FOR EACH ROW
BEGIN
    -- Send notification
    INSERT INTO notifications (
        user_id,
        message,
        type
    ) VALUES (
        NEW.user_id,
        CONCAT('Your cruise booking #', NEW.booking_id, ' has been confirmed'),
        'cruise_booking'
    );
END //

-- Car Rental Return Trigger
CREATE TRIGGER after_car_return
AFTER UPDATE ON car_rentals
FOR EACH ROW
BEGIN
    IF NEW.status = 'completed' AND OLD.status = 'active' THEN
        -- Update car status
        UPDATE rental_cars 
        SET status = 'available'
        WHERE car_id = NEW.car_id;
    END IF;
END //

-- Homestay Review Trigger
CREATE TRIGGER after_homestay_review
AFTER INSERT ON reviews
FOR EACH ROW
BEGIN
    -- Update homestay rating
    UPDATE homestays h
    SET h.rating = (
        SELECT AVG(r.rating)
        FROM reviews r
        WHERE r.homestay_id = h.homestay_id
    )
    WHERE h.homestay_id = NEW.homestay_id;
END //

DELIMITER ;
