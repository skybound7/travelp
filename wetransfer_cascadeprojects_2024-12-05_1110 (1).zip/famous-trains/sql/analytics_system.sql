USE luxury_travel;

DELIMITER //

-- Revenue Analytics
-- ===============
CREATE OR REPLACE VIEW revenue_analytics AS
SELECT 
    DATE_FORMAT(booking_date, '%Y-%m') as month,
    service_type,
    COUNT(*) as total_bookings,
    SUM(total_amount) as total_revenue,
    AVG(total_amount) as avg_booking_value,
    COUNT(DISTINCT user_id) as unique_customers
FROM (
    SELECT booking_date, total_amount, 'Train' as service_type, user_id FROM train_bookings
    UNION ALL
    SELECT booking_date, total_amount, 'Cruise' as service_type, user_id FROM cruise_bookings
    UNION ALL
    SELECT rental_date, total_amount, 'Car' as service_type, user_id FROM car_rentals
) all_bookings
GROUP BY month, service_type
ORDER BY month DESC;

-- Customer Analytics
-- ===============
CREATE OR REPLACE VIEW customer_insights AS
SELECT 
    u.user_id,
    COUNT(DISTINCT b.booking_id) as total_bookings,
    SUM(b.total_amount) as total_spent,
    COUNT(DISTINCT b.service_type) as services_used,
    MAX(b.booking_date) as last_booking_date,
    AVG(r.rating) as avg_rating
FROM users u
LEFT JOIN (
    SELECT booking_id, user_id, total_amount, booking_date, 'Train' as service_type FROM train_bookings
    UNION ALL
    SELECT booking_id, user_id, total_amount, booking_date, 'Cruise' FROM cruise_bookings
    UNION ALL
    SELECT rental_id, user_id, total_amount, rental_date, 'Car' FROM car_rentals
) b ON u.user_id = b.user_id
LEFT JOIN reviews r ON u.user_id = r.user_id
GROUP BY u.user_id;

-- Service Performance
-- ================
CREATE OR REPLACE VIEW service_performance AS
SELECT
    service_type,
    COUNT(*) as total_transactions,
    SUM(total_amount) as total_revenue,
    COUNT(DISTINCT user_id) as unique_customers,
    AVG(rating) as avg_rating,
    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancellations
FROM (
    SELECT 'Train' as service_type, tb.*, r.rating 
    FROM train_bookings tb
    LEFT JOIN reviews r ON tb.booking_id = r.booking_id
    UNION ALL
    SELECT 'Cruise', cb.*, r.rating 
    FROM cruise_bookings cb
    LEFT JOIN reviews r ON cb.booking_id = r.booking_id
    UNION ALL
    SELECT 'Car', cr.*, r.rating 
    FROM car_rentals cr
    LEFT JOIN reviews r ON cr.rental_id = r.booking_id
) all_services
GROUP BY service_type;

-- Automated Triggers
-- ===============

-- Customer Loyalty Trigger
CREATE TRIGGER after_booking_loyalty
AFTER INSERT ON train_bookings
FOR EACH ROW
BEGIN
    DECLARE total_spent DECIMAL(10,2);
    DECLARE booking_count INT;
    
    -- Calculate customer metrics
    SELECT 
        SUM(total_amount),
        COUNT(*)
    INTO total_spent, booking_count
    FROM (
        SELECT total_amount FROM train_bookings WHERE user_id = NEW.user_id
        UNION ALL
        SELECT total_amount FROM cruise_bookings WHERE user_id = NEW.user_id
        UNION ALL
        SELECT total_amount FROM car_rentals WHERE user_id = NEW.user_id
    ) all_bookings;
    
    -- Update loyalty status
    IF total_spent > 10000 OR booking_count > 10 THEN
        UPDATE users 
        SET loyalty_tier = 'GOLD',
            updated_at = NOW()
        WHERE user_id = NEW.user_id;
    ELSEIF total_spent > 5000 OR booking_count > 5 THEN
        UPDATE users 
        SET loyalty_tier = 'SILVER',
            updated_at = NOW()
        WHERE user_id = NEW.user_id;
    END IF;
END //

-- Service Monitoring
-- ===============
CREATE TRIGGER monitor_service_health
AFTER INSERT ON train_bookings
FOR EACH ROW
BEGIN
    DECLARE error_count INT;
    
    -- Check for errors
    SELECT COUNT(*) INTO error_count
    FROM train_bookings
    WHERE status = 'error'
    AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR);
    
    -- Create alert if needed
    IF error_count > 5 THEN
        INSERT INTO service_alerts (
            alert_type,
            service_name,
            message,
            severity
        ) VALUES (
            'ERROR_RATE',
            'Train Booking',
            CONCAT('High error rate detected: ', error_count, ' errors in last hour'),
            'HIGH'
        );
    END IF;
END //

-- Required Tables
-- ============

CREATE TABLE IF NOT EXISTS service_alerts (
    alert_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    alert_type VARCHAR(50),
    service_name VARCHAR(100),
    message TEXT,
    severity VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    INDEX idx_severity (severity),
    INDEX idx_created_at (created_at)
);

CREATE TABLE IF NOT EXISTS booking_metrics (
    metric_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    booking_date DATE,
    total_bookings INT,
    total_revenue DECIMAL(10,2),
    avg_booking_value DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_daily_metric (service_type, booking_date)
);

DELIMITER ;
