USE luxury_travel;

DELIMITER //

-- Dynamic Pricing Framework
-- ======================

-- Price Adjustments
CREATE TABLE IF NOT EXISTS price_adjustments (
    adjustment_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    adjustment_type VARCHAR(50),
    adjustment_factor DECIMAL(5,2),
    conditions JSON,
    start_date TIMESTAMP,
    end_date TIMESTAMP,
    active BOOLEAN DEFAULT TRUE,
    INDEX idx_service_dates (service_type, start_date, end_date)
);

-- Demand Forecasts
CREATE TABLE IF NOT EXISTS demand_forecasts (
    forecast_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    forecast_date DATE,
    predicted_demand DECIMAL(10,2),
    confidence_score DECIMAL(5,2),
    factors JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_service_date (service_type, forecast_date)
);

-- Revenue Metrics
CREATE TABLE IF NOT EXISTS revenue_metrics (
    metric_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    metric_date DATE,
    revenue DECIMAL(15,2),
    bookings INT,
    avg_price DECIMAL(10,2),
    dimensions JSON,
    INDEX idx_service_date (service_type, metric_date)
);

-- Pricing Functions
-- ==============

-- Calculate Dynamic Price
CREATE PROCEDURE calculate_dynamic_price(
    IN p_service_type VARCHAR(50),
    IN p_base_price DECIMAL(10,2),
    IN p_booking_date DATE,
    IN p_context JSON
)
BEGIN
    DECLARE v_final_price DECIMAL(10,2);
    DECLARE v_adjustments JSON;
    
    -- Calculate price adjustments
    SELECT 
        p_base_price * COALESCE(
            PROD(
                CASE 
                    WHEN JSON_CONTAINS_PATH(
                        p_context,
                        'all',
                        JSON_UNQUOTE(JSON_EXTRACT(conditions, '$.path'))
                    )
                    THEN adjustment_factor
                    ELSE 1.0
                END
            ),
            1.0
        ),
        JSON_ARRAYAGG(
            JSON_OBJECT(
                'type', adjustment_type,
                'factor', adjustment_factor,
                'applied', JSON_CONTAINS_PATH(
                    p_context,
                    'all',
                    JSON_UNQUOTE(JSON_EXTRACT(conditions, '$.path'))
                )
            )
        )
    INTO v_final_price, v_adjustments
    FROM price_adjustments
    WHERE service_type = p_service_type
    AND active = TRUE
    AND p_booking_date BETWEEN start_date AND end_date;
    
    -- Record pricing decision
    INSERT INTO revenue_metrics (
        service_type,
        metric_date,
        revenue,
        bookings,
        avg_price,
        dimensions
    ) VALUES (
        p_service_type,
        p_booking_date,
        v_final_price,
        1,
        v_final_price,
        JSON_OBJECT(
            'base_price', p_base_price,
            'final_price', v_final_price,
            'adjustments', v_adjustments,
            'context', p_context
        )
    );
    
    -- Return calculated price
    SELECT v_final_price as dynamic_price;
END //

-- Update Demand Forecast
CREATE PROCEDURE update_demand_forecast(
    IN p_service_type VARCHAR(50),
    IN p_forecast_date DATE,
    IN p_factors JSON
)
BEGIN
    DECLARE v_predicted_demand DECIMAL(10,2);
    DECLARE v_confidence_score DECIMAL(5,2);
    
    -- Calculate demand forecast based on historical data and factors
    WITH historical_demand AS (
        SELECT 
            AVG(bookings) as avg_bookings,
            STDDEV(bookings) as std_bookings
        FROM revenue_metrics
        WHERE service_type = p_service_type
        AND metric_date >= DATE_SUB(p_forecast_date, INTERVAL 90 DAY)
    )
    SELECT 
        avg_bookings * JSON_EXTRACT(p_factors, '$.seasonal_factor'),
        1 / (1 + std_bookings / avg_bookings)
    INTO v_predicted_demand, v_confidence_score
    FROM historical_demand;
    
    -- Record forecast
    INSERT INTO demand_forecasts (
        service_type,
        forecast_date,
        predicted_demand,
        confidence_score,
        factors
    ) VALUES (
        p_service_type,
        p_forecast_date,
        v_predicted_demand,
        v_confidence_score,
        p_factors
    )
    ON DUPLICATE KEY UPDATE
        predicted_demand = v_predicted_demand,
        confidence_score = v_confidence_score,
        factors = p_factors;
END //

-- Initialize Price Adjustments
INSERT IGNORE INTO price_adjustments 
(service_type, adjustment_type, adjustment_factor, conditions) VALUES 
('TRAIN', 'PEAK_SEASON',
 1.25,
 '{"path": "$.is_peak_season", "value": true}'),
('TRAIN', 'WEEKEND',
 1.15,
 '{"path": "$.is_weekend", "value": true}'),
('TRAIN', 'LOW_DEMAND',
 0.85,
 '{"path": "$.demand_score", "threshold": 0.3}'),
('TRAIN', 'HIGH_DEMAND',
 1.20,
 '{"path": "$.demand_score", "threshold": 0.8}');

-- Pricing Dashboard
CREATE OR REPLACE VIEW pricing_dashboard AS
SELECT 
    rm.service_type,
    rm.metric_date,
    -- Revenue Metrics
    JSON_OBJECT(
        'total_revenue', SUM(rm.revenue),
        'total_bookings', SUM(rm.bookings),
        'avg_price', AVG(rm.avg_price),
        'price_range', JSON_OBJECT(
            'min', MIN(rm.avg_price),
            'max', MAX(rm.avg_price)
        )
    ) as revenue_metrics,
    -- Demand Insights
    JSON_OBJECT(
        'predicted_demand', df.predicted_demand,
        'confidence_score', df.confidence_score,
        'factors', df.factors
    ) as demand_insights,
    -- Price Adjustments
    (SELECT JSON_ARRAYAGG(
        JSON_OBJECT(
            'type', adjustment_type,
            'factor', adjustment_factor,
            'conditions', conditions
        )
    )
    FROM price_adjustments pa
    WHERE pa.service_type = rm.service_type
    AND pa.active = TRUE) as active_adjustments
FROM revenue_metrics rm
LEFT JOIN demand_forecasts df 
    ON rm.service_type = df.service_type
    AND rm.metric_date = df.forecast_date
GROUP BY rm.service_type, rm.metric_date;

DELIMITER ;
