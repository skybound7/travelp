USE luxury_travel;

DELIMITER //

-- Advanced Monitoring System
-- =======================

-- Detailed Performance Metrics
CREATE OR REPLACE VIEW detailed_performance_metrics AS
SELECT 
    CURRENT_TIMESTAMP as snapshot_time,
    -- Query Performance
    (SELECT COUNT(*) FROM information_schema.processlist) as active_connections,
    (SELECT COUNT(*) FROM information_schema.processlist WHERE command = 'Query') as active_queries,
    -- Table Statistics
    (SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE()) as total_tables,
    (SELECT SUM(data_length + index_length)/1024/1024 FROM information_schema.tables 
     WHERE table_schema = DATABASE()) as total_db_size_mb,
    -- Index Usage
    (SELECT COUNT(*) FROM information_schema.statistics 
     WHERE table_schema = DATABASE()) as total_indexes,
    -- Transaction Stats
    (SELECT COUNT(*) FROM information_schema.innodb_trx) as active_transactions;

-- Advanced Query Analysis
CREATE TABLE IF NOT EXISTS query_analysis_logs (
    log_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    query_id VARCHAR(32),
    query_text TEXT,
    execution_plan JSON,
    execution_stats JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_query_id (query_id),
    INDEX idx_created_at (created_at)
);

-- Backup Management System
-- =====================

CREATE TABLE IF NOT EXISTS backup_history (
    backup_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    backup_type ENUM('FULL', 'INCREMENTAL', 'DIFFERENTIAL'),
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    backup_size BIGINT,
    status VARCHAR(20),
    error_message TEXT,
    backup_location VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_backup_type (backup_type),
    INDEX idx_status (status)
);

-- Backup Procedures
CREATE PROCEDURE perform_backup(
    IN p_backup_type VARCHAR(20),
    IN p_backup_location VARCHAR(255)
)
BEGIN
    DECLARE v_backup_id BIGINT;
    DECLARE v_error_message TEXT;
    
    -- Initialize backup record
    INSERT INTO backup_history (backup_type, start_time, status, backup_location)
    VALUES (p_backup_type, NOW(), 'STARTED', p_backup_location);
    
    SET v_backup_id = LAST_INSERT_ID();
    
    -- Perform backup based on type
    CASE p_backup_type
        WHEN 'FULL' THEN
            BEGIN
                -- Full backup logic
                SET @backup_cmd = CONCAT(
                    'mysqldump --single-transaction --routines --triggers ',
                    '--master-data=2 --databases ', DATABASE(), 
                    ' > ', p_backup_location
                );
            END;
        WHEN 'INCREMENTAL' THEN
            BEGIN
                -- Incremental backup logic using binary logs
                SET @backup_cmd = CONCAT(
                    'mysqlbinlog --start-datetime="',
                    (SELECT MAX(end_time) FROM backup_history WHERE status = 'COMPLETED'),
                    '" --stop-datetime="', NOW(), '" ',
                    '/var/log/mysql/mysql-bin.* > ', p_backup_location
                );
            END;
    END CASE;
    
    -- Update backup record
    UPDATE backup_history
    SET end_time = NOW(),
        status = 'COMPLETED',
        backup_size = (SELECT DATA_LENGTH FROM information_schema.tables WHERE table_schema = DATABASE())
    WHERE backup_id = v_backup_id;
    
    -- Log backup completion
    INSERT INTO maintenance_logs (maintenance_type, target_table, start_time, end_time, status, details)
    VALUES ('BACKUP', 'ALL', NOW(), NOW(), 'COMPLETED', 
            JSON_OBJECT('backup_id', v_backup_id, 'type', p_backup_type, 'location', p_backup_location));
END //

-- Advanced Optimization Procedures
-- ============================

CREATE PROCEDURE optimize_database_performance()
BEGIN
    DECLARE v_table_name VARCHAR(255);
    DECLARE v_done INT DEFAULT FALSE;
    DECLARE v_cur CURSOR FOR 
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = DATABASE();
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;
    
    -- Start optimization
    INSERT INTO maintenance_logs (maintenance_type, target_table, start_time, status)
    VALUES ('OPTIMIZATION', 'ALL', NOW(), 'STARTED');
    
    OPEN v_cur;
    
    read_loop: LOOP
        FETCH v_cur INTO v_table_name;
        IF v_done THEN
            LEAVE read_loop;
        END IF;
        
        -- Analyze table
        SET @analyze_sql = CONCAT('ANALYZE TABLE ', v_table_name);
        PREPARE stmt FROM @analyze_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        
        -- Optimize table
        SET @optimize_sql = CONCAT('OPTIMIZE TABLE ', v_table_name);
        PREPARE stmt FROM @optimize_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        
        -- Log optimization
        INSERT INTO maintenance_logs (maintenance_type, target_table, start_time, end_time, status)
        VALUES ('TABLE_OPTIMIZATION', v_table_name, NOW(), NOW(), 'COMPLETED');
    END LOOP;
    
    CLOSE v_cur;
    
    -- Update final status
    UPDATE maintenance_logs
    SET end_time = NOW(),
        status = 'COMPLETED'
    WHERE maintenance_type = 'OPTIMIZATION'
    AND target_table = 'ALL'
    AND end_time IS NULL;
END //

-- Scheduled Tasks
-- =============

-- Hourly Performance Monitoring
CREATE EVENT IF NOT EXISTS hourly_performance_check
ON SCHEDULE EVERY 1 HOUR
DO
BEGIN
    INSERT INTO query_analysis_logs (query_id, query_text, execution_stats)
    SELECT 
        MD5(CONCAT(sql_text, thread_id)),
        sql_text,
        JSON_OBJECT(
            'count_star', count_star,
            'sum_timer_wait', sum_timer_wait,
            'avg_timer_wait', avg_timer_wait
        )
    FROM performance_schema.events_statements_summary_by_digest
    WHERE last_seen >= DATE_SUB(NOW(), INTERVAL 1 HOUR);
END //

-- Weekly Backup
CREATE EVENT IF NOT EXISTS weekly_full_backup
ON SCHEDULE EVERY 1 WEEK
STARTS CURRENT_TIMESTAMP + INTERVAL 1 DAY
DO
BEGIN
    CALL perform_backup('FULL', CONCAT('/backup/full_', DATE_FORMAT(NOW(), '%Y%m%d'), '.sql'));
END //

-- Daily Incremental Backup
CREATE EVENT IF NOT EXISTS daily_incremental_backup
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP + INTERVAL 1 DAY
DO
BEGIN
    CALL perform_backup('INCREMENTAL', CONCAT('/backup/inc_', DATE_FORMAT(NOW(), '%Y%m%d'), '.sql'));
END //

DELIMITER ;
