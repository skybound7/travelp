USE luxury_travel;

DELIMITER //

-- Performance Monitoring Framework
-- ============================

-- Query Performance Tracking
CREATE TABLE IF NOT EXISTS query_performance (
    tracking_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    query_hash VARCHAR(64),
    query_pattern TEXT,
    execution_time DECIMAL(10,4),
    rows_examined BIGINT,
    rows_returned BIGINT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    context JSON,
    INDEX idx_hash_time (query_hash, timestamp)
);

-- System Metrics
CREATE TABLE IF NOT EXISTS system_metrics (
    metric_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    metric_type VARCHAR(50),
    metric_value DECIMAL(15,4),
    dimensions JSON,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_type_time (metric_type, timestamp)
);

-- Optimization Suggestions
CREATE TABLE IF NOT EXISTS optimization_suggestions (
    suggestion_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    target_object VARCHAR(100),
    suggestion_type VARCHAR(50),
    priority INT,
    impact_score DECIMAL(5,2),
    details JSON,
    implemented BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Performance Functions
-- ==================

-- Track Query Performance
CREATE PROCEDURE track_query_performance(
    IN p_query_pattern TEXT,
    IN p_execution_time DECIMAL(10,4),
    IN p_rows_examined BIGINT,
    IN p_rows_returned BIGINT,
    IN p_context JSON
)
BEGIN
    DECLARE v_query_hash VARCHAR(64);
    
    -- Generate query hash
    SET v_query_hash = SHA2(p_query_pattern, 256);
    
    -- Record performance metrics
    INSERT INTO query_performance (
        query_hash,
        query_pattern,
        execution_time,
        rows_examined,
        rows_returned,
        context
    ) VALUES (
        v_query_hash,
        p_query_pattern,
        p_execution_time,
        p_rows_examined,
        p_rows_returned,
        p_context
    );
    
    -- Generate optimization suggestions
    IF p_execution_time > 1.0 OR p_rows_examined / NULLIF(p_rows_returned, 0) > 100 THEN
        INSERT INTO optimization_suggestions (
            target_object,
            suggestion_type,
            priority,
            impact_score,
            details
        )
        VALUES (
            p_query_pattern,
            'QUERY_OPTIMIZATION',
            CASE 
                WHEN p_execution_time > 5.0 THEN 1
                WHEN p_execution_time > 2.0 THEN 2
                ELSE 3
            END,
            LEAST(p_execution_time / 10, 1.0),
            JSON_OBJECT(
                'execution_time', p_execution_time,
                'rows_examined', p_rows_examined,
                'rows_returned', p_rows_returned,
                'suggestions', JSON_ARRAY(
                    CASE 
                        WHEN p_rows_examined / NULLIF(p_rows_returned, 0) > 100 
                        THEN 'Consider adding indexes to reduce rows examined'
                        ELSE 'Optimize query pattern for better performance'
                    END
                )
            )
        );
    END IF;
END //

-- Record System Metrics
CREATE PROCEDURE record_system_metrics(
    IN p_metric_type VARCHAR(50),
    IN p_metric_value DECIMAL(15,4),
    IN p_dimensions JSON
)
BEGIN
    INSERT INTO system_metrics (
        metric_type,
        metric_value,
        dimensions
    ) VALUES (
        p_metric_type,
        p_metric_value,
        p_dimensions
    );
    
    -- Check for anomalies and generate suggestions
    WITH metric_stats AS (
        SELECT 
            AVG(metric_value) as avg_value,
            STDDEV(metric_value) as std_value
        FROM system_metrics
        WHERE metric_type = p_metric_type
        AND timestamp >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
    )
    INSERT INTO optimization_suggestions (
        target_object,
        suggestion_type,
        priority,
        impact_score,
        details
    )
    SELECT 
        p_metric_type,
        'SYSTEM_OPTIMIZATION',
        CASE 
            WHEN (p_metric_value - avg_value) > (2 * std_value) THEN 1
            WHEN (p_metric_value - avg_value) > std_value THEN 2
            ELSE 3
        END,
        LEAST((p_metric_value - avg_value) / avg_value, 1.0),
        JSON_OBJECT(
            'current_value', p_metric_value,
            'average_value', avg_value,
            'standard_deviation', std_value,
            'dimensions', p_dimensions,
            'suggestions', JSON_ARRAY(
                'Investigate unusual metric behavior',
                'Consider system resource allocation'
            )
        )
    FROM metric_stats
    WHERE (p_metric_value - avg_value) > std_value;
END //

-- Generate Performance Report
CREATE PROCEDURE generate_performance_report(
    IN p_start_time TIMESTAMP,
    IN p_end_time TIMESTAMP
)
BEGIN
    SELECT JSON_OBJECT(
        'query_performance', (
            SELECT JSON_OBJECT(
                'slow_queries', COUNT(*),
                'avg_execution_time', AVG(execution_time),
                'max_execution_time', MAX(execution_time),
                'total_rows_examined', SUM(rows_examined),
                'total_rows_returned', SUM(rows_returned),
                'problematic_patterns', JSON_ARRAYAGG(
                    JSON_OBJECT(
                        'pattern', query_pattern,
                        'avg_time', AVG(execution_time),
                        'executions', COUNT(*)
                    )
                )
            )
            FROM query_performance
            WHERE timestamp BETWEEN p_start_time AND p_end_time
            AND execution_time > 1.0
            GROUP BY query_hash
            HAVING COUNT(*) > 1
        ),
        'system_metrics', (
            SELECT JSON_OBJECT(
                'metric_summaries', JSON_OBJECTAGG(
                    metric_type,
                    JSON_OBJECT(
                        'avg_value', AVG(metric_value),
                        'max_value', MAX(metric_value),
                        'min_value', MIN(metric_value),
                        'measurements', COUNT(*)
                    )
                )
            )
            FROM system_metrics
            WHERE timestamp BETWEEN p_start_time AND p_end_time
            GROUP BY metric_type
        ),
        'optimization_suggestions', (
            SELECT JSON_ARRAYAGG(
                JSON_OBJECT(
                    'target', target_object,
                    'type', suggestion_type,
                    'priority', priority,
                    'impact', impact_score,
                    'details', details
                )
            )
            FROM optimization_suggestions
            WHERE created_at BETWEEN p_start_time AND p_end_time
            ORDER BY priority, impact_score DESC
        )
    ) as performance_report;
END //

-- Performance Dashboard
CREATE OR REPLACE VIEW performance_dashboard AS
SELECT 
    DATE(qp.timestamp) as report_date,
    -- Query Performance Metrics
    JSON_OBJECT(
        'total_queries', COUNT(*),
        'slow_queries', SUM(qp.execution_time > 1.0),
        'avg_execution_time', AVG(qp.execution_time),
        'total_rows_examined', SUM(qp.rows_examined),
        'efficiency_ratio', SUM(qp.rows_returned) / NULLIF(SUM(qp.rows_examined), 0)
    ) as query_metrics,
    -- System Health
    JSON_OBJECT(
        'metric_summaries', JSON_OBJECTAGG(
            sm.metric_type,
            JSON_OBJECT(
                'avg_value', AVG(sm.metric_value),
                'peak_value', MAX(sm.metric_value)
            )
        )
    ) as system_health,
    -- Optimization Progress
    JSON_OBJECT(
        'total_suggestions', COUNT(DISTINCT os.suggestion_id),
        'implemented_count', SUM(os.implemented),
        'high_priority_pending', SUM(os.priority = 1 AND NOT os.implemented),
        'potential_impact', AVG(os.impact_score)
    ) as optimization_status
FROM query_performance qp
LEFT JOIN system_metrics sm ON DATE(qp.timestamp) = DATE(sm.timestamp)
LEFT JOIN optimization_suggestions os ON DATE(qp.timestamp) = DATE(os.created_at)
GROUP BY DATE(qp.timestamp);

DELIMITER ;
