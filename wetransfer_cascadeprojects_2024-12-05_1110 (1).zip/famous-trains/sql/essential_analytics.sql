USE luxury_travel;

DELIMITER //

-- Essential Analytics Views
-- =======================

-- Booking Analytics
CREATE OR REPLACE VIEW booking_analytics AS
SELECT 
    DATE_FORMAT(booking_date, '%Y-%m') as month,
    service_type,
    COUNT(*) as bookings,
    SUM(total_amount) as revenue,
    AVG(total_amount) as avg_booking_value,
    COUNT(DISTINCT user_id) as unique_customers
FROM (
    SELECT booking_date, total_amount, 'Train' as service_type, user_id FROM train_bookings
    UNION ALL
    SELECT booking_date, total_amount, 'Cruise' as service_type, user_id FROM cruise_bookings
    UNION ALL
    SELECT rental_date, total_amount, 'Car' as service_type, user_id FROM car_rentals
) bookings
GROUP BY month, service_type
ORDER BY month DESC;

-- Customer Insights
CREATE OR REPLACE VIEW customer_analytics AS
SELECT 
    u.user_id,
    COUNT(b.booking_id) as total_bookings,
    SUM(b.total_amount) as total_spent,
    MAX(b.booking_date) as last_booking,
    AVG(r.rating) as avg_rating
FROM users u
LEFT JOIN train_bookings b ON u.user_id = b.user_id
LEFT JOIN reviews r ON b.booking_id = r.booking_id
GROUP BY u.user_id;

-- Service Performance
CREATE OR REPLACE VIEW service_performance AS
SELECT
    'Train' as service_type,
    COUNT(*) as total_bookings,
    SUM(total_amount) as revenue,
    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancellations,
    AVG(rating) as avg_rating
FROM train_bookings t
LEFT JOIN reviews r ON t.booking_id = r.booking_id
GROUP BY service_type;

-- Automated Triggers
-- ===============

-- Loyalty Program
CREATE TRIGGER update_loyalty_status
AFTER INSERT ON train_bookings
FOR EACH ROW
BEGIN
    DECLARE total_spent DECIMAL(10,2);
    
    SELECT SUM(total_amount) INTO total_spent
    FROM train_bookings
    WHERE user_id = NEW.user_id;
    
    IF total_spent > 10000 THEN
        UPDATE users 
        SET loyalty_tier = 'GOLD'
        WHERE user_id = NEW.user_id;
    ELSEIF total_spent > 5000 THEN
        UPDATE users 
        SET loyalty_tier = 'SILVER'
        WHERE user_id = NEW.user_id;
    END IF;
END //

-- Service Monitoring
CREATE TRIGGER monitor_bookings
AFTER INSERT ON train_bookings
FOR EACH ROW
BEGIN
    INSERT INTO booking_metrics (
        service_type,
        booking_date,
        total_bookings,
        total_revenue
    )
    SELECT 
        'Train',
        CURRENT_DATE,
        COUNT(*),
        SUM(total_amount)
    FROM train_bookings
    WHERE DATE(booking_date) = CURRENT_DATE
    ON DUPLICATE KEY UPDATE
        total_bookings = VALUES(total_bookings),
        total_revenue = VALUES(total_revenue);
END //

-- Required Tables
-- ============

CREATE TABLE IF NOT EXISTS booking_metrics (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    booking_date DATE,
    total_bookings INT,
    total_revenue DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_daily_metric (service_type, booking_date)
);

CREATE TABLE IF NOT EXISTS service_alerts (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    alert_type VARCHAR(50),
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

DELIMITER ;
