USE luxury_travel;

DELIMITER //

-- Advanced Integration System
-- ========================

-- Service Integration Registry
CREATE TABLE IF NOT EXISTS service_integrations (
    integration_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_name VARCHAR(100),
    integration_type ENUM('API', 'DATABASE', 'MESSAGE_QUEUE', 'WEBHOOK'),
    configuration JSON,
    credentials JSON,
    status ENUM('ACTIVE', 'INACTIVE', 'MAINTENANCE'),
    health_check_url VARCHAR(255),
    last_check_time TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_service_status (service_name, status)
);

-- Integration Metrics
CREATE TABLE IF NOT EXISTS integration_metrics (
    metric_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    integration_id BIGINT,
    metric_type VARCHAR(50),
    metric_value JSON,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (integration_id) REFERENCES service_integrations(integration_id),
    INDEX idx_integration_time (integration_id, timestamp)
);

-- Cross-Service Analytics
-- ====================

-- Service Performance Dashboard
CREATE OR REPLACE VIEW cross_service_performance AS
SELECT 
    DATE(created_at) as service_date,
    service_type,
    COUNT(*) as total_bookings,
    SUM(total_amount) as total_revenue,
    COUNT(DISTINCT user_id) as unique_customers,
    AVG(total_amount) as avg_booking_value,
    -- Service-specific metrics
    CASE service_type
        WHEN 'TRAIN' THEN JSON_OBJECT(
            'route_utilization', COUNT(DISTINCT route_id),
            'peak_hours', GROUP_CONCAT(DISTINCT HOUR(travel_date))
        )
        WHEN 'CRUISE' THEN JSON_OBJECT(
            'cabin_utilization', COUNT(DISTINCT cabin_type),
            'avg_duration', AVG(DATEDIFF(end_date, start_date))
        )
        WHEN 'CAR' THEN JSON_OBJECT(
            'vehicle_types', COUNT(DISTINCT vehicle_type),
            'avg_rental_days', AVG(DATEDIFF(return_date, pickup_date))
        )
    END as service_metrics
FROM (
    SELECT 'TRAIN' as service_type, * FROM train_bookings
    UNION ALL
    SELECT 'CRUISE' as service_type, * FROM cruise_bookings
    UNION ALL
    SELECT 'CAR' as service_type, * FROM car_rentals
) all_services
GROUP BY DATE(created_at), service_type;

-- Integration Health Monitor
CREATE OR REPLACE VIEW integration_health_monitor AS
SELECT 
    s.service_name,
    s.integration_type,
    s.status,
    s.last_check_time,
    -- Recent metrics
    (SELECT JSON_ARRAYAGG(
        JSON_OBJECT(
            'type', metric_type,
            'value', metric_value,
            'timestamp', timestamp
        )
    ) FROM integration_metrics m 
    WHERE m.integration_id = s.integration_id
    AND m.timestamp >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
    ) as recent_metrics,
    -- Performance stats
    JSON_OBJECT(
        'uptime', TIMESTAMPDIFF(MINUTE, created_at, NOW()),
        'last_error', (
            SELECT metric_value->>'$.error_message'
            FROM integration_metrics
            WHERE integration_id = s.integration_id
            AND metric_type = 'ERROR'
            ORDER BY timestamp DESC
            LIMIT 1
        )
    ) as performance_stats
FROM service_integrations s;

-- Integration Management
-- ===================

-- Health Check Procedure
CREATE PROCEDURE perform_integration_health_check(IN p_integration_id BIGINT)
BEGIN
    DECLARE v_health_check_url VARCHAR(255);
    DECLARE v_service_name VARCHAR(100);
    DECLARE v_response_time INT;
    DECLARE v_status VARCHAR(20);
    
    -- Get integration details
    SELECT health_check_url, service_name
    INTO v_health_check_url, v_service_name
    FROM service_integrations
    WHERE integration_id = p_integration_id;
    
    -- Simulate health check (replace with actual HTTP call in production)
    SET v_response_time = FLOOR(RAND() * 1000);
    SET v_status = IF(v_response_time < 800, 'HEALTHY', 'DEGRADED');
    
    -- Log metrics
    INSERT INTO integration_metrics (
        integration_id,
        metric_type,
        metric_value
    ) VALUES (
        p_integration_id,
        'HEALTH_CHECK',
        JSON_OBJECT(
            'response_time_ms', v_response_time,
            'status', v_status,
            'endpoint', v_health_check_url
        )
    );
    
    -- Update integration status
    UPDATE service_integrations
    SET status = IF(v_status = 'HEALTHY', 'ACTIVE', 'MAINTENANCE'),
        last_check_time = NOW()
    WHERE integration_id = p_integration_id;
END //

-- Initialize Core Integrations
INSERT IGNORE INTO service_integrations 
(service_name, integration_type, configuration, status, health_check_url) VALUES
('IRCTC_API', 'API',
 '{"endpoint": "https://api.irctc.co.in/v2/", "timeout": 30, "retry_attempts": 3}',
 'ACTIVE', 'https://api.irctc.co.in/v2/health'),
('PAYMENT_GATEWAY', 'API',
 '{"endpoint": "https://payments.example.com/api/", "webhook_url": "/payment/callback"}',
 'ACTIVE', 'https://payments.example.com/api/status'),
('EMAIL_SERVICE', 'MESSAGE_QUEUE',
 '{"queue": "email_notifications", "batch_size": 100, "retry_delay": 300}',
 'ACTIVE', 'https://email.service.com/health');

-- Scheduled Tasks
-- ============

-- Regular Health Checks
CREATE EVENT IF NOT EXISTS integration_health_monitor
ON SCHEDULE EVERY 5 MINUTE
DO
BEGIN
    DECLARE v_integration_id BIGINT;
    DECLARE v_done INT DEFAULT FALSE;
    DECLARE v_cur CURSOR FOR 
        SELECT integration_id 
        FROM service_integrations 
        WHERE status != 'INACTIVE';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;
    
    OPEN v_cur;
    
    read_loop: LOOP
        FETCH v_cur INTO v_integration_id;
        IF v_done THEN
            LEAVE read_loop;
        END IF;
        
        CALL perform_integration_health_check(v_integration_id);
    END LOOP;
    
    CLOSE v_cur;
END //

DELIMITER ;
