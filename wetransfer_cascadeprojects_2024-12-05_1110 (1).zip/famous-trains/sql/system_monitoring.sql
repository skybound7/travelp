USE luxury_travel;

DELIMITER //

-- System Monitoring Framework
-- ========================

-- Performance Metrics
CREATE TABLE IF NOT EXISTS system_metrics (
    metric_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    metric_type VARCHAR(50),
    metric_name VARCHAR(100),
    metric_value DECIMAL(10,2),
    dimensions JSON,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_metric_time (metric_type, timestamp)
);

-- Resource Utilization
CREATE TABLE IF NOT EXISTS resource_utilization (
    utilization_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    resource_type VARCHAR(50),
    resource_name VARCHAR(100),
    cpu_usage DECIMAL(5,2),
    memory_usage DECIMAL(5,2),
    disk_usage DECIMAL(5,2),
    network_usage DECIMAL(5,2),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_resource_time (resource_type, timestamp)
);

-- System Health Dashboard
CREATE OR REPLACE VIEW system_health_dashboard AS
SELECT 
    CURRENT_TIMESTAMP as snapshot_time,
    -- Database Performance
    (SELECT COUNT(*) FROM information_schema.processlist) as active_connections,
    (SELECT SUM(data_length + index_length)/1024/1024 
     FROM information_schema.tables WHERE table_schema = DATABASE()) as total_db_size_mb,
    
    -- Service Health
    (SELECT JSON_ARRAYAGG(
        JSON_OBJECT(
            'service', service_name,
            'status', status,
            'last_check', last_check_time
        )
    ) FROM service_integrations) as service_status,
    
    -- Resource Usage
    (SELECT JSON_OBJECT(
        'cpu', AVG(cpu_usage),
        'memory', AVG(memory_usage),
        'disk', AVG(disk_usage),
        'network', AVG(network_usage)
    ) FROM resource_utilization 
    WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)) as resource_usage,
    
    -- Error Rates
    (SELECT COUNT(*) FROM system_metrics 
     WHERE metric_type = 'ERROR' 
     AND timestamp >= DATE_SUB(NOW(), INTERVAL 1 HOUR)) as error_count;

-- Performance Monitoring
-- ===================

-- Query Performance Tracking
CREATE TABLE IF NOT EXISTS query_performance (
    query_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    query_pattern VARCHAR(1000),
    execution_count INT,
    total_time DECIMAL(10,2),
    avg_time DECIMAL(10,2),
    rows_examined BIGINT,
    last_executed TIMESTAMP,
    INDEX idx_pattern (query_pattern(255))
);

-- Monitor Slow Queries
CREATE PROCEDURE track_slow_queries()
BEGIN
    INSERT INTO query_performance (
        query_pattern,
        execution_count,
        total_time,
        avg_time,
        rows_examined,
        last_executed
    )
    SELECT 
        SUBSTRING_INDEX(digest_text, '?', 1) as query_pattern,
        COUNT_STAR as execution_count,
        SUM_TIMER_WAIT/1000000000 as total_time,
        AVG_TIMER_WAIT/1000000000 as avg_time,
        SUM_ROWS_EXAMINED as rows_examined,
        CURRENT_TIMESTAMP
    FROM performance_schema.events_statements_summary_by_digest
    WHERE LAST_SEEN >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
    AND AVG_TIMER_WAIT > 1000000000; -- queries taking more than 1 second

    -- Alert on problematic queries
    INSERT INTO system_metrics (
        metric_type,
        metric_name,
        metric_value,
        dimensions
    )
    SELECT 
        'QUERY_PERFORMANCE',
        'slow_query_alert',
        avg_time,
        JSON_OBJECT(
            'query_pattern', query_pattern,
            'execution_count', execution_count,
            'rows_examined', rows_examined
        )
    FROM query_performance
    WHERE avg_time > 5; -- queries averaging more than 5 seconds
END //

-- Resource Monitoring
CREATE PROCEDURE monitor_system_resources()
BEGIN
    -- Simulate resource metrics collection
    INSERT INTO resource_utilization (
        resource_type,
        resource_name,
        cpu_usage,
        memory_usage,
        disk_usage,
        network_usage
    )
    SELECT 
        'DATABASE_SERVER',
        'primary_db',
        -- Simulated metrics (replace with actual monitoring in production)
        (SELECT COUNT(*) * 100.0 / @@max_connections 
         FROM information_schema.processlist) as cpu_usage,
        (SELECT SUM(data_length + index_length) * 100.0 / @@max_connections 
         FROM information_schema.tables 
         WHERE table_schema = DATABASE()) as memory_usage,
        (SELECT COUNT(*) * 100.0 / @@max_connections 
         FROM information_schema.tables 
         WHERE table_schema = DATABASE()) as disk_usage,
        (SELECT COUNT(*) * 100.0 / @@max_connections 
         FROM information_schema.processlist 
         WHERE command != 'Sleep') as network_usage;

    -- Generate alerts for high resource usage
    IF EXISTS (
        SELECT 1 FROM resource_utilization
        WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)
        AND (cpu_usage > 80 OR memory_usage > 80 OR disk_usage > 80)
    ) THEN
        INSERT INTO system_metrics (
            metric_type,
            metric_name,
            metric_value,
            dimensions
        )
        SELECT 
            'RESOURCE_ALERT',
            'high_resource_usage',
            GREATEST(cpu_usage, memory_usage, disk_usage),
            JSON_OBJECT(
                'cpu', cpu_usage,
                'memory', memory_usage,
                'disk', disk_usage,
                'network', network_usage
            )
        FROM resource_utilization
        WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)
        ORDER BY timestamp DESC
        LIMIT 1;
    END IF;
END //

-- Scheduled Monitoring Tasks
-- ======================

CREATE EVENT IF NOT EXISTS system_monitoring_scheduler
ON SCHEDULE EVERY 5 MINUTE
DO
BEGIN
    -- Track query performance
    CALL track_slow_queries();
    
    -- Monitor system resources
    CALL monitor_system_resources();
    
    -- Clean up old metrics
    DELETE FROM system_metrics 
    WHERE timestamp < DATE_SUB(NOW(), INTERVAL 30 DAY);
    
    DELETE FROM resource_utilization 
    WHERE timestamp < DATE_SUB(NOW(), INTERVAL 7 DAY);
END //

DELIMITER ;
