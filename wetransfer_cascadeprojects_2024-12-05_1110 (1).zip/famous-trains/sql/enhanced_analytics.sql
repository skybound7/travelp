USE luxury_travel;

DELIMITER //

-- Enhanced Customer Analytics
-- ========================

-- Customer Behavior Analysis
CREATE OR REPLACE VIEW customer_behavior_analysis AS
SELECT 
    u.user_id,
    u.email,
    -- Booking Patterns
    COUNT(DISTINCT b.booking_id) as total_bookings,
    COUNT(DISTINCT b.service_type) as unique_services_used,
    MAX(b.booking_date) as last_booking_date,
    MIN(b.booking_date) as first_booking_date,
    -- Spending Patterns
    SUM(b.total_amount) as total_spent,
    AVG(b.total_amount) as avg_booking_value,
    MAX(b.total_amount) as highest_booking_value,
    -- Service Preferences
    GROUP_CONCAT(DISTINCT b.service_type) as used_services,
    -- Loyalty Metrics
    DATEDIFF(NOW(), MIN(b.booking_date)) as customer_age_days,
    DATEDIFF(NOW(), MAX(b.booking_date)) as days_since_last_booking,
    -- Satisfaction
    AVG(r.rating) as avg_rating,
    COUNT(r.review_id) as total_reviews,
    -- Behavioral Flags
    CASE 
        WHEN COUNT(CASE WHEN b.status = 'cancelled' THEN 1 END) > 2 THEN 'High'
        WHEN COUNT(CASE WHEN b.status = 'cancelled' THEN 1 END) > 0 THEN 'Medium'
        ELSE 'Low'
    END as cancellation_risk,
    CASE 
        WHEN AVG(r.rating) < 3 THEN 'At Risk'
        WHEN AVG(r.rating) >= 4 THEN 'Promoter'
        ELSE 'Neutral'
    END as satisfaction_level
FROM users u
LEFT JOIN (
    SELECT booking_id, user_id, total_amount, booking_date, status, 'Train' as service_type 
    FROM train_bookings
    UNION ALL
    SELECT booking_id, user_id, total_amount, booking_date, status, 'Cruise' 
    FROM cruise_bookings
    UNION ALL
    SELECT rental_id, user_id, total_amount, rental_date, status, 'Car' 
    FROM car_rentals
) b ON u.user_id = b.user_id
LEFT JOIN reviews r ON b.booking_id = r.booking_id
GROUP BY u.user_id;

-- Cross-Service Performance
-- ======================

CREATE OR REPLACE VIEW cross_service_metrics AS
SELECT 
    DATE_FORMAT(metric_date, '%Y-%m') as month,
    service_type,
    -- Booking Metrics
    COUNT(*) as total_bookings,
    COUNT(DISTINCT user_id) as unique_customers,
    -- Revenue Metrics
    SUM(total_amount) as total_revenue,
    AVG(total_amount) as avg_booking_value,
    -- Growth Metrics
    LAG(COUNT(*)) OVER (PARTITION BY service_type ORDER BY metric_date) as prev_month_bookings,
    LAG(SUM(total_amount)) OVER (PARTITION BY service_type ORDER BY metric_date) as prev_month_revenue,
    -- Performance Indicators
    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) / COUNT(*) * 100 as cancellation_rate,
    AVG(CASE WHEN status = 'completed' THEN rating END) as avg_rating
FROM (
    SELECT 
        booking_date as metric_date,
        'Train' as service_type,
        user_id,
        total_amount,
        status,
        r.rating
    FROM train_bookings tb
    LEFT JOIN reviews r ON tb.booking_id = r.booking_id
    UNION ALL
    SELECT 
        booking_date,
        'Cruise',
        user_id,
        total_amount,
        status,
        r.rating
    FROM cruise_bookings cb
    LEFT JOIN reviews r ON cb.booking_id = r.booking_id
    UNION ALL
    SELECT 
        rental_date,
        'Car',
        user_id,
        total_amount,
        status,
        r.rating
    FROM car_rentals cr
    LEFT JOIN reviews r ON cr.rental_id = r.booking_id
) all_services
GROUP BY DATE_FORMAT(metric_date, '%Y-%m'), service_type
ORDER BY month DESC, service_type;

-- Advanced Performance Metrics
-- =========================

CREATE PROCEDURE generate_performance_report(
    IN start_date DATE,
    IN end_date DATE
)
BEGIN
    -- Service Performance
    SELECT 
        service_type,
        COUNT(*) as total_bookings,
        SUM(total_amount) as total_revenue,
        AVG(total_amount) as avg_booking_value,
        COUNT(DISTINCT user_id) as unique_customers,
        COUNT(CASE WHEN status = 'cancelled' THEN 1 END) / COUNT(*) * 100 as cancellation_rate,
        AVG(rating) as avg_satisfaction
    FROM (
        SELECT 'Train' as service_type, tb.*, r.rating 
        FROM train_bookings tb
        LEFT JOIN reviews r ON tb.booking_id = r.booking_id
        WHERE booking_date BETWEEN start_date AND end_date
        UNION ALL
        SELECT 'Cruise', cb.*, r.rating 
        FROM cruise_bookings cb
        LEFT JOIN reviews r ON cb.booking_id = r.booking_id
        WHERE booking_date BETWEEN start_date AND end_date
        UNION ALL
        SELECT 'Car', cr.*, r.rating 
        FROM car_rentals cr
        LEFT JOIN reviews r ON cr.rental_id = r.booking_id
        WHERE rental_date BETWEEN start_date AND end_date
    ) all_services
    GROUP BY service_type;

    -- Customer Segments Performance
    SELECT 
        cs.segment,
        COUNT(DISTINCT b.user_id) as customers,
        SUM(b.total_amount) as revenue,
        AVG(b.total_amount) as avg_spend,
        COUNT(b.booking_id) / COUNT(DISTINCT b.user_id) as bookings_per_customer
    FROM customer_segments cs
    JOIN (
        SELECT booking_id, user_id, total_amount FROM train_bookings
        WHERE booking_date BETWEEN start_date AND end_date
        UNION ALL
        SELECT booking_id, user_id, total_amount FROM cruise_bookings
        WHERE booking_date BETWEEN start_date AND end_date
        UNION ALL
        SELECT rental_id, user_id, total_amount FROM car_rentals
        WHERE rental_date BETWEEN start_date AND end_date
    ) b ON cs.user_id = b.user_id
    GROUP BY cs.segment;

    -- Route Performance
    SELECT 
        r.origin,
        r.destination,
        COUNT(*) as total_trips,
        SUM(b.total_amount) as revenue,
        AVG(b.total_amount) as avg_fare,
        COUNT(DISTINCT b.user_id) as unique_passengers
    FROM routes r
    JOIN train_bookings b ON r.route_id = b.route_id
    WHERE b.booking_date BETWEEN start_date AND end_date
    GROUP BY r.route_id
    ORDER BY revenue DESC;
END //

-- Create Required Tables
-- ===================

CREATE TABLE IF NOT EXISTS performance_reports (
    report_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    report_type VARCHAR(50),
    start_date DATE,
    end_date DATE,
    metrics JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_date_range (start_date, end_date)
);

DELIMITER ;
