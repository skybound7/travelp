USE luxury_travel;

DELIMITER //

-- Recommendation Engine Framework
-- ===========================

-- Service Relationships
CREATE TABLE IF NOT EXISTS service_relationships (
    relationship_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    primary_service VARCHAR(50),
    related_service VARCHAR(50),
    relationship_type VARCHAR(50),
    affinity_score DECIMAL(5,2),
    context JSON,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_services (primary_service, related_service)
);

-- Recommendation Rules
CREATE TABLE IF NOT EXISTS recommendation_rules (
    rule_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    rule_name VARCHAR(100),
    conditions JSON,
    recommendation_type VARCHAR(50),
    priority INT,
    effectiveness DECIMAL(5,2),
    active BOOLEAN DEFAULT TRUE,
    INDEX idx_type_active (recommendation_type, active)
);

-- Recommendation History
CREATE TABLE IF NOT EXISTS recommendation_history (
    history_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT,
    recommendation_type VARCHAR(50),
    recommended_items JSON,
    context JSON,
    accepted BOOLEAN,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_type (user_id, recommendation_type)
);

-- Recommendation Functions
-- ====================

-- Generate Service Recommendations
CREATE PROCEDURE generate_recommendations(
    IN p_user_id BIGINT,
    IN p_context JSON
)
BEGIN
    DECLARE v_user_preferences JSON;
    DECLARE v_recent_bookings JSON;
    
    -- Get user preferences and history
    SELECT 
        preferences,
        (SELECT JSON_ARRAYAGG(
            JSON_OBJECT(
                'service_type', service_type,
                'service_id', service_id,
                'created_at', created_at,
                'total_amount', total_amount
            )
        )
        FROM (
            SELECT * FROM train_bookings
            UNION ALL
            SELECT * FROM cruise_bookings
            UNION ALL
            SELECT * FROM car_rentals
        ) recent_bookings
        WHERE user_id = p_user_id
        ORDER BY created_at DESC
        LIMIT 5)
    INTO v_user_preferences, v_recent_bookings
    FROM customer_profiles
    WHERE user_id = p_user_id;
    
    -- Generate and record recommendations
    INSERT INTO recommendation_history (
        user_id,
        recommendation_type,
        recommended_items,
        context
    )
    WITH user_affinities AS (
        -- Calculate service affinities based on booking history
        SELECT 
            sr.related_service,
            AVG(sr.affinity_score) as affinity_score,
            COUNT(*) as relationship_count
        FROM JSON_TABLE(
            v_recent_bookings,
            '$[*]' COLUMNS (
                service_type VARCHAR(50) PATH '$.service_type'
            )
        ) bookings
        JOIN service_relationships sr ON bookings.service_type = sr.primary_service
        GROUP BY sr.related_service
    ),
    preference_matches AS (
        -- Match services with user preferences
        SELECT 
            service_type,
            JSON_EXTRACT(v_user_preferences, '$.preferred_features') as preferred_features,
            JSON_EXTRACT(v_user_preferences, '$.price_range') as price_range
        FROM (
            SELECT DISTINCT service_type 
            FROM price_history
        ) services
    )
    SELECT 
        p_user_id,
        'PERSONALIZED',
        JSON_OBJECT(
            'top_recommendations', (
                SELECT JSON_ARRAYAGG(
                    JSON_OBJECT(
                        'service_type', ua.related_service,
                        'affinity_score', ua.affinity_score,
                        'reason', CASE
                            WHEN ua.affinity_score > 0.8 THEN 'Strong match based on your history'
                            WHEN ua.affinity_score > 0.5 THEN 'Similar to services you enjoy'
                            ELSE 'You might also like'
                        END,
                        'features', JSON_EXTRACT(pm.preferred_features, '$'),
                        'price_range', JSON_EXTRACT(pm.price_range, '$')
                    )
                )
                FROM user_affinities ua
                JOIN preference_matches pm ON ua.related_service = pm.service_type
                ORDER BY ua.affinity_score DESC
                LIMIT 5
            ),
            'complementary_services', (
                SELECT JSON_ARRAYAGG(
                    JSON_OBJECT(
                        'primary_service', sr.primary_service,
                        'complementary_service', sr.related_service,
                        'relationship_type', sr.relationship_type,
                        'context', sr.context
                    )
                )
                FROM service_relationships sr
                WHERE sr.relationship_type = 'COMPLEMENTARY'
                AND sr.affinity_score > 0.7
                LIMIT 3
            )
        ),
        p_context;
END //

-- Update Service Relationships
CREATE PROCEDURE update_service_relationships()
BEGIN
    -- Analyze booking patterns
    INSERT INTO service_relationships (
        primary_service,
        related_service,
        relationship_type,
        affinity_score,
        context
    )
    WITH service_combinations AS (
        SELECT 
            b1.service_type as primary_service,
            b2.service_type as related_service,
            COUNT(*) as combination_count,
            AVG(DATEDIFF(b2.created_at, b1.created_at)) as avg_time_gap
        FROM (
            SELECT * FROM train_bookings
            UNION ALL
            SELECT * FROM cruise_bookings
            UNION ALL
            SELECT * FROM car_rentals
        ) b1
        JOIN (
            SELECT * FROM train_bookings
            UNION ALL
            SELECT * FROM cruise_bookings
            UNION ALL
            SELECT * FROM car_rentals
        ) b2 ON b1.user_id = b2.user_id
        AND b1.created_at < b2.created_at
        AND DATEDIFF(b2.created_at, b1.created_at) <= 30
        GROUP BY b1.service_type, b2.service_type
    )
    SELECT 
        primary_service,
        related_service,
        CASE 
            WHEN avg_time_gap < 1 THEN 'COMPLEMENTARY'
            WHEN avg_time_gap < 7 THEN 'RELATED'
            ELSE 'SEQUENTIAL'
        END,
        combination_count / (
            SELECT MAX(combination_count) 
            FROM service_combinations
        ) as affinity_score,
        JSON_OBJECT(
            'combination_count', combination_count,
            'avg_time_gap', avg_time_gap,
            'last_updated', CURRENT_TIMESTAMP
        )
    FROM service_combinations
    ON DUPLICATE KEY UPDATE
        affinity_score = VALUES(affinity_score),
        context = VALUES(context),
        last_updated = CURRENT_TIMESTAMP;
END //

-- Initialize Recommendation Rules
INSERT IGNORE INTO recommendation_rules 
(rule_name, conditions, recommendation_type, priority, effectiveness) VALUES 
('Recent Bookers', 
 '{"timeframe": 7, "min_bookings": 1}',
 'RECENT_ACTIVITY', 1, 0.8),
('High Value Customers',
 '{"min_value_score": 80, "min_bookings": 5}',
 'PREMIUM_OFFERS', 2, 0.9),
('First Time Users',
 '{"total_bookings": 0}',
 'INTRODUCTORY', 3, 0.7),
('Cross-Service Opportunities',
 '{"min_service_types": 2, "max_gap_days": 30}',
 'CROSS_SELL', 4, 0.85);

-- Recommendation Dashboard
CREATE OR REPLACE VIEW recommendation_dashboard AS
SELECT 
    rh.user_id,
    -- Recommendation Performance
    JSON_OBJECT(
        'total_recommendations', COUNT(*),
        'accepted_recommendations', SUM(rh.accepted),
        'acceptance_rate', (SUM(rh.accepted) * 100.0 / COUNT(*)),
        'recommendation_types', COUNT(DISTINCT rh.recommendation_type)
    ) as recommendation_metrics,
    -- User Context
    JSON_OBJECT(
        'recent_services', JSON_EXTRACT(cp.preferences, '$.recent_behaviors'),
        'preferred_types', JSON_EXTRACT(cp.preferences, '$.preferred_services')
    ) as user_context,
    -- Service Relationships
    (SELECT JSON_ARRAYAGG(
        JSON_OBJECT(
            'primary', sr.primary_service,
            'related', sr.related_service,
            'affinity', sr.affinity_score,
            'type', sr.relationship_type
        )
    )
    FROM service_relationships sr
    WHERE sr.affinity_score > 0.7) as strong_relationships
FROM recommendation_history rh
JOIN customer_profiles cp ON rh.user_id = cp.user_id
GROUP BY rh.user_id;

DELIMITER ;
