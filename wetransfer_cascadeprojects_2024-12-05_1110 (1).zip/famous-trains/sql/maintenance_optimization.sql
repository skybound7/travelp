USE luxury_travel;

DELIMITER //

-- Database Maintenance and Optimization
-- ==================================

-- Table Statistics Monitor
CREATE OR REPLACE VIEW table_statistics AS
SELECT 
    table_name,
    table_rows,
    data_length/1024/1024 as data_size_mb,
    index_length/1024/1024 as index_size_mb,
    (data_length + index_length)/1024/1024 as total_size_mb,
    update_time,
    table_collation,
    engine
FROM information_schema.tables
WHERE table_schema = DATABASE()
ORDER BY (data_length + index_length) DESC;

-- Query Performance Monitor
CREATE TABLE IF NOT EXISTS query_performance_logs (
    log_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    query_pattern VARCHAR(1000),
    execution_count INT,
    avg_execution_time DECIMAL(10,4),
    max_execution_time DECIMAL(10,4),
    total_rows_examined BIGINT,
    last_executed TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_query_pattern (query_pattern(255)),
    INDEX idx_execution_time (avg_execution_time)
);

-- Database Health Check
CREATE PROCEDURE perform_health_check()
BEGIN
    -- Check table sizes and growth
    SELECT 
        table_name,
        table_rows,
        ROUND((data_length + index_length)/1024/1024, 2) as total_size_mb
    FROM information_schema.tables
    WHERE table_schema = DATABASE()
    ORDER BY (data_length + index_length) DESC
    LIMIT 10;

    -- Check fragmented tables
    SELECT 
        table_name,
        data_free/1024/1024 as fragmented_space_mb
    FROM information_schema.tables
    WHERE table_schema = DATABASE()
    AND data_free > 0
    ORDER BY data_free DESC;

    -- Check slow queries
    SELECT 
        query_pattern,
        execution_count,
        avg_execution_time,
        total_rows_examined
    FROM query_performance_logs
    WHERE avg_execution_time > 1
    ORDER BY avg_execution_time DESC
    LIMIT 10;
END //

-- Automated Maintenance
CREATE PROCEDURE perform_maintenance(IN p_table_name VARCHAR(255))
BEGIN
    SET @sql = CONCAT('ANALYZE TABLE ', p_table_name);
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    SET @sql = CONCAT('OPTIMIZE TABLE ', p_table_name);
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END //

-- Data Archival
CREATE PROCEDURE archive_old_data(
    IN p_months_old INT,
    IN p_batch_size INT
)
BEGIN
    -- Archive old bookings
    INSERT INTO archived_train_bookings
    SELECT *
    FROM train_bookings
    WHERE booking_date < DATE_SUB(NOW(), INTERVAL p_months_old MONTH)
    LIMIT p_batch_size;
    
    DELETE FROM train_bookings
    WHERE booking_id IN (
        SELECT booking_id 
        FROM archived_train_bookings
    );
    
    -- Archive old reviews
    INSERT INTO archived_reviews
    SELECT r.*
    FROM reviews r
    JOIN archived_train_bookings atb ON r.booking_id = atb.booking_id;
    
    DELETE FROM reviews
    WHERE booking_id IN (
        SELECT booking_id 
        FROM archived_train_bookings
    );
END //

-- Performance Monitoring
CREATE PROCEDURE monitor_system_performance()
BEGIN
    -- Monitor connection stats
    SELECT * FROM performance_schema.hosts
    WHERE CURRENT_CONNECTIONS > 0;
    
    -- Monitor memory usage
    SELECT 
        EVENT_NAME,
        COUNT_ALLOC,
        SUM_NUMBER_OF_BYTES_ALLOC
    FROM performance_schema.memory_summary_global_by_event_name
    WHERE SUM_NUMBER_OF_BYTES_ALLOC > 0
    ORDER BY SUM_NUMBER_OF_BYTES_ALLOC DESC;
    
    -- Monitor table operations
    SELECT 
        TABLE_SCHEMA,
        TABLE_NAME,
        ROWS_READ,
        ROWS_INSERTED,
        ROWS_UPDATED,
        ROWS_DELETED
    FROM performance_schema.table_io_waits_summary_by_table
    WHERE TABLE_SCHEMA = DATABASE()
    ORDER BY (ROWS_READ + ROWS_INSERTED + ROWS_UPDATED + ROWS_DELETED) DESC;
END //

-- Required Tables
-- ============

CREATE TABLE IF NOT EXISTS archived_train_bookings LIKE train_bookings;
CREATE TABLE IF NOT EXISTS archived_reviews LIKE reviews;

CREATE TABLE IF NOT EXISTS maintenance_logs (
    log_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    maintenance_type VARCHAR(50),
    target_table VARCHAR(255),
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    status VARCHAR(20),
    details JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_maintenance_type (maintenance_type),
    INDEX idx_target_table (target_table)
);

-- Schedule Maintenance Tasks
CREATE EVENT IF NOT EXISTS daily_maintenance
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP + INTERVAL 1 DAY
DO
BEGIN
    -- Log maintenance start
    INSERT INTO maintenance_logs (maintenance_type, target_table, start_time, status)
    VALUES ('DAILY', 'ALL', NOW(), 'STARTED');
    
    -- Perform maintenance tasks
    CALL perform_health_check();
    CALL monitor_system_performance();
    
    -- Archive old data
    CALL archive_old_data(12, 1000);
    
    -- Update maintenance log
    UPDATE maintenance_logs
    SET end_time = NOW(),
        status = 'COMPLETED'
    WHERE maintenance_type = 'DAILY'
    AND target_table = 'ALL'
    AND DATE(created_at) = DATE(NOW());
END //

DELIMITER ;
