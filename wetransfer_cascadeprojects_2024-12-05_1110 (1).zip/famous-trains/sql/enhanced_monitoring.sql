USE luxury_travel;

DELIMITER //

-- Enhanced Performance Metrics
-- =========================

-- Detailed Performance Tracking
CREATE TABLE IF NOT EXISTS detailed_performance_metrics (
    metric_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    category VARCHAR(50),
    subcategory VARCHAR(50),
    metric_name VARCHAR(100),
    value DECIMAL(10,2),
    unit VARCHAR(20),
    dimensions JSON,
    tags JSON,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_category_time (category, subcategory, timestamp)
);

-- Alert Configuration
CREATE TABLE IF NOT EXISTS alert_thresholds (
    threshold_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    metric_category VARCHAR(50),
    metric_name VARCHAR(100),
    warning_threshold DECIMAL(10,2),
    critical_threshold DECIMAL(10,2),
    comparison_operator ENUM('GT', 'LT', 'EQ', 'GTE', 'LTE'),
    evaluation_period INT,
    notification_channels JSON,
    active BOOLEAN DEFAULT TRUE,
    INDEX idx_metric (metric_category, metric_name)
);

-- Trend Analysis
-- ============

-- Historical Trends View
CREATE OR REPLACE VIEW performance_trends AS
SELECT 
    DATE(timestamp) as trend_date,
    category,
    subcategory,
    metric_name,
    -- Current metrics
    AVG(value) as avg_value,
    MIN(value) as min_value,
    MAX(value) as max_value,
    -- Historical comparison
    LAG(AVG(value)) OVER (
        PARTITION BY category, subcategory, metric_name 
        ORDER BY DATE(timestamp)
    ) as prev_day_avg,
    -- Trend calculation
    (AVG(value) - LAG(AVG(value)) OVER (
        PARTITION BY category, subcategory, metric_name 
        ORDER BY DATE(timestamp)
    )) / LAG(AVG(value)) OVER (
        PARTITION BY category, subcategory, metric_name 
        ORDER BY DATE(timestamp)
    ) * 100 as day_over_day_change
FROM detailed_performance_metrics
WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY DATE(timestamp), category, subcategory, metric_name;

-- Advanced Monitoring Procedures
-- ==========================

-- Collect Detailed Metrics
CREATE PROCEDURE collect_detailed_metrics()
BEGIN
    -- Database Performance
    INSERT INTO detailed_performance_metrics (
        category, subcategory, metric_name, value, unit, dimensions
    )
    SELECT 
        'DATABASE',
        'PERFORMANCE',
        metric_name,
        metric_value,
        'count',
        metric_dimensions
    FROM (
        -- Active Connections
        SELECT 
            'active_connections' as metric_name,
            COUNT(*) as metric_value,
            JSON_OBJECT(
                'user_connections', SUM(CASE WHEN user != 'system user' THEN 1 ELSE 0 END),
                'system_connections', SUM(CASE WHEN user = 'system user' THEN 1 ELSE 0 END)
            ) as metric_dimensions
        FROM information_schema.processlist
        
        UNION ALL
        
        -- Table Statistics
        SELECT 
            'table_statistics',
            COUNT(*),
            JSON_OBJECT(
                'total_size_mb', SUM(data_length + index_length)/1024/1024,
                'total_rows', SUM(table_rows)
            )
        FROM information_schema.tables
        WHERE table_schema = DATABASE()
        
        UNION ALL
        
        -- Query Performance
        SELECT 
            'query_performance',
            COUNT(*),
            JSON_OBJECT(
                'avg_execution_time', AVG(avg_time),
                'slow_queries', SUM(CASE WHEN avg_time > 1 THEN 1 ELSE 0 END)
            )
        FROM query_performance
        WHERE last_executed >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
    ) db_metrics;

    -- Application Performance
    INSERT INTO detailed_performance_metrics (
        category, subcategory, metric_name, value, unit, dimensions
    )
    SELECT 
        'APPLICATION',
        'PERFORMANCE',
        metric_name,
        metric_value,
        'count',
        metric_dimensions
    FROM (
        -- Service Response Times
        SELECT 
            'service_response_time',
            AVG(CAST(JSON_EXTRACT(metric_value, '$.response_time_ms') AS DECIMAL)),
            JSON_OBJECT(
                'service_name', service_name,
                'status', status
            )
        FROM integration_metrics m
        JOIN service_integrations s ON m.integration_id = s.integration_id
        WHERE m.timestamp >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)
        GROUP BY service_name
        
        UNION ALL
        
        -- Transaction Performance
        SELECT 
            'transaction_performance',
            COUNT(*),
            JSON_OBJECT(
                'success_rate', SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) / COUNT(*) * 100,
                'avg_amount', AVG(total_amount)
            )
        FROM (
            SELECT * FROM train_bookings
            UNION ALL
            SELECT * FROM cruise_bookings
            UNION ALL
            SELECT * FROM car_rentals
        ) all_transactions
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
    ) app_metrics;
END //

-- Analyze Trends
CREATE PROCEDURE analyze_performance_trends()
BEGIN
    -- Calculate trend metrics
    WITH trend_data AS (
        SELECT 
            category,
            subcategory,
            metric_name,
            DATE(timestamp) as metric_date,
            AVG(value) as daily_avg,
            -- Rolling averages
            AVG(value) OVER (
                PARTITION BY category, subcategory, metric_name
                ORDER BY DATE(timestamp)
                ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
            ) as weekly_avg,
            -- Volatility
            STDDEV(value) OVER (
                PARTITION BY category, subcategory, metric_name
                ORDER BY DATE(timestamp)
                ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
            ) as monthly_volatility
        FROM detailed_performance_metrics
        WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY category, subcategory, metric_name, DATE(timestamp)
    )
    
    -- Store trend analysis
    INSERT INTO system_metrics (
        metric_type,
        metric_name,
        metric_value,
        dimensions
    )
    SELECT 
        'TREND_ANALYSIS',
        CONCAT(category, '_', subcategory, '_', metric_name),
        weekly_avg,
        JSON_OBJECT(
            'daily_avg', daily_avg,
            'weekly_avg', weekly_avg,
            'monthly_volatility', monthly_volatility,
            'trend_direction', CASE 
                WHEN daily_avg > weekly_avg THEN 'UP'
                WHEN daily_avg < weekly_avg THEN 'DOWN'
                ELSE 'STABLE'
            END
        )
    FROM trend_data
    WHERE metric_date = DATE(NOW());
END //

-- Initialize Alert Thresholds
INSERT IGNORE INTO alert_thresholds 
(metric_category, metric_name, warning_threshold, critical_threshold, comparison_operator, evaluation_period, notification_channels) 
VALUES 
('DATABASE', 'active_connections', 80, 90, 'GT', 5, '["email", "slack"]'),
('DATABASE', 'query_performance', 1000, 5000, 'GT', 5, '["email", "slack"]'),
('APPLICATION', 'service_response_time', 500, 1000, 'GT', 5, '["email", "slack"]'),
('APPLICATION', 'error_rate', 5, 10, 'GT', 5, '["email", "slack", "pager"]');

-- Security Monitoring
-- ================

-- Security Events
CREATE TABLE IF NOT EXISTS security_events (
    event_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    event_type VARCHAR(50),
    severity VARCHAR(20),
    source_ip VARCHAR(45),
    user_agent TEXT,
    user_id BIGINT,
    event_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_type_severity (event_type, severity),
    INDEX idx_user_time (user_id, created_at)
);

-- Access Audit
CREATE TABLE IF NOT EXISTS access_audit (
    audit_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT,
    resource_type VARCHAR(50),
    resource_id VARCHAR(100),
    action VARCHAR(20),
    status VARCHAR(20),
    request_metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_resource (user_id, resource_type)
);

-- Security Monitoring Procedures
CREATE PROCEDURE monitor_security_events()
BEGIN
    -- Monitor failed login attempts
    INSERT INTO security_events (
        event_type,
        severity,
        source_ip,
        user_id,
        event_data
    )
    SELECT 
        'LOGIN_FAILURE',
        CASE 
            WHEN COUNT(*) > 10 THEN 'HIGH'
            WHEN COUNT(*) > 5 THEN 'MEDIUM'
            ELSE 'LOW'
        END,
        source_ip,
        user_id,
        JSON_OBJECT(
            'attempt_count', COUNT(*),
            'time_window', '1 hour',
            'last_attempt', MAX(created_at)
        )
    FROM login_attempts
    WHERE status = 'FAILED'
    AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
    GROUP BY source_ip, user_id
    HAVING COUNT(*) > 3;

    -- Monitor suspicious activities
    INSERT INTO security_events (
        event_type,
        severity,
        user_id,
        event_data
    )
    SELECT 
        'SUSPICIOUS_ACTIVITY',
        'HIGH',
        user_id,
        JSON_OBJECT(
            'activity_type', 'UNUSUAL_BOOKING_PATTERN',
            'details', JSON_OBJECT(
                'booking_count', COUNT(*),
                'total_amount', SUM(total_amount),
                'usual_average', avg_booking_amount
            )
        )
    FROM (
        SELECT 
            b.user_id,
            COUNT(*) as booking_count,
            SUM(b.total_amount) as total_amount,
            up.avg_booking_amount
        FROM (
            SELECT * FROM train_bookings
            UNION ALL
            SELECT * FROM cruise_bookings
            UNION ALL
            SELECT * FROM car_rentals
        ) b
        JOIN user_profiles up ON b.user_id = up.user_id
        WHERE b.created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)
        GROUP BY b.user_id
        HAVING SUM(b.total_amount) > up.avg_booking_amount * 5
    ) suspicious_bookings;
END //

-- Security Dashboard View
CREATE OR REPLACE VIEW security_dashboard AS
SELECT 
    -- Current Security Status
    JSON_OBJECT(
        'threat_level', 
        CASE 
            WHEN EXISTS (
                SELECT 1 FROM security_events 
                WHERE severity = 'HIGH' 
                AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
            ) THEN 'HIGH'
            WHEN EXISTS (
                SELECT 1 FROM security_events 
                WHERE severity = 'MEDIUM' 
                AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
            ) THEN 'MEDIUM'
            ELSE 'LOW'
        END,
        'active_alerts', (
            SELECT COUNT(*) 
            FROM security_events
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        )
    ) as security_status,
    
    -- Event Summary
    JSON_OBJECT(
        'event_summary', (
            SELECT JSON_OBJECTAGG(
                event_type,
                JSON_OBJECT(
                    'count', COUNT(*),
                    'severity_distribution', JSON_OBJECTAGG(
                        severity,
                        COUNT(*)
                    )
                )
            )
            FROM security_events
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            GROUP BY event_type
        )
    ) as event_metrics,
    
    -- Access Patterns
    JSON_OBJECT(
        'access_patterns', (
            SELECT JSON_OBJECTAGG(
                resource_type,
                JSON_OBJECT(
                    'total_access', COUNT(*),
                    'failed_access', SUM(
                        CASE WHEN status = 'FAILED' THEN 1 ELSE 0 END
                    )
                )
            )
            FROM access_audit
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            GROUP BY resource_type
        )
    ) as access_metrics
FROM (SELECT 1) as dummy;

-- Schedule Security Monitoring
CREATE EVENT IF NOT EXISTS security_monitoring_job
ON SCHEDULE EVERY 5 MINUTE
DO CALL monitor_security_events();

-- Scheduled Tasks
-- ============

CREATE EVENT IF NOT EXISTS detailed_monitoring_scheduler
ON SCHEDULE EVERY 5 MINUTE
DO
BEGIN
    -- Collect detailed metrics
    CALL collect_detailed_metrics();
    
    -- Analyze trends
    CALL analyze_performance_trends();
    
    -- Cleanup old data
    DELETE FROM detailed_performance_metrics 
    WHERE timestamp < DATE_SUB(NOW(), INTERVAL 90 DAY);
END //

DELIMITER ;
