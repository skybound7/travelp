USE luxury_travel;

DELIMITER //

-- Vendor Management Framework
-- =======================

-- Vendors
CREATE TABLE IF NOT EXISTS vendors (
    vendor_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    vendor_name VARCHAR(100),
    service_types JSON,
    contract_details JSON,
    performance_score DECIMAL(5,2),
    status VARCHAR(20) DEFAULT 'ACTIVE',
    last_reviewed DATE,
    INDEX idx_status_score (status, performance_score)
);

-- Service Agreements
CREATE TABLE IF NOT EXISTS service_agreements (
    agreement_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    vendor_id BIGINT,
    service_type VARCHAR(50),
    terms JSON,
    start_date DATE,
    end_date DATE,
    status VARCHAR(20),
    INDEX idx_vendor_service (vendor_id, service_type)
);

-- Vendor Performance
CREATE TABLE IF NOT EXISTS vendor_performance (
    performance_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    vendor_id BIGINT,
    metric_type VARCHAR(50),
    metric_value DECIMAL(10,2),
    evaluation_date DATE,
    details JSON,
    INDEX idx_vendor_date (vendor_id, evaluation_date)
);

-- Management Functions
-- ================

-- Evaluate Vendor
CREATE PROCEDURE evaluate_vendor(
    IN p_vendor_id BIGINT,
    IN p_evaluation_date DATE
)
BEGIN
    DECLARE v_performance_score DECIMAL(5,2);
    
    -- Calculate performance metrics
    WITH performance_metrics AS (
        SELECT 
            metric_type,
            AVG(metric_value) as avg_value,
            COUNT(*) as metric_count
        FROM vendor_performance
        WHERE vendor_id = p_vendor_id
        AND evaluation_date >= DATE_SUB(p_evaluation_date, INTERVAL 90 DAY)
        GROUP BY metric_type
    )
    
    -- Calculate overall score
    SELECT 
        AVG(
            CASE metric_type
                WHEN 'RELIABILITY' THEN avg_value * 0.4
                WHEN 'QUALITY' THEN avg_value * 0.3
                WHEN 'RESPONSIVENESS' THEN avg_value * 0.2
                ELSE avg_value * 0.1
            END
        )
    INTO v_performance_score
    FROM performance_metrics;
    
    -- Update vendor status
    UPDATE vendors
    SET 
        performance_score = v_performance_score,
        status = CASE
            WHEN v_performance_score >= 4.5 THEN 'PREFERRED'
            WHEN v_performance_score >= 3.5 THEN 'ACTIVE'
            WHEN v_performance_score >= 2.5 THEN 'PROBATION'
            ELSE 'REVIEW_NEEDED'
        END,
        last_reviewed = p_evaluation_date
    WHERE vendor_id = p_vendor_id;
    
    -- Record evaluation
    INSERT INTO vendor_performance (
        vendor_id,
        metric_type,
        metric_value,
        evaluation_date,
        details
    )
    SELECT 
        p_vendor_id,
        'COMPOSITE_SCORE',
        v_performance_score,
        p_evaluation_date,
        JSON_OBJECT(
            'metrics', JSON_ARRAYAGG(
                JSON_OBJECT(
                    'type', metric_type,
                    'value', avg_value,
                    'weight', CASE metric_type
                        WHEN 'RELIABILITY' THEN 0.4
                        WHEN 'QUALITY' THEN 0.3
                        WHEN 'RESPONSIVENESS' THEN 0.2
                        ELSE 0.1
                    END
                )
            )
        )
    FROM performance_metrics;
END //

-- Review Agreements
CREATE PROCEDURE review_agreements(
    IN p_vendor_id BIGINT
)
BEGIN
    -- Update agreement statuses
    UPDATE service_agreements
    SET status = CASE
        WHEN end_date < CURRENT_DATE THEN 'EXPIRED'
        WHEN end_date < DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY) THEN 'RENEWAL_NEEDED'
        WHEN start_date > CURRENT_DATE THEN 'PENDING'
        ELSE 'ACTIVE'
    END
    WHERE vendor_id = p_vendor_id;
    
    -- Generate recommendations
    SELECT JSON_OBJECT(
        'vendor_status', v.status,
        'performance_score', v.performance_score,
        'agreements', JSON_ARRAYAGG(
            JSON_OBJECT(
                'service_type', sa.service_type,
                'status', sa.status,
                'recommendations', CASE
                    WHEN sa.status = 'EXPIRED' THEN
                        CASE
                            WHEN v.performance_score >= 4.0 THEN 'RENEW_WITH_BENEFITS'
                            WHEN v.performance_score >= 3.0 THEN 'STANDARD_RENEWAL'
                            ELSE 'REVIEW_ALTERNATIVES'
                        END
                    WHEN sa.status = 'RENEWAL_NEEDED' THEN
                        CASE
                            WHEN v.performance_score >= 4.0 THEN 'EARLY_RENEWAL_OFFER'
                            ELSE 'STANDARD_RENEWAL_PROCESS'
                        END
                    ELSE 'MAINTAIN_CURRENT_TERMS'
                END
            )
        )
    ) as recommendations
    FROM vendors v
    JOIN service_agreements sa ON v.vendor_id = sa.vendor_id
    WHERE v.vendor_id = p_vendor_id
    GROUP BY v.vendor_id;
END //

-- Initialize Vendors
INSERT IGNORE INTO vendors 
(vendor_name, service_types, contract_details, performance_score) VALUES 
('Premium Railways',
 '["TRAIN_SERVICE", "MAINTENANCE"]',
 '{"contract_type": "PREMIUM", "payment_terms": "NET_30"}',
 4.5),
('Elite Catering',
 '["FOOD_SERVICE", "BEVERAGES"]',
 '{"contract_type": "STANDARD", "payment_terms": "NET_15"}',
 4.2),
('Tech Solutions',
 '["BOOKING_SYSTEM", "CUSTOMER_SERVICE"]',
 '{"contract_type": "ENTERPRISE", "payment_terms": "NET_45"}',
 3.8);

-- Initialize Service Agreements
INSERT IGNORE INTO service_agreements 
(vendor_id, service_type, terms, start_date, end_date, status) VALUES 
(1, 'TRAIN_SERVICE',
 '{"service_level": "PREMIUM", "response_time": "4h"}',
 '2023-01-01', '2024-12-31', 'ACTIVE'),
(2, 'FOOD_SERVICE',
 '{"menu_rotation": "WEEKLY", "quality_standard": "LUXURY"}',
 '2023-01-01', '2023-12-31', 'RENEWAL_NEEDED'),
(3, 'BOOKING_SYSTEM',
 '{"uptime_sla": "99.9%", "support_level": "24x7"}',
 '2023-06-01', '2024-05-31', 'ACTIVE');

-- Vendor Management Dashboard
CREATE OR REPLACE VIEW vendor_management_dashboard AS
SELECT 
    v.vendor_id,
    v.vendor_name,
    -- Vendor Details
    JSON_OBJECT(
        'status', v.status,
        'performance_score', v.performance_score,
        'service_types', v.service_types,
        'last_reviewed', v.last_reviewed
    ) as vendor_details,
    -- Agreement Status
    JSON_OBJECT(
        'active_agreements', COUNT(
            CASE WHEN sa.status = 'ACTIVE' THEN 1 END
        ),
        'expiring_soon', COUNT(
            CASE WHEN sa.status = 'RENEWAL_NEEDED' THEN 1 END
        ),
        'agreement_details', JSON_ARRAYAGG(
            JSON_OBJECT(
                'service_type', sa.service_type,
                'status', sa.status,
                'end_date', sa.end_date
            )
        )
    ) as agreement_status,
    -- Performance Metrics
    JSON_OBJECT(
        'metrics_summary', (
            SELECT JSON_OBJECTAGG(
                metric_type,
                JSON_OBJECT(
                    'current_value', metric_value,
                    'trend', CASE
                        WHEN metric_value > LAG(metric_value) OVER (
                            PARTITION BY metric_type 
                            ORDER BY evaluation_date
                        ) THEN 'IMPROVING'
                        ELSE 'DECLINING'
                    END
                )
            )
            FROM vendor_performance vp
            WHERE vp.vendor_id = v.vendor_id
            AND vp.evaluation_date = (
                SELECT MAX(evaluation_date)
                FROM vendor_performance
                WHERE vendor_id = v.vendor_id
            )
        )
    ) as performance_metrics
FROM vendors v
LEFT JOIN service_agreements sa ON v.vendor_id = sa.vendor_id
GROUP BY v.vendor_id, v.vendor_name;

DELIMITER ;
