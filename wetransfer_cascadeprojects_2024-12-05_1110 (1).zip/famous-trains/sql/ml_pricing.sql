USE luxury_travel;

DELIMITER //

-- ML-Based Pricing Framework
-- =======================

-- Price Prediction Models
CREATE TABLE IF NOT EXISTS price_prediction_models (
    model_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    model_name VARCHAR(100),
    model_type ENUM('REGRESSION', 'TIMESERIES', 'ENSEMBLE'),
    features JSON,
    weights JSON,
    performance_metrics JSON,
    last_trained TIMESTAMP,
    active BOOLEAN DEFAULT TRUE,
    INDEX idx_model_active (model_type, active)
);

-- Market Trends
CREATE TABLE IF NOT EXISTS market_trends (
    trend_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    trend_type VARCHAR(50),
    service_type VARCHAR(50),
    trend_data JSON,
    confidence_score DECIMAL(5,4),
    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_trend (trend_type, service_type)
);

-- Additional Market Segments
CREATE TABLE IF NOT EXISTS advanced_segments (
    segment_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    parent_segment_id BIGINT,
    segment_name VARCHAR(100),
    behavioral_patterns JSON,
    price_elasticity DECIMAL(5,4),
    seasonal_preferences JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_segment_id) REFERENCES market_segments(segment_id),
    INDEX idx_elasticity (price_elasticity)
);

-- Real-time Market Analysis
-- ======================

-- Calculate Price Prediction
CREATE PROCEDURE calculate_price_prediction(
    IN p_service_type VARCHAR(50),
    IN p_service_id BIGINT,
    IN p_travel_date DATE,
    OUT p_predicted_price DECIMAL(10,2)
)
BEGIN
    DECLARE v_features JSON;
    DECLARE v_market_trend DECIMAL(10,2);
    DECLARE v_seasonal_factor DECIMAL(10,2);
    DECLARE v_competitor_influence DECIMAL(10,2);
    
    -- Collect feature data
    SET v_features = (
        SELECT JSON_OBJECT(
            'historical_prices', (
                SELECT JSON_ARRAYAGG(
                    JSON_OBJECT(
                        'price', final_price,
                        'date', DATE(timestamp),
                        'factors', factors_applied
                    )
                )
                FROM price_history
                WHERE service_type = p_service_type
                AND service_id = p_service_id
                AND timestamp >= DATE_SUB(NOW(), INTERVAL 90 DAY)
            ),
            'market_trends', (
                SELECT JSON_ARRAYAGG(trend_data)
                FROM market_trends
                WHERE service_type = p_service_type
                AND detected_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            ),
            'competitor_prices', (
                SELECT JSON_ARRAYAGG(
                    JSON_OBJECT(
                        'competitor', competitor_name,
                        'price', price,
                        'features', features
                    )
                )
                FROM competitor_pricing
                WHERE service_type = p_service_type
                AND last_updated >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            ),
            'demand_indicators', (
                SELECT JSON_OBJECT(
                    'recent_bookings', COUNT(*),
                    'avg_price', AVG(total_amount),
                    'conversion_rate', 
                    COUNT(*) / COUNT(DISTINCT DATE(created_at))
                )
                FROM (
                    SELECT * FROM train_bookings
                    UNION ALL
                    SELECT * FROM cruise_bookings
                    UNION ALL
                    SELECT * FROM car_rentals
                ) bookings
                WHERE service_type = p_service_type
                AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            )
        )
    );
    
    -- Apply ML model weights
    SET p_predicted_price = (
        SELECT 
            -- Base prediction using weighted features
            (
                JSON_EXTRACT(weights, '$.historical') * 
                    (SELECT AVG(final_price) FROM price_history 
                     WHERE service_type = p_service_type
                     AND service_id = p_service_id) +
                JSON_EXTRACT(weights, '$.market_trend') * v_market_trend +
                JSON_EXTRACT(weights, '$.seasonal') * v_seasonal_factor +
                JSON_EXTRACT(weights, '$.competitor') * v_competitor_influence
            )
        FROM price_prediction_models
        WHERE model_type = 'ENSEMBLE'
        AND active = TRUE
        ORDER BY last_trained DESC
        LIMIT 1
    );
    
    -- Record prediction
    INSERT INTO price_prediction_models (
        model_name,
        model_type,
        features,
        performance_metrics
    ) VALUES (
        'ENSEMBLE_PREDICTOR',
        'ENSEMBLE',
        v_features,
        JSON_OBJECT(
            'predicted_price', p_predicted_price,
            'confidence_score', 0.85,
            'feature_importance', JSON_OBJECT(
                'historical_weight', 0.4,
                'market_trend_weight', 0.3,
                'seasonal_weight', 0.2,
                'competitor_weight', 0.1
            )
        )
    );
END //

-- Real-time Market Analysis
CREATE PROCEDURE analyze_market_realtime(
    IN p_service_type VARCHAR(50)
)
BEGIN
    -- Detect market trends
    INSERT INTO market_trends (
        trend_type,
        service_type,
        trend_data,
        confidence_score
    )
    WITH recent_market_data AS (
        SELECT 
            DATE(timestamp) as trend_date,
            AVG(final_price) as avg_price,
            COUNT(DISTINCT service_id) as service_count,
            -- Calculate moving averages
            AVG(AVG(final_price)) OVER (
                ORDER BY DATE(timestamp)
                ROWS BETWEEN 7 PRECEDING AND CURRENT ROW
            ) as price_ma_7,
            AVG(AVG(final_price)) OVER (
                ORDER BY DATE(timestamp)
                ROWS BETWEEN 30 PRECEDING AND CURRENT ROW
            ) as price_ma_30
        FROM price_history
        WHERE service_type = p_service_type
        AND timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY DATE(timestamp)
    )
    SELECT 
        'PRICE_TREND',
        p_service_type,
        JSON_OBJECT(
            'trend_direction', CASE 
                WHEN price_ma_7 > price_ma_30 THEN 'UP'
                WHEN price_ma_7 < price_ma_30 THEN 'DOWN'
                ELSE 'STABLE'
            END,
            'trend_strength', ABS(price_ma_7 - price_ma_30) / price_ma_30,
            'price_volatility', STDDEV(avg_price) / AVG(avg_price),
            'market_momentum', (
                price_ma_7 - LAG(price_ma_7, 7) OVER (ORDER BY trend_date)
            ) / LAG(price_ma_7, 7) OVER (ORDER BY trend_date)
        ),
        -- Confidence score based on data quality
        CASE 
            WHEN COUNT(*) >= 30 THEN 0.9
            WHEN COUNT(*) >= 15 THEN 0.7
            ELSE 0.5
        END
    FROM recent_market_data;
END //

-- Initialize Advanced Market Segments
INSERT IGNORE INTO advanced_segments 
(parent_segment_id, segment_name, behavioral_patterns, price_elasticity, seasonal_preferences) 
SELECT 
    ms.segment_id,
    CASE ms.segment_name
        WHEN 'Luxury Travelers' THEN 'Ultra-Luxury Experience Seekers'
        WHEN 'Business Travelers' THEN 'Executive Premium'
        WHEN 'Budget Conscious' THEN 'Smart Value Seekers'
        WHEN 'Family Travelers' THEN 'Multi-Generation Luxury'
    END,
    JSON_OBJECT(
        'booking_window', CASE ms.segment_name
            WHEN 'Luxury Travelers' THEN '90+ days'
            WHEN 'Business Travelers' THEN '1-7 days'
            WHEN 'Budget Conscious' THEN '30-60 days'
            WHEN 'Family Travelers' THEN '60-90 days'
        END,
        'preferred_amenities', CASE ms.segment_name
            WHEN 'Luxury Travelers' THEN '["private_tours", "concierge", "luxury_transfers"]'
            WHEN 'Business Travelers' THEN '["fast_track", "lounge_access", "wifi"]'
            WHEN 'Budget Conscious' THEN '["flexible_dates", "basic_amenities"]'
            WHEN 'Family Travelers' THEN '["connecting_rooms", "kid_friendly", "meal_plans"]'
        END
    ),
    CASE ms.segment_name
        WHEN 'Luxury Travelers' THEN 0.15
        WHEN 'Business Travelers' THEN 0.35
        WHEN 'Budget Conscious' THEN 0.85
        WHEN 'Family Travelers' THEN 0.55
    END,
    JSON_OBJECT(
        'peak_booking_months', CASE ms.segment_name
            WHEN 'Luxury Travelers' THEN '[12,1,7,8]'
            WHEN 'Business Travelers' THEN '[3,4,9,10]'
            WHEN 'Budget Conscious' THEN '[5,6,9]'
            WHEN 'Family Travelers' THEN '[7,8,12]'
        END,
        'preferred_destinations', CASE ms.segment_name
            WHEN 'Luxury Travelers' THEN '["Monaco", "Swiss Alps", "Maldives"]'
            WHEN 'Business Travelers' THEN '["London", "Paris", "Frankfurt"]'
            WHEN 'Budget Conscious' THEN '["Barcelona", "Prague", "Budapest"]'
            WHEN 'Family Travelers' THEN '["Disney", "Costa del Sol", "Algarve"]'
        END
    )
FROM market_segments ms;

-- Initialize ML Models
INSERT IGNORE INTO price_prediction_models 
(model_name, model_type, features, weights, performance_metrics) VALUES 
('Advanced Ensemble Predictor', 'ENSEMBLE',
 '{"features": ["historical_prices", "market_trends", "competitor_prices", "demand_indicators"]}',
 '{"historical": 0.4, "market_trend": 0.3, "seasonal": 0.2, "competitor": 0.1}',
 '{"accuracy": 0.85, "mae": 12.5, "rmse": 15.8}');

DELIMITER ;
