USE luxury_travel;

DELIMITER //

-- Enhanced Workflow System
-- =====================

-- Integration Endpoints
CREATE TABLE IF NOT EXISTS integration_endpoints (
    endpoint_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    endpoint_name VARCHAR(100),
    endpoint_type ENUM('EMAIL', 'SMS', 'WEBHOOK', 'API', 'SLACK'),
    configuration JSON,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_type_active (endpoint_type, active)
);

-- Notification Templates
CREATE TABLE IF NOT EXISTS notification_templates (
    template_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    template_name VARCHAR(100),
    template_type VARCHAR(50),
    subject_template TEXT,
    body_template TEXT,
    variables JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_template_type (template_type)
);

-- Advanced Workflow Templates
-- =======================

-- Data Exfiltration Prevention
INSERT INTO security_workflows 
(workflow_name, trigger_conditions, actions, severity, status) VALUES
('Data Exfiltration Detection',
 '{
    "type": "data_access",
    "conditions": {
        "record_count_threshold": 1000,
        "sensitive_data_types": ["PII", "PAYMENT", "PASSPORT"],
        "time_window_minutes": 5
    }
 }',
 '{
    "block_session": true,
    "create_alert": {"severity": "CRITICAL"},
    "notify": ["SECURITY_TEAM", "DATA_PROTECTION_OFFICER"],
    "log_evidence": true
 }',
 'CRITICAL', 'ACTIVE');

-- API Abuse Prevention
INSERT INTO security_workflows 
(workflow_name, trigger_conditions, actions, severity, status) VALUES
('API Abuse Prevention',
 '{
    "type": "api_usage",
    "conditions": {
        "requests_per_minute": 100,
        "error_rate_threshold": 0.3,
        "unique_endpoints": 10
    }
 }',
 '{
    "rate_limit": {"window": 3600, "max_requests": 1000},
    "create_alert": {"severity": "HIGH"},
    "notify": ["API_TEAM"],
    "block_ip": {"duration_hours": 24}
 }',
 'HIGH', 'ACTIVE');

-- Session Hijacking Prevention
INSERT INTO security_workflows 
(workflow_name, trigger_conditions, actions, severity, status) VALUES
('Session Hijacking Detection',
 '{
    "type": "session_analysis",
    "conditions": {
        "ip_change": true,
        "user_agent_change": true,
        "time_window_minutes": 30
    }
 }',
 '{
    "invalidate_session": true,
    "require_2fa": true,
    "create_alert": {"severity": "HIGH"},
    "notify": ["USER", "SECURITY_TEAM"]
 }',
 'HIGH', 'ACTIVE');

-- Enhanced Reporting Views
-- ====================

-- Security Compliance Dashboard
CREATE OR REPLACE VIEW security_compliance_dashboard AS
SELECT 
    CURRENT_TIMESTAMP as report_time,
    -- Authentication Metrics
    (SELECT COUNT(*) FROM user_activity_logs 
     WHERE action_type = 'LOGIN_2FA' 
     AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as mfa_authentications,
    
    -- Password Policy Compliance
    (SELECT COUNT(*) FROM users 
     WHERE password_last_changed < DATE_SUB(NOW(), INTERVAL 90 DAY)) as password_updates_needed,
    
    -- Session Security
    (SELECT COUNT(DISTINCT session_id) FROM user_activity_logs 
     WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)) as active_sessions,
    
    -- API Security
    (SELECT COUNT(*) FROM user_activity_logs 
     WHERE action_type LIKE 'API_%' 
     AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as api_requests,
    
    -- Data Access Patterns
    (SELECT COUNT(*) FROM user_activity_logs 
     WHERE action_type IN ('VIEW_PII', 'EXPORT_DATA') 
     AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as sensitive_data_access;

-- Workflow Performance Metrics
CREATE OR REPLACE VIEW workflow_performance_metrics AS
SELECT 
    w.workflow_name,
    COUNT(e.execution_id) as total_executions,
    AVG(TIMESTAMPDIFF(SECOND, e.started_at, e.completed_at)) as avg_execution_time,
    COUNT(CASE WHEN e.status = 'COMPLETED' THEN 1 END) / COUNT(*) * 100 as success_rate,
    COUNT(CASE WHEN e.status = 'FAILED' THEN 1 END) as failures,
    MAX(e.started_at) as last_execution
FROM security_workflows w
LEFT JOIN workflow_executions e ON w.workflow_id = e.workflow_id
WHERE e.started_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
GROUP BY w.workflow_id, w.workflow_name;

-- Integration Procedures
-- ==================

-- Send Notification
CREATE PROCEDURE send_security_notification(
    IN p_template_id BIGINT,
    IN p_recipient_type VARCHAR(50),
    IN p_data JSON
)
BEGIN
    DECLARE v_template_body TEXT;
    DECLARE v_template_subject TEXT;
    DECLARE v_endpoint_config JSON;
    
    -- Get template
    SELECT body_template, subject_template
    INTO v_template_body, v_template_subject
    FROM notification_templates
    WHERE template_id = p_template_id;
    
    -- Get endpoint configuration
    SELECT configuration
    INTO v_endpoint_config
    FROM integration_endpoints
    WHERE endpoint_type = 
        CASE p_recipient_type
            WHEN 'SECURITY_TEAM' THEN 'SLACK'
            WHEN 'USER' THEN 'EMAIL'
            ELSE 'WEBHOOK'
        END
    AND active = TRUE
    LIMIT 1;
    
    -- Log notification attempt
    INSERT INTO notification_logs (
        template_id,
        recipient_type,
        notification_data,
        endpoint_config,
        status
    ) VALUES (
        p_template_id,
        p_recipient_type,
        p_data,
        v_endpoint_config,
        'PENDING'
    );
END //

-- Initialize Notification Templates
INSERT INTO notification_templates 
(template_name, template_type, subject_template, body_template, variables) VALUES
('Security Alert', 'SECURITY_TEAM',
 'Security Alert: {{ alert_type }}',
 'Security alert detected:\nType: {{ alert_type }}\nSeverity: {{ severity }}\nDetails: {{ details }}',
 '{"alert_type": "string", "severity": "string", "details": "object"}'),
('User Security Notice', 'USER',
 'Security Notice: Action Required',
 'Dear {{ user_name }},\n\nA security event has been detected on your account: {{ event_description }}\n\nRequired Action: {{ action_required }}',
 '{"user_name": "string", "event_description": "string", "action_required": "string"}');

DELIMITER ;
