USE luxury_travel;

DELIMITER //

-- Loyalty Program Framework
-- =====================

-- Loyalty Tiers
CREATE TABLE IF NOT EXISTS loyalty_tiers (
    tier_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    tier_name VARCHAR(50),
    min_points INT,
    benefits JSON,
    multiplier DECIMAL(3,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Loyalty Points
CREATE TABLE IF NOT EXISTS loyalty_points (
    point_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT,
    points_earned INT,
    points_type VARCHAR(50),
    transaction_ref JSON,
    expiry_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_expiry (user_id, expiry_date)
);

-- A/B Testing Framework
CREATE TABLE IF NOT EXISTS ab_tests (
    test_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    test_name VARCHAR(100),
    test_type VARCHAR(50),
    variants JSON,
    start_date TIMESTAMP,
    end_date TIMESTAMP,
    status ENUM('DRAFT', 'ACTIVE', 'COMPLETED', 'ANALYZED'),
    results JSON,
    INDEX idx_status (status)
);

-- Test Assignments
CREATE TABLE IF NOT EXISTS test_assignments (
    assignment_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    test_id BIGINT,
    user_id BIGINT,
    variant_id VARCHAR(50),
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    conversion_tracked BOOLEAN DEFAULT FALSE,
    INDEX idx_test_user (test_id, user_id)
);

-- Advanced Functions
-- ===============

-- Calculate Loyalty Status
CREATE PROCEDURE calculate_loyalty_status(
    IN p_user_id BIGINT,
    OUT p_tier_id BIGINT,
    OUT p_total_points INT
)
BEGIN
    -- Calculate total active points
    SELECT COALESCE(SUM(points_earned), 0)
    INTO p_total_points
    FROM loyalty_points
    WHERE user_id = p_user_id
    AND (expiry_date IS NULL OR expiry_date > CURRENT_DATE);
    
    -- Determine tier
    SELECT tier_id INTO p_tier_id
    FROM loyalty_tiers
    WHERE min_points <= p_total_points
    ORDER BY min_points DESC
    LIMIT 1;
    
    -- Update customer profile
    UPDATE customer_profiles
    SET 
        preferences = JSON_SET(
            preferences,
            '$.loyalty_tier', (SELECT tier_name FROM loyalty_tiers WHERE tier_id = p_tier_id),
            '$.total_points', p_total_points,
            '$.tier_benefits', (SELECT benefits FROM loyalty_tiers WHERE tier_id = p_tier_id)
        )
    WHERE user_id = p_user_id;
END //

-- Create A/B Test
CREATE PROCEDURE create_ab_test(
    IN p_test_name VARCHAR(100),
    IN p_test_type VARCHAR(50),
    IN p_variants JSON,
    IN p_duration INT -- days
)
BEGIN
    INSERT INTO ab_tests (
        test_name,
        test_type,
        variants,
        start_date,
        end_date,
        status
    ) VALUES (
        p_test_name,
        p_test_type,
        p_variants,
        CURRENT_TIMESTAMP,
        DATE_ADD(CURRENT_TIMESTAMP, INTERVAL p_duration DAY),
        'ACTIVE'
    );
END //

-- Assign Test Variant
CREATE PROCEDURE assign_test_variant(
    IN p_test_id BIGINT,
    IN p_user_id BIGINT
)
BEGIN
    DECLARE v_variants JSON;
    DECLARE v_variant_id VARCHAR(50);
    
    -- Get test variants
    SELECT variants INTO v_variants
    FROM ab_tests
    WHERE test_id = p_test_id
    AND status = 'ACTIVE';
    
    -- Randomly select variant
    SET v_variant_id = JSON_EXTRACT(v_variants, 
        CONCAT('$[', FLOOR(RAND() * JSON_LENGTH(v_variants)), ']'));
    
    -- Assign variant
    INSERT INTO test_assignments (
        test_id,
        user_id,
        variant_id
    ) VALUES (
        p_test_id,
        p_user_id,
        v_variant_id
    );
END //

-- Track Test Conversion
CREATE PROCEDURE track_test_conversion(
    IN p_test_id BIGINT,
    IN p_user_id BIGINT,
    IN p_conversion_data JSON
)
BEGIN
    -- Update assignment
    UPDATE test_assignments
    SET 
        conversion_tracked = TRUE
    WHERE test_id = p_test_id
    AND user_id = p_user_id;
    
    -- Update test results
    UPDATE ab_tests
    SET results = JSON_MERGE_PATCH(
        COALESCE(results, '{}'),
        JSON_OBJECT(
            'conversions', COALESCE(
                JSON_EXTRACT(results, '$.conversions'),
                JSON_OBJECT()
            ) + 1,
            'conversion_data', JSON_MERGE_PRESERVE(
                COALESCE(
                    JSON_EXTRACT(results, '$.conversion_data'),
                    JSON_ARRAY()
                ),
                JSON_ARRAY(p_conversion_data)
            )
        )
    )
    WHERE test_id = p_test_id;
END //

-- Analyze Test Results
CREATE PROCEDURE analyze_test_results(
    IN p_test_id BIGINT
)
BEGIN
    -- Mark test as analyzed
    UPDATE ab_tests
    SET 
        status = 'ANALYZED',
        results = JSON_MERGE_PATCH(
            results,
            (
                SELECT JSON_OBJECT(
                    'analysis_date', CURRENT_TIMESTAMP,
                    'variants', JSON_OBJECTAGG(
                        variant_id,
                        JSON_OBJECT(
                            'assignments', COUNT(*),
                            'conversions', SUM(conversion_tracked),
                            'conversion_rate', 
                                (SUM(conversion_tracked) / COUNT(*)) * 100
                        )
                    ),
                    'winner', (
                        SELECT variant_id
                        FROM test_assignments
                        WHERE test_id = p_test_id
                        GROUP BY variant_id
                        ORDER BY (SUM(conversion_tracked) / COUNT(*)) DESC
                        LIMIT 1
                    )
                )
                FROM test_assignments
                WHERE test_id = p_test_id
                GROUP BY variant_id
            )
        )
    WHERE test_id = p_test_id;
END //

-- Initialize Loyalty Tiers
INSERT IGNORE INTO loyalty_tiers 
(tier_name, min_points, benefits, multiplier) VALUES 
('Bronze', 0, 
 '{"discount_rate": 0.05, "priority_support": false, "free_upgrades": false}', 
 1.0),
('Silver', 1000, 
 '{"discount_rate": 0.10, "priority_support": true, "free_upgrades": false}',
 1.25),
('Gold', 5000, 
 '{"discount_rate": 0.15, "priority_support": true, "free_upgrades": true}',
 1.5),
('Platinum', 10000, 
 '{"discount_rate": 0.20, "priority_support": true, "free_upgrades": true, "exclusive_offers": true}',
 2.0);

-- Testing Dashboard
CREATE OR REPLACE VIEW testing_dashboard AS
SELECT 
    t.test_id,
    t.test_name,
    t.test_type,
    t.status,
    -- Test metrics
    JSON_OBJECT(
        'duration_days', DATEDIFF(t.end_date, t.start_date),
        'participants', COUNT(DISTINCT ta.user_id),
        'conversions', SUM(ta.conversion_tracked),
        'overall_conversion_rate', 
            (SUM(ta.conversion_tracked) / COUNT(DISTINCT ta.user_id)) * 100
    ) as test_metrics,
    -- Variant performance
    JSON_OBJECTAGG(
        ta.variant_id,
        JSON_OBJECT(
            'assignments', COUNT(*),
            'conversions', SUM(ta.conversion_tracked),
            'conversion_rate', (SUM(ta.conversion_tracked) / COUNT(*)) * 100
        )
    ) as variant_performance,
    -- Test results
    t.results as detailed_results
FROM ab_tests t
LEFT JOIN test_assignments ta ON t.test_id = ta.test_id
GROUP BY t.test_id, t.test_name, t.test_type, t.status, t.results;

DELIMITER ;
