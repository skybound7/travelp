USE luxury_travel;

DELIMITER //

-- Advanced Threat Detection
-- ======================

-- Threat Detection Rules
CREATE TABLE IF NOT EXISTS threat_detection_rules (
    rule_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    rule_name VARCHAR(100),
    rule_type ENUM('PATTERN', 'THRESHOLD', 'ANOMALY'),
    conditions JSON,
    severity ENUM('LOW', 'MEDIUM', 'HIGH', 'CRITICAL'),
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_rule_type (rule_type),
    INDEX idx_severity (severity)
);

-- Threat Incidents
CREATE TABLE IF NOT EXISTS threat_incidents (
    incident_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    rule_id BIGINT,
    user_id INT,
    ip_address VARCHAR(45),
    threat_type VARCHAR(50),
    severity ENUM('LOW', 'MEDIUM', 'HIGH', 'CRITICAL'),
    details JSON,
    status ENUM('NEW', 'INVESTIGATING', 'RESOLVED', 'FALSE_POSITIVE'),
    resolution_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP,
    FOREIGN KEY (rule_id) REFERENCES threat_detection_rules(rule_id),
    INDEX idx_threat_type (threat_type),
    INDEX idx_status (status)
);

-- Enhanced Audit Logging
-- ===================

-- Detailed Audit Log
CREATE TABLE IF NOT EXISTS detailed_audit_log (
    audit_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action_type VARCHAR(50),
    entity_type VARCHAR(50),
    entity_id VARCHAR(100),
    old_value JSON,
    new_value JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    request_headers JSON,
    request_params JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_action (user_id, action_type),
    INDEX idx_entity (entity_type, entity_id)
);

-- Advanced Security Procedures
-- ========================

-- Pattern-Based Threat Detection
CREATE PROCEDURE detect_suspicious_patterns()
BEGIN
    -- Detect rapid-fire requests
    INSERT INTO threat_incidents (rule_id, user_id, ip_address, threat_type, severity, details)
    SELECT 
        1 as rule_id,
        user_id,
        ip_address,
        'RAPID_FIRE_REQUESTS',
        'HIGH',
        JSON_OBJECT(
            'request_count', COUNT(*),
            'time_window', '1 minute',
            'actions', GROUP_CONCAT(action_type)
        )
    FROM user_activity_logs
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 MINUTE)
    GROUP BY user_id, ip_address
    HAVING COUNT(*) > 100;

    -- Detect credential stuffing
    INSERT INTO threat_incidents (rule_id, user_id, ip_address, threat_type, severity, details)
    SELECT 
        2,
        NULL,
        ip_address,
        'CREDENTIAL_STUFFING',
        'CRITICAL',
        JSON_OBJECT(
            'attempt_count', COUNT(*),
            'unique_users', COUNT(DISTINCT username)
        )
    FROM failed_login_attempts
    WHERE attempt_time >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)
    GROUP BY ip_address
    HAVING COUNT(DISTINCT username) > 10;

    -- Detect suspicious access patterns
    INSERT INTO threat_incidents (rule_id, user_id, ip_address, threat_type, severity, details)
    SELECT 
        3,
        user_id,
        ip_address,
        'SUSPICIOUS_ACCESS_PATTERN',
        'HIGH',
        JSON_OBJECT(
            'unique_sessions', COUNT(DISTINCT session_id),
            'locations', COUNT(DISTINCT ip_address),
            'time_window', '1 hour'
        )
    FROM user_activity_logs
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
    GROUP BY user_id
    HAVING COUNT(DISTINCT ip_address) > 5;
END //

-- Anomaly Detection
CREATE PROCEDURE detect_behavioral_anomalies()
BEGIN
    -- Detect unusual transaction patterns
    INSERT INTO threat_incidents (rule_id, user_id, ip_address, threat_type, severity, details)
    SELECT 
        4,
        user_id,
        ip_address,
        'UNUSUAL_TRANSACTION_PATTERN',
        'HIGH',
        JSON_OBJECT(
            'transaction_count', COUNT(*),
            'total_amount', SUM(CAST(JSON_EXTRACT(request_data, '$.amount') AS DECIMAL)),
            'avg_amount', AVG(CAST(JSON_EXTRACT(request_data, '$.amount') AS DECIMAL))
        )
    FROM user_activity_logs
    WHERE action_type = 'PAYMENT'
    AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
    GROUP BY user_id, ip_address
    HAVING COUNT(*) > 10 OR SUM(CAST(JSON_EXTRACT(request_data, '$.amount') AS DECIMAL)) > 10000;

    -- Detect account takeover attempts
    INSERT INTO threat_incidents (rule_id, user_id, ip_address, threat_type, severity, details)
    SELECT 
        5,
        user_id,
        ip_address,
        'POTENTIAL_ACCOUNT_TAKEOVER',
        'CRITICAL',
        JSON_OBJECT(
            'suspicious_actions', GROUP_CONCAT(action_type),
            'time_window', '15 minutes'
        )
    FROM user_activity_logs
    WHERE action_type IN ('PASSWORD_CHANGE', 'EMAIL_CHANGE', 'PROFILE_UPDATE')
    AND created_at >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)
    GROUP BY user_id, ip_address
    HAVING COUNT(DISTINCT action_type) >= 2;
END //

-- Enhanced Audit Logging
CREATE PROCEDURE log_detailed_audit(
    IN p_user_id INT,
    IN p_action_type VARCHAR(50),
    IN p_entity_type VARCHAR(50),
    IN p_entity_id VARCHAR(100),
    IN p_old_value JSON,
    IN p_new_value JSON,
    IN p_ip_address VARCHAR(45),
    IN p_user_agent TEXT,
    IN p_request_headers JSON,
    IN p_request_params JSON
)
BEGIN
    INSERT INTO detailed_audit_log (
        user_id,
        action_type,
        entity_type,
        entity_id,
        old_value,
        new_value,
        ip_address,
        user_agent,
        request_headers,
        request_params
    ) VALUES (
        p_user_id,
        p_action_type,
        p_entity_type,
        p_entity_id,
        p_old_value,
        p_new_value,
        p_ip_address,
        p_user_agent,
        p_request_headers,
        p_request_params
    );
END //

-- Scheduled Security Tasks
-- ====================

-- Continuous Threat Monitoring
CREATE EVENT IF NOT EXISTS continuous_threat_monitoring
ON SCHEDULE EVERY 1 MINUTE
DO
BEGIN
    CALL detect_suspicious_patterns();
    CALL detect_behavioral_anomalies();
END //

-- Initialize Default Threat Rules
INSERT IGNORE INTO threat_detection_rules 
(rule_name, rule_type, conditions, severity) VALUES
('Rapid Fire Requests', 'THRESHOLD', 
 '{"requests_per_minute": 100, "window_seconds": 60}', 'HIGH'),
('Credential Stuffing', 'PATTERN',
 '{"unique_users": 10, "window_seconds": 300}', 'CRITICAL'),
('Suspicious Access', 'ANOMALY',
 '{"unique_locations": 5, "window_hours": 1}', 'HIGH'),
('Unusual Transactions', 'THRESHOLD',
 '{"max_amount": 10000, "max_count": 10, "window_hours": 24}', 'HIGH'),
('Account Takeover', 'PATTERN',
 '{"sensitive_actions": 2, "window_minutes": 15}', 'CRITICAL');

DELIMITER ;
