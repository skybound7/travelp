USE luxury_travel;

DELIMITER //

-- Revenue Optimization Framework
-- ==========================

-- Revenue Models
CREATE TABLE IF NOT EXISTS revenue_models (
    model_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    model_type ENUM('YIELD', 'DYNAMIC', 'COMPETITIVE', 'SEASONAL'),
    parameters JSON,
    performance_metrics JSON,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_service_type (service_type, model_type)
);

-- Yield Management
CREATE TABLE IF NOT EXISTS yield_metrics (
    metric_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    booking_date DATE,
    travel_date DATE,
    occupancy_rate DECIMAL(5,2),
    revenue_per_unit DECIMAL(10,2),
    yield_score DECIMAL(5,2),
    optimization_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_dates (service_type, booking_date, travel_date)
);

-- Revenue Optimization Functions
-- ==========================

-- Calculate Optimal Yield
CREATE PROCEDURE calculate_optimal_yield(
    IN p_service_type VARCHAR(50),
    IN p_travel_date DATE
)
BEGIN
    -- Calculate yield metrics
    INSERT INTO yield_metrics (
        service_type,
        booking_date,
        travel_date,
        occupancy_rate,
        revenue_per_unit,
        yield_score,
        optimization_data
    )
    SELECT 
        p_service_type,
        CURRENT_DATE,
        p_travel_date,
        -- Calculate occupancy rate
        COUNT(DISTINCT b.booking_id) / 
            CASE p_service_type
                WHEN 'TRAIN' THEN 100  -- Example capacity
                WHEN 'CRUISE' THEN 50
                WHEN 'CAR' THEN 20
                ELSE 100
            END as occupancy_rate,
        -- Revenue per unit
        COALESCE(AVG(b.total_amount), 0) as revenue_per_unit,
        -- Yield score (occupancy * revenue efficiency)
        (COUNT(DISTINCT b.booking_id) / 
            CASE p_service_type
                WHEN 'TRAIN' THEN 100
                WHEN 'CRUISE' THEN 50
                WHEN 'CAR' THEN 20
                ELSE 100
            END) * 
        (COALESCE(AVG(b.total_amount), 0) / 
            COALESCE((SELECT AVG(base_price) FROM price_history 
                     WHERE service_type = p_service_type), 1)) as yield_score,
        -- Optimization data
        JSON_OBJECT(
            'booking_curve', JSON_ARRAYAGG(
                JSON_OBJECT(
                    'days_to_travel', DATEDIFF(p_travel_date, b.created_at),
                    'bookings', COUNT(*),
                    'revenue', SUM(total_amount)
                )
            ),
            'price_points', JSON_ARRAYAGG(
                JSON_OBJECT(
                    'price_level', ph.final_price,
                    'conversion_rate', COUNT(DISTINCT b.booking_id) / COUNT(DISTINCT ph.history_id)
                )
            ),
            'segment_performance', JSON_ARRAYAGG(
                JSON_OBJECT(
                    'segment', ms.segment_name,
                    'revenue_share', SUM(b.total_amount) / SUM(SUM(b.total_amount)) OVER ()
                )
            )
        )
    FROM (
        SELECT * FROM train_bookings
        UNION ALL
        SELECT * FROM cruise_bookings
        UNION ALL
        SELECT * FROM car_rentals
    ) b
    LEFT JOIN price_history ph ON b.service_type = ph.service_type 
        AND b.service_id = ph.service_id
    LEFT JOIN market_segments ms ON JSON_CONTAINS(ms.preferred_services, 
        JSON_ARRAY(b.service_type))
    WHERE b.service_type = p_service_type
    AND b.travel_date = p_travel_date
    GROUP BY b.service_type;
END //

-- Optimize Revenue Strategy
CREATE PROCEDURE optimize_revenue_strategy(
    IN p_service_type VARCHAR(50),
    IN p_target_date DATE
)
BEGIN
    DECLARE v_yield_score DECIMAL(5,2);
    DECLARE v_occupancy_rate DECIMAL(5,2);
    DECLARE v_revenue_per_unit DECIMAL(10,2);
    
    -- Get current yield metrics
    SELECT 
        yield_score,
        occupancy_rate,
        revenue_per_unit
    INTO 
        v_yield_score,
        v_occupancy_rate,
        v_revenue_per_unit
    FROM yield_metrics
    WHERE service_type = p_service_type
    AND travel_date = p_target_date
    ORDER BY created_at DESC
    LIMIT 1;
    
    -- Create optimization model
    INSERT INTO revenue_models (
        service_type,
        model_type,
        parameters,
        performance_metrics
    )
    SELECT 
        p_service_type,
        CASE 
            WHEN v_occupancy_rate < 0.5 THEN 'DYNAMIC'
            WHEN v_occupancy_rate > 0.8 THEN 'YIELD'
            ELSE 'COMPETITIVE'
        END,
        JSON_OBJECT(
            'target_date', p_target_date,
            'current_yield', v_yield_score,
            'occupancy_rate', v_occupancy_rate,
            'revenue_per_unit', v_revenue_per_unit,
            'optimization_rules', JSON_ARRAY(
                -- Low occupancy strategy
                JSON_OBJECT(
                    'condition', 'occupancy < 0.5',
                    'action', 'DYNAMIC_PRICING',
                    'parameters', JSON_OBJECT(
                        'min_discount', 0.1,
                        'max_discount', 0.3,
                        'price_sensitivity', 0.8
                    )
                ),
                -- High occupancy strategy
                JSON_OBJECT(
                    'condition', 'occupancy > 0.8',
                    'action', 'YIELD_MANAGEMENT',
                    'parameters', JSON_OBJECT(
                        'min_markup', 0.1,
                        'max_markup', 0.5,
                        'demand_elasticity', 0.6
                    )
                ),
                -- Competitive strategy
                JSON_OBJECT(
                    'condition', 'occupancy between 0.5 and 0.8',
                    'action', 'COMPETITIVE_PRICING',
                    'parameters', JSON_OBJECT(
                        'target_position', 'MATCH',
                        'max_variance', 0.1
                    )
                )
            )
        ),
        JSON_OBJECT(
            'current_metrics', JSON_OBJECT(
                'yield_score', v_yield_score,
                'occupancy_rate', v_occupancy_rate,
                'revenue_per_unit', v_revenue_per_unit
            ),
            'optimization_targets', JSON_OBJECT(
                'target_yield', v_yield_score * 1.2,
                'target_occupancy', LEAST(v_occupancy_rate * 1.15, 0.95),
                'target_revenue', v_revenue_per_unit * 1.1
            )
        );
END //

-- Revenue Performance Dashboard
CREATE OR REPLACE VIEW revenue_performance_dashboard AS
SELECT 
    r.service_type,
    r.model_type,
    -- Current performance
    JSON_OBJECT(
        'yield_score', y.yield_score,
        'occupancy_rate', y.occupancy_rate,
        'revenue_per_unit', y.revenue_per_unit
    ) as current_metrics,
    -- Model parameters
    r.parameters as optimization_strategy,
    -- Performance tracking
    r.performance_metrics as performance_tracking,
    -- Optimization data
    y.optimization_data as detailed_analytics,
    -- Last update
    r.last_updated
FROM revenue_models r
LEFT JOIN yield_metrics y ON r.service_type = y.service_type
WHERE r.last_updated = (
    SELECT MAX(last_updated)
    FROM revenue_models r2
    WHERE r2.service_type = r.service_type
)
ORDER BY r.last_updated DESC;

DELIMITER ;
