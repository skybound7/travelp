USE luxury_travel;

DELIMITER //

-- Capacity Management Framework
-- =========================

-- Inventory Levels
CREATE TABLE IF NOT EXISTS inventory_levels (
    inventory_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    service_date DATE,
    total_capacity INT,
    available_capacity INT,
    reserved_capacity INT,
    status VARCHAR(20),
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_service_date (service_type, service_date)
);

-- Capacity Rules
CREATE TABLE IF NOT EXISTS capacity_rules (
    rule_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    rule_type VARCHAR(50),
    conditions JSON,
    capacity_adjustment INT,
    priority INT,
    active BOOLEAN DEFAULT TRUE
);

-- Overbooking Limits
CREATE TABLE IF NOT EXISTS overbooking_limits (
    limit_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    season_type VARCHAR(20),
    max_overbooking_percent DECIMAL(5,2),
    risk_factor DECIMAL(5,2),
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Management Functions
-- =================

-- Update Inventory
CREATE PROCEDURE update_inventory(
    IN p_service_type VARCHAR(50),
    IN p_service_date DATE,
    IN p_change_amount INT,
    IN p_update_type VARCHAR(20)
)
BEGIN
    DECLARE v_current_capacity INT;
    DECLARE v_new_capacity INT;
    DECLARE v_status VARCHAR(20);
    
    -- Get current capacity
    SELECT available_capacity 
    INTO v_current_capacity
    FROM inventory_levels
    WHERE service_type = p_service_type
    AND service_date = p_service_date;
    
    -- Calculate new capacity
    SET v_new_capacity = v_current_capacity + 
        CASE p_update_type
            WHEN 'RESERVE' THEN -p_change_amount
            WHEN 'RELEASE' THEN p_change_amount
            ELSE 0
        END;
        
    -- Determine status
    SET v_status = CASE
        WHEN v_new_capacity <= 0 THEN 'SOLD_OUT'
        WHEN v_new_capacity < (SELECT total_capacity * 0.2 
                             FROM inventory_levels 
                             WHERE service_type = p_service_type 
                             AND service_date = p_service_date)
        THEN 'LOW_AVAILABILITY'
        ELSE 'AVAILABLE'
    END;
    
    -- Update inventory
    UPDATE inventory_levels
    SET 
        available_capacity = v_new_capacity,
        reserved_capacity = CASE p_update_type
            WHEN 'RESERVE' THEN reserved_capacity + p_change_amount
            WHEN 'RELEASE' THEN reserved_capacity - p_change_amount
            ELSE reserved_capacity
        END,
        status = v_status,
        last_updated = CURRENT_TIMESTAMP
    WHERE service_type = p_service_type
    AND service_date = p_service_date;
END //

-- Calculate Overbooking Limit
CREATE PROCEDURE calculate_overbooking_limit(
    IN p_service_type VARCHAR(50),
    IN p_service_date DATE
)
BEGIN
    DECLARE v_season_type VARCHAR(20);
    DECLARE v_max_overbooking INT;
    
    -- Determine season type
    SET v_season_type = CASE
        WHEN MONTH(p_service_date) IN (6,7,8) THEN 'PEAK'
        WHEN MONTH(p_service_date) IN (12,1) THEN 'HOLIDAY'
        ELSE 'REGULAR'
    END;
    
    -- Calculate overbooking limit
    SELECT 
        FLOOR(
            il.total_capacity * (1 + (ol.max_overbooking_percent/100)) *
            CASE
                WHEN ol.risk_factor > 0.8 THEN 0.8
                WHEN ol.risk_factor > 0.5 THEN 0.9
                ELSE 1.0
            END
        )
    INTO v_max_overbooking
    FROM inventory_levels il
    JOIN overbooking_limits ol 
        ON ol.service_type = il.service_type
        AND ol.season_type = v_season_type
    WHERE il.service_type = p_service_type
    AND il.service_date = p_service_date;
    
    -- Return calculated limit
    SELECT v_max_overbooking as overbooking_limit;
END //

-- Initialize Capacity Rules
INSERT IGNORE INTO capacity_rules 
(service_type, rule_type, conditions, capacity_adjustment, priority) VALUES 
('TRAIN', 'SEASONAL_ADJUSTMENT',
 '{"season": "PEAK", "min_occupancy": 0.8}',
 20, 1),
('TRAIN', 'SPECIAL_EVENT',
 '{"event_type": "FESTIVAL", "location_match": true}',
 15, 2),
('TRAIN', 'MAINTENANCE',
 '{"maintenance_type": "SCHEDULED", "duration_hours": 4}',
 -10, 3);

-- Initialize Overbooking Limits
INSERT IGNORE INTO overbooking_limits 
(service_type, season_type, max_overbooking_percent, risk_factor) VALUES 
('TRAIN', 'PEAK', 10.0, 0.7),
('TRAIN', 'HOLIDAY', 15.0, 0.8),
('TRAIN', 'REGULAR', 5.0, 0.5);

-- Capacity Dashboard
CREATE OR REPLACE VIEW capacity_dashboard AS
SELECT 
    il.service_type,
    il.service_date,
    -- Capacity Metrics
    JSON_OBJECT(
        'total_capacity', il.total_capacity,
        'available_capacity', il.available_capacity,
        'reserved_capacity', il.reserved_capacity,
        'utilization_rate', 
            ((il.total_capacity - il.available_capacity) * 100.0 / il.total_capacity),
        'status', il.status
    ) as capacity_metrics,
    -- Overbooking Settings
    JSON_OBJECT(
        'season_type', ol.season_type,
        'max_overbooking', ol.max_overbooking_percent,
        'risk_factor', ol.risk_factor,
        'last_updated', ol.last_updated
    ) as overbooking_config,
    -- Active Rules
    (SELECT JSON_ARRAYAGG(
        JSON_OBJECT(
            'type', rule_type,
            'adjustment', capacity_adjustment,
            'conditions', conditions,
            'priority', priority
        )
    )
    FROM capacity_rules cr
    WHERE cr.service_type = il.service_type
    AND cr.active = TRUE) as active_rules
FROM inventory_levels il
LEFT JOIN overbooking_limits ol 
    ON ol.service_type = il.service_type
    AND ol.season_type = CASE
        WHEN MONTH(il.service_date) IN (6,7,8) THEN 'PEAK'
        WHEN MONTH(il.service_date) IN (12,1) THEN 'HOLIDAY'
        ELSE 'REGULAR'
    END;

DELIMITER ;
