USE luxury_travel;

DELIMITER //

-- Real-time Market Analysis Framework
-- ================================

-- Market Indicators
CREATE TABLE IF NOT EXISTS market_indicators (
    indicator_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    indicator_type VARCHAR(50),
    service_type VARCHAR(50),
    current_value DECIMAL(10,2),
    historical_values JSON,
    trend_direction ENUM('UP', 'DOWN', 'STABLE'),
    confidence_score DECIMAL(5,4),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_indicator (indicator_type, service_type)
);

-- Predictive Models
CREATE TABLE IF NOT EXISTS predictive_models (
    model_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    model_name VARCHAR(100),
    algorithm_type VARCHAR(50),
    parameters JSON,
    training_metrics JSON,
    last_updated TIMESTAMP,
    active BOOLEAN DEFAULT TRUE,
    INDEX idx_active (active)
);

-- Market Sentiment
CREATE TABLE IF NOT EXISTS market_sentiment (
    sentiment_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    sentiment_score DECIMAL(5,4),
    factors JSON,
    analysis_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_service_date (service_type, analysis_date)
);

-- Predictive Analysis Functions
-- =========================

-- Calculate Market Sentiment
CREATE PROCEDURE calculate_market_sentiment(
    IN p_service_type VARCHAR(50)
)
BEGIN
    INSERT INTO market_sentiment (
        service_type,
        sentiment_score,
        factors
    )
    WITH sentiment_factors AS (
        -- Booking Trends
        SELECT 
            COUNT(*) as booking_count,
            AVG(total_amount) as avg_booking_value,
            COUNT(DISTINCT user_id) / COUNT(*) as user_diversity,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) / COUNT(*) as cancellation_rate
        FROM (
            SELECT * FROM train_bookings
            UNION ALL
            SELECT * FROM cruise_bookings
            UNION ALL
            SELECT * FROM car_rentals
        ) all_bookings
        WHERE service_type = p_service_type
        AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ),
    -- Price Trends
    price_trends AS (
        SELECT 
            AVG(final_price) as avg_price,
            STDDEV(final_price) as price_volatility,
            (MAX(final_price) - MIN(final_price)) / MIN(final_price) as price_range
        FROM price_history
        WHERE service_type = p_service_type
        AND timestamp >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ),
    -- Competitor Analysis
    competitor_stats AS (
        SELECT 
            AVG(price) as competitor_avg_price,
            COUNT(DISTINCT competitor_name) as competitor_count
        FROM competitor_pricing
        WHERE service_type = p_service_type
        AND last_updated >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    )
    SELECT 
        p_service_type,
        -- Calculate sentiment score (0-1)
        (
            -- Booking health (40%)
            (CASE 
                WHEN s.booking_count > 100 THEN 0.4
                ELSE s.booking_count / 250
            END) * 0.4 +
            -- Price stability (30%)
            (1 - LEAST(p.price_volatility / p.avg_price, 1)) * 0.3 +
            -- Market position (30%)
            (CASE 
                WHEN p.avg_price <= c.competitor_avg_price THEN 0.3
                ELSE 0.3 * (c.competitor_avg_price / p.avg_price)
            END)
        ),
        -- Record contributing factors
        JSON_OBJECT(
            'booking_metrics', JSON_OBJECT(
                'daily_bookings', s.booking_count / 7,
                'avg_value', s.avg_booking_value,
                'user_diversity', s.user_diversity,
                'cancellation_rate', s.cancellation_rate
            ),
            'price_metrics', JSON_OBJECT(
                'avg_price', p.avg_price,
                'volatility', p.price_volatility,
                'price_range', p.price_range
            ),
            'market_metrics', JSON_OBJECT(
                'competitor_avg', c.competitor_avg_price,
                'competitor_count', c.competitor_count,
                'price_position', p.avg_price / c.competitor_avg_price
            )
        )
    FROM sentiment_factors s
    CROSS JOIN price_trends p
    CROSS JOIN competitor_stats c;
END //

-- Predict Future Demand
CREATE PROCEDURE predict_demand(
    IN p_service_type VARCHAR(50),
    IN p_future_date DATE,
    OUT p_predicted_demand DECIMAL(10,2)
)
BEGIN
    DECLARE v_historical_demand DECIMAL(10,2);
    DECLARE v_seasonal_factor DECIMAL(10,2);
    DECLARE v_market_sentiment DECIMAL(5,4);
    DECLARE v_price_elasticity DECIMAL(5,4);
    
    -- Get historical demand
    SELECT AVG(daily_bookings) INTO v_historical_demand
    FROM (
        SELECT 
            DATE(created_at) as booking_date,
            COUNT(*) as daily_bookings
        FROM (
            SELECT * FROM train_bookings
            UNION ALL
            SELECT * FROM cruise_bookings
            UNION ALL
            SELECT * FROM car_rentals
        ) all_bookings
        WHERE service_type = p_service_type
        AND created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)
        GROUP BY DATE(created_at)
    ) historical_data;
    
    -- Get seasonal factor
    SET v_seasonal_factor = calculate_seasonal_factor(p_service_type, p_future_date);
    
    -- Get market sentiment
    SELECT sentiment_score INTO v_market_sentiment
    FROM market_sentiment
    WHERE service_type = p_service_type
    AND analysis_date >= DATE_SUB(NOW(), INTERVAL 1 DAY)
    ORDER BY analysis_date DESC
    LIMIT 1;
    
    -- Get price elasticity
    SELECT AVG(price_elasticity) INTO v_price_elasticity
    FROM advanced_segments
    WHERE parent_segment_id IN (
        SELECT segment_id 
        FROM market_segments 
        WHERE JSON_CONTAINS(preferred_services, JSON_ARRAY(p_service_type))
    );
    
    -- Calculate predicted demand
    SET p_predicted_demand = v_historical_demand * 
        v_seasonal_factor * 
        (1 + v_market_sentiment) * 
        (1 - v_price_elasticity);
        
    -- Record prediction
    INSERT INTO predictive_models (
        model_name,
        algorithm_type,
        parameters,
        training_metrics
    ) VALUES (
        'DEMAND_PREDICTOR',
        'ENSEMBLE',
        JSON_OBJECT(
            'historical_demand', v_historical_demand,
            'seasonal_factor', v_seasonal_factor,
            'market_sentiment', v_market_sentiment,
            'price_elasticity', v_price_elasticity
        ),
        JSON_OBJECT(
            'predicted_demand', p_predicted_demand,
            'confidence_score', 0.8,
            'prediction_date', p_future_date
        )
    );
END //

-- Market Analysis Dashboard
CREATE OR REPLACE VIEW market_analysis_dashboard AS
SELECT 
    service_type,
    -- Current market state
    (SELECT sentiment_score 
     FROM market_sentiment ms 
     WHERE ms.service_type = m.service_type
     ORDER BY analysis_date DESC LIMIT 1) as current_sentiment,
    -- Price positioning
    JSON_OBJECT(
        'avg_price', AVG(ph.final_price),
        'min_price', MIN(ph.final_price),
        'max_price', MAX(ph.final_price),
        'competitor_avg', (
            SELECT AVG(price)
            FROM competitor_pricing
            WHERE service_type = m.service_type
        )
    ) as price_metrics,
    -- Demand indicators
    JSON_OBJECT(
        'current_demand', COUNT(DISTINCT b.booking_id),
        'conversion_rate', COUNT(DISTINCT b.booking_id) / COUNT(DISTINCT ph.history_id),
        'avg_booking_value', AVG(b.total_amount)
    ) as demand_metrics,
    -- Market trends
    JSON_OBJECT(
        'price_trend', (
            SELECT trend_direction
            FROM market_indicators
            WHERE indicator_type = 'PRICE'
            AND service_type = m.service_type
            ORDER BY updated_at DESC LIMIT 1
        ),
        'demand_trend', (
            SELECT trend_direction
            FROM market_indicators
            WHERE indicator_type = 'DEMAND'
            AND service_type = m.service_type
            ORDER BY updated_at DESC LIMIT 1
        )
    ) as market_trends
FROM market_segments m
CROSS JOIN price_history ph
LEFT JOIN (
    SELECT * FROM train_bookings
    UNION ALL
    SELECT * FROM cruise_bookings
    UNION ALL
    SELECT * FROM car_rentals
) b ON b.service_type = ph.service_type 
    AND b.service_id = ph.service_id
WHERE ph.timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY service_type;

DELIMITER ;
