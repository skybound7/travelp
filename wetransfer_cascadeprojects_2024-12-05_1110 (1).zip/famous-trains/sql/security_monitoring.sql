USE luxury_travel;

DELIMITER //

-- Security Monitoring System
-- =======================

-- User Activity Tracking
CREATE TABLE IF NOT EXISTS user_activity_logs (
    log_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    session_id VARCHAR(64),
    action_type VARCHAR(50),
    ip_address VARCHAR(45),
    user_agent TEXT,
    request_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_action_type (action_type),
    INDEX idx_created_at (created_at)
);

-- Failed Login Attempts
CREATE TABLE IF NOT EXISTS failed_login_attempts (
    attempt_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(255),
    ip_address VARCHAR(45),
    attempt_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    user_agent TEXT,
    INDEX idx_username (username),
    INDEX idx_ip_address (ip_address),
    INDEX idx_attempt_time (attempt_time)
);

-- Security Procedures
-- ================

-- Monitor Suspicious Activity
CREATE PROCEDURE monitor_suspicious_activity()
BEGIN
    -- Check for multiple failed logins
    SELECT 
        username,
        ip_address,
        COUNT(*) as attempt_count
    FROM failed_login_attempts
    WHERE attempt_time >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
    GROUP BY username, ip_address
    HAVING COUNT(*) >= 5;
    
    -- Check for unusual access patterns
    SELECT 
        user_id,
        ip_address,
        COUNT(*) as access_count,
        COUNT(DISTINCT session_id) as session_count
    FROM user_activity_logs
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
    GROUP BY user_id, ip_address
    HAVING COUNT(*) > 100 OR COUNT(DISTINCT session_id) > 5;
    
    -- Monitor sensitive data access
    SELECT 
        user_id,
        action_type,
        COUNT(*) as access_count
    FROM user_activity_logs
    WHERE action_type IN ('VIEW_PAYMENT', 'EDIT_USER', 'ACCESS_ADMIN')
    AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
    GROUP BY user_id, action_type
    HAVING COUNT(*) > 20;
END //

-- Security Alert System
CREATE PROCEDURE create_security_alert(
    IN p_alert_type VARCHAR(50),
    IN p_severity VARCHAR(20),
    IN p_details JSON
)
BEGIN
    INSERT INTO security_alerts (
        alert_type,
        severity,
        details,
        status
    ) VALUES (
        p_alert_type,
        p_severity,
        p_details,
        'NEW'
    );
END //

-- User Session Management
CREATE PROCEDURE track_user_session(
    IN p_user_id INT,
    IN p_session_id VARCHAR(64),
    IN p_action VARCHAR(50),
    IN p_ip_address VARCHAR(45),
    IN p_user_agent TEXT,
    IN p_request_data JSON
)
BEGIN
    INSERT INTO user_activity_logs (
        user_id,
        session_id,
        action_type,
        ip_address,
        user_agent,
        request_data
    ) VALUES (
        p_user_id,
        p_session_id,
        p_action,
        p_ip_address,
        p_user_agent,
        p_request_data
    );
END //

-- Required Tables
-- ============

CREATE TABLE IF NOT EXISTS security_alerts (
    alert_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    alert_type VARCHAR(50),
    severity VARCHAR(20),
    details JSON,
    status VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_alert_type (alert_type),
    INDEX idx_status (status),
    INDEX idx_severity (severity)
);

-- Security Monitoring Views
-- =====================

-- Active Sessions Monitor
CREATE OR REPLACE VIEW active_sessions_monitor AS
SELECT 
    user_id,
    session_id,
    ip_address,
    MIN(created_at) as session_start,
    MAX(created_at) as last_activity,
    COUNT(*) as activity_count,
    GROUP_CONCAT(DISTINCT action_type) as actions_performed
FROM user_activity_logs
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
GROUP BY user_id, session_id, ip_address
HAVING TIMESTAMPDIFF(MINUTE, MAX(created_at), NOW()) <= 30;

-- Security Metrics Dashboard
CREATE OR REPLACE VIEW security_metrics_dashboard AS
SELECT 
    DATE(created_at) as metric_date,
    COUNT(DISTINCT user_id) as active_users,
    COUNT(DISTINCT session_id) as total_sessions,
    COUNT(DISTINCT ip_address) as unique_ips,
    COUNT(CASE WHEN action_type IN ('LOGIN_FAILED', 'INVALID_TOKEN') THEN 1 END) as security_violations,
    COUNT(CASE WHEN action_type = 'ACCESS_ADMIN' THEN 1 END) as admin_accesses
FROM user_activity_logs
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY DATE(created_at);

-- Scheduled Security Tasks
-- ====================

-- Hourly Security Check
CREATE EVENT IF NOT EXISTS hourly_security_check
ON SCHEDULE EVERY 1 HOUR
DO
BEGIN
    -- Monitor suspicious activity
    CALL monitor_suspicious_activity();
    
    -- Clean up old failed login attempts
    DELETE FROM failed_login_attempts 
    WHERE attempt_time < DATE_SUB(NOW(), INTERVAL 24 HOUR);
    
    -- Archive old activity logs
    INSERT INTO archived_activity_logs
    SELECT * FROM user_activity_logs
    WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
    
    DELETE FROM user_activity_logs
    WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
END //

DELIMITER ;
