USE luxury_travel;

DELIMITER //

-- Advanced Pricing Framework
-- =======================

-- Market Segments
CREATE TABLE IF NOT EXISTS market_segments (
    segment_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    segment_name VARCHAR(100),
    characteristics JSON,
    price_sensitivity DECIMAL(3,2),
    lifetime_value DECIMAL(10,2),
    preferred_services JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_sensitivity (price_sensitivity)
);

-- Competitor Pricing
CREATE TABLE IF NOT EXISTS competitor_pricing (
    competitor_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    competitor_name VARCHAR(100),
    service_type VARCHAR(50),
    route_or_service VARCHAR(100),
    price DECIMAL(10,2),
    features JSON,
    last_updated TIMESTAMP,
    INDEX idx_service (service_type, route_or_service)
);

-- Revenue Optimization Models
CREATE TABLE IF NOT EXISTS revenue_models (
    model_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    model_name VARCHAR(100),
    service_type VARCHAR(50),
    parameters JSON,
    performance_metrics JSON,
    active BOOLEAN DEFAULT TRUE,
    last_updated TIMESTAMP,
    INDEX idx_service_active (service_type, active)
);

-- Advanced Pricing Functions
-- =======================

-- Calculate Price Elasticity by Segment
CREATE FUNCTION calculate_segment_elasticity(
    p_segment_id BIGINT,
    p_service_type VARCHAR(50),
    p_date_range INT
) RETURNS DECIMAL(10,4)
DETERMINISTIC
BEGIN
    DECLARE v_elasticity DECIMAL(10,4);
    DECLARE v_avg_price_change DECIMAL(10,4);
    DECLARE v_avg_demand_change DECIMAL(10,4);
    
    SELECT 
        -- Price elasticity = % change in demand / % change in price
        ABS(
            (MAX(demand_change) - MIN(demand_change)) / AVG(demand_change)
        ) / NULLIF(
            (MAX(price_change) - MIN(price_change)) / AVG(price_change),
            0
        ) INTO v_elasticity
    FROM (
        SELECT 
            DATE(ph.timestamp) as price_date,
            AVG(ph.final_price) as price,
            LAG(AVG(ph.final_price)) OVER (ORDER BY DATE(ph.timestamp)) as prev_price,
            COUNT(DISTINCT b.booking_id) as demand,
            LAG(COUNT(DISTINCT b.booking_id)) OVER (ORDER BY DATE(ph.timestamp)) as prev_demand,
            -- Calculate changes
            (AVG(ph.final_price) - LAG(AVG(ph.final_price)) OVER (ORDER BY DATE(ph.timestamp))) /
                NULLIF(LAG(AVG(ph.final_price)) OVER (ORDER BY DATE(ph.timestamp)), 0) as price_change,
            (COUNT(DISTINCT b.booking_id) - LAG(COUNT(DISTINCT b.booking_id)) OVER (ORDER BY DATE(ph.timestamp))) /
                NULLIF(LAG(COUNT(DISTINCT b.booking_id)) OVER (ORDER BY DATE(ph.timestamp)), 0) as demand_change
        FROM price_history ph
        LEFT JOIN (
            SELECT * FROM train_bookings
            UNION ALL
            SELECT * FROM cruise_bookings
            UNION ALL
            SELECT * FROM car_rentals
        ) b ON b.service_type = ph.service_type 
            AND b.service_id = ph.service_id
            AND DATE(b.created_at) = DATE(ph.timestamp)
        WHERE ph.timestamp >= DATE_SUB(NOW(), INTERVAL p_date_range DAY)
        AND ph.service_type = p_service_type
        GROUP BY DATE(ph.timestamp)
    ) price_demand_changes
    WHERE price_change IS NOT NULL 
    AND demand_change IS NOT NULL;
    
    RETURN COALESCE(v_elasticity, 0);
END //

-- Optimize Price for Maximum Revenue
CREATE PROCEDURE optimize_price_for_revenue(
    IN p_service_type VARCHAR(50),
    IN p_service_id BIGINT,
    IN p_travel_date DATE,
    OUT p_optimal_price DECIMAL(10,2)
)
BEGIN
    DECLARE v_base_price DECIMAL(10,2);
    DECLARE v_elasticity DECIMAL(10,4);
    DECLARE v_competitor_avg_price DECIMAL(10,2);
    DECLARE v_segment_factor DECIMAL(10,2);
    DECLARE v_optimal_markup DECIMAL(10,2);
    
    -- Get base price
    SELECT AVG(base_price) INTO v_base_price
    FROM price_history
    WHERE service_type = p_service_type
    AND service_id = p_service_id
    AND timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY);
    
    -- Get price elasticity
    SELECT AVG(calculate_segment_elasticity(segment_id, p_service_type, 30))
    INTO v_elasticity
    FROM market_segments;
    
    -- Get competitor average price
    SELECT AVG(price) INTO v_competitor_avg_price
    FROM competitor_pricing
    WHERE service_type = p_service_type
    AND last_updated >= DATE_SUB(NOW(), INTERVAL 7 DAY);
    
    -- Calculate optimal markup based on elasticity
    -- Using optimal markup formula: (1/|elasticity|)
    SET v_optimal_markup = 1 / NULLIF(ABS(v_elasticity), 0);
    
    -- Calculate optimal price
    SET p_optimal_price = v_base_price * (1 + LEAST(v_optimal_markup, 0.5));
    
    -- Adjust based on competitor pricing
    IF v_competitor_avg_price IS NOT NULL THEN
        SET p_optimal_price = LEAST(
            p_optimal_price,
            v_competitor_avg_price * 1.1  -- Max 10% above competitor
        );
    END IF;
    
    -- Record optimization result
    INSERT INTO revenue_models (
        model_name,
        service_type,
        parameters,
        performance_metrics
    ) VALUES (
        'REVENUE_OPTIMIZATION',
        p_service_type,
        JSON_OBJECT(
            'base_price', v_base_price,
            'elasticity', v_elasticity,
            'competitor_avg', v_competitor_avg_price,
            'optimal_markup', v_optimal_markup
        ),
        JSON_OBJECT(
            'optimal_price', p_optimal_price,
            'price_change_pct', (p_optimal_price - v_base_price) / v_base_price * 100
        )
    );
END //

-- Advanced Market Analysis
CREATE PROCEDURE analyze_market_conditions(
    IN p_service_type VARCHAR(50)
)
BEGIN
    -- Analyze market segments
    WITH segment_analysis AS (
        SELECT 
            ms.segment_id,
            ms.segment_name,
            ms.price_sensitivity,
            COUNT(DISTINCT b.booking_id) as total_bookings,
            AVG(b.total_amount) as avg_booking_value,
            -- Segment performance metrics
            JSON_OBJECT(
                'conversion_rate', COUNT(DISTINCT b.booking_id) / COUNT(DISTINCT ph.history_id),
                'avg_discount', AVG((ph.base_price - ph.final_price) / ph.base_price * 100),
                'revenue_share', SUM(b.total_amount) / SUM(SUM(b.total_amount)) OVER ()
            ) as performance_metrics
        FROM market_segments ms
        CROSS JOIN price_history ph
        LEFT JOIN (
            SELECT * FROM train_bookings
            UNION ALL
            SELECT * FROM cruise_bookings
            UNION ALL
            SELECT * FROM car_rentals
        ) b ON b.service_type = ph.service_type 
            AND b.service_id = ph.service_id
            AND DATE(b.created_at) = DATE(ph.timestamp)
        WHERE ph.service_type = p_service_type
        AND ph.timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY ms.segment_id, ms.segment_name, ms.price_sensitivity
    )
    
    -- Generate market insights
    SELECT 
        segment_name,
        total_bookings,
        avg_booking_value,
        performance_metrics,
        -- Pricing recommendations
        CASE 
            WHEN price_sensitivity > 0.8 THEN 'Price sensitive - Consider discounts'
            WHEN price_sensitivity < 0.3 THEN 'Premium segment - Opportunity for premium pricing'
            ELSE 'Balanced pricing recommended'
        END as pricing_strategy,
        -- Revenue optimization opportunities
        CASE 
            WHEN JSON_EXTRACT(performance_metrics, '$.conversion_rate') < 0.2 
            THEN 'Low conversion - Review pricing strategy'
            WHEN JSON_EXTRACT(performance_metrics, '$.revenue_share') > 0.3 
            THEN 'Key segment - Protect market share'
            ELSE 'Standard optimization'
        END as optimization_recommendation
    FROM segment_analysis
    ORDER BY total_bookings DESC;
END //

-- Initialize Market Segments
INSERT IGNORE INTO market_segments 
(segment_name, characteristics, price_sensitivity, lifetime_value, preferred_services) VALUES 
('Luxury Travelers', 
 '{"income_level": "high", "travel_frequency": "frequent", "preference": "premium"}',
 0.2, 5000.00, '["CRUISE", "FIRST_CLASS_TRAIN"]'),
('Business Travelers',
 '{"income_level": "high", "travel_frequency": "very_frequent", "preference": "convenience"}',
 0.4, 3000.00, '["TRAIN", "CAR_RENTAL"]'),
('Budget Conscious',
 '{"income_level": "medium", "travel_frequency": "moderate", "preference": "value"}',
 0.8, 1000.00, '["ECONOMY_TRAIN", "SHARED_TRANSFER"]'),
('Family Travelers',
 '{"income_level": "medium", "travel_frequency": "seasonal", "preference": "comfort"}',
 0.6, 2000.00, '["CRUISE", "FAMILY_CARS"]');

-- Initialize Competitor Data
INSERT IGNORE INTO competitor_pricing 
(competitor_name, service_type, route_or_service, price, features, last_updated) VALUES 
('CompetitorA', 'TRAIN', 'London-Paris', 
 200.00, '{"class": "first", "wifi": true, "meals": true}', NOW()),
('CompetitorB', 'CRUISE', 'Mediterranean',
 1500.00, '{"duration": "7days", "cabin": "balcony", "all_inclusive": true}', NOW()),
('CompetitorC', 'CAR', 'Luxury Sedan',
 100.00, '{"model": "Mercedes", "insurance": true, "unlimited_miles": true}', NOW());

DELIMITER ;
