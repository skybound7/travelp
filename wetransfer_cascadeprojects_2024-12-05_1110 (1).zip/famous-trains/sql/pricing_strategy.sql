USE luxury_travel;

DELIMITER //

-- Dynamic Pricing Framework
-- =======================

-- Price Factors
CREATE TABLE IF NOT EXISTS price_factors (
    factor_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    factor_name VARCHAR(100),
    factor_type ENUM('SEASONAL', 'DEMAND', 'COMPETITION', 'INVENTORY', 'CUSTOMER'),
    weight DECIMAL(3,2),
    active BOOLEAN DEFAULT TRUE,
    configuration JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_factor_type (factor_type)
);

-- Price Rules
CREATE TABLE IF NOT EXISTS pricing_rules (
    rule_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    rule_name VARCHAR(100),
    conditions JSON,
    adjustment_type ENUM('PERCENTAGE', 'FIXED_AMOUNT'),
    adjustment_value DECIMAL(10,2),
    priority INT,
    start_date DATE,
    end_date DATE,
    active BOOLEAN DEFAULT TRUE,
    INDEX idx_service_dates (service_type, start_date, end_date)
);

-- Historical Pricing
CREATE TABLE IF NOT EXISTS price_history (
    history_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    service_id BIGINT,
    base_price DECIMAL(10,2),
    final_price DECIMAL(10,2),
    factors_applied JSON,
    rules_applied JSON,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_service (service_type, service_id)
);

-- Dynamic Pricing Functions
-- ======================

-- Calculate Seasonal Factor
CREATE FUNCTION calculate_seasonal_factor(
    p_service_type VARCHAR(50),
    p_date DATE
) RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    DECLARE v_factor DECIMAL(10,2);
    
    -- Base seasonal calculations
    SET v_factor = CASE
        -- Peak season (summer months)
        WHEN MONTH(p_date) BETWEEN 6 AND 8 THEN 1.3
        -- Shoulder season (spring/fall)
        WHEN MONTH(p_date) IN (4,5,9,10) THEN 1.1
        -- Holiday season
        WHEN MONTH(p_date) = 12 THEN 1.25
        -- Low season
        ELSE 0.9
    END;
    
    -- Additional holiday adjustments
    IF DAYOFWEEK(p_date) IN (1,7) THEN -- Weekends
        SET v_factor = v_factor * 1.1;
    END IF;
    
    RETURN v_factor;
END //

-- Calculate Demand Factor
CREATE FUNCTION calculate_demand_factor(
    p_service_type VARCHAR(50),
    p_service_id BIGINT,
    p_date DATE
) RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    DECLARE v_factor DECIMAL(10,2);
    DECLARE v_bookings INT;
    DECLARE v_capacity INT;
    
    -- Get recent bookings
    SELECT COUNT(*) INTO v_bookings
    FROM (
        SELECT * FROM train_bookings
        UNION ALL
        SELECT * FROM cruise_bookings
        UNION ALL
        SELECT * FROM car_rentals
    ) all_bookings
    WHERE service_type = p_service_type
    AND service_id = p_service_id
    AND DATE(travel_date) = p_date;
    
    -- Simulate capacity (replace with actual capacity logic)
    SET v_capacity = 100;
    
    -- Calculate demand factor
    SET v_factor = CASE
        WHEN v_bookings >= v_capacity * 0.9 THEN 1.5  -- Near full
        WHEN v_bookings >= v_capacity * 0.7 THEN 1.3  -- High demand
        WHEN v_bookings >= v_capacity * 0.5 THEN 1.1  -- Medium demand
        WHEN v_bookings <= v_capacity * 0.3 THEN 0.9  -- Low demand
        ELSE 1.0
    END;
    
    RETURN v_factor;
END //

-- Calculate Dynamic Price
CREATE PROCEDURE calculate_dynamic_price(
    IN p_service_type VARCHAR(50),
    IN p_service_id BIGINT,
    IN p_base_price DECIMAL(10,2),
    IN p_travel_date DATE,
    OUT p_final_price DECIMAL(10,2)
)
BEGIN
    DECLARE v_seasonal_factor DECIMAL(10,2);
    DECLARE v_demand_factor DECIMAL(10,2);
    DECLARE v_factors_applied JSON;
    DECLARE v_rules_applied JSON;
    
    -- Calculate basic factors
    SET v_seasonal_factor = calculate_seasonal_factor(p_service_type, p_travel_date);
    SET v_demand_factor = calculate_demand_factor(p_service_type, p_service_id, p_travel_date);
    
    -- Initialize price
    SET p_final_price = p_base_price;
    
    -- Apply factors
    SET p_final_price = p_final_price * v_seasonal_factor * v_demand_factor;
    
    -- Store factors applied
    SET v_factors_applied = JSON_OBJECT(
        'seasonal_factor', v_seasonal_factor,
        'demand_factor', v_demand_factor
    );
    
    -- Apply pricing rules
    SET v_rules_applied = JSON_ARRAY();
    
    -- Apply active rules
    UPDATE v_rules_applied
    SET v_rules_applied = JSON_ARRAY_APPEND(
        v_rules_applied,
        '$',
        JSON_OBJECT(
            'rule_id', rule_id,
            'adjustment', CASE 
                WHEN adjustment_type = 'PERCENTAGE' 
                THEN p_final_price * (adjustment_value/100)
                ELSE adjustment_value
            END
        )
    )
    FROM pricing_rules
    WHERE service_type = p_service_type
    AND p_travel_date BETWEEN start_date AND end_date
    AND active = TRUE
    ORDER BY priority;
    
    -- Record price history
    INSERT INTO price_history (
        service_type,
        service_id,
        base_price,
        final_price,
        factors_applied,
        rules_applied
    ) VALUES (
        p_service_type,
        p_service_id,
        p_base_price,
        p_final_price,
        v_factors_applied,
        v_rules_applied
    );
END //

-- Price Optimization
-- ===============

-- Analyze Price Performance
CREATE PROCEDURE analyze_price_performance(
    IN p_service_type VARCHAR(50),
    IN p_date_range INT -- days to analyze
)
BEGIN
    WITH price_performance AS (
        SELECT 
            service_type,
            service_id,
            DATE(timestamp) as price_date,
            AVG(base_price) as avg_base_price,
            AVG(final_price) as avg_final_price,
            COUNT(*) as price_changes,
            -- Calculate conversion rate (bookings/price changes)
            (SELECT COUNT(*)
             FROM (
                SELECT * FROM train_bookings
                UNION ALL
                SELECT * FROM cruise_bookings
                UNION ALL
                SELECT * FROM car_rentals
             ) bookings
             WHERE bookings.service_type = price_history.service_type
             AND bookings.service_id = price_history.service_id
             AND DATE(bookings.created_at) = DATE(price_history.timestamp)
            ) / COUNT(*) as conversion_rate
        FROM price_history
        WHERE timestamp >= DATE_SUB(NOW(), INTERVAL p_date_range DAY)
        AND service_type = p_service_type
        GROUP BY service_type, service_id, DATE(timestamp)
    )
    
    -- Generate price optimization recommendations
    SELECT 
        service_type,
        service_id,
        AVG(avg_base_price) as typical_base_price,
        AVG(avg_final_price) as typical_final_price,
        AVG(conversion_rate) as avg_conversion_rate,
        -- Price elasticity
        (MAX(conversion_rate) - MIN(conversion_rate)) / 
        (MAX(avg_final_price) - MIN(avg_final_price)) as price_elasticity,
        -- Optimal price point
        AVG(CASE 
            WHEN conversion_rate > AVG(conversion_rate) OVER ()
            THEN avg_final_price 
        END) as optimal_price_point,
        -- Recommendations
        CASE 
            WHEN AVG(conversion_rate) < 0.1 THEN 'Consider price reduction'
            WHEN AVG(conversion_rate) > 0.8 THEN 'Opportunity for price increase'
            ELSE 'Price point optimal'
        END as recommendation
    FROM price_performance
    GROUP BY service_type, service_id;
END //

-- Initialize Price Factors
INSERT IGNORE INTO price_factors 
(factor_name, factor_type, weight, configuration) VALUES 
('Peak Season', 'SEASONAL', 0.30, '{"months": [6,7,8], "multiplier": 1.3}'),
('Weekend Premium', 'SEASONAL', 0.20, '{"days": [6,7], "multiplier": 1.1}'),
('High Demand', 'DEMAND', 0.25, '{"threshold": 0.8, "multiplier": 1.3}'),
('Loyalty Discount', 'CUSTOMER', 0.15, '{"min_bookings": 5, "discount": 0.1}'),
('Competitor Price', 'COMPETITION', 0.10, '{"max_difference": 0.15}');

-- Initialize Pricing Rules
INSERT IGNORE INTO pricing_rules 
(service_type, rule_name, conditions, adjustment_type, adjustment_value, priority, start_date, end_date) VALUES 
('TRAIN', 'Early Bird Discount', 
 '{"days_before": 30}', 'PERCENTAGE', -10, 1, 
 CURRENT_DATE, DATE_ADD(CURRENT_DATE, INTERVAL 1 YEAR)),
('CRUISE', 'Last Minute Deal', 
 '{"days_before": 7}', 'PERCENTAGE', -15, 2,
 CURRENT_DATE, DATE_ADD(CURRENT_DATE, INTERVAL 1 YEAR)),
('CAR', 'Weekend Special', 
 '{"days": [6,7]}', 'PERCENTAGE', 15, 3,
 CURRENT_DATE, DATE_ADD(CURRENT_DATE, INTERVAL 1 YEAR));

DELIMITER ;
