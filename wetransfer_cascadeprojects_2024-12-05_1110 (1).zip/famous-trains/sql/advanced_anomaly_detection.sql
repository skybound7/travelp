USE luxury_travel;

DELIMITER //

-- Advanced Anomaly Detection System
-- ==============================

-- User Behavior Profiles
CREATE TABLE IF NOT EXISTS user_behavior_profiles (
    profile_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    login_times JSON,
    usual_locations JSON,
    device_fingerprints JSON,
    transaction_patterns JSON,
    access_patterns JSON,
    last_updated TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id)
);

-- Anomaly Scores
CREATE TABLE IF NOT EXISTS anomaly_scores (
    score_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    session_id VARCHAR(64),
    score_type VARCHAR(50),
    score_value DECIMAL(5,2),
    contributing_factors JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_session (user_id, session_id),
    INDEX idx_score_type (score_type)
);

-- Machine Learning Features
CREATE TABLE IF NOT EXISTS ml_features (
    feature_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    feature_type VARCHAR(50),
    feature_name VARCHAR(100),
    feature_value JSON,
    training_data BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_feature_type (feature_type)
);

-- Advanced Detection Procedures
-- =========================

-- Build User Behavior Profile
CREATE PROCEDURE build_user_profile(IN p_user_id INT)
BEGIN
    -- Analyze login patterns
    WITH login_patterns AS (
        SELECT 
            HOUR(created_at) as login_hour,
            DAYOFWEEK(created_at) as login_day,
            ip_address,
            COUNT(*) as frequency
        FROM user_activity_logs
        WHERE user_id = p_user_id
        AND action_type = 'LOGIN'
        AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY HOUR(created_at), DAYOFWEEK(created_at), ip_address
    )
    
    -- Update or insert profile
    INSERT INTO user_behavior_profiles (
        user_id,
        login_times,
        usual_locations,
        device_fingerprints,
        transaction_patterns,
        access_patterns,
        last_updated
    )
    SELECT 
        p_user_id,
        (SELECT JSON_ARRAYAGG(
            JSON_OBJECT(
                'hour', login_hour,
                'day', login_day,
                'frequency', frequency
            )
        ) FROM login_patterns),
        (SELECT JSON_ARRAYAGG(
            JSON_OBJECT(
                'ip', ip_address,
                'frequency', COUNT(*)
            )
        ) FROM user_activity_logs 
        WHERE user_id = p_user_id 
        GROUP BY ip_address),
        (SELECT JSON_ARRAYAGG(
            JSON_OBJECT(
                'user_agent', user_agent,
                'frequency', COUNT(*)
            )
        ) FROM user_activity_logs 
        WHERE user_id = p_user_id 
        GROUP BY user_agent),
        (SELECT JSON_OBJECT(
            'avg_amount', AVG(CAST(JSON_EXTRACT(request_data, '$.amount') AS DECIMAL)),
            'max_amount', MAX(CAST(JSON_EXTRACT(request_data, '$.amount') AS DECIMAL)),
            'usual_times', JSON_ARRAYAGG(HOUR(created_at))
        ) FROM user_activity_logs 
        WHERE user_id = p_user_id 
        AND action_type = 'PAYMENT'),
        (SELECT JSON_OBJECT(
            'frequent_actions', JSON_ARRAYAGG(action_type),
            'peak_hours', JSON_ARRAYAGG(HOUR(created_at))
        ) FROM user_activity_logs 
        WHERE user_id = p_user_id),
        NOW()
    ON DUPLICATE KEY UPDATE
        login_times = VALUES(login_times),
        usual_locations = VALUES(usual_locations),
        device_fingerprints = VALUES(device_fingerprints),
        transaction_patterns = VALUES(transaction_patterns),
        access_patterns = VALUES(access_patterns),
        last_updated = NOW();
END //

-- Calculate Anomaly Scores
CREATE PROCEDURE calculate_anomaly_scores(
    IN p_user_id INT,
    IN p_session_id VARCHAR(64)
)
BEGIN
    DECLARE v_profile_data JSON;
    DECLARE v_current_behavior JSON;
    
    -- Get user profile
    SELECT JSON_OBJECT(
        'login_times', login_times,
        'usual_locations', usual_locations,
        'device_fingerprints', device_fingerprints,
        'transaction_patterns', transaction_patterns,
        'access_patterns', access_patterns
    )
    INTO v_profile_data
    FROM user_behavior_profiles
    WHERE user_id = p_user_id;
    
    -- Get current session behavior
    SELECT JSON_OBJECT(
        'login_time', HOUR(MIN(created_at)),
        'login_day', DAYOFWEEK(MIN(created_at)),
        'ip_address', ip_address,
        'user_agent', user_agent,
        'actions', JSON_ARRAYAGG(action_type)
    )
    INTO v_current_behavior
    FROM user_activity_logs
    WHERE user_id = p_user_id
    AND session_id = p_session_id;
    
    -- Calculate and store scores
    INSERT INTO anomaly_scores (
        user_id,
        session_id,
        score_type,
        score_value,
        contributing_factors
    )
    SELECT 
        p_user_id,
        p_session_id,
        'BEHAVIORAL',
        -- Complex scoring logic based on multiple factors
        (
            CASE 
                WHEN JSON_CONTAINS(
                    JSON_EXTRACT(v_profile_data, '$.usual_locations'),
                    JSON_EXTRACT(v_current_behavior, '$.ip_address')
                ) THEN 0
                ELSE 0.5
            END +
            CASE 
                WHEN JSON_CONTAINS(
                    JSON_EXTRACT(v_profile_data, '$.device_fingerprints'),
                    JSON_EXTRACT(v_current_behavior, '$.user_agent')
                ) THEN 0
                ELSE 0.3
            END +
            CASE 
                WHEN JSON_CONTAINS(
                    JSON_EXTRACT(v_profile_data, '$.login_times'),
                    JSON_EXTRACT(v_current_behavior, '$.login_time')
                ) THEN 0
                ELSE 0.2
            END
        ),
        JSON_OBJECT(
            'location_match', JSON_CONTAINS(
                JSON_EXTRACT(v_profile_data, '$.usual_locations'),
                JSON_EXTRACT(v_current_behavior, '$.ip_address')
            ),
            'device_match', JSON_CONTAINS(
                JSON_EXTRACT(v_profile_data, '$.device_fingerprints'),
                JSON_EXTRACT(v_current_behavior, '$.user_agent')
            ),
            'time_match', JSON_CONTAINS(
                JSON_EXTRACT(v_profile_data, '$.login_times'),
                JSON_EXTRACT(v_current_behavior, '$.login_time')
            )
        );
END //

-- Security Dashboard Views
-- =====================

-- Real-time Security Dashboard
CREATE OR REPLACE VIEW security_dashboard AS
SELECT 
    CURRENT_TIMESTAMP as snapshot_time,
    -- Active Threats
    (SELECT COUNT(*) FROM threat_incidents 
     WHERE status IN ('NEW', 'INVESTIGATING')) as active_threats,
    -- Anomaly Statistics
    (SELECT COUNT(*) FROM anomaly_scores 
     WHERE score_value > 0.7 
     AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)) as high_risk_anomalies,
    -- Session Statistics
    (SELECT COUNT(DISTINCT session_id) FROM user_activity_logs 
     WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)) as active_sessions,
    -- Security Events
    (SELECT COUNT(*) FROM security_alerts 
     WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)) as recent_alerts;

-- Threat Intelligence Report
CREATE OR REPLACE VIEW threat_intelligence AS
SELECT 
    DATE(created_at) as report_date,
    threat_type,
    severity,
    COUNT(*) as incident_count,
    COUNT(CASE WHEN status = 'RESOLVED' THEN 1 END) as resolved_count,
    AVG(TIMESTAMPDIFF(MINUTE, created_at, 
        CASE WHEN resolved_at IS NOT NULL THEN resolved_at ELSE NOW() END)) as avg_resolution_time
FROM threat_incidents
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY DATE(created_at), threat_type, severity;

-- Scheduled Tasks
-- ============

-- Update User Profiles
CREATE EVENT IF NOT EXISTS daily_profile_update
ON SCHEDULE EVERY 1 DAY
DO
BEGIN
    DECLARE v_user_id INT;
    DECLARE v_done INT DEFAULT FALSE;
    DECLARE v_cur CURSOR FOR SELECT DISTINCT user_id FROM user_activity_logs;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;
    
    OPEN v_cur;
    
    read_loop: LOOP
        FETCH v_cur INTO v_user_id;
        IF v_done THEN
            LEAVE read_loop;
        END IF;
        
        CALL build_user_profile(v_user_id);
    END LOOP;
    
    CLOSE v_cur;
END //

DELIMITER ;
