USE luxury_travel;

DELIMITER //

-- Advanced Reporting Views
-- ======================

-- Customer Lifetime Value Analysis
CREATE OR REPLACE VIEW customer_lifetime_value AS
SELECT 
    u.user_id,
    CONCAT(u.first_name, ' ', u.last_name) AS customer_name,
    COUNT(DISTINCT b.booking_id) AS total_bookings,
    SUM(CASE WHEN b.status = 'completed' THEN b.total_amount ELSE 0 END) AS train_revenue,
    SUM(CASE WHEN cb.status = 'completed' THEN cb.total_amount ELSE 0 END) AS cruise_revenue,
    SUM(CASE WHEN cr.status = 'completed' THEN cr.total_amount ELSE 0 END) AS car_rental_revenue,
    SUM(CASE WHEN ip.status = 'active' THEN ip.premium_amount ELSE 0 END) AS insurance_revenue,
    (
        COALESCE(SUM(b.total_amount), 0) +
        COALESCE(SUM(cb.total_amount), 0) +
        COALESCE(SUM(cr.total_amount), 0) +
        COALESCE(SUM(ip.premium_amount), 0)
    ) AS total_revenue,
    MAX(b.booking_date) AS last_booking_date,
    AVG(r.rating) AS average_rating
FROM users u
LEFT JOIN bookings b ON u.user_id = b.user_id
LEFT JOIN cruise_bookings cb ON u.user_id = cb.user_id
LEFT JOIN car_rentals cr ON u.user_id = cr.user_id
LEFT JOIN insurance_policies ip ON u.user_id = ip.user_id
LEFT JOIN reviews r ON u.user_id = r.user_id
GROUP BY u.user_id;

-- Service Performance Analysis
CREATE OR REPLACE VIEW service_performance_analysis AS
SELECT 
    'Train' AS service_type,
    DATE_FORMAT(b.booking_date, '%Y-%m') AS month,
    COUNT(*) AS total_bookings,
    SUM(b.total_amount) AS revenue,
    COUNT(CASE WHEN b.status = 'cancelled' THEN 1 END) AS cancellations,
    AVG(r.rating) AS average_rating
FROM bookings b
LEFT JOIN reviews r ON b.booking_id = r.booking_id
GROUP BY DATE_FORMAT(b.booking_date, '%Y-%m')
UNION ALL
SELECT 
    'Cruise',
    DATE_FORMAT(cb.booking_date, '%Y-%m'),
    COUNT(*),
    SUM(cb.total_amount),
    COUNT(CASE WHEN cb.status = 'cancelled' THEN 1 END),
    AVG(r.rating)
FROM cruise_bookings cb
LEFT JOIN reviews r ON cb.booking_id = r.booking_id
GROUP BY DATE_FORMAT(cb.booking_date, '%Y-%m');

-- Security Audit View
CREATE OR REPLACE VIEW security_audit_summary AS
SELECT 
    audit_type,
    COUNT(*) AS occurrence_count,
    MIN(timestamp) AS first_occurrence,
    MAX(timestamp) AS last_occurrence
FROM security_audit_log
GROUP BY audit_type
ORDER BY occurrence_count DESC;

-- Additional Stored Procedures
-- ==========================

-- Data Archiving Procedure
CREATE PROCEDURE archive_old_data(IN p_months_old INT)
BEGIN
    DECLARE v_archive_date DATE;
    SET v_archive_date = DATE_SUB(CURRENT_DATE, INTERVAL p_months_old MONTH);
    
    START TRANSACTION;
    
    -- Archive old bookings
    INSERT INTO archived_bookings
    SELECT * FROM bookings
    WHERE booking_date < v_archive_date
    AND status IN ('completed', 'cancelled');
    
    DELETE FROM bookings
    WHERE booking_date < v_archive_date
    AND status IN ('completed', 'cancelled');
    
    -- Archive old reviews
    INSERT INTO archived_reviews
    SELECT * FROM reviews
    WHERE created_at < v_archive_date;
    
    DELETE FROM reviews
    WHERE created_at < v_archive_date;
    
    -- Archive audit logs
    INSERT INTO archived_audit_trail
    SELECT * FROM audit_trail
    WHERE changed_at < v_archive_date;
    
    DELETE FROM audit_trail
    WHERE changed_at < v_archive_date;
    
    COMMIT;
    
    -- Return archive summary
    SELECT 
        'Archive complete' AS status,
        ROW_COUNT() AS records_archived,
        v_archive_date AS archive_date;
END //

-- Security Features
-- ================

-- Create Security Audit Log
CREATE TABLE security_audit_log (
    audit_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    audit_type VARCHAR(50),
    action_type VARCHAR(50),
    ip_address VARCHAR(45),
    user_agent TEXT,
    details TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_type (audit_type),
    INDEX idx_timestamp (timestamp)
);

-- Security Audit Procedure
CREATE PROCEDURE log_security_event(
    IN p_user_id INT,
    IN p_audit_type VARCHAR(50),
    IN p_action_type VARCHAR(50),
    IN p_ip_address VARCHAR(45),
    IN p_user_agent TEXT,
    IN p_details TEXT
)
BEGIN
    INSERT INTO security_audit_log (
        user_id, audit_type, action_type,
        ip_address, user_agent, details
    ) VALUES (
        p_user_id, p_audit_type, p_action_type,
        p_ip_address, p_user_agent, p_details
    );
END //

-- Failed Login Attempt Tracking
CREATE TABLE login_attempts (
    attempt_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100),
    ip_address VARCHAR(45),
    attempt_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    success BOOLEAN,
    INDEX idx_username_ip (username, ip_address),
    INDEX idx_attempt_time (attempt_time)
);

-- Check Login Attempts Procedure
CREATE PROCEDURE check_login_attempts(
    IN p_username VARCHAR(100),
    IN p_ip_address VARCHAR(45)
)
BEGIN
    DECLARE v_attempt_count INT;
    
    -- Count failed attempts in last 30 minutes
    SELECT COUNT(*) INTO v_attempt_count
    FROM login_attempts
    WHERE username = p_username
    AND ip_address = p_ip_address
    AND success = FALSE
    AND attempt_time > DATE_SUB(NOW(), INTERVAL 30 MINUTE);
    
    IF v_attempt_count >= 5 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Account temporarily locked due to multiple failed attempts';
    END IF;
END //

-- Data Cleanup Procedures
-- =====================

-- Clean Expired Sessions
CREATE PROCEDURE cleanup_expired_sessions()
BEGIN
    DELETE FROM sessions 
    WHERE last_activity < DATE_SUB(NOW(), INTERVAL 24 HOUR);
END //

-- Clean Old Notifications
CREATE PROCEDURE cleanup_old_notifications()
BEGIN
    DELETE FROM notifications 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL 6 MONTH)
    AND is_read = TRUE;
END //

-- Database Maintenance Procedures
-- ============================

-- Optimize Tables
CREATE PROCEDURE optimize_database()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_table_name VARCHAR(255);
    DECLARE cur CURSOR FOR 
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = DATABASE();
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN cur;
    
    read_loop: LOOP
        FETCH cur INTO v_table_name;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        SET @sql = CONCAT('OPTIMIZE TABLE ', v_table_name);
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END LOOP;
    
    CLOSE cur;
END //

-- Create Archive Tables
-- ===================

CREATE TABLE archived_bookings LIKE bookings;
ALTER TABLE archived_bookings ADD archive_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

CREATE TABLE archived_reviews LIKE reviews;
ALTER TABLE archived_reviews ADD archive_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

CREATE TABLE archived_audit_trail LIKE audit_trail;
ALTER TABLE archived_audit_trail ADD archive_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

-- Monitoring Views
-- ==============

CREATE OR REPLACE VIEW system_health_check AS
SELECT 
    (SELECT COUNT(*) FROM security_audit_log 
     WHERE timestamp > DATE_SUB(NOW(), INTERVAL 1 HOUR)) AS recent_security_events,
    (SELECT COUNT(*) FROM login_attempts 
     WHERE success = FALSE 
     AND attempt_time > DATE_SUB(NOW(), INTERVAL 1 HOUR)) AS recent_failed_logins,
    (SELECT COUNT(*) FROM sessions 
     WHERE last_activity > DATE_SUB(NOW(), INTERVAL 1 HOUR)) AS active_sessions,
    (SELECT COUNT(*) FROM notifications 
     WHERE created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)) AS recent_notifications;

DELIMITER ;
