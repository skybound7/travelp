USE luxury_travel;

DELIMITER //

-- Notification Framework
-- ===================

-- Notification Templates
CREATE TABLE IF NOT EXISTS notification_templates (
    template_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    template_name VARCHAR(100),
    template_type VARCHAR(50),
    content_template JSON,
    variables JSON,
    channels JSON,
    active BOOLEAN DEFAULT TRUE,
    INDEX idx_type_active (template_type, active)
);

-- Notification Queue
CREATE TABLE IF NOT EXISTS notification_queue (
    queue_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT,
    template_id BIGINT,
    notification_data JSON,
    priority VARCHAR(20),
    status VARCHAR(20),
    scheduled_time TIMESTAMP,
    sent_time TIMESTAMP,
    INDEX idx_user_status (user_id, status)
);

-- Notification History
CREATE TABLE IF NOT EXISTS notification_history (
    history_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    queue_id BIGINT,
    delivery_status VARCHAR(20),
    delivery_time TIMESTAMP,
    channel VARCHAR(50),
    response JSON,
    INDEX idx_queue (queue_id)
);

-- Communication Functions
-- ===================

-- Queue Notification
CREATE PROCEDURE queue_notification(
    IN p_user_id BIGINT,
    IN p_template_name VARCHAR(100),
    IN p_notification_data JSON,
    IN p_priority VARCHAR(20),
    IN p_scheduled_time TIMESTAMP
)
BEGIN
    DECLARE v_template_id BIGINT;
    DECLARE v_content_template JSON;
    DECLARE v_variables JSON;
    
    -- Get template details
    SELECT 
        template_id,
        content_template,
        variables
    INTO 
        v_template_id,
        v_content_template,
        v_variables
    FROM notification_templates
    WHERE template_name = p_template_name
    AND active = TRUE;
    
    -- Queue notification
    INSERT INTO notification_queue (
        user_id,
        template_id,
        notification_data,
        priority,
        status,
        scheduled_time
    ) VALUES (
        p_user_id,
        v_template_id,
        JSON_MERGE_PATCH(
            p_notification_data,
            JSON_OBJECT(
                'template', v_content_template,
                'variables', v_variables
            )
        ),
        p_priority,
        'PENDING',
        COALESCE(p_scheduled_time, CURRENT_TIMESTAMP)
    );
END //

-- Process Notifications
CREATE PROCEDURE process_notifications()
BEGIN
    DECLARE v_queue_id BIGINT;
    DECLARE v_channels JSON;
    DECLARE v_notification_data JSON;
    
    -- Get pending notifications
    SELECT 
        nq.queue_id,
        nt.channels,
        nq.notification_data
    INTO 
        v_queue_id,
        v_channels,
        v_notification_data
    FROM notification_queue nq
    JOIN notification_templates nt ON nq.template_id = nt.template_id
    WHERE nq.status = 'PENDING'
    AND nq.scheduled_time <= CURRENT_TIMESTAMP
    ORDER BY 
        CASE nq.priority
            WHEN 'HIGH' THEN 1
            WHEN 'MEDIUM' THEN 2
            ELSE 3
        END,
        nq.scheduled_time
    LIMIT 1;
    
    -- Process notification
    IF v_queue_id IS NOT NULL THEN
        -- Update queue status
        UPDATE notification_queue
        SET 
            status = 'PROCESSING',
            sent_time = CURRENT_TIMESTAMP
        WHERE queue_id = v_queue_id;
        
        -- Record delivery attempts
        INSERT INTO notification_history (
            queue_id,
            delivery_status,
            delivery_time,
            channel,
            response
        )
        SELECT 
            v_queue_id,
            'ATTEMPTED',
            CURRENT_TIMESTAMP,
            JSON_UNQUOTE(channel_value),
            JSON_OBJECT(
                'attempt_number', 1,
                'notification_data', v_notification_data
            )
        FROM JSON_TABLE(
            v_channels,
            '$[*]' COLUMNS (
                channel_value VARCHAR(50) PATH '$'
            )
        ) channels;
        
        -- Update final status
        UPDATE notification_queue
        SET status = 'SENT'
        WHERE queue_id = v_queue_id;
    END IF;
END //

-- Initialize Templates
INSERT IGNORE INTO notification_templates 
(template_name, template_type, content_template, variables, channels) VALUES 
('BOOKING_CONFIRMATION',
 'TRANSACTIONAL',
 '{"subject": "Booking Confirmation: {booking_id}",
   "body": "Dear {customer_name},\n\nYour booking {booking_id} is confirmed.\n\nDetails: {booking_details}"}',
 '["booking_id", "customer_name", "booking_details"]',
 '["EMAIL", "SMS"]'),
('TRAVEL_REMINDER',
 'OPERATIONAL',
 '{"subject": "Travel Reminder: {journey_date}",
   "body": "Dear {customer_name},\n\nYour journey is scheduled for {journey_date}.\n\nDetails: {journey_details}"}',
 '["journey_date", "customer_name", "journey_details"]',
 '["EMAIL", "SMS", "PUSH"]'),
('SPECIAL_OFFER',
 'MARKETING',
 '{"subject": "Special Offer for {customer_name}",
   "body": "Exclusive offer: {offer_details}\n\nValid until: {expiry_date}"}',
 '["customer_name", "offer_details", "expiry_date"]',
 '["EMAIL", "PUSH"]');

-- Notification Dashboard
CREATE OR REPLACE VIEW notification_dashboard AS
SELECT 
    DATE(nq.scheduled_time) as notification_date,
    -- Queue Status
    JSON_OBJECT(
        'total_notifications', COUNT(*),
        'status_distribution', JSON_OBJECTAGG(
            nq.status,
            COUNT(*)
        ),
        'priority_distribution', JSON_OBJECTAGG(
            nq.priority,
            COUNT(*)
        )
    ) as queue_metrics,
    -- Delivery Performance
    JSON_OBJECT(
        'delivery_stats', JSON_OBJECTAGG(
            nh.channel,
            JSON_OBJECT(
                'attempts', COUNT(*),
                'successful', SUM(
                    CASE WHEN nh.delivery_status = 'DELIVERED' 
                    THEN 1 ELSE 0 END
                ),
                'failed', SUM(
                    CASE WHEN nh.delivery_status = 'FAILED' 
                    THEN 1 ELSE 0 END
                )
            )
        )
    ) as delivery_metrics,
    -- Template Usage
    JSON_OBJECT(
        'template_stats', JSON_ARRAYAGG(
            JSON_OBJECT(
                'template', nt.template_name,
                'type', nt.template_type,
                'usage_count', COUNT(*)
            )
        )
    ) as template_metrics
FROM notification_queue nq
LEFT JOIN notification_history nh ON nq.queue_id = nh.queue_id
LEFT JOIN notification_templates nt ON nq.template_id = nt.template_id
GROUP BY DATE(nq.scheduled_time);

DELIMITER ;
