USE luxury_travel;

DELIMITER //

-- Fraud Detection Framework
-- ======================

-- Suspicious Activities
CREATE TABLE IF NOT EXISTS suspicious_activities (
    activity_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT,
    activity_type VARCHAR(50),
    risk_score DECIMAL(5,2),
    details JSON,
    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'PENDING',
    INDEX idx_user_type (user_id, activity_type)
);

-- Fraud Rules
CREATE TABLE IF NOT EXISTS fraud_rules (
    rule_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    rule_name VARCHAR(100),
    conditions JSON,
    risk_weight DECIMAL(5,2),
    active BOOLEAN DEFAULT TRUE,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Detection Functions
-- ================

-- Analyze Transaction
CREATE PROCEDURE analyze_transaction(
    IN p_user_id BIGINT,
    IN p_transaction_data JSON
)
BEGIN
    DECLARE v_total_risk DECIMAL(5,2) DEFAULT 0;
    DECLARE v_details JSON;
    
    -- Calculate risk score based on active rules
    SELECT 
        SUM(
            CASE WHEN JSON_CONTAINS_PATH(
                p_transaction_data,
                'all',
                JSON_UNQUOTE(JSON_EXTRACT(conditions, '$.path'))
            ) 
            THEN risk_weight
            ELSE 0
            END
        ),
        JSON_ARRAYAGG(
            JSON_OBJECT(
                'rule', rule_name,
                'matched', JSON_CONTAINS_PATH(
                    p_transaction_data,
                    'all',
                    JSON_UNQUOTE(JSON_EXTRACT(conditions, '$.path'))
                ),
                'weight', risk_weight
            )
        )
    INTO v_total_risk, v_details
    FROM fraud_rules
    WHERE active = TRUE;
    
    -- Record suspicious activity if risk score is high
    IF v_total_risk > 0.7 THEN
        INSERT INTO suspicious_activities (
            user_id,
            activity_type,
            risk_score,
            details
        ) VALUES (
            p_user_id,
            'HIGH_RISK_TRANSACTION',
            v_total_risk,
            JSON_OBJECT(
                'transaction_data', p_transaction_data,
                'rule_matches', v_details,
                'risk_factors', JSON_EXTRACT(p_transaction_data, '$.risk_factors')
            )
        );
    END IF;
END //

-- Initialize Fraud Rules
INSERT IGNORE INTO fraud_rules 
(rule_name, conditions, risk_weight) VALUES 
('Rapid Booking Pattern',
 '{"path": "$.booking_count_24h", "threshold": 5}',
 0.3),
('High Value Transaction',
 '{"path": "$.amount", "threshold": 10000}',
 0.4),
('Multiple Payment Methods',
 '{"path": "$.payment_method_count_24h", "threshold": 3}',
 0.5),
('Location Mismatch',
 '{"path": "$.location_risk_score", "threshold": 0.8}',
 0.6);

-- Fraud Detection Dashboard
CREATE OR REPLACE VIEW fraud_detection_dashboard AS
SELECT 
    DATE(detected_at) as detection_date,
    -- Activity Summary
    JSON_OBJECT(
        'total_suspicious', COUNT(*),
        'high_risk', SUM(risk_score > 0.8),
        'avg_risk_score', AVG(risk_score),
        'activity_types', COUNT(DISTINCT activity_type)
    ) as activity_metrics,
    -- Risk Distribution
    JSON_OBJECT(
        'risk_levels', JSON_OBJECTAGG(
            CASE 
                WHEN risk_score > 0.8 THEN 'HIGH'
                WHEN risk_score > 0.5 THEN 'MEDIUM'
                ELSE 'LOW'
            END,
            COUNT(*)
        )
    ) as risk_distribution,
    -- Status Summary
    JSON_OBJECT(
        'status_counts', JSON_OBJECTAGG(
            status,
            COUNT(*)
        )
    ) as status_summary
FROM suspicious_activities
GROUP BY DATE(detected_at);

DELIMITER ;
