USE luxury_travel;

DELIMITER //

-- Real-time Monitoring Views
-- ========================

-- Booking Performance Monitor
CREATE OR REPLACE VIEW booking_performance AS
SELECT 
    DATE_FORMAT(created_at, '%Y-%m-%d') as booking_date,
    service_type,
    COUNT(*) as total_bookings,
    SUM(total_amount) as revenue,
    AVG(total_amount) as avg_booking_value,
    COUNT(DISTINCT user_id) as unique_customers
FROM (
    SELECT created_at, 'Train' as service_type, total_amount, user_id FROM train_bookings
    UNION ALL
    SELECT created_at, 'Cruise' as service_type, total_amount, user_id FROM cruise_bookings
    UNION ALL
    SELECT created_at, 'Car' as service_type, total_amount, user_id FROM car_rentals
) all_bookings
GROUP BY DATE_FORMAT(created_at, '%Y-%m-%d'), service_type
ORDER BY booking_date DESC;

-- Service Health Monitor
CREATE OR REPLACE VIEW service_health AS
SELECT
    service_name,
    total_active_bookings,
    cancellation_rate,
    avg_response_time,
    system_status
FROM (
    SELECT 
        'Train Service' as service_name,
        COUNT(CASE WHEN status = 'active' THEN 1 END) as total_active_bookings,
        ROUND((COUNT(CASE WHEN status = 'cancelled' THEN 1 END) / COUNT(*)) * 100, 2) as cancellation_rate,
        AVG(TIMESTAMPDIFF(SECOND, created_at, updated_at)) as avg_response_time,
        CASE 
            WHEN COUNT(CASE WHEN status = 'error' THEN 1 END) > 10 THEN 'Warning'
            ELSE 'Healthy'
        END as system_status
    FROM train_bookings
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
) service_metrics;

-- Automated Triggers
-- ===============

-- Performance Alert Trigger
CREATE TRIGGER monitor_service_performance
AFTER INSERT ON train_bookings
FOR EACH ROW
BEGIN
    DECLARE error_count INT;
    DECLARE response_time DECIMAL(10,2);
    
    -- Check for errors in last hour
    SELECT COUNT(*) INTO error_count
    FROM train_bookings
    WHERE status = 'error'
    AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR);
    
    -- Calculate average response time
    SELECT AVG(TIMESTAMPDIFF(SECOND, created_at, updated_at)) 
    INTO response_time
    FROM train_bookings
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR);
    
    -- Create alert if needed
    IF error_count > 5 OR response_time > 10 THEN
        INSERT INTO system_alerts (
            alert_type,
            service_name,
            message,
            severity,
            created_at
        ) VALUES (
            CASE 
                WHEN error_count > 5 THEN 'HIGH_ERROR_RATE'
                ELSE 'SLOW_RESPONSE'
            END,
            'Train Service',
            CASE 
                WHEN error_count > 5 THEN CONCAT('High error rate detected: ', error_count, ' errors in last hour')
                ELSE CONCAT('Slow response time detected: ', ROUND(response_time, 2), ' seconds')
            END,
            'HIGH',
            NOW()
        );
    END IF;
END //

-- Required Tables
-- =============

CREATE TABLE IF NOT EXISTS system_alerts (
    alert_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    alert_type VARCHAR(50),
    service_name VARCHAR(100),
    message TEXT,
    severity VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    INDEX idx_service_severity (service_name, severity),
    INDEX idx_created_at (created_at)
);

-- Performance Metrics
CREATE TABLE IF NOT EXISTS performance_metrics (
    metric_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_name VARCHAR(100),
    metric_type VARCHAR(50),
    metric_value DECIMAL(10,2),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_service_metric (service_name, metric_type),
    INDEX idx_timestamp (timestamp)
);

-- Monitoring Procedures
-- ==================

-- System Health Check
CREATE PROCEDURE check_system_health()
BEGIN
    -- Check database performance
    INSERT INTO performance_metrics (service_name, metric_type, metric_value)
    SELECT 
        'Database',
        'Query Response Time',
        AVG(TIMESTAMPDIFF(MICROSECOND, created_at, updated_at))
    FROM train_bookings
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR);
    
    -- Check booking performance
    INSERT INTO performance_metrics (service_name, metric_type, metric_value)
    SELECT 
        'Booking System',
        'Success Rate',
        (COUNT(CASE WHEN status = 'completed' THEN 1 END) / COUNT(*)) * 100
    FROM train_bookings
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR);
    
    -- Generate report
    SELECT 
        service_name,
        metric_type,
        metric_value,
        CASE 
            WHEN metric_value < threshold_value THEN 'Warning'
            ELSE 'Healthy'
        END as status
    FROM performance_metrics
    JOIN performance_thresholds ON 
        performance_metrics.service_name = performance_thresholds.service_name
        AND performance_metrics.metric_type = performance_thresholds.metric_type
    WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 1 HOUR);
END //

DELIMITER ;
