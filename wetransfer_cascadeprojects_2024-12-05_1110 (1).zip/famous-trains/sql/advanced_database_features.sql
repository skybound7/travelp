USE luxury_travel;

-- Additional Views for Reporting
-- ============================

-- Revenue Analysis View
CREATE OR REPLACE VIEW revenue_analysis AS
SELECT 
    DATE_FORMAT(b.booking_date, '%Y-%m') AS month,
    COUNT(b.booking_id) AS total_bookings,
    SUM(b.total_amount) AS total_revenue,
    AVG(b.total_amount) AS average_booking_value,
    COUNT(DISTINCT b.user_id) AS unique_customers
FROM bookings b
WHERE b.status = 'completed'
GROUP BY DATE_FORMAT(b.booking_date, '%Y-%m')
ORDER BY month DESC;

-- Customer Insights View
CREATE OR REPLACE VIEW customer_insights AS
SELECT 
    u.user_id,
    CONCAT(u.first_name, ' ', u.last_name) AS customer_name,
    COUNT(b.booking_id) AS total_bookings,
    SUM(b.total_amount) AS total_spent,
    AVG(r.rating) AS average_rating_given,
    MAX(b.booking_date) AS last_booking_date
FROM users u
LEFT JOIN bookings b ON u.user_id = b.user_id
LEFT JOIN reviews r ON b.booking_id = r.booking_id
GROUP BY u.user_id;

-- Route Performance View
CREATE OR REPLACE VIEW route_performance AS
SELECT 
    ts.departure_station,
    ts.arrival_station,
    COUNT(b.booking_id) AS total_bookings,
    AVG(ts.base_price) AS average_price,
    SUM(b.total_amount) AS total_revenue,
    AVG(r.rating) AS route_satisfaction
FROM train_schedules ts
LEFT JOIN bookings b ON ts.schedule_id = b.schedule_id
LEFT JOIN reviews r ON b.booking_id = r.booking_id
GROUP BY ts.departure_station, ts.arrival_station;

-- Occupancy Analysis View
CREATE OR REPLACE VIEW occupancy_analysis AS
SELECT 
    t.train_id,
    t.name AS train_name,
    ts.schedule_id,
    ts.departure_time,
    ts.available_seats,
    t.capacity,
    ((t.capacity - ts.available_seats) / t.capacity * 100) AS occupancy_rate
FROM trains t
JOIN train_schedules ts ON t.train_id = ts.train_id
WHERE ts.departure_time > NOW();

-- Additional Performance Indexes
-- ============================

-- Composite indexes for complex queries
CREATE INDEX idx_booking_date_status ON bookings(booking_date, status);
CREATE INDEX idx_schedule_stations ON train_schedules(departure_station, arrival_station);
CREATE INDEX idx_user_name ON users(first_name, last_name);
CREATE INDEX idx_train_vendor ON trains(vendor_id, status);
CREATE INDEX idx_review_rating ON reviews(train_id, rating);
CREATE INDEX idx_promotion_dates ON promotions(start_date, end_date, status);

-- Stored Procedures
-- ================

DELIMITER //

-- Create Booking Procedure
CREATE PROCEDURE create_booking(
    IN p_user_id INT,
    IN p_schedule_id INT,
    IN p_passenger_count INT
)
BEGIN
    DECLARE v_available_seats INT;
    DECLARE v_base_price DECIMAL(10,2);
    DECLARE v_total_amount DECIMAL(10,2);
    
    -- Check seat availability
    SELECT available_seats, base_price 
    INTO v_available_seats, v_base_price
    FROM train_schedules 
    WHERE schedule_id = p_schedule_id;
    
    IF v_available_seats >= p_passenger_count THEN
        -- Calculate total amount
        SET v_total_amount = v_base_price * p_passenger_count;
        
        -- Create booking
        INSERT INTO bookings (user_id, schedule_id, passenger_count, total_amount)
        VALUES (p_user_id, p_schedule_id, p_passenger_count, v_total_amount);
        
        -- Update available seats
        UPDATE train_schedules 
        SET available_seats = available_seats - p_passenger_count
        WHERE schedule_id = p_schedule_id;
        
        SELECT 'Booking created successfully' AS message;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Not enough available seats';
    END IF;
END //

-- Cancel Booking Procedure
CREATE PROCEDURE cancel_booking(
    IN p_booking_id INT
)
BEGIN
    DECLARE v_schedule_id INT;
    DECLARE v_passenger_count INT;
    DECLARE v_current_status VARCHAR(20);
    
    -- Get booking details
    SELECT schedule_id, passenger_count, status
    INTO v_schedule_id, v_passenger_count, v_current_status
    FROM bookings
    WHERE booking_id = p_booking_id;
    
    IF v_current_status = 'confirmed' THEN
        START TRANSACTION;
        
        -- Update booking status
        UPDATE bookings 
        SET status = 'cancelled',
            payment_status = 'refunded'
        WHERE booking_id = p_booking_id;
        
        -- Restore available seats
        UPDATE train_schedules 
        SET available_seats = available_seats + v_passenger_count
        WHERE schedule_id = v_schedule_id;
        
        -- Create refund record
        INSERT INTO payments (booking_id, amount, payment_method, status)
        SELECT booking_id, total_amount, 'refund', 'completed'
        FROM bookings
        WHERE booking_id = p_booking_id;
        
        COMMIT;
        
        SELECT 'Booking cancelled successfully' AS message;
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Booking cannot be cancelled';
    END IF;
END //

-- Generate Revenue Report Procedure
CREATE PROCEDURE generate_revenue_report(
    IN p_start_date DATE,
    IN p_end_date DATE
)
BEGIN
    SELECT 
        v.name AS vendor_name,
        COUNT(b.booking_id) AS total_bookings,
        SUM(b.total_amount) AS total_revenue,
        AVG(r.rating) AS average_rating
    FROM vendors v
    LEFT JOIN trains t ON v.vendor_id = t.vendor_id
    LEFT JOIN train_schedules ts ON t.train_id = ts.train_id
    LEFT JOIN bookings b ON ts.schedule_id = b.schedule_id
    LEFT JOIN reviews r ON b.booking_id = r.booking_id
    WHERE b.booking_date BETWEEN p_start_date AND p_end_date
    GROUP BY v.vendor_id;
END //

-- Triggers
-- ========

-- Audit Trail Trigger
CREATE TRIGGER after_booking_update
AFTER UPDATE ON bookings
FOR EACH ROW
BEGIN
    INSERT INTO audit_trail (
        table_name,
        record_id,
        action,
        old_status,
        new_status,
        changed_at
    )
    VALUES (
        'bookings',
        NEW.booking_id,
        'UPDATE',
        OLD.status,
        NEW.status,
        NOW()
    );
END //

-- Notification Trigger
CREATE TRIGGER after_booking_status_change
AFTER UPDATE ON bookings
FOR EACH ROW
BEGIN
    IF NEW.status != OLD.status THEN
        INSERT INTO notifications (
            user_id,
            message,
            type,
            created_at
        )
        VALUES (
            NEW.user_id,
            CONCAT('Your booking #', NEW.booking_id, ' status has changed to: ', NEW.status),
            'booking_update',
            NOW()
        );
    END IF;
END //

-- Low Seat Availability Alert Trigger
CREATE TRIGGER after_schedule_update
AFTER UPDATE ON train_schedules
FOR EACH ROW
BEGIN
    IF NEW.available_seats < (
        SELECT capacity * 0.2 
        FROM trains 
        WHERE train_id = NEW.train_id
    ) THEN
        INSERT INTO alerts (
            type,
            message,
            created_at
        )
        VALUES (
            'low_seats',
            CONCAT('Low seat availability for schedule #', NEW.schedule_id),
            NOW()
        );
    END IF;
END //

DELIMITER ;

-- Create Required Support Tables
-- ============================

-- Audit Trail Table
CREATE TABLE IF NOT EXISTS audit_trail (
    audit_id INT PRIMARY KEY AUTO_INCREMENT,
    table_name VARCHAR(50),
    record_id INT,
    action VARCHAR(20),
    old_status VARCHAR(50),
    new_status VARCHAR(50),
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    message TEXT,
    type VARCHAR(50),
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Alerts Table
CREATE TABLE IF NOT EXISTS alerts (
    alert_id INT PRIMARY KEY AUTO_INCREMENT,
    type VARCHAR(50),
    message TEXT,
    is_handled BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
