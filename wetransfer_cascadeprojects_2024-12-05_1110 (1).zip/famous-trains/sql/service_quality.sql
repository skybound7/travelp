USE luxury_travel;

DELIMITER //

-- Service Quality Framework
-- ======================

-- Customer Feedback
CREATE TABLE IF NOT EXISTS customer_feedback (
    feedback_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT,
    service_type VARCHAR(50),
    booking_id BIGINT,
    rating INT,
    feedback_text TEXT,
    sentiment_score DECIMAL(5,2),
    categories JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_service (user_id, service_type)
);

-- Service Metrics
CREATE TABLE IF NOT EXISTS service_metrics (
    metric_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    metric_name VARCHAR(100),
    metric_value DECIMAL(10,2),
    threshold DECIMAL(10,2),
    status VARCHAR(20),
    measured_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_service_metric (service_type, metric_name)
);

-- Quality Alerts
CREATE TABLE IF NOT EXISTS quality_alerts (
    alert_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_type VARCHAR(50),
    alert_type VARCHAR(50),
    severity VARCHAR(20),
    details JSON,
    status VARCHAR(20) DEFAULT 'OPEN',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP,
    INDEX idx_service_status (service_type, status)
);

-- Quality Functions
-- ==============

-- Process Feedback
CREATE PROCEDURE process_feedback(
    IN p_user_id BIGINT,
    IN p_service_type VARCHAR(50),
    IN p_booking_id BIGINT,
    IN p_rating INT,
    IN p_feedback_text TEXT
)
BEGIN
    DECLARE v_sentiment_score DECIMAL(5,2);
    DECLARE v_categories JSON;
    
    -- Calculate sentiment score (simplified)
    SET v_sentiment_score = CASE
        WHEN p_rating >= 4 THEN 0.8
        WHEN p_rating >= 3 THEN 0.5
        ELSE 0.2
    END;
    
    -- Categorize feedback (simplified)
    SET v_categories = JSON_ARRAY_APPEND(
        JSON_ARRAY(),
        '$',
        CASE
            WHEN p_feedback_text LIKE '%clean%' THEN 'CLEANLINESS'
            WHEN p_feedback_text LIKE '%staff%' THEN 'STAFF'
            WHEN p_feedback_text LIKE '%time%' THEN 'PUNCTUALITY'
            ELSE 'GENERAL'
        END
    );
    
    -- Record feedback
    INSERT INTO customer_feedback (
        user_id,
        service_type,
        booking_id,
        rating,
        feedback_text,
        sentiment_score,
        categories
    ) VALUES (
        p_user_id,
        p_service_type,
        p_booking_id,
        p_rating,
        p_feedback_text,
        v_sentiment_score,
        v_categories
    );
    
    -- Update service metrics
    INSERT INTO service_metrics (
        service_type,
        metric_name,
        metric_value,
        threshold,
        status
    )
    SELECT 
        p_service_type,
        'AVG_RATING',
        AVG(rating),
        4.0,
        CASE 
            WHEN AVG(rating) >= 4.0 THEN 'GOOD'
            WHEN AVG(rating) >= 3.0 THEN 'AVERAGE'
            ELSE 'NEEDS_ATTENTION'
        END
    FROM customer_feedback
    WHERE service_type = p_service_type
    AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY service_type;
    
    -- Generate alerts if needed
    IF p_rating <= 2 THEN
        INSERT INTO quality_alerts (
            service_type,
            alert_type,
            severity,
            details
        ) VALUES (
            p_service_type,
            'LOW_RATING',
            'HIGH',
            JSON_OBJECT(
                'booking_id', p_booking_id,
                'rating', p_rating,
                'feedback', p_feedback_text,
                'categories', v_categories
            )
        );
    END IF;
END //

-- Monitor Service Quality
CREATE PROCEDURE monitor_service_quality(
    IN p_service_type VARCHAR(50)
)
BEGIN
    -- Calculate quality metrics
    INSERT INTO service_metrics (
        service_type,
        metric_name,
        metric_value,
        threshold,
        status
    )
    SELECT 
        p_service_type,
        metric_name,
        metric_value,
        threshold,
        CASE 
            WHEN metric_value >= threshold THEN 'GOOD'
            WHEN metric_value >= threshold * 0.8 THEN 'AVERAGE'
            ELSE 'NEEDS_ATTENTION'
        END
    FROM (
        SELECT 
            'SATISFACTION_SCORE' as metric_name,
            AVG(sentiment_score) as metric_value,
            0.8 as threshold
        FROM customer_feedback
        WHERE service_type = p_service_type
        AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        
        UNION ALL
        
        SELECT 
            'RESPONSE_RATE',
            COUNT(DISTINCT CASE WHEN status = 'RESOLVED' THEN alert_id END) * 100.0 /
            NULLIF(COUNT(DISTINCT alert_id), 0),
            90.0
        FROM quality_alerts
        WHERE service_type = p_service_type
        AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ) metrics;
    
    -- Generate alerts for declining metrics
    INSERT INTO quality_alerts (
        service_type,
        alert_type,
        severity,
        details
    )
    SELECT 
        p_service_type,
        'DECLINING_METRIC',
        CASE 
            WHEN metric_value < threshold * 0.7 THEN 'HIGH'
            WHEN metric_value < threshold * 0.8 THEN 'MEDIUM'
            ELSE 'LOW'
        END,
        JSON_OBJECT(
            'metric_name', metric_name,
            'current_value', metric_value,
            'threshold', threshold,
            'trend', 'DECLINING'
        )
    FROM service_metrics
    WHERE service_type = p_service_type
    AND status = 'NEEDS_ATTENTION'
    AND measured_at >= DATE_SUB(NOW(), INTERVAL 1 DAY);
END //

-- Service Quality Dashboard
CREATE OR REPLACE VIEW service_quality_dashboard AS
SELECT 
    cf.service_type,
    -- Feedback Metrics
    JSON_OBJECT(
        'avg_rating', AVG(cf.rating),
        'feedback_count', COUNT(*),
        'sentiment_distribution', JSON_OBJECT(
            'positive', SUM(cf.sentiment_score >= 0.7),
            'neutral', SUM(cf.sentiment_score BETWEEN 0.3 AND 0.7),
            'negative', SUM(cf.sentiment_score < 0.3)
        ),
        'top_categories', (
            SELECT JSON_ARRAYAGG(category)
            FROM (
                SELECT JSON_UNQUOTE(JSON_EXTRACT(cf2.categories, '$[0]')) as category,
                       COUNT(*) as category_count
                FROM customer_feedback cf2
                WHERE cf2.service_type = cf.service_type
                GROUP BY JSON_UNQUOTE(JSON_EXTRACT(cf2.categories, '$[0]'))
                ORDER BY category_count DESC
                LIMIT 3
            ) top_cats
        )
    ) as feedback_metrics,
    -- Service Metrics
    JSON_OBJECT(
        'metrics', JSON_OBJECTAGG(
            sm.metric_name,
            JSON_OBJECT(
                'value', sm.metric_value,
                'threshold', sm.threshold,
                'status', sm.status
            )
        )
    ) as service_metrics,
    -- Alert Summary
    JSON_OBJECT(
        'open_alerts', COUNT(DISTINCT CASE WHEN qa.status = 'OPEN' THEN qa.alert_id END),
        'severity_distribution', JSON_OBJECT(
            'high', SUM(qa.severity = 'HIGH'),
            'medium', SUM(qa.severity = 'MEDIUM'),
            'low', SUM(qa.severity = 'LOW')
        ),
        'response_time', AVG(
            TIMESTAMPDIFF(HOUR, qa.created_at, COALESCE(qa.resolved_at, NOW()))
        )
    ) as alert_metrics
FROM customer_feedback cf
LEFT JOIN service_metrics sm ON cf.service_type = sm.service_type
LEFT JOIN quality_alerts qa ON cf.service_type = qa.service_type
GROUP BY cf.service_type;

DELIMITER ;
