USE luxury_travel;

DELIMITER //

-- Predictive Analytics System
-- =========================

-- Demand Forecasting
CREATE OR REPLACE VIEW demand_forecast AS
SELECT 
    r.route_id,
    r.origin,
    r.destination,
    -- Historical Metrics
    COUNT(b.booking_id) as total_bookings,
    AVG(b.total_amount) as avg_price,
    -- Seasonal Patterns
    MONTH(b.booking_date) as booking_month,
    DAYOFWEEK(b.booking_date) as booking_day,
    -- Demand Indicators
    COUNT(CASE WHEN DATEDIFF(b.travel_date, b.booking_date) <= 7 THEN 1 END) as last_minute_bookings,
    COUNT(CASE WHEN b.status = 'cancelled' THEN 1 END) as cancellations,
    -- Price Sensitivity
    STDDEV(b.total_amount) as price_variance,
    -- Occupancy Rate
    COUNT(*) / DATEDIFF(MAX(b.travel_date), MIN(b.travel_date)) as daily_booking_rate
FROM routes r
LEFT JOIN train_bookings b ON r.route_id = b.route_id
WHERE b.booking_date >= DATE_SUB(NOW(), INTERVAL 1 YEAR)
GROUP BY r.route_id, MONTH(b.booking_date), DAYOFWEEK(b.booking_date);

-- Dynamic Pricing Model
CREATE PROCEDURE calculate_dynamic_price(
    IN p_route_id INT,
    IN p_travel_date DATE,
    OUT p_recommended_price DECIMAL(10,2)
)
BEGIN
    DECLARE base_price DECIMAL(10,2);
    DECLARE demand_multiplier DECIMAL(5,2);
    DECLARE seasonal_factor DECIMAL(5,2);
    
    -- Get base price
    SELECT AVG(total_amount)
    INTO base_price
    FROM train_bookings
    WHERE route_id = p_route_id
    AND booking_date >= DATE_SUB(NOW(), INTERVAL 3 MONTH);
    
    -- Calculate demand multiplier
    SELECT 
        CASE 
            WHEN booking_count > avg_bookings * 1.2 THEN 1.3
            WHEN booking_count > avg_bookings THEN 1.1
            WHEN booking_count < avg_bookings * 0.8 THEN 0.9
            ELSE 1.0
        END
    INTO demand_multiplier
    FROM (
        SELECT 
            COUNT(*) as booking_count,
            (SELECT COUNT(*)/90 FROM train_bookings 
             WHERE booking_date >= DATE_SUB(NOW(), INTERVAL 90 DAY)
             AND route_id = p_route_id) as avg_bookings
        FROM train_bookings
        WHERE route_id = p_route_id
        AND booking_date >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ) demand_stats;
    
    -- Calculate seasonal factor
    SELECT 
        CASE 
            WHEN MONTH(p_travel_date) IN (6,7,8) THEN 1.2  -- Summer
            WHEN MONTH(p_travel_date) IN (12) THEN 1.3     -- Holiday
            WHEN MONTH(p_travel_date) IN (1,2) THEN 0.9    -- Low season
            ELSE 1.0
        END
    INTO seasonal_factor;
    
    -- Calculate recommended price
    SET p_recommended_price = base_price * demand_multiplier * seasonal_factor;
END //

-- Customer Churn Prediction
CREATE OR REPLACE VIEW churn_risk_analysis AS
SELECT 
    u.user_id,
    u.email,
    -- Activity Metrics
    DATEDIFF(NOW(), MAX(b.booking_date)) as days_since_last_booking,
    COUNT(b.booking_id) as total_bookings,
    -- Satisfaction Indicators
    AVG(r.rating) as avg_rating,
    COUNT(CASE WHEN r.rating < 3 THEN 1 END) as low_ratings,
    -- Behavioral Flags
    COUNT(CASE WHEN b.status = 'cancelled' THEN 1 END) as cancellations,
    -- Value Metrics
    AVG(b.total_amount) as avg_spend,
    -- Churn Risk Score
    CASE 
        WHEN DATEDIFF(NOW(), MAX(b.booking_date)) > 180 AND AVG(r.rating) < 3 THEN 'High'
        WHEN DATEDIFF(NOW(), MAX(b.booking_date)) > 90 OR AVG(r.rating) < 3 THEN 'Medium'
        ELSE 'Low'
    END as churn_risk
FROM users u
LEFT JOIN (
    SELECT booking_id, user_id, booking_date, status, total_amount 
    FROM train_bookings
    UNION ALL
    SELECT booking_id, user_id, booking_date, status, total_amount 
    FROM cruise_bookings
    UNION ALL
    SELECT rental_id, user_id, rental_date, status, total_amount 
    FROM car_rentals
) b ON u.user_id = b.user_id
LEFT JOIN reviews r ON b.booking_id = r.booking_id
GROUP BY u.user_id;

-- Service Optimization
CREATE PROCEDURE optimize_service_schedule(
    IN p_route_id INT,
    IN p_date DATE
)
BEGIN
    -- Calculate optimal departure times based on historical demand
    SELECT 
        HOUR(travel_date) as departure_hour,
        COUNT(*) as booking_count,
        AVG(total_amount) as avg_revenue,
        COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancellations
    FROM train_bookings
    WHERE route_id = p_route_id
    AND DATE(travel_date) = p_date
    GROUP BY HOUR(travel_date)
    ORDER BY booking_count DESC;
    
    -- Calculate capacity requirements
    SELECT 
        DATE(travel_date) as travel_day,
        COUNT(*) as total_bookings,
        MAX(COUNT(*)) OVER (PARTITION BY DAYOFWEEK(travel_date)) as peak_demand,
        AVG(COUNT(*)) OVER (PARTITION BY DAYOFWEEK(travel_date)) as avg_demand
    FROM train_bookings
    WHERE route_id = p_route_id
    AND travel_date >= DATE_SUB(p_date, INTERVAL 30 DAY)
    GROUP BY DATE(travel_date);
END //

-- Required Tables
-- ============

CREATE TABLE IF NOT EXISTS price_history (
    price_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    route_id INT,
    travel_date DATE,
    calculated_price DECIMAL(10,2),
    base_price DECIMAL(10,2),
    demand_multiplier DECIMAL(5,2),
    seasonal_factor DECIMAL(5,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_route_date (route_id, travel_date)
);

CREATE TABLE IF NOT EXISTS optimization_logs (
    log_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    route_id INT,
    optimization_date DATE,
    metrics JSON,
    recommendations JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_route_date (route_id, optimization_date)
);

DELIMITER ;
