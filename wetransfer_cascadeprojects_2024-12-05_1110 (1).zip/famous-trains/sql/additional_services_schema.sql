USE luxury_travel;

-- Cruise Services
-- ==============
CREATE TABLE cruise_ships (
    ship_id INT PRIMARY KEY AUTO_INCREMENT,
    vendor_id INT,
    name VARCHAR(100) NOT NULL,
    capacity INT,
    description TEXT,
    amenities TEXT,
    status ENUM('active', 'maintenance', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id)
);

CREATE TABLE cruise_itineraries (
    itinerary_id INT PRIMARY KEY AUTO_INCREMENT,
    ship_id INT,
    name VARCHAR(100),
    duration_days INT,
    start_port VARCHAR(100),
    end_port VARCHAR(100),
    route_details TEXT,
    base_price DECIMAL(10,2),
    status ENUM('active', 'cancelled', 'completed') DEFAULT 'active',
    FOREIGN KEY (ship_id) REFERENCES cruise_ships(ship_id)
);

CREATE TABLE cruise_bookings (
    booking_id INT PRIMARY KEY AUTO_INCREMENT,
    itinerary_id INT,
    user_id INT,
    cabin_type ENUM('suite', 'deluxe', 'standard'),
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    passenger_count INT,
    total_amount DECIMAL(10,2),
    status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
    FOREIGN KEY (itinerary_id) REFERENCES cruise_itineraries(itinerary_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Car Rental Services
-- ==================
CREATE TABLE rental_cars (
    car_id INT PRIMARY KEY AUTO_INCREMENT,
    vendor_id INT,
    make VARCHAR(50),
    model VARCHAR(50),
    year INT,
    category ENUM('economy', 'compact', 'luxury', 'suv', 'van'),
    seats INT,
    transmission ENUM('automatic', 'manual'),
    daily_rate DECIMAL(10,2),
    status ENUM('available', 'rented', 'maintenance') DEFAULT 'available',
    location VARCHAR(100),
    FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id)
);

CREATE TABLE car_rentals (
    rental_id INT PRIMARY KEY AUTO_INCREMENT,
    car_id INT,
    user_id INT,
    pickup_date DATETIME,
    return_date DATETIME,
    pickup_location VARCHAR(100),
    return_location VARCHAR(100),
    total_amount DECIMAL(10,2),
    status ENUM('reserved', 'active', 'completed', 'cancelled') DEFAULT 'reserved',
    FOREIGN KEY (car_id) REFERENCES rental_cars(car_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Airport Transfers
-- ================
CREATE TABLE transfer_vehicles (
    vehicle_id INT PRIMARY KEY AUTO_INCREMENT,
    vendor_id INT,
    type ENUM('sedan', 'suv', 'van', 'luxury'),
    capacity INT,
    base_rate DECIMAL(10,2),
    status ENUM('active', 'maintenance', 'inactive') DEFAULT 'active',
    FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id)
);

CREATE TABLE airport_transfers (
    transfer_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    vehicle_id INT,
    pickup_location VARCHAR(100),
    dropoff_location VARCHAR(100),
    pickup_time DATETIME,
    passenger_count INT,
    flight_number VARCHAR(20),
    total_amount DECIMAL(10,2),
    status ENUM('scheduled', 'completed', 'cancelled') DEFAULT 'scheduled',
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (vehicle_id) REFERENCES transfer_vehicles(vehicle_id)
);

-- Travel Insurance
-- ===============
CREATE TABLE insurance_plans (
    plan_id INT PRIMARY KEY AUTO_INCREMENT,
    vendor_id INT,
    name VARCHAR(100),
    description TEXT,
    coverage_details TEXT,
    base_premium DECIMAL(10,2),
    status ENUM('active', 'inactive') DEFAULT 'active',
    FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id)
);

CREATE TABLE insurance_policies (
    policy_id INT PRIMARY KEY AUTO_INCREMENT,
    plan_id INT,
    user_id INT,
    booking_reference VARCHAR(100),
    start_date DATE,
    end_date DATE,
    premium_amount DECIMAL(10,2),
    status ENUM('active', 'expired', 'cancelled') DEFAULT 'active',
    FOREIGN KEY (plan_id) REFERENCES insurance_plans(plan_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Courier Services
-- ===============
CREATE TABLE courier_services (
    service_id INT PRIMARY KEY AUTO_INCREMENT,
    vendor_id INT,
    service_name VARCHAR(100),
    description TEXT,
    base_rate DECIMAL(10,2),
    status ENUM('active', 'inactive') DEFAULT 'active',
    FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id)
);

CREATE TABLE courier_shipments (
    shipment_id INT PRIMARY KEY AUTO_INCREMENT,
    service_id INT,
    user_id INT,
    pickup_address TEXT,
    delivery_address TEXT,
    weight DECIMAL(5,2),
    dimensions VARCHAR(50),
    tracking_number VARCHAR(50) UNIQUE,
    total_amount DECIMAL(10,2),
    status ENUM('pending', 'picked_up', 'in_transit', 'delivered', 'cancelled'),
    FOREIGN KEY (service_id) REFERENCES courier_services(service_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Home Stay
-- =========
CREATE TABLE homestays (
    homestay_id INT PRIMARY KEY AUTO_INCREMENT,
    vendor_id INT,
    name VARCHAR(100),
    address TEXT,
    description TEXT,
    amenities TEXT,
    rooms INT,
    max_guests INT,
    nightly_rate DECIMAL(10,2),
    status ENUM('available', 'booked', 'maintenance') DEFAULT 'available',
    FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id)
);

CREATE TABLE homestay_bookings (
    booking_id INT PRIMARY KEY AUTO_INCREMENT,
    homestay_id INT,
    user_id INT,
    check_in_date DATE,
    check_out_date DATE,
    guest_count INT,
    total_amount DECIMAL(10,2),
    status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
    FOREIGN KEY (homestay_id) REFERENCES homestays(homestay_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Eurail Passes
-- ============
CREATE TABLE eurail_passes (
    pass_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    description TEXT,
    duration_days INT,
    countries_covered TEXT,
    class_type ENUM('first', 'second'),
    base_price DECIMAL(10,2),
    status ENUM('active', 'inactive') DEFAULT 'active'
);

CREATE TABLE eurail_bookings (
    booking_id INT PRIMARY KEY AUTO_INCREMENT,
    pass_id INT,
    user_id INT,
    start_date DATE,
    passenger_count INT,
    total_amount DECIMAL(10,2),
    status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
    FOREIGN KEY (pass_id) REFERENCES eurail_passes(pass_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- IRCTC Integration
-- ================
CREATE TABLE irctc_trains (
    train_id INT PRIMARY KEY AUTO_INCREMENT,
    train_number VARCHAR(20) UNIQUE,
    name VARCHAR(100),
    source_station VARCHAR(100),
    destination_station VARCHAR(100),
    schedule TEXT,
    class_types TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active'
);

CREATE TABLE irctc_bookings (
    booking_id INT PRIMARY KEY AUTO_INCREMENT,
    train_id INT,
    user_id INT,
    journey_date DATE,
    class_type VARCHAR(20),
    passenger_count INT,
    pnr_number VARCHAR(20) UNIQUE,
    total_amount DECIMAL(10,2),
    status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
    FOREIGN KEY (train_id) REFERENCES irctc_trains(train_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create Indexes for Performance
-- ============================
CREATE INDEX idx_cruise_status ON cruise_ships(status);
CREATE INDEX idx_car_availability ON rental_cars(status, location);
CREATE INDEX idx_transfer_datetime ON airport_transfers(pickup_time);
CREATE INDEX idx_insurance_dates ON insurance_policies(start_date, end_date);
CREATE INDEX idx_shipment_tracking ON courier_shipments(tracking_number);
CREATE INDEX idx_homestay_availability ON homestays(status);
CREATE INDEX idx_eurail_active ON eurail_passes(status);
CREATE INDEX idx_irctc_train_number ON irctc_trains(train_number);

-- Create Views for Common Queries
-- =============================
CREATE VIEW available_homestays AS
SELECT h.*, v.name AS vendor_name, v.contact_number
FROM homestays h
JOIN vendors v ON h.vendor_id = v.vendor_id
WHERE h.status = 'available';

CREATE VIEW active_transfers AS
SELECT at.*, v.type AS vehicle_type, u.first_name, u.last_name
FROM airport_transfers at
JOIN transfer_vehicles v ON at.vehicle_id = v.vehicle_id
JOIN users u ON at.user_id = u.user_id
WHERE at.status = 'scheduled';

CREATE VIEW cruise_availability AS
SELECT cs.name AS ship_name, ci.name AS itinerary_name,
       ci.start_port, ci.end_port, ci.duration_days,
       ci.base_price, cs.capacity
FROM cruise_ships cs
JOIN cruise_itineraries ci ON cs.ship_id = ci.ship_id
WHERE cs.status = 'active' AND ci.status = 'active';
