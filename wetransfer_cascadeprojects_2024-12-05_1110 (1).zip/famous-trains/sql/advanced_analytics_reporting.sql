USE luxury_travel;

DELIMITER //

-- Advanced Analytics Views
-- =====================

-- Service Performance Dashboard
CREATE OR REPLACE VIEW service_performance_dashboard AS
SELECT 
    service_type,
    current_month_stats.bookings as current_month_bookings,
    current_month_stats.revenue as current_month_revenue,
    ROUND((current_month_stats.bookings - prev_month_stats.bookings) / prev_month_stats.bookings * 100, 2) as booking_growth,
    ROUND((current_month_stats.revenue - prev_month_stats.revenue) / prev_month_stats.revenue * 100, 2) as revenue_growth,
    current_month_stats.avg_booking_value,
    current_month_stats.cancellation_rate,
    current_month_stats.avg_rating
FROM (
    SELECT 
        service_type,
        COUNT(*) as bookings,
        SUM(total_amount) as revenue,
        AVG(total_amount) as avg_booking_value,
        COUNT(CASE WHEN status = 'cancelled' THEN 1 END) / COUNT(*) * 100 as cancellation_rate,
        AVG(rating) as avg_rating
    FROM (
        SELECT 'Train' as service_type, b.*, r.rating 
        FROM train_bookings b
        LEFT JOIN reviews r ON b.booking_id = r.booking_id
        WHERE DATE_FORMAT(b.booking_date, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m')
    ) current_month
    GROUP BY service_type
) current_month_stats
JOIN (
    SELECT 
        service_type,
        COUNT(*) as bookings,
        SUM(total_amount) as revenue
    FROM (
        SELECT 'Train' as service_type, * 
        FROM train_bookings
        WHERE DATE_FORMAT(booking_date, '%Y-%m') = DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 MONTH), '%Y-%m')
    ) prev_month
    GROUP BY service_type
) prev_month_stats USING (service_type);

-- Customer Lifetime Value Analysis
CREATE OR REPLACE VIEW customer_lifetime_value AS
SELECT 
    u.user_id,
    u.email,
    COUNT(DISTINCT b.booking_id) as total_bookings,
    SUM(b.total_amount) as total_spent,
    AVG(b.total_amount) as avg_booking_value,
    COUNT(DISTINCT b.service_type) as services_used,
    DATEDIFF(NOW(), MIN(b.booking_date)) as customer_age_days,
    DATEDIFF(NOW(), MAX(b.booking_date)) as days_since_last_booking,
    SUM(b.total_amount) / NULLIF(DATEDIFF(NOW(), MIN(b.booking_date)), 0) * 365 as yearly_value,
    CASE 
        WHEN DATEDIFF(NOW(), MAX(b.booking_date)) <= 90 THEN 'Active'
        WHEN DATEDIFF(NOW(), MAX(b.booking_date)) <= 180 THEN 'At Risk'
        ELSE 'Churned'
    END as customer_status
FROM users u
LEFT JOIN (
    SELECT booking_id, user_id, total_amount, booking_date, 'Train' as service_type FROM train_bookings
    UNION ALL
    SELECT booking_id, user_id, total_amount, booking_date, 'Cruise' FROM cruise_bookings
    UNION ALL
    SELECT rental_id, user_id, total_amount, rental_date, 'Car' FROM car_rentals
) b ON u.user_id = b.user_id
GROUP BY u.user_id;

-- Route Profitability Analysis
CREATE OR REPLACE VIEW route_profitability AS
SELECT 
    r.route_id,
    r.origin,
    r.destination,
    COUNT(b.booking_id) as total_bookings,
    SUM(b.total_amount) as total_revenue,
    AVG(b.total_amount) as avg_ticket_price,
    COUNT(DISTINCT b.user_id) as unique_customers,
    COUNT(CASE WHEN b.status = 'cancelled' THEN 1 END) as cancellations,
    AVG(rev.rating) as avg_rating,
    SUM(b.total_amount) / COUNT(b.booking_id) as revenue_per_booking,
    COUNT(b.booking_id) / DATEDIFF(MAX(b.booking_date), MIN(b.booking_date)) as bookings_per_day
FROM routes r
LEFT JOIN train_bookings b ON r.route_id = b.route_id
LEFT JOIN reviews rev ON b.booking_id = rev.booking_id
GROUP BY r.route_id;

-- Advanced Reporting Procedures
-- =========================

-- Generate Executive Summary
CREATE PROCEDURE generate_executive_summary(IN report_date DATE)
BEGIN
    -- Overall Performance
    SELECT 
        COUNT(*) as total_bookings,
        SUM(total_amount) as total_revenue,
        COUNT(DISTINCT user_id) as active_customers,
        AVG(total_amount) as avg_booking_value
    FROM train_bookings
    WHERE DATE(booking_date) = report_date;
    
    -- Service Distribution
    SELECT 
        service_type,
        COUNT(*) as bookings,
        SUM(total_amount) as revenue,
        ROUND(COUNT(*) / total_bookings.cnt * 100, 2) as booking_percentage
    FROM (
        SELECT 'Train' as service_type, * FROM train_bookings
        WHERE DATE(booking_date) = report_date
        UNION ALL
        SELECT 'Cruise', * FROM cruise_bookings
        WHERE DATE(booking_date) = report_date
        UNION ALL
        SELECT 'Car', * FROM car_rentals
        WHERE DATE(rental_date) = report_date
    ) services
    CROSS JOIN (
        SELECT COUNT(*) as cnt
        FROM (
            SELECT booking_id FROM train_bookings WHERE DATE(booking_date) = report_date
            UNION ALL
            SELECT booking_id FROM cruise_bookings WHERE DATE(booking_date) = report_date
            UNION ALL
            SELECT rental_id FROM car_rentals WHERE DATE(rental_date) = report_date
        ) all_bookings
    ) total_bookings
    GROUP BY service_type;
    
    -- Customer Segments
    SELECT 
        customer_segment,
        COUNT(*) as customer_count,
        SUM(total_spent) as segment_revenue
    FROM customer_segments
    GROUP BY customer_segment;
    
    -- Top Routes
    SELECT 
        r.origin,
        r.destination,
        COUNT(*) as bookings,
        SUM(b.total_amount) as revenue
    FROM routes r
    JOIN train_bookings b ON r.route_id = b.route_id
    WHERE DATE(b.booking_date) = report_date
    GROUP BY r.route_id
    ORDER BY revenue DESC
    LIMIT 5;
END //

-- Required Tables
-- ============

CREATE TABLE IF NOT EXISTS executive_reports (
    report_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    report_date DATE,
    report_type VARCHAR(50),
    metrics JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_daily_report (report_date, report_type)
);

DELIMITER ;
