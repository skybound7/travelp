USE luxury_travel;

DELIMITER //

-- Customer Segmentation Framework
-- ===========================

-- Customer Profiles
CREATE TABLE IF NOT EXISTS customer_profiles (
    profile_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT,
    segment_id BIGINT,
    booking_history JSON,
    preferences JSON,
    value_score DECIMAL(5,2),
    price_sensitivity DECIMAL(5,2),
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_segment (segment_id)
);

-- Personalized Offers
CREATE TABLE IF NOT EXISTS personalized_offers (
    offer_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    profile_id BIGINT,
    service_type VARCHAR(50),
    base_price DECIMAL(10,2),
    adjusted_price DECIMAL(10,2),
    discount_factors JSON,
    valid_from TIMESTAMP,
    valid_until TIMESTAMP,
    status ENUM('ACTIVE', 'EXPIRED', 'REDEEMED') DEFAULT 'ACTIVE',
    INDEX idx_profile (profile_id),
    INDEX idx_validity (valid_from, valid_until)
);

-- Personalization Functions
-- =====================

-- Calculate Customer Value Score
CREATE PROCEDURE calculate_customer_value(
    IN p_user_id BIGINT,
    OUT p_value_score DECIMAL(5,2)
)
BEGIN
    -- Analyze booking history
    WITH user_metrics AS (
        SELECT 
            COUNT(*) as total_bookings,
            SUM(total_amount) as total_spent,
            AVG(total_amount) as avg_booking_value,
            MAX(created_at) as last_booking,
            MIN(created_at) as first_booking,
            COUNT(DISTINCT service_type) as service_diversity
        FROM (
            SELECT * FROM train_bookings
            UNION ALL
            SELECT * FROM cruise_bookings
            UNION ALL
            SELECT * FROM car_rentals
        ) all_bookings
        WHERE user_id = p_user_id
    )
    SELECT 
        -- Value score calculation (0-100)
        (
            -- Frequency (30%)
            (total_bookings / 10) * 0.3 +
            -- Monetary (40%)
            (total_spent / 5000) * 0.4 +
            -- Diversity (20%)
            (service_diversity / 3) * 0.2 +
            -- Loyalty (10%)
            (DATEDIFF(last_booking, first_booking) / 365) * 0.1
        ) * 100 INTO p_value_score
    FROM user_metrics;
    
    -- Update customer profile
    INSERT INTO customer_profiles (
        user_id,
        value_score,
        booking_history,
        preferences
    )
    SELECT 
        p_user_id,
        p_value_score,
        JSON_OBJECT(
            'total_bookings', total_bookings,
            'total_spent', total_spent,
            'avg_value', avg_booking_value,
            'service_diversity', service_diversity,
            'loyalty_days', DATEDIFF(last_booking, first_booking)
        ),
        JSON_OBJECT(
            'preferred_services', (
                SELECT JSON_ARRAYAGG(
                    JSON_OBJECT(
                        'service_type', service_type,
                        'frequency', COUNT(*)
                    )
                )
                FROM (
                    SELECT * FROM train_bookings
                    UNION ALL
                    SELECT * FROM cruise_bookings
                    UNION ALL
                    SELECT * FROM car_rentals
                ) service_bookings
                WHERE user_id = p_user_id
                GROUP BY service_type
            )
        )
    ON DUPLICATE KEY UPDATE
        value_score = p_value_score,
        last_updated = CURRENT_TIMESTAMP;
END //

-- Generate Personalized Offer
CREATE PROCEDURE generate_personalized_offer(
    IN p_user_id BIGINT,
    IN p_service_type VARCHAR(50),
    IN p_base_price DECIMAL(10,2)
)
BEGIN
    DECLARE v_profile_id BIGINT;
    DECLARE v_value_score DECIMAL(5,2);
    DECLARE v_price_sensitivity DECIMAL(5,2);
    DECLARE v_adjusted_price DECIMAL(10,2);
    
    -- Get customer profile
    SELECT 
        profile_id,
        value_score,
        price_sensitivity
    INTO 
        v_profile_id,
        v_value_score,
        v_price_sensitivity
    FROM customer_profiles
    WHERE user_id = p_user_id;
    
    -- Calculate personalized price
    SET v_adjusted_price = p_base_price * (
        1 - CASE
            -- High value, low sensitivity customers
            WHEN v_value_score >= 80 AND v_price_sensitivity <= 0.3 THEN 0.05
            -- High value, medium sensitivity
            WHEN v_value_score >= 80 AND v_price_sensitivity <= 0.7 THEN 0.10
            -- High value, high sensitivity
            WHEN v_value_score >= 80 THEN 0.15
            -- Medium value customers
            WHEN v_value_score >= 50 THEN 0.08
            -- Low value customers - focus on acquisition
            ELSE 0.12
        END
    );
    
    -- Create personalized offer
    INSERT INTO personalized_offers (
        profile_id,
        service_type,
        base_price,
        adjusted_price,
        discount_factors,
        valid_from,
        valid_until
    ) VALUES (
        v_profile_id,
        p_service_type,
        p_base_price,
        v_adjusted_price,
        JSON_OBJECT(
            'value_score', v_value_score,
            'price_sensitivity', v_price_sensitivity,
            'discount_rate', (p_base_price - v_adjusted_price) / p_base_price,
            'factors', JSON_OBJECT(
                'customer_value', v_value_score >= 80,
                'price_sensitivity', v_price_sensitivity,
                'service_type', p_service_type
            )
        ),
        CURRENT_TIMESTAMP,
        DATE_ADD(CURRENT_TIMESTAMP, INTERVAL 7 DAY)
    );
END //

-- Personalization Dashboard
CREATE OR REPLACE VIEW personalization_dashboard AS
SELECT 
    cp.user_id,
    cp.segment_id,
    cp.value_score,
    -- Booking patterns
    JSON_EXTRACT(cp.booking_history, '$.total_bookings') as total_bookings,
    JSON_EXTRACT(cp.booking_history, '$.total_spent') as total_spent,
    JSON_EXTRACT(cp.booking_history, '$.avg_value') as avg_booking_value,
    -- Preferences
    cp.preferences as customer_preferences,
    -- Active offers
    (SELECT COUNT(*) 
     FROM personalized_offers po 
     WHERE po.profile_id = cp.profile_id
     AND po.status = 'ACTIVE') as active_offers,
    -- Offer performance
    JSON_OBJECT(
        'total_offers', COUNT(po.offer_id),
        'redemption_rate', 
        SUM(CASE WHEN po.status = 'REDEEMED' THEN 1 ELSE 0 END) / COUNT(po.offer_id),
        'avg_discount', 
        AVG((po.base_price - po.adjusted_price) / po.base_price)
    ) as offer_metrics
FROM customer_profiles cp
LEFT JOIN personalized_offers po ON cp.profile_id = po.profile_id
GROUP BY cp.user_id, cp.segment_id, cp.value_score, cp.booking_history, 
         cp.preferences;

DELIMITER ;
