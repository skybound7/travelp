USE luxury_travel;

DELIMITER //

-- Maintenance Framework
-- ==================

-- Equipment Inventory
CREATE TABLE IF NOT EXISTS equipment_inventory (
    equipment_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    equipment_type VARCHAR(50),
    model_number VARCHAR(100),
    serial_number VARCHAR(100),
    status VARCHAR(20),
    specifications JSON,
    purchase_date DATE,
    last_maintenance DATE,
    INDEX idx_type_status (equipment_type, status)
);

-- Maintenance Schedule
CREATE TABLE IF NOT EXISTS maintenance_schedule (
    schedule_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    equipment_id BIGINT,
    maintenance_type VARCHAR(50),
    frequency_days INT,
    last_performed DATE,
    next_due DATE,
    priority VARCHAR(20),
    INDEX idx_equipment_due (equipment_id, next_due)
);

-- Maintenance History
CREATE TABLE IF NOT EXISTS maintenance_history (
    history_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    equipment_id BIGINT,
    maintenance_type VARCHAR(50),
    performed_date DATE,
    technician VARCHAR(100),
    findings JSON,
    parts_replaced JSON,
    cost DECIMAL(10,2),
    INDEX idx_equipment_date (equipment_id, performed_date)
);

-- Maintenance Functions
-- =================

-- Schedule Maintenance
CREATE PROCEDURE schedule_maintenance(
    IN p_equipment_id BIGINT,
    IN p_maintenance_type VARCHAR(50)
)
BEGIN
    DECLARE v_last_maintenance DATE;
    DECLARE v_frequency_days INT;
    
    -- Get last maintenance date and frequency
    SELECT 
        COALESCE(MAX(performed_date), ei.purchase_date),
        ms.frequency_days
    INTO v_last_maintenance, v_frequency_days
    FROM equipment_inventory ei
    LEFT JOIN maintenance_history mh ON ei.equipment_id = mh.equipment_id
    JOIN maintenance_schedule ms 
        ON ei.equipment_id = ms.equipment_id
        AND ms.maintenance_type = p_maintenance_type
    WHERE ei.equipment_id = p_equipment_id;
    
    -- Update maintenance schedule
    UPDATE maintenance_schedule
    SET 
        last_performed = v_last_maintenance,
        next_due = DATE_ADD(v_last_maintenance, INTERVAL v_frequency_days DAY),
        priority = CASE
            WHEN DATEDIFF(CURRENT_DATE, v_last_maintenance) > v_frequency_days
            THEN 'HIGH'
            WHEN DATEDIFF(CURRENT_DATE, v_last_maintenance) > v_frequency_days * 0.8
            THEN 'MEDIUM'
            ELSE 'LOW'
        END
    WHERE equipment_id = p_equipment_id
    AND maintenance_type = p_maintenance_type;
END //

-- Record Maintenance
CREATE PROCEDURE record_maintenance(
    IN p_equipment_id BIGINT,
    IN p_maintenance_type VARCHAR(50),
    IN p_technician VARCHAR(100),
    IN p_findings JSON,
    IN p_parts_replaced JSON,
    IN p_cost DECIMAL(10,2)
)
BEGIN
    -- Record maintenance history
    INSERT INTO maintenance_history (
        equipment_id,
        maintenance_type,
        performed_date,
        technician,
        findings,
        parts_replaced,
        cost
    ) VALUES (
        p_equipment_id,
        p_maintenance_type,
        CURRENT_DATE,
        p_technician,
        p_findings,
        p_parts_replaced,
        p_cost
    );
    
    -- Update equipment status
    UPDATE equipment_inventory
    SET 
        status = CASE
            WHEN JSON_EXTRACT(p_findings, '$.issues_found') = 'true'
            THEN 'NEEDS_REPAIR'
            ELSE 'OPERATIONAL'
        END,
        last_maintenance = CURRENT_DATE
    WHERE equipment_id = p_equipment_id;
    
    -- Schedule next maintenance
    CALL schedule_maintenance(p_equipment_id, p_maintenance_type);
END //

-- Initialize Equipment Types
INSERT IGNORE INTO equipment_inventory 
(equipment_type, model_number, status, specifications, purchase_date) VALUES 
('LOCOMOTIVE',
 'TR-2000',
 'OPERATIONAL',
 '{"max_speed": 200, "capacity": 500, "fuel_type": "DIESEL"}',
 '2023-01-01'),
('PASSENGER_CAR',
 'PC-1500',
 'OPERATIONAL',
 '{"seats": 80, "class": "FIRST", "amenities": ["WIFI", "POWER"]}',
 '2023-01-01'),
('MAINTENANCE_EQUIPMENT',
 'ME-500',
 'OPERATIONAL',
 '{"type": "DIAGNOSTIC", "compatibility": ["TR-2000", "PC-1500"]}',
 '2023-01-01');

-- Initialize Maintenance Types
INSERT IGNORE INTO maintenance_schedule 
(equipment_id, maintenance_type, frequency_days, priority) VALUES 
(1, 'ROUTINE_CHECK', 7, 'LOW'),
(1, 'FULL_SERVICE', 90, 'MEDIUM'),
(1, 'SAFETY_INSPECTION', 30, 'HIGH'),
(2, 'ROUTINE_CHECK', 14, 'LOW'),
(2, 'INTERIOR_SERVICE', 60, 'MEDIUM'),
(3, 'CALIBRATION', 180, 'MEDIUM');

-- Maintenance Dashboard
CREATE OR REPLACE VIEW maintenance_dashboard AS
SELECT 
    ei.equipment_id,
    ei.equipment_type,
    -- Equipment Details
    JSON_OBJECT(
        'model', ei.model_number,
        'status', ei.status,
        'specifications', ei.specifications,
        'age_days', DATEDIFF(CURRENT_DATE, ei.purchase_date)
    ) as equipment_details,
    -- Maintenance Schedule
    JSON_OBJECT(
        'upcoming_maintenance', (
            SELECT JSON_ARRAYAGG(
                JSON_OBJECT(
                    'type', maintenance_type,
                    'due_date', next_due,
                    'priority', priority,
                    'days_until_due', DATEDIFF(next_due, CURRENT_DATE)
                )
            )
            FROM maintenance_schedule ms
            WHERE ms.equipment_id = ei.equipment_id
            AND ms.next_due > CURRENT_DATE
            ORDER BY ms.next_due
            LIMIT 3
        )
    ) as maintenance_schedule,
    -- Maintenance History
    JSON_OBJECT(
        'last_maintenance', (
            SELECT JSON_OBJECT(
                'type', maintenance_type,
                'date', performed_date,
                'findings', findings,
                'cost', cost
            )
            FROM maintenance_history mh
            WHERE mh.equipment_id = ei.equipment_id
            ORDER BY mh.performed_date DESC
            LIMIT 1
        ),
        'maintenance_stats', (
            SELECT JSON_OBJECT(
                'total_cost', SUM(cost),
                'maintenance_count', COUNT(*),
                'avg_cost', AVG(cost),
                'issues_found', COUNT(CASE 
                    WHEN JSON_EXTRACT(findings, '$.issues_found') = 'true' 
                    THEN 1 END)
            )
            FROM maintenance_history mh
            WHERE mh.equipment_id = ei.equipment_id
            AND mh.performed_date >= DATE_SUB(CURRENT_DATE, INTERVAL 1 YEAR)
        )
    ) as maintenance_history
FROM equipment_inventory ei;

DELIMITER ;
