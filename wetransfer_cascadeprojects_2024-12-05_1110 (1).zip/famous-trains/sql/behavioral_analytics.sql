USE luxury_travel;

DELIMITER //

-- Behavioral Analytics Framework
-- ==========================

-- User Behavior Tracking
CREATE TABLE IF NOT EXISTS user_behaviors (
    behavior_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT,
    behavior_type VARCHAR(50),
    context JSON,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_time (user_id, timestamp)
);

-- Behavior Patterns
CREATE TABLE IF NOT EXISTS behavior_patterns (
    pattern_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    pattern_name VARCHAR(100),
    pattern_type VARCHAR(50),
    conditions JSON,
    actions JSON,
    priority INT,
    active BOOLEAN DEFAULT TRUE,
    INDEX idx_type_active (pattern_type, active)
);

-- Personalization Rules
CREATE TABLE IF NOT EXISTS personalization_rules (
    rule_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    pattern_id BIGINT,
    service_type VARCHAR(50),
    conditions JSON,
    modifications JSON,
    effectiveness_score DECIMAL(5,2),
    last_updated TIMESTAMP,
    INDEX idx_pattern (pattern_id),
    INDEX idx_service (service_type)
);

-- Advanced Analytics Functions
-- ========================

-- Track User Behavior
CREATE PROCEDURE track_behavior(
    IN p_user_id BIGINT,
    IN p_behavior_type VARCHAR(50),
    IN p_context JSON
)
BEGIN
    -- Record behavior
    INSERT INTO user_behaviors (
        user_id,
        behavior_type,
        context
    ) VALUES (
        p_user_id,
        p_behavior_type,
        p_context
    );
    
    -- Update user profile
    UPDATE customer_profiles
    SET preferences = JSON_MERGE_PATCH(
        preferences,
        JSON_OBJECT(
            'recent_behaviors', (
                SELECT JSON_ARRAYAGG(
                    JSON_OBJECT(
                        'type', behavior_type,
                        'context', context,
                        'timestamp', timestamp
                    )
                )
                FROM user_behaviors
                WHERE user_id = p_user_id
                ORDER BY timestamp DESC
                LIMIT 10
            )
        )
    )
    WHERE user_id = p_user_id;
END //

-- Analyze Behavior Patterns
CREATE PROCEDURE analyze_patterns(
    IN p_user_id BIGINT
)
BEGIN
    -- Analyze recent behaviors
    WITH user_patterns AS (
        SELECT 
            behavior_type,
            COUNT(*) as frequency,
            JSON_ARRAYAGG(context) as contexts,
            MIN(timestamp) as first_seen,
            MAX(timestamp) as last_seen
        FROM user_behaviors
        WHERE user_id = p_user_id
        AND timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY behavior_type
    )
    
    -- Update behavior patterns
    INSERT INTO behavior_patterns (
        pattern_name,
        pattern_type,
        conditions,
        actions
    )
    SELECT 
        CONCAT('Pattern_', behavior_type),
        'BEHAVIORAL',
        JSON_OBJECT(
            'behavior_type', behavior_type,
            'min_frequency', frequency,
            'timeframe_days', 30,
            'contexts', contexts
        ),
        JSON_OBJECT(
            'recommended_actions', CASE behavior_type
                WHEN 'SEARCH' THEN '["PERSONALIZE_RESULTS", "SUGGEST_SIMILAR"]'
                WHEN 'BOOKING' THEN '["OFFER_RELATED", "LOYALTY_REWARD"]'
                WHEN 'CANCELLATION' THEN '["RETENTION_OFFER", "FEEDBACK_REQUEST"]'
                ELSE '["STANDARD_ENGAGEMENT"]'
            END
        )
    FROM user_patterns
    ON DUPLICATE KEY UPDATE
        conditions = VALUES(conditions),
        actions = VALUES(actions);
END //

-- Generate Personalization Rules
CREATE PROCEDURE generate_personalization_rules(
    IN p_pattern_id BIGINT
)
BEGIN
    DECLARE v_pattern_type VARCHAR(50);
    DECLARE v_conditions JSON;
    
    -- Get pattern details
    SELECT 
        pattern_type,
        conditions
    INTO 
        v_pattern_type,
        v_conditions
    FROM behavior_patterns
    WHERE pattern_id = p_pattern_id;
    
    -- Create personalization rules
    INSERT INTO personalization_rules (
        pattern_id,
        service_type,
        conditions,
        modifications,
        effectiveness_score
    )
    SELECT 
        p_pattern_id,
        service_type,
        v_conditions,
        CASE v_pattern_type
            WHEN 'BEHAVIORAL' THEN JSON_OBJECT(
                'price_adjustment', JSON_OBJECT(
                    'type', 'DYNAMIC',
                    'factor', 0.9,
                    'max_discount', 0.2
                ),
                'content_personalization', JSON_OBJECT(
                    'priority_features', JSON_EXTRACT(v_conditions, '$.contexts'),
                    'highlight_preferences', TRUE
                ),
                'special_offers', JSON_OBJECT(
                    'type', 'TARGETED',
                    'based_on', 'user_behavior'
                )
            )
            ELSE JSON_OBJECT(
                'standard_modifications', TRUE
            )
        END,
        0.5  -- Initial effectiveness score
    FROM (
        SELECT DISTINCT service_type 
        FROM price_history
    ) services;
END //

-- Behavioral Analytics Dashboard
CREATE OR REPLACE VIEW behavioral_analytics_dashboard AS
SELECT 
    cp.user_id,
    -- Behavior Summary
    JSON_OBJECT(
        'total_behaviors', COUNT(DISTINCT ub.behavior_id),
        'behavior_types', COUNT(DISTINCT ub.behavior_type),
        'most_common', (
            SELECT behavior_type
            FROM user_behaviors ub2
            WHERE ub2.user_id = cp.user_id
            GROUP BY behavior_type
            ORDER BY COUNT(*) DESC
            LIMIT 1
        ),
        'recent_patterns', JSON_EXTRACT(cp.preferences, '$.recent_behaviors')
    ) as behavior_metrics,
    -- Pattern Matching
    JSON_OBJECT(
        'matched_patterns', COUNT(DISTINCT bp.pattern_id),
        'active_rules', COUNT(DISTINCT pr.rule_id),
        'effectiveness', AVG(pr.effectiveness_score)
    ) as pattern_metrics,
    -- Personalization Impact
    JSON_OBJECT(
        'personalized_views', COUNT(DISTINCT CASE 
            WHEN ub.behavior_type = 'VIEW_PERSONALIZED' THEN ub.behavior_id 
            END),
        'conversion_rate', (
            COUNT(DISTINCT CASE 
                WHEN ub.behavior_type = 'BOOKING' THEN ub.behavior_id 
                END) * 100.0 / 
            NULLIF(COUNT(DISTINCT CASE 
                WHEN ub.behavior_type = 'VIEW' THEN ub.behavior_id 
                END), 0)
        )
    ) as impact_metrics
FROM customer_profiles cp
LEFT JOIN user_behaviors ub ON cp.user_id = ub.user_id
LEFT JOIN behavior_patterns bp ON JSON_CONTAINS(
    bp.conditions, 
    JSON_EXTRACT(ub.context, '$.type'),
    '$.behavior_type'
)
LEFT JOIN personalization_rules pr ON bp.pattern_id = pr.pattern_id
GROUP BY cp.user_id;

DELIMITER ;
