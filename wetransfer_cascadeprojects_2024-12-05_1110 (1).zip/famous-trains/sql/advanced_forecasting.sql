USE luxury_travel;

DELIMITER //

-- Advanced Customer Segmentation
-- ===========================

CREATE OR REPLACE VIEW advanced_customer_segments AS
SELECT 
    user_id,
    CASE 
        WHEN total_spent >= 20000 AND bookings >= 20 THEN 'PLATINUM'
        WHEN total_spent >= 10000 AND bookings >= 10 THEN 'GOLD'
        WHEN total_spent >= 5000 OR bookings >= 5 THEN 'SILVER'
        WHEN last_booking > DATE_SUB(NOW(), INTERVAL 3 MONTH) THEN 'ACTIVE'
        WHEN last_booking > DATE_SUB(NOW(), INTERVAL 6 MONTH) THEN 'AT_RISK'
        ELSE 'INACTIVE'
    END as loyalty_tier,
    CASE 
        WHEN avg_booking_value >= 2000 THEN 'HIGH_VALUE'
        WHEN avg_booking_value >= 1000 THEN 'MID_VALUE'
        ELSE 'BUDGET'
    END as value_segment,
    CASE 
        WHEN services_used >= 3 THEN 'MULTI_SERVICE'
        WHEN services_used = 2 THEN 'DUAL_SERVICE'
        ELSE 'SINGLE_SERVICE'
    END as service_usage
FROM (
    SELECT 
        u.user_id,
        SUM(b.total_amount) as total_spent,
        COUNT(*) as bookings,
        AVG(b.total_amount) as avg_booking_value,
        COUNT(DISTINCT b.service_type) as services_used,
        MAX(b.booking_date) as last_booking
    FROM users u
    LEFT JOIN (
        SELECT booking_id, user_id, total_amount, booking_date, 'Train' as service_type FROM train_bookings
        UNION ALL
        SELECT booking_id, user_id, total_amount, booking_date, 'Cruise' FROM cruise_bookings
        UNION ALL
        SELECT rental_id, user_id, total_amount, rental_date, 'Car' FROM car_rentals
    ) b ON u.user_id = b.user_id
    GROUP BY u.user_id
) customer_metrics;

-- Advanced Pricing Strategies
-- ========================

CREATE PROCEDURE calculate_optimal_pricing(
    IN route_id INT,
    IN travel_date DATE
)
BEGIN
    DECLARE base_price DECIMAL(10,2);
    DECLARE final_price DECIMAL(10,2);
    
    -- Factors
    DECLARE season_factor DECIMAL(3,2);
    DECLARE demand_factor DECIMAL(3,2);
    DECLARE competition_factor DECIMAL(3,2);
    DECLARE historical_factor DECIMAL(3,2);
    
    -- Calculate seasonal factor
    SET season_factor = CASE
        WHEN MONTH(travel_date) IN (12,1,7,8) THEN 1.3  -- Peak
        WHEN MONTH(travel_date) IN (6,9) THEN 1.2      -- High
        WHEN MONTH(travel_date) IN (3,4,5,10) THEN 1.1 -- Medium
        ELSE 1.0                                        -- Low
    END;
    
    -- Calculate demand factor
    SELECT 
        CASE
            WHEN COUNT(*) > 150 THEN 1.3
            WHEN COUNT(*) > 100 THEN 1.2
            WHEN COUNT(*) > 50 THEN 1.1
            ELSE 1.0
        END INTO demand_factor
    FROM train_bookings
    WHERE route_id = route_id
    AND booking_date >= DATE_SUB(NOW(), INTERVAL 7 DAY);
    
    -- Calculate historical performance
    SELECT 
        CASE
            WHEN AVG(total_amount) > 2000 THEN 1.2
            WHEN AVG(total_amount) > 1000 THEN 1.1
            ELSE 1.0
        END INTO historical_factor
    FROM train_bookings
    WHERE route_id = route_id
    AND booking_date >= DATE_SUB(NOW(), INTERVAL 30 DAY);
    
    -- Get base price
    SELECT base_price INTO base_price
    FROM route_prices
    WHERE route_id = route_id;
    
    -- Calculate final price
    SET final_price = base_price * season_factor * demand_factor * historical_factor;
    
    -- Update price
    UPDATE route_prices
    SET 
        current_price = final_price,
        last_updated = NOW()
    WHERE route_id = route_id;
END //

-- Advanced Forecasting Models
-- ========================

CREATE PROCEDURE forecast_demand(
    IN forecast_days INT
)
BEGIN
    -- Historical patterns
    WITH historical_patterns AS (
        SELECT 
            DAYNAME(booking_date) as day_of_week,
            MONTH(booking_date) as month,
            AVG(bookings) as avg_bookings,
            AVG(revenue) as avg_revenue
        FROM (
            SELECT 
                booking_date,
                COUNT(*) as bookings,
                SUM(total_amount) as revenue
            FROM train_bookings
            WHERE booking_date >= DATE_SUB(NOW(), INTERVAL 90 DAY)
            GROUP BY booking_date
        ) daily_stats
        GROUP BY DAYNAME(booking_date), MONTH(booking_date)
    )
    
    -- Generate forecast
    SELECT 
        forecast_date,
        DAYNAME(forecast_date) as day_of_week,
        MONTH(forecast_date) as month,
        hp.avg_bookings as predicted_bookings,
        hp.avg_revenue as predicted_revenue,
        CASE 
            WHEN DAYNAME(forecast_date) IN ('Saturday', 'Sunday') THEN 'Weekend'
            ELSE 'Weekday'
        END as day_type,
        CASE 
            WHEN MONTH(forecast_date) IN (12,1,7,8) THEN 'Peak'
            WHEN MONTH(forecast_date) IN (6,9) THEN 'High'
            WHEN MONTH(forecast_date) IN (3,4,5,10) THEN 'Medium'
            ELSE 'Low'
        END as season_type
    FROM (
        SELECT DATE_ADD(CURRENT_DATE, INTERVAL n DAY) as forecast_date
        FROM (
            SELECT a.N + b.N * 10 + c.N * 100 as n
            FROM (SELECT 0 as N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) a
            CROSS JOIN (SELECT 0 as N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) b
            CROSS JOIN (SELECT 0 as N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) c
        ) numbers
        WHERE n < forecast_days
    ) dates
    JOIN historical_patterns hp 
        ON DAYNAME(dates.forecast_date) = hp.day_of_week
        AND MONTH(dates.forecast_date) = hp.month
    ORDER BY forecast_date;
END //

-- Advanced Maintenance
-- =================

CREATE PROCEDURE optimize_system()
BEGIN
    -- Optimize tables
    OPTIMIZE TABLE train_bookings;
    OPTIMIZE TABLE cruise_bookings;
    OPTIMIZE TABLE car_rentals;
    OPTIMIZE TABLE users;
    OPTIMIZE TABLE routes;
    
    -- Update statistics
    ANALYZE TABLE train_bookings;
    ANALYZE TABLE cruise_bookings;
    ANALYZE TABLE car_rentals;
    ANALYZE TABLE users;
    ANALYZE TABLE routes;
    
    -- Clean old data
    CALL cleanup_old_data();
    
    -- Rebuild indexes
    ALTER TABLE train_bookings DROP INDEX idx_booking_date;
    ALTER TABLE train_bookings ADD INDEX idx_booking_date (booking_date);
    
    ALTER TABLE users DROP INDEX idx_last_login;
    ALTER TABLE users ADD INDEX idx_last_login (last_login);
    
    -- Log optimization
    INSERT INTO maintenance_log (
        maintenance_type,
        details,
        status
    ) VALUES (
        'SYSTEM_OPTIMIZATION',
        'Full system optimization completed',
        'SUCCESS'
    );
END //

DELIMITER ;
