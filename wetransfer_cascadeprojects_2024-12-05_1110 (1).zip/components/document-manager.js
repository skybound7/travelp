class DocumentManager {
    constructor() {
        this.documents = new Map();
        this.templates = new Map();
        this.categories = new Set([
            'contracts',
            'invoices',
            'reports',
            'policies',
            'licenses',
            'certificates'
        ]);
        this.currentFolder = 'root';
    }

    async initialize() {
        await this.loadDocuments();
        this.initializeEventListeners();
        this.setupDragAndDrop();
        this.initializeSearch();
    }

    async loadDocuments() {
        try {
            const [docs, templates] = await Promise.all([
                this.fetchDocuments(),
                this.fetchTemplates()
            ]);

            this.documents = new Map(docs.map(doc => [doc.id, doc]));
            this.templates = new Map(templates.map(temp => [temp.id, temp]));

            this.updateDocumentList();
            this.updateTemplateList();
        } catch (error) {
            console.error('Error loading documents:', error);
            this.showError('Failed to load documents');
        }
    }

    async fetchDocuments() {
        const response = await fetch('/api/staff/documents/all.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        const data = await response.json();
        return data.documents;
    }

    async fetchTemplates() {
        const response = await fetch('/api/staff/documents/templates.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        const data = await response.json();
        return data.templates;
    }

    initializeEventListeners() {
        // Upload document
        document.getElementById('upload-doc-btn')?.addEventListener('click', () => {
            this.showUploadModal();
        });

        // Create from template
        document.getElementById('create-from-template-btn')?.addEventListener('click', () => {
            this.showTemplateModal();
        });

        // Document actions
        document.getElementById('document-list')?.addEventListener('click', (e) => {
            const action = e.target.closest('[data-action]');
            if (action) {
                const docId = action.closest('[data-doc-id]').dataset.docId;
                const actionType = action.dataset.action;
                this.handleDocumentAction(docId, actionType);
            }
        });

        // Folder navigation
        document.getElementById('folder-nav')?.addEventListener('click', (e) => {
            const folder = e.target.closest('[data-folder]');
            if (folder) {
                this.navigateToFolder(folder.dataset.folder);
            }
        });

        // Search functionality
        document.getElementById('doc-search')?.addEventListener('input', (e) => {
            this.searchDocuments(e.target.value);
        });
    }

    setupDragAndDrop() {
        const dropZone = document.getElementById('drop-zone');
        if (!dropZone) return;

        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
            });
        });

        dropZone.addEventListener('dragenter', () => dropZone.classList.add('drag-active'));
        dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-active'));
        dropZone.addEventListener('drop', (e) => {
            dropZone.classList.remove('drag-active');
            const files = Array.from(e.dataTransfer.files);
            this.handleFileUpload(files);
        });
    }

    updateDocumentList() {
        const container = document.getElementById('document-list');
        if (!container) return;

        const documents = Array.from(this.documents.values())
            .filter(doc => doc.folder === this.currentFolder);

        container.innerHTML = `
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Size</th>
                            <th>Modified</th>
                            <th>Owner</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${documents.map(doc => `
                            <tr data-doc-id="${doc.id}">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <i class="fas ${this.getFileIcon(doc.type)} me-2"></i>
                                        <div>
                                            <div class="fw-bold">${doc.name}</div>
                                            <small class="text-muted">${doc.type}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-${this.getCategoryColor(doc.category)}">
                                        ${doc.category}
                                    </span>
                                </td>
                                <td>${this.formatFileSize(doc.size)}</td>
                                <td>
                                    <div>${this.formatDate(doc.modified)}</div>
                                    <small class="text-muted">by ${doc.modifiedBy}</small>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="${doc.owner.avatar}" 
                                             class="rounded-circle me-2" width="32">
                                        <div>${doc.owner.name}</div>
                                    </div>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-outline-primary" 
                                                data-action="view">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-success" 
                                                data-action="download">
                                            <i class="fas fa-download"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-warning" 
                                                data-action="share">
                                            <i class="fas fa-share-alt"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" 
                                                data-action="delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }

    async handleFileUpload(files) {
        const formData = new FormData();
        files.forEach(file => {
            formData.append('files[]', file);
        });
        formData.append('folder', this.currentFolder);

        try {
            const response = await fetch('/api/staff/documents/upload.php', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: formData
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.showSuccess('Files uploaded successfully');
                await this.loadDocuments();
            }
        } catch (error) {
            console.error('Error uploading files:', error);
            this.showError('Failed to upload files');
        }
    }

    async handleDocumentAction(docId, action) {
        const doc = this.documents.get(docId);
        if (!doc) return;

        switch (action) {
            case 'view':
                this.viewDocument(doc);
                break;
            case 'download':
                await this.downloadDocument(doc);
                break;
            case 'share':
                this.showShareModal(doc);
                break;
            case 'delete':
                this.confirmDeleteDocument(doc);
                break;
        }
    }

    async downloadDocument(doc) {
        try {
            const response = await fetch(`/api/staff/documents/download.php?id=${doc.id}`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const blob = await response.blob();
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = doc.name;
            document.body.appendChild(a);
            a.click();
            URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } catch (error) {
            console.error('Error downloading document:', error);
            this.showError('Failed to download document');
        }
    }

    // Utility functions
    getFileIcon(type) {
        const icons = {
            'pdf': 'fa-file-pdf',
            'doc': 'fa-file-word',
            'docx': 'fa-file-word',
            'xls': 'fa-file-excel',
            'xlsx': 'fa-file-excel',
            'jpg': 'fa-file-image',
            'png': 'fa-file-image'
        };
        return icons[type.toLowerCase()] || 'fa-file';
    }

    getCategoryColor(category) {
        const colors = {
            contracts: 'primary',
            invoices: 'success',
            reports: 'info',
            policies: 'warning',
            licenses: 'danger',
            certificates: 'secondary'
        };
        return colors[category.toLowerCase()] || 'secondary';
    }

    formatFileSize(bytes) {
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        if (bytes === 0) return '0 Bytes';
        const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
    }

    formatDate(date) {
        return new Date(date).toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize DocumentManager when the document management page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.document-manager')) {
        const documentManager = new DocumentManager();
        documentManager.initialize();
    }
});
