class SupportManager {
    constructor() {
        this.tickets = new Map();
        this.knowledgeBase = new Map();
        this.priorities = ['low', 'medium', 'high', 'urgent'];
        this.categories = [
            'booking',
            'payment',
            'vehicle',
            'driver',
            'route',
            'technical',
            'general'
        ];
        this.activeFilters = {
            status: 'all',
            priority: 'all',
            category: 'all'
        };
    }

    async initialize() {
        await this.loadSupportData();
        this.initializeEventListeners();
        this.initializeCharts();
        this.setupLiveChat();
    }

    async loadSupportData() {
        try {
            const [tickets, articles] = await Promise.all([
                this.fetchTickets(),
                this.fetchKnowledgeBase()
            ]);

            this.tickets = new Map(tickets.map(t => [t.id, t]));
            this.knowledgeBase = new Map(articles.map(a => [a.id, a]));

            this.updateDashboard();
        } catch (error) {
            console.error('Error loading support data:', error);
            this.showError('Failed to load support data');
        }
    }

    async fetchTickets() {
        const response = await fetch('/api/staff/support/tickets.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        const data = await response.json();
        return data.tickets;
    }

    async fetchKnowledgeBase() {
        const response = await fetch('/api/staff/support/knowledge-base.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        const data = await response.json();
        return data.articles;
    }

    initializeEventListeners() {
        // Create ticket
        document.getElementById('create-ticket-btn')?.addEventListener('click', () => {
            this.showTicketModal();
        });

        // Add KB article
        document.getElementById('add-article-btn')?.addEventListener('click', () => {
            this.showArticleModal();
        });

        // Filter tickets
        document.querySelectorAll('.ticket-filter')?.forEach(filter => {
            filter.addEventListener('change', (e) => {
                this.activeFilters[e.target.name] = e.target.value;
                this.updateTicketList();
            });
        });

        // Search functionality
        document.getElementById('ticket-search')?.addEventListener('input', (e) => {
            this.searchTickets(e.target.value);
        });

        // Quick responses
        document.getElementById('quick-responses')?.addEventListener('click', (e) => {
            const response = e.target.closest('[data-response]');
            if (response) {
                this.insertQuickResponse(response.dataset.response);
            }
        });
    }

    updateDashboard() {
        this.updateTicketList();
        this.updateKnowledgeBase();
        this.updateMetrics();
        this.updateCharts();
    }

    updateTicketList() {
        const container = document.getElementById('ticket-list');
        if (!container) return;

        const filteredTickets = this.filterTickets();

        container.innerHTML = `
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Customer</th>
                            <th>Subject</th>
                            <th>Category</th>
                            <th>Priority</th>
                            <th>Status</th>
                            <th>Assigned To</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${filteredTickets.map(ticket => `
                            <tr data-ticket-id="${ticket.id}">
                                <td>#${ticket.id}</td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="${ticket.customer.avatar}" 
                                             class="rounded-circle me-2" width="32">
                                        <div>
                                            <div>${ticket.customer.name}</div>
                                            <small class="text-muted">${ticket.customer.email}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="fw-bold">${ticket.subject}</div>
                                    <small class="text-muted">
                                        ${this.truncateText(ticket.description, 50)}
                                    </small>
                                </td>
                                <td>
                                    <span class="badge bg-${this.getCategoryColor(ticket.category)}">
                                        ${ticket.category}
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-${this.getPriorityColor(ticket.priority)}">
                                        ${ticket.priority}
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-${this.getStatusColor(ticket.status)}">
                                        ${ticket.status}
                                    </span>
                                </td>
                                <td>
                                    ${ticket.assignedTo ? `
                                        <div class="d-flex align-items-center">
                                            <img src="${ticket.assignedTo.avatar}" 
                                                 class="rounded-circle me-2" width="32">
                                            <div>${ticket.assignedTo.name}</div>
                                        </div>
                                    ` : '<span class="text-muted">Unassigned</span>'}
                                </td>
                                <td>
                                    <div>${this.formatDate(ticket.created)}</div>
                                    <small class="text-muted">
                                        ${this.getTimeAgo(ticket.created)}
                                    </small>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-outline-primary view-ticket"
                                                title="View Ticket">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-success reply-ticket"
                                                title="Reply">
                                            <i class="fas fa-reply"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-warning assign-ticket"
                                                title="Assign">
                                            <i class="fas fa-user-plus"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger close-ticket"
                                                title="Close"
                                                ${ticket.status === 'closed' ? 'disabled' : ''}>
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;

        this.addTicketEventListeners();
    }

    updateKnowledgeBase() {
        const container = document.getElementById('knowledge-base');
        if (!container) return;

        container.innerHTML = `
            <div class="row">
                ${Array.from(this.knowledgeBase.values()).map(article => `
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card h-100">
                            <div class="card-body">
                                <h5 class="card-title">${article.title}</h5>
                                <p class="card-text">
                                    ${this.truncateText(article.content, 150)}
                                </p>
                                <div class="d-flex justify-content-between align-items-center mt-3">
                                    <span class="badge bg-info">
                                        ${article.category}
                                    </span>
                                    <button class="btn btn-sm btn-outline-primary view-article"
                                            data-article-id="${article.id}">
                                        Read More
                                    </button>
                                </div>
                            </div>
                            <div class="card-footer text-muted">
                                <small>
                                    Last updated: ${this.formatDate(article.updated)}
                                </small>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;

        this.addArticleEventListeners();
    }

    async replyToTicket(ticketId, message) {
        try {
            const response = await fetch('/api/staff/support/reply.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({
                    ticketId,
                    message
                })
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.showSuccess('Reply sent successfully');
                await this.loadSupportData();
            }
        } catch (error) {
            console.error('Error sending reply:', error);
            this.showError('Failed to send reply');
        }
    }

    // Utility functions
    filterTickets() {
        return Array.from(this.tickets.values()).filter(ticket => {
            if (this.activeFilters.status !== 'all' && 
                ticket.status !== this.activeFilters.status) return false;
            if (this.activeFilters.priority !== 'all' && 
                ticket.priority !== this.activeFilters.priority) return false;
            if (this.activeFilters.category !== 'all' && 
                ticket.category !== this.activeFilters.category) return false;
            return true;
        });
    }

    getCategoryColor(category) {
        const colors = {
            booking: 'primary',
            payment: 'success',
            vehicle: 'info',
            driver: 'warning',
            route: 'secondary',
            technical: 'danger',
            general: 'dark'
        };
        return colors[category.toLowerCase()] || 'secondary';
    }

    getPriorityColor(priority) {
        const colors = {
            low: 'success',
            medium: 'info',
            high: 'warning',
            urgent: 'danger'
        };
        return colors[priority.toLowerCase()] || 'secondary';
    }

    getStatusColor(status) {
        const colors = {
            open: 'success',
            pending: 'warning',
            'in-progress': 'info',
            resolved: 'primary',
            closed: 'secondary'
        };
        return colors[status.toLowerCase()] || 'secondary';
    }

    formatDate(date) {
        return new Date(date).toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    }

    getTimeAgo(date) {
        const seconds = Math.floor((new Date() - new Date(date)) / 1000);
        const intervals = {
            year: 31536000,
            month: 2592000,
            week: 604800,
            day: 86400,
            hour: 3600,
            minute: 60
        };

        for (const [unit, secondsInUnit] of Object.entries(intervals)) {
            const interval = Math.floor(seconds / secondsInUnit);
            if (interval >= 1) {
                return `${interval} ${unit}${interval === 1 ? '' : 's'} ago`;
            }
        }
        return 'Just now';
    }

    truncateText(text, length) {
        if (text.length <= length) return text;
        return text.substring(0, length) + '...';
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize SupportManager when the support page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.support-manager')) {
        const supportManager = new SupportManager();
        supportManager.initialize();
    }
});
