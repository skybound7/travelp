class InventoryManager {
    constructor() {
        this.inventory = new Map();
        this.suppliers = new Map();
        this.orders = new Map();
        this.categories = [
            'vehicle_parts',
            'office_supplies',
            'uniforms',
            'cleaning_supplies',
            'safety_equipment',
            'tools'
        ];
        this.lowStockThreshold = 10;
    }

    async initialize() {
        await this.loadInventoryData();
        this.initializeEventListeners();
        this.setupAutoReorder();
        this.initializeBarcodeScan();
    }

    async loadInventoryData() {
        try {
            const [items, suppliers, orders] = await Promise.all([
                this.fetchInventory(),
                this.fetchSuppliers(),
                this.fetchOrders()
            ]);

            this.inventory = new Map(items.map(item => [item.id, item]));
            this.suppliers = new Map(suppliers.map(supplier => [supplier.id, supplier]));
            this.orders = new Map(orders.map(order => [order.id, order]));

            this.updateDashboard();
        } catch (error) {
            console.error('Error loading inventory data:', error);
            this.showError('Failed to load inventory data');
        }
    }

    async fetchInventory() {
        const response = await fetch('/api/staff/inventory/items.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        const data = await response.json();
        return data.items;
    }

    initializeEventListeners() {
        // Add item
        document.getElementById('add-item-btn')?.addEventListener('click', () => {
            this.showItemModal();
        });

        // Place order
        document.getElementById('place-order-btn')?.addEventListener('click', () => {
            this.showOrderModal();
        });

        // Stock adjustment
        document.getElementById('adjust-stock-btn')?.addEventListener('click', () => {
            this.showAdjustmentModal();
        });

        // Barcode scanner
        document.getElementById('barcode-input')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.handleBarcodeInput(e.target.value);
            }
        });

        // Category filters
        document.querySelectorAll('.category-filter')?.forEach(filter => {
            filter.addEventListener('change', (e) => {
                this.filterInventory(e.target.value);
            });
        });

        // Search
        document.getElementById('inventory-search')?.addEventListener('input', (e) => {
            this.searchInventory(e.target.value);
        });
    }

    updateDashboard() {
        this.updateInventoryList();
        this.updateOrdersList();
        this.updateLowStockAlerts();
        this.updateMetrics();
    }

    updateInventoryList() {
        const container = document.getElementById('inventory-list');
        if (!container) return;

        container.innerHTML = `
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Category</th>
                            <th>Stock Level</th>
                            <th>Unit Price</th>
                            <th>Supplier</th>
                            <th>Last Updated</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${Array.from(this.inventory.values()).map(item => `
                            <tr data-item-id="${item.id}">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="${item.image}" class="me-2" width="48">
                                        <div>
                                            <div class="fw-bold">${item.name}</div>
                                            <small class="text-muted">${item.sku}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-${this.getCategoryColor(item.category)}">
                                        ${this.formatCategory(item.category)}
                                    </span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="me-2">
                                            <div class="fw-bold ${
                                                this.getStockLevelColor(item.stockLevel)
                                            }">
                                                ${item.stockLevel}
                                            </div>
                                            <small class="text-muted">
                                                Min: ${item.minStock}
                                            </small>
                                        </div>
                                        <div class="progress" style="width: 100px; height: 8px;">
                                            <div class="progress-bar bg-${
                                                this.getStockLevelColor(item.stockLevel)
                                            }" style="width: ${
                                                this.calculateStockPercentage(item)
                                            }%"></div>
                                        </div>
                                    </div>
                                </td>
                                <td>${this.formatCurrency(item.unitPrice)}</td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="${item.supplier.logo}" 
                                             class="rounded-circle me-2" width="32">
                                        <div>
                                            <div>${item.supplier.name}</div>
                                            <small class="text-muted">${
                                                item.supplier.contact
                                            }</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div>${this.formatDate(item.lastUpdated)}</div>
                                    <small class="text-muted">
                                        by ${item.lastUpdatedBy}
                                    </small>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-outline-primary edit-item"
                                                title="Edit Item">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-success adjust-stock"
                                                title="Adjust Stock">
                                            <i class="fas fa-plus-minus"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-info order-item"
                                                title="Order Item">
                                            <i class="fas fa-shopping-cart"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-warning history"
                                                title="View History">
                                            <i class="fas fa-history"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;

        this.addInventoryEventListeners();
    }

    updateLowStockAlerts() {
        const container = document.getElementById('low-stock-alerts');
        if (!container) return;

        const lowStockItems = Array.from(this.inventory.values())
            .filter(item => item.stockLevel <= item.minStock);

        container.innerHTML = `
            <div class="alert alert-warning mb-0">
                <h6 class="alert-heading mb-2">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Low Stock Alerts
                </h6>
                ${lowStockItems.length > 0 ? `
                    <ul class="list-unstyled mb-0">
                        ${lowStockItems.map(item => `
                            <li class="mb-2">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>${item.name}</strong>
                                        <small class="text-muted">(${item.sku})</small>
                                    </div>
                                    <button class="btn btn-sm btn-warning order-now"
                                            data-item-id="${item.id}">
                                        Order Now
                                    </button>
                                </div>
                                <div class="progress mt-1" style="height: 4px;">
                                    <div class="progress-bar bg-warning" 
                                         style="width: ${
                                             this.calculateStockPercentage(item)
                                         }%"></div>
                                </div>
                            </li>
                        `).join('')}
                    </ul>
                ` : `
                    <p class="mb-0">No items currently at low stock levels.</p>
                `}
            </div>
        `;
    }

    async placeOrder(itemId, quantity) {
        try {
            const response = await fetch('/api/staff/inventory/order.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({
                    itemId,
                    quantity
                })
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.showSuccess('Order placed successfully');
                await this.loadInventoryData();
            }
        } catch (error) {
            console.error('Error placing order:', error);
            this.showError('Failed to place order');
        }
    }

    // Utility functions
    getCategoryColor(category) {
        const colors = {
            vehicle_parts: 'primary',
            office_supplies: 'success',
            uniforms: 'info',
            cleaning_supplies: 'warning',
            safety_equipment: 'danger',
            tools: 'secondary'
        };
        return colors[category] || 'secondary';
    }

    formatCategory(category) {
        return category
            .split('_')
            .map(word => word.charAt(0).toUpperCase() + word.slice(1))
            .join(' ');
    }

    getStockLevelColor(level) {
        if (level <= 0) return 'text-danger';
        if (level <= this.lowStockThreshold) return 'text-warning';
        return 'text-success';
    }

    calculateStockPercentage(item) {
        const maxStock = Math.max(item.minStock * 2, item.stockLevel);
        return Math.min(100, (item.stockLevel / maxStock) * 100);
    }

    formatCurrency(amount) {
        return new Intl.NumberFormat('en-GB', {
            style: 'currency',
            currency: 'GBP'
        }).format(amount);
    }

    formatDate(date) {
        return new Date(date).toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize InventoryManager when the inventory page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.inventory-manager')) {
        const inventoryManager = new InventoryManager();
        inventoryManager.initialize();
    }
});
