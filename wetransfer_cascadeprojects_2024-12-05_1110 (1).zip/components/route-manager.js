class RouteManager {
    constructor() {
        this.map = null;
        this.directionsService = null;
        this.directionsRenderer = null;
        this.activeRoutes = [];
        this.markers = [];
        this.routeOptimizer = null;
    }

    async initialize() {
        this.initializeGoogleMaps();
        this.initializeEventListeners();
        await this.loadActiveRoutes();
        this.initializeRouteOptimizer();
    }

    initializeGoogleMaps() {
        this.map = new google.maps.Map(document.getElementById('route-map'), {
            zoom: 12,
            center: { lat: 51.5074, lng: -0.1278 }, // London center
            mapTypeId: google.maps.MapTypeId.ROADMAP
        });

        this.directionsService = new google.maps.DirectionsService();
        this.directionsRenderer = new google.maps.DirectionsRenderer({
            map: this.map,
            suppressMarkers: true
        });
    }

    initializeEventListeners() {
        // Route creation form
        document.getElementById('route-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.createRoute();
        });

        // Route optimization controls
        document.getElementById('optimize-routes')?.addEventListener('click', () => {
            this.optimizeRoutes();
        });

        // Route filters
        document.getElementById('route-filter')?.addEventListener('change', (e) => {
            this.filterRoutes(e.target.value);
        });

        // Time slot selector
        document.getElementById('time-slot')?.addEventListener('change', (e) => {
            this.loadRoutesByTimeSlot(e.target.value);
        });

        // Driver assignment
        document.getElementById('assign-driver')?.addEventListener('click', () => {
            this.assignDriver();
        });
    }

    async loadActiveRoutes() {
        try {
            const response = await fetch('/api/staff/routes/active.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.activeRoutes = data.routes;
                this.displayRoutes();
                this.updateRoutesList();
            }
        } catch (error) {
            console.error('Error loading active routes:', error);
            this.showError('Failed to load active routes');
        }
    }

    displayRoutes() {
        // Clear existing markers
        this.clearMarkers();

        this.activeRoutes.forEach(route => {
            // Add markers for pickup and dropoff points
            this.addRouteMarkers(route);
            // Draw route on map
            this.drawRoute(route);
        });

        // Fit map bounds to show all markers
        this.fitMapToMarkers();
    }

    addRouteMarkers(route) {
        // Pickup point marker
        const pickupMarker = new google.maps.Marker({
            position: route.pickup.location,
            map: this.map,
            icon: 'assets/images/pickup-marker.png',
            title: `Pickup: ${route.pickup.address}`
        });

        // Dropoff point marker
        const dropoffMarker = new google.maps.Marker({
            position: route.dropoff.location,
            map: this.map,
            icon: 'assets/images/dropoff-marker.png',
            title: `Dropoff: ${route.dropoff.address}`
        });

        // Add info windows
        this.addMarkerInfoWindow(pickupMarker, route, 'pickup');
        this.addMarkerInfoWindow(dropoffMarker, route, 'dropoff');

        this.markers.push(pickupMarker, dropoffMarker);
    }

    addMarkerInfoWindow(marker, route, type) {
        const infoWindow = new google.maps.InfoWindow({
            content: `
                <div class="route-info-window">
                    <h6>${type === 'pickup' ? 'Pickup' : 'Dropoff'} Point</h6>
                    <p><strong>Address:</strong> ${type === 'pickup' ? route.pickup.address : route.dropoff.address}</p>
                    <p><strong>Time:</strong> ${this.formatTime(type === 'pickup' ? route.pickup.time : route.dropoff.time)}</p>
                    <p><strong>Customer:</strong> ${route.customer.name}</p>
                    ${route.driver ? `<p><strong>Driver:</strong> ${route.driver.name}</p>` : ''}
                </div>
            `
        });

        marker.addListener('click', () => {
            infoWindow.open(this.map, marker);
        });
    }

    async drawRoute(route) {
        const request = {
            origin: route.pickup.location,
            destination: route.dropoff.location,
            travelMode: google.maps.TravelMode.DRIVING,
            drivingOptions: {
                departureTime: new Date(route.pickup.time),
                trafficModel: google.maps.TrafficModel.BEST_GUESS
            }
        };

        try {
            const result = await this.directionsService.route(request);
            const routeLine = new google.maps.DirectionsRenderer({
                map: this.map,
                directions: result,
                suppressMarkers: true,
                polylineOptions: {
                    strokeColor: this.getRouteColor(route.status),
                    strokeWeight: 5
                }
            });
        } catch (error) {
            console.error('Error drawing route:', error);
        }
    }

    updateRoutesList() {
        const container = document.getElementById('routes-list');
        if (!container) return;

        container.innerHTML = this.activeRoutes.map(route => `
            <div class="route-item ${route.status.toLowerCase()}" data-route-id="${route.id}">
                <div class="route-header">
                    <div class="route-info">
                        <span class="badge bg-${this.getStatusColor(route.status)}">
                            ${route.status}
                        </span>
                        <span class="route-id">#${route.id}</span>
                    </div>
                    <div class="route-actions">
                        <button class="btn btn-sm btn-outline-primary view-route">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-success assign-driver" 
                                ${route.driver ? 'disabled' : ''}>
                            <i class="fas fa-user-plus"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger cancel-route"
                                ${route.status === 'COMPLETED' ? 'disabled' : ''}>
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
                <div class="route-details">
                    <div class="route-points">
                        <div class="pickup-point">
                            <i class="fas fa-map-marker-alt text-success"></i>
                            <div>
                                <strong>Pickup:</strong> ${route.pickup.address}
                                <div class="text-muted">${this.formatTime(route.pickup.time)}</div>
                            </div>
                        </div>
                        <div class="route-divider">
                            <i class="fas fa-arrow-down"></i>
                            <span>${route.distance} km • ${route.duration} mins</span>
                        </div>
                        <div class="dropoff-point">
                            <i class="fas fa-map-marker-alt text-danger"></i>
                            <div>
                                <strong>Dropoff:</strong> ${route.dropoff.address}
                                <div class="text-muted">${this.formatTime(route.dropoff.time)}</div>
                            </div>
                        </div>
                    </div>
                    <div class="route-meta">
                        <div class="customer-info">
                            <img src="${route.customer.avatar}" class="rounded-circle" width="32">
                            <div>
                                <div class="customer-name">${route.customer.name}</div>
                                <small class="text-muted">${route.customer.phone}</small>
                            </div>
                        </div>
                        ${route.driver ? `
                            <div class="driver-info">
                                <img src="${route.driver.avatar}" class="rounded-circle" width="32">
                                <div>
                                    <div class="driver-name">${route.driver.name}</div>
                                    <small class="text-muted">${route.driver.vehicle}</small>
                                </div>
                            </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        `).join('');

        this.addRouteItemEventListeners();
    }

    async optimizeRoutes() {
        try {
            const response = await fetch('/api/staff/routes/optimize.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({
                    routes: this.activeRoutes.map(route => route.id)
                })
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.activeRoutes = data.optimizedRoutes;
                this.displayRoutes();
                this.updateRoutesList();
                this.showSuccess('Routes optimized successfully');
            }
        } catch (error) {
            console.error('Error optimizing routes:', error);
            this.showError('Failed to optimize routes');
        }
    }

    async assignDriver() {
        const selectedRoute = document.querySelector('.route-item.selected');
        if (!selectedRoute) return;

        const routeId = selectedRoute.dataset.routeId;
        const driverId = document.getElementById('driver-select').value;

        try {
            const response = await fetch(`/api/staff/routes/${routeId}/assign.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({ driverId })
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.updateRouteDriver(routeId, data.driver);
                this.showSuccess('Driver assigned successfully');
            }
        } catch (error) {
            console.error('Error assigning driver:', error);
            this.showError('Failed to assign driver');
        }
    }

    // Utility functions
    clearMarkers() {
        this.markers.forEach(marker => marker.setMap(null));
        this.markers = [];
    }

    fitMapToMarkers() {
        if (this.markers.length === 0) return;

        const bounds = new google.maps.LatLngBounds();
        this.markers.forEach(marker => bounds.extend(marker.getPosition()));
        this.map.fitBounds(bounds);
    }

    formatTime(timestamp) {
        return new Date(timestamp).toLocaleTimeString([], { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
    }

    getRouteColor(status) {
        const colors = {
            PENDING: '#f1c40f',
            ASSIGNED: '#3498db',
            IN_PROGRESS: '#2ecc71',
            COMPLETED: '#95a5a6',
            CANCELLED: '#e74c3c'
        };
        return colors[status] || '#95a5a6';
    }

    getStatusColor(status) {
        const colors = {
            PENDING: 'warning',
            ASSIGNED: 'primary',
            IN_PROGRESS: 'success',
            COMPLETED: 'secondary',
            CANCELLED: 'danger'
        };
        return colors[status] || 'secondary';
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize RouteManager when the routes page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.route-manager')) {
        const routeManager = new RouteManager();
        routeManager.initialize();
    }
});
