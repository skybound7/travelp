class PayrollManager {
    constructor() {
        this.payroll = new Map();
        this.timesheets = new Map();
        this.staff = new Map();
        this.payPeriods = new Map();
        this.paymentTypes = [
            'salary',
            'hourly',
            'overtime',
            'bonus',
            'commission',
            'deduction'
        ];
    }

    async initialize() {
        await this.loadPayrollData();
        this.initializeEventListeners();
        this.setupCharts();
        this.calculatePayroll();
    }

    async loadPayrollData() {
        try {
            const [payroll, timesheets, staff, payPeriods] = await Promise.all([
                this.fetchPayroll(),
                this.fetchTimesheets(),
                this.fetchStaff(),
                this.fetchPayPeriods()
            ]);

            this.payroll = new Map(payroll.map(p => [p.id, p]));
            this.timesheets = new Map(timesheets.map(t => [t.id, t]));
            this.staff = new Map(staff.map(s => [s.id, s]));
            this.payPeriods = new Map(payPeriods.map(p => [p.id, p]));

            this.updatePayrollView();
        } catch (error) {
            console.error('Error loading payroll data:', error);
            this.showError('Failed to load payroll data');
        }
    }

    async fetchPayroll() {
        const response = await fetch('/api/staff/payroll/list.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        return await response.json();
    }

    initializeEventListeners() {
        // Process payroll
        document.getElementById('process-payroll-btn')?.addEventListener('click', () => {
            this.processPayroll();
        });

        // Approve timesheets
        document.getElementById('approve-timesheets-btn')?.addEventListener('click', () => {
            this.approveTimesheets();
        });

        // Pay period selection
        document.getElementById('pay-period-select')?.addEventListener('change', (e) => {
            this.loadPayPeriodData(e.target.value);
        });

        // Staff filters
        document.getElementById('staff-filter')?.addEventListener('change', (e) => {
            this.filterPayrollByStaff(e.target.value);
        });

        // Export payroll
        document.getElementById('export-payroll-btn')?.addEventListener('click', () => {
            this.exportPayroll();
        });
    }

    updatePayrollView() {
        this.updatePayrollSummary();
        this.updateTimesheetsList();
        this.updatePaymentHistory();
        this.updatePayrollMetrics();
    }

    updatePayrollSummary() {
        const container = document.getElementById('payroll-summary');
        if (!container) return;

        const currentPeriod = this.getCurrentPayPeriod();
        const totalPayroll = this.calculateTotalPayroll(currentPeriod);

        container.innerHTML = `
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Payroll Summary</h5>
                    <h6 class="card-subtitle mb-3 text-muted">
                        Pay Period: ${this.formatDateRange(currentPeriod)}
                    </h6>
                    
                    <div class="row g-3">
                        <div class="col-md-3">
                            <div class="border rounded p-3">
                                <div class="text-muted small">Total Payroll</div>
                                <div class="h4 mb-0">
                                    ${this.formatCurrency(totalPayroll.total)}
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="border rounded p-3">
                                <div class="text-muted small">Base Salary</div>
                                <div class="h4 mb-0">
                                    ${this.formatCurrency(totalPayroll.baseSalary)}
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="border rounded p-3">
                                <div class="text-muted small">Overtime</div>
                                <div class="h4 mb-0">
                                    ${this.formatCurrency(totalPayroll.overtime)}
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="border rounded p-3">
                                <div class="text-muted small">Deductions</div>
                                <div class="h4 mb-0 text-danger">
                                    -${this.formatCurrency(totalPayroll.deductions)}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mt-4">
                        <h6>Quick Actions</h6>
                        <div class="btn-group">
                            <button class="btn btn-primary" id="process-payroll-btn">
                                <i class="fas fa-money-bill-wave me-2"></i>
                                Process Payroll
                            </button>
                            <button class="btn btn-success" id="approve-timesheets-btn">
                                <i class="fas fa-check-circle me-2"></i>
                                Approve Timesheets
                            </button>
                            <button class="btn btn-info" id="export-payroll-btn">
                                <i class="fas fa-file-export me-2"></i>
                                Export Payroll
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    updateTimesheetsList() {
        const container = document.getElementById('timesheets-list');
        if (!container) return;

        container.innerHTML = `
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Staff Member</th>
                            <th>Date</th>
                            <th>Hours</th>
                            <th>Overtime</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${Array.from(this.timesheets.values())
                            .sort((a, b) => new Date(b.date) - new Date(a.date))
                            .map(timesheet => `
                                <tr data-timesheet-id="${timesheet.id}">
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <img src="${
                                                this.staff.get(timesheet.staffId)?.avatar
                                            }" 
                                                 class="rounded-circle me-2" 
                                                 width="32">
                                            ${this.staff.get(timesheet.staffId)?.name}
                                        </div>
                                    </td>
                                    <td>${this.formatDate(timesheet.date)}</td>
                                    <td>${timesheet.regularHours}</td>
                                    <td>${timesheet.overtimeHours}</td>
                                    <td>
                                        <span class="badge bg-${
                                            this.getTimesheetStatusColor(timesheet.status)
                                        }">
                                            ${this.formatTimesheetStatus(timesheet.status)}
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <button class="btn btn-sm btn-outline-primary view-timesheet"
                                                    title="View Details">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn btn-sm btn-outline-success approve-timesheet"
                                                    title="Approve"
                                                    ${timesheet.status !== 'pending' ? 'disabled' : ''}>
                                                <i class="fas fa-check"></i>
                                            </button>
                                            <button class="btn btn-sm btn-outline-danger reject-timesheet"
                                                    title="Reject"
                                                    ${timesheet.status !== 'pending' ? 'disabled' : ''}>
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }

    // Utility functions
    formatCurrency(amount) {
        return new Intl.NumberFormat('en-GB', {
            style: 'currency',
            currency: 'GBP'
        }).format(amount);
    }

    formatDate(date) {
        return new Date(date).toLocaleDateString('en-GB', {
            weekday: 'short',
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    }

    formatDateRange(period) {
        return `${this.formatDate(period.startDate)} - ${this.formatDate(period.endDate)}`;
    }

    getTimesheetStatusColor(status) {
        const colors = {
            pending: 'warning',
            approved: 'success',
            rejected: 'danger'
        };
        return colors[status] || 'secondary';
    }

    formatTimesheetStatus(status) {
        return status.charAt(0).toUpperCase() + status.slice(1);
    }

    getCurrentPayPeriod() {
        const currentDate = new Date();
        return Array.from(this.payPeriods.values())
            .find(period => 
                new Date(period.startDate) <= currentDate && 
                new Date(period.endDate) >= currentDate
            );
    }

    calculateTotalPayroll(period) {
        let total = 0;
        let baseSalary = 0;
        let overtime = 0;
        let deductions = 0;

        this.payroll.forEach(payment => {
            if (this.isInPayPeriod(payment.date, period)) {
                total += payment.amount;
                switch (payment.type) {
                    case 'salary':
                        baseSalary += payment.amount;
                        break;
                    case 'overtime':
                        overtime += payment.amount;
                        break;
                    case 'deduction':
                        deductions += payment.amount;
                        break;
                }
            }
        });

        return { total, baseSalary, overtime, deductions };
    }

    isInPayPeriod(date, period) {
        const paymentDate = new Date(date);
        return paymentDate >= new Date(period.startDate) && 
               paymentDate <= new Date(period.endDate);
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize PayrollManager when the payroll page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.payroll-manager')) {
        const payrollManager = new PayrollManager();
        payrollManager.initialize();
    }
});
