class CommunicationManager {
    constructor() {
        this.messages = [];
        this.notifications = [];
        this.templates = {};
        this.activeChat = null;
        this.socket = null;
        this.unreadCount = 0;
    }

    async initialize() {
        await this.loadMessageTemplates();
        this.initializeWebSocket();
        this.initializeEventListeners();
        await this.loadNotifications();
        await this.loadRecentMessages();
    }

    initializeWebSocket() {
        this.socket = new WebSocket('wss://your-websocket-server/staff-communications');
        
        this.socket.onmessage = (event) => {
            const data = JSON.parse(event.data);
            switch (data.type) {
                case 'message':
                    this.handleNewMessage(data.message);
                    break;
                case 'notification':
                    this.handleNewNotification(data.notification);
                    break;
                case 'status':
                    this.updateCustomerStatus(data.customerId, data.status);
                    break;
            }
        };

        this.socket.onclose = () => {
            setTimeout(() => this.initializeWebSocket(), 5000); // Reconnect after 5 seconds
        };
    }

    initializeEventListeners() {
        // Message composition
        document.getElementById('message-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.sendMessage();
        });

        // Template selection
        document.getElementById('template-select')?.addEventListener('change', (e) => {
            this.loadTemplate(e.target.value);
        });

        // Customer search
        document.getElementById('customer-search')?.addEventListener('input', debounce((e) => {
            this.searchCustomers(e.target.value);
        }, 300));

        // Notification preferences
        document.getElementById('notification-preferences')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.updateNotificationPreferences();
        });

        // Bulk message form
        document.getElementById('bulk-message-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.sendBulkMessage();
        });

        // Chat window controls
        document.querySelectorAll('.chat-window').forEach(window => {
            window.querySelector('.minimize')?.addEventListener('click', () => {
                window.classList.toggle('minimized');
            });
            window.querySelector('.close')?.addEventListener('click', () => {
                this.closeChat(window.dataset.customerId);
            });
        });
    }

    async loadMessageTemplates() {
        try {
            const response = await fetch('/api/staff/communications/templates.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.templates = data.templates;
                this.updateTemplateSelector();
            }
        } catch (error) {
            console.error('Error loading message templates:', error);
            this.showError('Failed to load message templates');
        }
    }

    async loadNotifications() {
        try {
            const response = await fetch('/api/staff/communications/notifications.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.notifications = data.notifications;
                this.updateNotificationPanel();
            }
        } catch (error) {
            console.error('Error loading notifications:', error);
            this.showError('Failed to load notifications');
        }
    }

    async loadRecentMessages() {
        try {
            const response = await fetch('/api/staff/communications/messages.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.messages = data.messages;
                this.updateMessagesList();
            }
        } catch (error) {
            console.error('Error loading messages:', error);
            this.showError('Failed to load messages');
        }
    }

    async sendMessage() {
        const form = document.getElementById('message-form');
        const formData = new FormData(form);

        try {
            const response = await fetch('/api/staff/communications/send.php', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: formData
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.showSuccess('Message sent successfully');
                form.reset();
                this.updateMessagesList();
            }
        } catch (error) {
            console.error('Error sending message:', error);
            this.showError('Failed to send message');
        }
    }

    async sendBulkMessage() {
        const form = document.getElementById('bulk-message-form');
        const formData = new FormData(form);

        try {
            const response = await fetch('/api/staff/communications/bulk-send.php', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: formData
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.showSuccess('Bulk message sent successfully');
                form.reset();
            }
        } catch (error) {
            console.error('Error sending bulk message:', error);
            this.showError('Failed to send bulk message');
        }
    }

    updateMessagesList() {
        const container = document.getElementById('messages-list');
        if (!container) return;

        container.innerHTML = this.messages.map(message => `
            <div class="message-item ${message.unread ? 'unread' : ''}" data-message-id="${message.id}">
                <div class="message-header">
                    <div class="message-sender">
                        <img src="${message.sender.avatar}" class="rounded-circle me-2" width="32">
                        <div>
                            <div class="sender-name">${message.sender.name}</div>
                            <small class="text-muted">${this.formatDateTime(message.timestamp)}</small>
                        </div>
                    </div>
                    <div class="message-actions">
                        <button class="btn btn-sm btn-outline-primary reply-btn">
                            <i class="fas fa-reply"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-secondary mark-btn">
                            <i class="fas fa-check"></i>
                        </button>
                    </div>
                </div>
                <div class="message-content">
                    ${message.content}
                </div>
                ${message.attachments ? `
                    <div class="message-attachments">
                        ${message.attachments.map(attachment => `
                            <a href="${attachment.url}" class="attachment-item">
                                <i class="fas fa-${this.getAttachmentIcon(attachment.type)}"></i>
                                ${attachment.name}
                            </a>
                        `).join('')}
                    </div>
                ` : ''}
            </div>
        `).join('');

        this.addMessageEventListeners();
    }

    updateNotificationPanel() {
        const container = document.getElementById('notifications-panel');
        if (!container) return;

        container.innerHTML = `
            <div class="notifications-header">
                <h5>Notifications</h5>
                <button class="btn btn-sm btn-outline-secondary mark-all-read">
                    Mark All Read
                </button>
            </div>
            <div class="notifications-list">
                ${this.notifications.map(notification => `
                    <div class="notification-item ${notification.read ? '' : 'unread'}" 
                         data-notification-id="${notification.id}">
                        <div class="notification-icon">
                            <i class="fas fa-${this.getNotificationIcon(notification.type)}"></i>
                        </div>
                        <div class="notification-content">
                            <div class="notification-text">${notification.message}</div>
                            <small class="text-muted">
                                ${this.formatTimeAgo(notification.timestamp)}
                            </small>
                        </div>
                        ${!notification.read ? `
                            <button class="btn btn-sm mark-read">
                                <i class="fas fa-check"></i>
                            </button>
                        ` : ''}
                    </div>
                `).join('')}
            </div>
        `;

        this.updateUnreadCount();
        this.addNotificationEventListeners();
    }

    updateTemplateSelector() {
        const selector = document.getElementById('template-select');
        if (!selector) return;

        selector.innerHTML = `
            <option value="">Select a template</option>
            ${Object.entries(this.templates).map(([id, template]) => `
                <option value="${id}">${template.name}</option>
            `).join('')}
        `;
    }

    loadTemplate(templateId) {
        if (!templateId) return;

        const template = this.templates[templateId];
        if (!template) return;

        const messageInput = document.getElementById('message-input');
        if (messageInput) {
            messageInput.value = template.content;
        }
    }

    async searchCustomers(query) {
        if (!query) {
            document.getElementById('customer-search-results').innerHTML = '';
            return;
        }

        try {
            const response = await fetch(`/api/staff/customers/search.php?q=${encodeURIComponent(query)}`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.updateCustomerSearchResults(data.customers);
            }
        } catch (error) {
            console.error('Error searching customers:', error);
        }
    }

    updateCustomerSearchResults(customers) {
        const container = document.getElementById('customer-search-results');
        if (!container) return;

        container.innerHTML = customers.map(customer => `
            <div class="customer-result" data-customer-id="${customer.id}">
                <img src="${customer.avatar}" class="rounded-circle me-2" width="32">
                <div class="customer-info">
                    <div class="customer-name">${customer.name}</div>
                    <small class="text-muted">${customer.email}</small>
                </div>
            </div>
        `).join('');

        container.querySelectorAll('.customer-result').forEach(result => {
            result.addEventListener('click', () => {
                this.selectCustomer(result.dataset.customerId);
            });
        });
    }

    // Utility functions
    formatDateTime(timestamp) {
        return new Date(timestamp).toLocaleString();
    }

    formatTimeAgo(timestamp) {
        const seconds = Math.floor((new Date() - new Date(timestamp)) / 1000);
        const intervals = {
            year: 31536000,
            month: 2592000,
            week: 604800,
            day: 86400,
            hour: 3600,
            minute: 60
        };

        for (const [unit, secondsInUnit] of Object.entries(intervals)) {
            const interval = Math.floor(seconds / secondsInUnit);
            if (interval >= 1) {
                return `${interval} ${unit}${interval === 1 ? '' : 's'} ago`;
            }
        }
        return 'Just now';
    }

    getAttachmentIcon(type) {
        const icons = {
            pdf: 'file-pdf',
            doc: 'file-word',
            docx: 'file-word',
            xls: 'file-excel',
            xlsx: 'file-excel',
            jpg: 'file-image',
            jpeg: 'file-image',
            png: 'file-image'
        };
        return icons[type.toLowerCase()] || 'file';
    }

    getNotificationIcon(type) {
        const icons = {
            message: 'envelope',
            booking: 'calendar-check',
            alert: 'exclamation-circle',
            update: 'info-circle'
        };
        return icons[type] || 'bell';
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize CommunicationManager when the communications page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.communication-manager')) {
        const communicationManager = new CommunicationManager();
        communicationManager.initialize();
    }
});
