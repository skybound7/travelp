class DriverManager {
    constructor() {
        this.drivers = [];
        this.activeShifts = new Map();
        this.scheduleCalendar = null;
        this.performanceMetrics = new Map();
        this.filters = {
            status: 'all',
            availability: 'all',
            vehicleType: 'all'
        };
    }

    async initialize() {
        await this.loadDrivers();
        this.initializeCalendar();
        this.initializeEventListeners();
        this.initializePerformanceCharts();
        await this.loadActiveShifts();
    }

    async loadDrivers() {
        try {
            const response = await fetch('/api/staff/drivers/list.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.drivers = data.drivers;
                this.updateDriversList();
                await this.loadDriverMetrics();
            }
        } catch (error) {
            console.error('Error loading drivers:', error);
            this.showError('Failed to load drivers');
        }
    }

    initializeCalendar() {
        const calendarEl = document.getElementById('schedule-calendar');
        if (!calendarEl) return;

        this.scheduleCalendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'timeGridWeek',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'timeGridWeek,timeGridDay'
            },
            slotMinTime: '04:00:00',
            slotMaxTime: '24:00:00',
            allDaySlot: false,
            slotDuration: '01:00:00',
            eventClick: (info) => this.handleShiftClick(info.event),
            dateClick: (info) => this.handleDateClick(info),
            events: (info, successCallback) => this.loadShifts(info, successCallback),
            eventContent: (arg) => this.renderShiftEvent(arg.event),
            eventDidMount: (info) => {
                new bootstrap.Tooltip(info.el, {
                    title: this.getShiftTooltip(info.event),
                    html: true,
                    placement: 'top'
                });
            }
        });

        this.scheduleCalendar.render();
    }

    initializeEventListeners() {
        // Driver filters
        document.querySelectorAll('.driver-filter').forEach(filter => {
            filter.addEventListener('change', (e) => {
                this.filters[e.target.name] = e.target.value;
                this.updateDriversList();
            });
        });

        // Add new driver
        document.getElementById('add-driver-btn')?.addEventListener('click', () => {
            this.showDriverModal();
        });

        // Bulk schedule assignment
        document.getElementById('bulk-schedule-btn')?.addEventListener('click', () => {
            this.showBulkScheduleModal();
        });

        // Performance period selector
        document.getElementById('performance-period')?.addEventListener('change', (e) => {
            this.updatePerformanceCharts(e.target.value);
        });
    }

    async loadDriverMetrics() {
        try {
            const response = await fetch('/api/staff/drivers/metrics.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.performanceMetrics = new Map(data.metrics.map(m => [m.driverId, m]));
                this.updatePerformanceCharts();
            }
        } catch (error) {
            console.error('Error loading driver metrics:', error);
        }
    }

    updateDriversList() {
        const container = document.getElementById('drivers-list');
        if (!container) return;

        const filteredDrivers = this.filterDrivers();

        container.innerHTML = `
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Driver</th>
                            <th>Vehicle</th>
                            <th>Status</th>
                            <th>Current/Next Trip</th>
                            <th>Performance</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${filteredDrivers.map(driver => `
                            <tr data-driver-id="${driver.id}">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="${driver.avatar}" class="rounded-circle me-2" width="40">
                                        <div>
                                            <div class="fw-bold">${driver.name}</div>
                                            <small class="text-muted">${driver.phone}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div>${driver.vehicle.model}</div>
                                    <small class="text-muted">${driver.vehicle.plate}</small>
                                </td>
                                <td>
                                    <span class="badge bg-${this.getStatusColor(driver.status)}">
                                        ${driver.status}
                                    </span>
                                </td>
                                <td>
                                    ${driver.currentTrip ? `
                                        <div class="current-trip">
                                            <div>${driver.currentTrip.route}</div>
                                            <small class="text-muted">
                                                ${this.formatTime(driver.currentTrip.startTime)}
                                            </small>
                                        </div>
                                    ` : `
                                        <div class="text-muted">No active trip</div>
                                    `}
                                </td>
                                <td>
                                    <div class="performance-indicators">
                                        <div class="rating">
                                            ${this.getStarRating(driver.rating)}
                                        </div>
                                        <div class="completion-rate">
                                            <div class="progress" style="height: 5px;">
                                                <div class="progress-bar bg-success" 
                                                     style="width: ${driver.completionRate}%">
                                                </div>
                                            </div>
                                            <small class="text-muted">
                                                ${driver.completionRate}% completion
                                            </small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-outline-primary view-schedule"
                                                title="View Schedule">
                                            <i class="fas fa-calendar"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-success assign-route"
                                                title="Assign Route"
                                                ${driver.status !== 'AVAILABLE' ? 'disabled' : ''}>
                                            <i class="fas fa-route"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-info message-driver"
                                                title="Message Driver">
                                            <i class="fas fa-comment"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-secondary edit-driver"
                                                title="Edit Driver">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;

        this.addDriverEventListeners();
    }

    filterDrivers() {
        return this.drivers.filter(driver => {
            if (this.filters.status !== 'all' && driver.status !== this.filters.status) return false;
            if (this.filters.availability !== 'all' && driver.availability !== this.filters.availability) return false;
            if (this.filters.vehicleType !== 'all' && driver.vehicle.type !== this.filters.vehicleType) return false;
            return true;
        });
    }

    initializePerformanceCharts() {
        // Completion Rate Chart
        const completionCtx = document.getElementById('completion-rate-chart');
        if (completionCtx) {
            this.charts.completion = new Chart(completionCtx, {
                type: 'bar',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Completion Rate',
                        data: [],
                        backgroundColor: '#2ecc71'
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            ticks: {
                                callback: value => value + '%'
                            }
                        }
                    }
                }
            });
        }

        // Rating Distribution Chart
        const ratingCtx = document.getElementById('rating-distribution-chart');
        if (ratingCtx) {
            this.charts.rating = new Chart(ratingCtx, {
                type: 'doughnut',
                data: {
                    labels: ['5★', '4★', '3★', '2★', '1★'],
                    datasets: [{
                        data: [],
                        backgroundColor: [
                            '#2ecc71',
                            '#3498db',
                            '#f1c40f',
                            '#e67e22',
                            '#e74c3c'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    }
                }
            });
        }
    }

    showDriverModal(driver = null) {
        const modal = new bootstrap.Modal(document.getElementById('driver-modal'));
        const form = document.getElementById('driver-form');

        if (driver) {
            // Edit mode
            form.elements.name.value = driver.name;
            form.elements.phone.value = driver.phone;
            form.elements.email.value = driver.email;
            form.elements.vehicleModel.value = driver.vehicle.model;
            form.elements.vehiclePlate.value = driver.vehicle.plate;
            form.elements.driverId.value = driver.id;
        } else {
            // Add mode
            form.reset();
            form.elements.driverId.value = '';
        }

        modal.show();
    }

    async saveDriver(formData) {
        try {
            const url = formData.get('driverId')
                ? `/api/staff/drivers/${formData.get('driverId')}.php`
                : '/api/staff/drivers/create.php';

            const response = await fetch(url, {
                method: formData.get('driverId') ? 'PUT' : 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: formData
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.showSuccess('Driver saved successfully');
                await this.loadDrivers();
            }
        } catch (error) {
            console.error('Error saving driver:', error);
            this.showError('Failed to save driver');
        }
    }

    // Utility functions
    formatTime(timestamp) {
        return new Date(timestamp).toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    getStatusColor(status) {
        const colors = {
            AVAILABLE: 'success',
            ON_TRIP: 'primary',
            OFF_DUTY: 'secondary',
            ON_BREAK: 'warning'
        };
        return colors[status] || 'secondary';
    }

    getStarRating(rating) {
        const fullStars = Math.floor(rating);
        const halfStar = rating % 1 >= 0.5;
        const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);

        return `
            ${'<i class="fas fa-star text-warning"></i>'.repeat(fullStars)}
            ${halfStar ? '<i class="fas fa-star-half-alt text-warning"></i>' : ''}
            ${'<i class="far fa-star text-warning"></i>'.repeat(emptyStars)}
            <small class="ms-1">(${rating.toFixed(1)})</small>
        `;
    }

    getShiftTooltip(event) {
        const driver = this.drivers.find(d => d.id === event.extendedProps.driverId);
        if (!driver) return '';

        return `
            <div class="shift-tooltip">
                <div class="driver-info">
                    <strong>${driver.name}</strong>
                    <div>${driver.vehicle.model} (${driver.vehicle.plate})</div>
                </div>
                <div class="shift-time">
                    ${this.formatTime(event.start)} - ${this.formatTime(event.end)}
                </div>
                ${event.extendedProps.trips ? `
                    <div class="trip-count">
                        <i class="fas fa-route"></i> ${event.extendedProps.trips} trips
                    </div>
                ` : ''}
            </div>
        `;
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize DriverManager when the drivers page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.driver-manager')) {
        const driverManager = new DriverManager();
        driverManager.initialize();
    }
});
