class CustomerManager {
    constructor() {
        this.customers = [];
        this.filters = {
            status: 'all',
            membershipType: 'all',
            searchQuery: ''
        };
        this.pagination = {
            page: 1,
            perPage: 20,
            total: 0
        };
    }

    async initialize() {
        await this.loadCustomers();
        this.initializeEventListeners();
        this.initializeCharts();
    }

    async loadCustomers() {
        try {
            const response = await fetch(`/api/staff/customers.php?${this.getQueryString()}`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.customers = data.customers;
                this.pagination.total = data.total;
                this.renderCustomers();
            }
        } catch (error) {
            console.error('Error loading customers:', error);
            this.showError('Failed to load customers');
        }
    }

    initializeEventListeners() {
        // Search functionality
        document.getElementById('customer-search').addEventListener('input', debounce((e) => {
            this.filters.searchQuery = e.target.value;
            this.loadCustomers();
        }, 300));

        // Filters
        document.getElementById('status-filter').addEventListener('change', (e) => {
            this.filters.status = e.target.value;
            this.loadCustomers();
        });

        document.getElementById('membership-filter').addEventListener('change', (e) => {
            this.filters.membershipType = e.target.value;
            this.loadCustomers();
        });

        // Add new customer
        document.getElementById('add-customer-btn').addEventListener('click', () => {
            this.showCustomerModal();
        });

        // Export customers
        document.getElementById('export-customers').addEventListener('click', () => {
            this.exportCustomerData();
        });
    }

    initializeCharts() {
        // Customer Growth Chart
        const growthCtx = document.getElementById('customer-growth-chart');
        if (growthCtx) {
            new Chart(growthCtx, {
                type: 'line',
                data: {
                    labels: this.getLastSixMonths(),
                    datasets: [{
                        label: 'New Customers',
                        data: this.getCustomerGrowthData(),
                        borderColor: '#3498db',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }

        // Customer Demographics Chart
        const demographicsCtx = document.getElementById('customer-demographics-chart');
        if (demographicsCtx) {
            new Chart(demographicsCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Regular', 'VIP', 'Corporate', 'First-Time'],
                    datasets: [{
                        data: this.getCustomerDemographics(),
                        backgroundColor: ['#2ecc71', '#e74c3c', '#f1c40f', '#95a5a6']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }
    }

    renderCustomers() {
        const container = document.getElementById('customers-container');
        if (!container) return;

        container.innerHTML = `
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Customer ID</th>
                            <th>Name</th>
                            <th>Contact</th>
                            <th>Membership</th>
                            <th>Total Bookings</th>
                            <th>Last Booking</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${this.customers.map(customer => `
                            <tr data-customer-id="${customer.id}">
                                <td>#${customer.id}</td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="${customer.avatar}" class="rounded-circle me-2" width="32">
                                        <div>
                                            <div>${customer.name}</div>
                                            <small class="text-muted">${customer.email}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div>${customer.phone}</div>
                                    <small class="text-muted">${customer.location}</small>
                                </td>
                                <td>
                                    <span class="badge bg-${this.getMembershipColor(customer.membershipType)}">
                                        ${customer.membershipType}
                                    </span>
                                </td>
                                <td>
                                    <div>${customer.totalBookings}</div>
                                    <small class="text-muted">£${customer.totalSpent}</small>
                                </td>
                                <td>
                                    <div>${this.formatDate(customer.lastBooking)}</div>
                                    <small class="text-muted">${customer.lastBookingService}</small>
                                </td>
                                <td>
                                    <span class="badge bg-${this.getStatusColor(customer.status)}">
                                        ${customer.status}
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-outline-primary view-customer">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-success edit-customer">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-info message-customer">
                                            <i class="fas fa-envelope"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
            ${this.renderPagination()}
        `;

        this.addTableEventListeners();
    }

    showCustomerModal(customer = null) {
        const modal = new bootstrap.Modal(document.getElementById('customer-modal'));
        const form = document.getElementById('customer-form');

        if (customer) {
            // Edit mode
            form.elements.name.value = customer.name;
            form.elements.email.value = customer.email;
            form.elements.phone.value = customer.phone;
            form.elements.membershipType.value = customer.membershipType;
            form.elements.customerId.value = customer.id;
        } else {
            // Add mode
            form.reset();
            form.elements.customerId.value = '';
        }

        modal.show();
    }

    async saveCustomer(formData) {
        try {
            const url = formData.get('customerId') 
                ? `/api/staff/customers/${formData.get('customerId')}.php`
                : '/api/staff/customers/create.php';

            const response = await fetch(url, {
                method: formData.get('customerId') ? 'PUT' : 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: formData
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.showSuccess('Customer saved successfully');
                this.loadCustomers();
            }
        } catch (error) {
            console.error('Error saving customer:', error);
            this.showError('Failed to save customer');
        }
    }

    async showCustomerDetails(customerId) {
        try {
            const response = await fetch(`/api/staff/customers/${customerId}.php`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.renderCustomerProfile(data.customer);
            }
        } catch (error) {
            console.error('Error loading customer details:', error);
            this.showError('Failed to load customer details');
        }
    }

    renderCustomerProfile(customer) {
        const container = document.getElementById('customer-profile');
        if (!container) return;

        container.innerHTML = `
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="text-center">
                                <img src="${customer.avatar}" class="rounded-circle img-thumbnail mb-3" width="150">
                                <h4>${customer.name}</h4>
                                <p class="text-muted">${customer.email}</p>
                                <div class="mb-3">
                                    <span class="badge bg-${this.getMembershipColor(customer.membershipType)}">
                                        ${customer.membershipType}
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <h5>Customer Information</h5>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <p><strong>Phone:</strong> ${customer.phone}</p>
                                    <p><strong>Location:</strong> ${customer.location}</p>
                                    <p><strong>Member Since:</strong> ${this.formatDate(customer.createdAt)}</p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Total Bookings:</strong> ${customer.totalBookings}</p>
                                    <p><strong>Total Spent:</strong> £${customer.totalSpent}</p>
                                    <p><strong>Last Booking:</strong> ${this.formatDate(customer.lastBooking)}</p>
                                </div>
                            </div>
                            
                            <h5>Recent Bookings</h5>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Service</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${customer.recentBookings.map(booking => `
                                            <tr>
                                                <td>${this.formatDate(booking.date)}</td>
                                                <td>${booking.service}</td>
                                                <td>£${booking.amount}</td>
                                                <td>
                                                    <span class="badge bg-${this.getStatusColor(booking.status)}">
                                                        ${booking.status}
                                                    </span>
                                                </td>
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    async exportCustomerData() {
        try {
            const response = await fetch('/api/staff/customers/export.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `customers_export_${new Date().toISOString().split('T')[0]}.csv`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } catch (error) {
            console.error('Error exporting customer data:', error);
            this.showError('Failed to export customer data');
        }
    }

    // Utility functions
    formatDate(date) {
        return new Date(date).toLocaleDateString();
    }

    getMembershipColor(type) {
        const colors = {
            regular: 'secondary',
            vip: 'primary',
            corporate: 'success',
            'first-time': 'info'
        };
        return colors[type.toLowerCase()] || 'secondary';
    }

    getStatusColor(status) {
        const colors = {
            active: 'success',
            inactive: 'warning',
            blocked: 'danger'
        };
        return colors[status.toLowerCase()] || 'secondary';
    }

    getLastSixMonths() {
        const months = [];
        for (let i = 5; i >= 0; i--) {
            const date = new Date();
            date.setMonth(date.getMonth() - i);
            months.push(date.toLocaleString('default', { month: 'short' }));
        }
        return months;
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize CustomerManager when the customers page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.customer-manager')) {
        const customerManager = new CustomerManager();
        customerManager.initialize();
    }
});
