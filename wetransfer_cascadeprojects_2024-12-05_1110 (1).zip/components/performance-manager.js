class PerformanceManager {
    constructor() {
        this.staffMetrics = new Map();
        this.goals = new Map();
        this.evaluations = [];
        this.kpis = new Set([
            'customer_satisfaction',
            'on_time_performance',
            'booking_completion_rate',
            'response_time',
            'revenue_generation'
        ]);
    }

    async initialize() {
        await this.loadPerformanceData();
        this.initializeEventListeners();
        this.initializeCharts();
        this.setupPerformanceReviews();
    }

    async loadPerformanceData() {
        try {
            const [metrics, goals, evaluations] = await Promise.all([
                this.fetchStaffMetrics(),
                this.fetchGoals(),
                this.fetchEvaluations()
            ]);

            this.staffMetrics = new Map(metrics.map(m => [m.staffId, m]));
            this.goals = new Map(goals.map(g => [g.staffId, g]));
            this.evaluations = evaluations;

            this.updateDashboard();
        } catch (error) {
            console.error('Error loading performance data:', error);
            this.showError('Failed to load performance data');
        }
    }

    async fetchStaffMetrics() {
        const response = await fetch('/api/staff/performance/metrics.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        const data = await response.json();
        return data.metrics;
    }

    async fetchGoals() {
        const response = await fetch('/api/staff/performance/goals.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        const data = await response.json();
        return data.goals;
    }

    async fetchEvaluations() {
        const response = await fetch('/api/staff/performance/evaluations.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        const data = await response.json();
        return data.evaluations;
    }

    initializeEventListeners() {
        // Performance review scheduling
        document.getElementById('schedule-review-btn')?.addEventListener('click', () => {
            this.showReviewModal();
        });

        // Goal setting
        document.getElementById('set-goals-btn')?.addEventListener('click', () => {
            this.showGoalSettingModal();
        });

        // KPI tracking
        document.getElementById('update-kpi-btn')?.addEventListener('click', () => {
            this.showKPIUpdateModal();
        });

        // Performance report generation
        document.getElementById('generate-report-btn')?.addEventListener('click', () => {
            this.generatePerformanceReport();
        });

        // Staff feedback
        document.getElementById('submit-feedback-btn')?.addEventListener('click', () => {
            this.showFeedbackModal();
        });
    }

    initializeCharts() {
        // Performance Overview Chart
        const performanceCtx = document.getElementById('performance-overview-chart');
        if (performanceCtx) {
            new Chart(performanceCtx, {
                type: 'radar',
                data: {
                    labels: Array.from(this.kpis),
                    datasets: [{
                        label: 'Current Performance',
                        data: this.getCurrentPerformanceData(),
                        borderColor: '#3498db',
                        backgroundColor: 'rgba(52, 152, 219, 0.2)'
                    }, {
                        label: 'Target Performance',
                        data: this.getTargetPerformanceData(),
                        borderColor: '#2ecc71',
                        backgroundColor: 'rgba(46, 204, 113, 0.2)'
                    }]
                },
                options: {
                    scales: {
                        r: {
                            beginAtZero: true,
                            max: 100
                        }
                    }
                }
            });
        }

        // Goal Completion Chart
        const goalsCtx = document.getElementById('goals-completion-chart');
        if (goalsCtx) {
            new Chart(goalsCtx, {
                type: 'bar',
                data: {
                    labels: this.getGoalCategories(),
                    datasets: [{
                        label: 'Completion Rate',
                        data: this.getGoalCompletionData(),
                        backgroundColor: '#f1c40f'
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            ticks: {
                                callback: value => value + '%'
                            }
                        }
                    }
                }
            });
        }
    }

    updateDashboard() {
        this.updatePerformanceMetrics();
        this.updateGoalProgress();
        this.updateEvaluationSchedule();
        this.updateStaffRankings();
    }

    updatePerformanceMetrics() {
        const container = document.getElementById('performance-metrics');
        if (!container) return;

        container.innerHTML = Array.from(this.staffMetrics.values()).map(staff => `
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <img src="${staff.avatar}" class="rounded-circle me-3" width="48">
                            <div>
                                <h5 class="card-title mb-0">${staff.name}</h5>
                                <small class="text-muted">${staff.role}</small>
                            </div>
                        </div>
                        ${Array.from(this.kpis).map(kpi => `
                            <div class="mb-3">
                                <div class="d-flex justify-content-between mb-1">
                                    <span>${this.formatKPIName(kpi)}</span>
                                    <span class="fw-bold">${staff.metrics[kpi]}%</span>
                                </div>
                                <div class="progress" style="height: 5px;">
                                    <div class="progress-bar bg-${this.getPerformanceColor(staff.metrics[kpi])}"
                                         style="width: ${staff.metrics[kpi]}%"></div>
                                </div>
                            </div>
                        `).join('')}
                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <span class="badge bg-${this.getOverallPerformanceColor(staff.overallScore)}">
                                Overall: ${staff.overallScore}%
                            </span>
                            <button class="btn btn-sm btn-outline-primary view-details-btn"
                                    data-staff-id="${staff.id}">
                                View Details
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');

        this.addStaffCardEventListeners();
    }

    updateGoalProgress() {
        const container = document.getElementById('goal-progress');
        if (!container) return;

        container.innerHTML = Array.from(this.goals.values()).map(staffGoals => `
            <div class="col-12 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            ${staffGoals.name}'s Goals
                            <span class="badge bg-${this.getProgressColor(staffGoals.overallProgress)}">
                                ${staffGoals.overallProgress}% Complete
                            </span>
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Goal</th>
                                        <th>Category</th>
                                        <th>Deadline</th>
                                        <th>Progress</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${staffGoals.goals.map(goal => `
                                        <tr>
                                            <td>${goal.description}</td>
                                            <td>
                                                <span class="badge bg-info">
                                                    ${goal.category}
                                                </span>
                                            </td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <i class="fas fa-calendar-alt me-2"></i>
                                                    ${this.formatDate(goal.deadline)}
                                                </div>
                                            </td>
                                            <td>
                                                <div class="progress">
                                                    <div class="progress-bar bg-${
                                                        this.getProgressColor(goal.progress)
                                                    }" style="width: ${goal.progress}%">
                                                        ${goal.progress}%
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="badge bg-${
                                                    this.getStatusColor(goal.status)
                                                }">
                                                    ${goal.status}
                                                </span>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <button class="btn btn-sm btn-outline-primary update-goal"
                                                            data-goal-id="${goal.id}">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <button class="btn btn-sm btn-outline-success complete-goal"
                                                            data-goal-id="${goal.id}"
                                                            ${goal.status === 'completed' ? 'disabled' : ''}>
                                                        <i class="fas fa-check"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');

        this.addGoalEventListeners();
    }

    async generatePerformanceReport() {
        try {
            const response = await fetch('/api/staff/performance/report/generate.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `performance_report_${new Date().toISOString().split('T')[0]}.pdf`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } catch (error) {
            console.error('Error generating report:', error);
            this.showError('Failed to generate performance report');
        }
    }

    // Utility functions
    formatKPIName(kpi) {
        return kpi.split('_').map(word => 
            word.charAt(0).toUpperCase() + word.slice(1)
        ).join(' ');
    }

    formatDate(date) {
        return new Date(date).toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    }

    getPerformanceColor(value) {
        if (value >= 80) return 'success';
        if (value >= 60) return 'warning';
        return 'danger';
    }

    getProgressColor(value) {
        if (value >= 75) return 'success';
        if (value >= 50) return 'info';
        if (value >= 25) return 'warning';
        return 'danger';
    }

    getStatusColor(status) {
        const colors = {
            completed: 'success',
            'in-progress': 'info',
            pending: 'warning',
            overdue: 'danger'
        };
        return colors[status.toLowerCase()] || 'secondary';
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize PerformanceManager when the performance page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.performance-manager')) {
        const performanceManager = new PerformanceManager();
        performanceManager.initialize();
    }
});
