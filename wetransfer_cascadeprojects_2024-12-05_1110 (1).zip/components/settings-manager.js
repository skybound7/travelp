class SettingsManager {
    constructor() {
        this.settings = {
            system: new Map(),
            notifications: new Map(),
            security: new Map(),
            display: new Map(),
            integration: new Map()
        };
        this.defaultSettings = this.getDefaultSettings();
    }

    async initialize() {
        await this.loadSettings();
        this.initializeEventListeners();
        this.setupValidation();
    }

    async loadSettings() {
        try {
            const response = await fetch('/api/staff/settings/all.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });
            const data = await response.json();
            
            Object.keys(this.settings).forEach(category => {
                this.settings[category] = new Map(Object.entries(data[category] || {}));
            });

            this.updateSettingsUI();
        } catch (error) {
            console.error('Error loading settings:', error);
            this.showError('Failed to load settings');
        }
    }

    getDefaultSettings() {
        return {
            system: {
                timezone: 'UTC',
                dateFormat: 'DD/MM/YYYY',
                timeFormat: '24h',
                language: 'en',
                currency: 'GBP'
            },
            notifications: {
                emailNotifications: true,
                pushNotifications: true,
                smsNotifications: false,
                notificationSound: true,
                dailyDigest: true
            },
            security: {
                sessionTimeout: 30,
                passwordExpiry: 90,
                twoFactorAuth: false,
                ipWhitelist: [],
                loginAttempts: 3
            },
            display: {
                theme: 'light',
                sidebarCollapsed: false,
                density: 'comfortable',
                fontSize: 'medium',
                tableRows: 10
            },
            integration: {
                googleMapsKey: '',
                paymentGateway: 'stripe',
                emailService: 'smtp',
                smsGateway: 'twilio'
            }
        };
    }

    initializeEventListeners() {
        // Save settings
        document.getElementById('save-settings-btn')?.addEventListener('click', () => {
            this.saveAllSettings();
        });

        // Reset settings
        document.getElementById('reset-settings-btn')?.addEventListener('click', () => {
            this.confirmResetSettings();
        });

        // Import/Export settings
        document.getElementById('import-settings-btn')?.addEventListener('click', () => {
            this.importSettings();
        });
        document.getElementById('export-settings-btn')?.addEventListener('click', () => {
            this.exportSettings();
        });

        // Theme switcher
        document.getElementById('theme-switch')?.addEventListener('change', (e) => {
            this.updateTheme(e.target.checked ? 'dark' : 'light');
        });

        // Settings search
        document.getElementById('settings-search')?.addEventListener('input', (e) => {
            this.filterSettings(e.target.value);
        });
    }

    setupValidation() {
        const forms = document.querySelectorAll('.settings-form');
        forms.forEach(form => {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                if (this.validateForm(form)) {
                    this.saveFormSettings(form);
                }
            });
        });
    }

    updateSettingsUI() {
        Object.keys(this.settings).forEach(category => {
            const container = document.getElementById(`${category}-settings`);
            if (!container) return;

            container.innerHTML = this.generateSettingsHTML(category);
        });

        this.initializeFormElements();
    }

    generateSettingsHTML(category) {
        const settings = Array.from(this.settings[category].entries());
        
        return `
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">${this.formatCategoryName(category)} Settings</h5>
                </div>
                <div class="card-body">
                    <form class="settings-form" id="${category}-form">
                        ${settings.map(([key, value]) => this.generateSettingField(key, value)).join('')}
                        <div class="mt-3">
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                            <button type="reset" class="btn btn-secondary ms-2">Reset</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
    }

    generateSettingField(key, value) {
        const fieldId = `setting-${key}`;
        const label = this.formatSettingName(key);

        switch (typeof value) {
            case 'boolean':
                return `
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input type="checkbox" class="form-check-input" 
                                   id="${fieldId}" name="${key}" 
                                   ${value ? 'checked' : ''}>
                            <label class="form-check-label" for="${fieldId}">
                                ${label}
                            </label>
                        </div>
                    </div>
                `;
            case 'number':
                return `
                    <div class="mb-3">
                        <label class="form-label" for="${fieldId}">${label}</label>
                        <input type="number" class="form-control" 
                               id="${fieldId}" name="${key}" 
                               value="${value}">
                    </div>
                `;
            default:
                if (Array.isArray(value)) {
                    return `
                        <div class="mb-3">
                            <label class="form-label" for="${fieldId}">${label}</label>
                            <select class="form-select" id="${fieldId}" 
                                    name="${key}" multiple>
                                ${value.map(item => `
                                    <option value="${item}" selected>${item}</option>
                                `).join('')}
                            </select>
                        </div>
                    `;
                }
                return `
                    <div class="mb-3">
                        <label class="form-label" for="${fieldId}">${label}</label>
                        <input type="text" class="form-control" 
                               id="${fieldId}" name="${key}" 
                               value="${value}">
                    </div>
                `;
        }
    }

    async saveAllSettings() {
        try {
            const settings = {};
            Object.keys(this.settings).forEach(category => {
                settings[category] = Object.fromEntries(this.settings[category]);
            });

            const response = await fetch('/api/staff/settings/save.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify(settings)
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.showSuccess('Settings saved successfully');
                await this.loadSettings();
            }
        } catch (error) {
            console.error('Error saving settings:', error);
            this.showError('Failed to save settings');
        }
    }

    async exportSettings() {
        const settings = {};
        Object.keys(this.settings).forEach(category => {
            settings[category] = Object.fromEntries(this.settings[category]);
        });

        const blob = new Blob([JSON.stringify(settings, null, 2)], {
            type: 'application/json'
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `settings_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    importSettings() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (file) {
                try {
                    const content = await file.text();
                    const settings = JSON.parse(content);
                    await this.validateAndImportSettings(settings);
                } catch (error) {
                    console.error('Error importing settings:', error);
                    this.showError('Invalid settings file');
                }
            }
        };
        input.click();
    }

    // Utility functions
    formatCategoryName(category) {
        return category.charAt(0).toUpperCase() + category.slice(1);
    }

    formatSettingName(key) {
        return key
            .split(/(?=[A-Z])|_/)
            .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
            .join(' ');
    }

    validateForm(form) {
        // Add form validation logic
        return true;
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize SettingsManager when the settings page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.settings-manager')) {
        const settingsManager = new SettingsManager();
        settingsManager.initialize();
    }
});
