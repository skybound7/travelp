class FeedbackManager {
    constructor() {
        this.feedback = new Map();
        this.categories = [
            'service',
            'staff',
            'vehicle',
            'booking',
            'pricing',
            'general'
        ];
        this.ratings = {
            1: 'Poor',
            2: 'Fair',
            3: 'Good',
            4: 'Very Good',
            5: 'Excellent'
        };
    }

    async initialize() {
        await this.loadFeedbackData();
        this.initializeEventListeners();
        this.setupCharts();
        this.initializeFilters();
    }

    async loadFeedbackData() {
        try {
            const feedback = await this.fetchFeedback();
            this.feedback = new Map(feedback.map(item => [item.id, item]));
            this.updateFeedbackView();
        } catch (error) {
            console.error('Error loading feedback data:', error);
            this.showError('Failed to load feedback data');
        }
    }

    async fetchFeedback() {
        const response = await fetch('/api/staff/feedback/list.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        return await response.json();
    }

    initializeEventListeners() {
        // Category filters
        document.querySelectorAll('.feedback-category')?.forEach(filter => {
            filter.addEventListener('change', (e) => {
                this.filterFeedback(e.target.value);
            });
        });

        // Rating filters
        document.querySelectorAll('.rating-filter')?.forEach(filter => {
            filter.addEventListener('change', (e) => {
                this.filterByRating(parseInt(e.target.value));
            });
        });

        // Date range picker
        const dateRange = document.getElementById('feedback-date-range');
        if (dateRange) {
            new DateRangePicker(dateRange, {
                ranges: {
                    'Today': [moment(), moment()],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')]
                }
            });
        }

        // Search
        document.getElementById('feedback-search')?.addEventListener('input', (e) => {
            this.searchFeedback(e.target.value);
        });

        // Export
        document.getElementById('export-feedback')?.addEventListener('click', () => {
            this.exportFeedback();
        });
    }

    setupCharts() {
        // Rating distribution chart
        const ratingCtx = document.getElementById('rating-distribution')?.getContext('2d');
        if (ratingCtx) {
            new Chart(ratingCtx, {
                type: 'bar',
                data: this.getRatingDistributionData(),
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        },
                        title: {
                            display: true,
                            text: 'Rating Distribution'
                        }
                    }
                }
            });
        }

        // Category sentiment chart
        const categoryCtx = document.getElementById('category-sentiment')?.getContext('2d');
        if (categoryCtx) {
            new Chart(categoryCtx, {
                type: 'radar',
                data: this.getCategorySentimentData(),
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        },
                        title: {
                            display: true,
                            text: 'Category Sentiment Analysis'
                        }
                    }
                }
            });
        }
    }

    updateFeedbackView() {
        const container = document.getElementById('feedback-list');
        if (!container) return;

        container.innerHTML = `
            <div class="list-group">
                ${Array.from(this.feedback.values())
                    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
                    .map(item => `
                        <div class="list-group-item" data-feedback-id="${item.id}">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-1">
                                    ${this.formatCategory(item.category)}
                                    <span class="badge bg-${
                                        this.getRatingColor(item.rating)
                                    } ms-2">
                                        ${this.ratings[item.rating]}
                                    </span>
                                </h6>
                                <small class="text-muted">
                                    ${this.formatDate(item.timestamp)}
                                </small>
                            </div>
                            <p class="mb-1">${item.comment}</p>
                            <div class="d-flex align-items-center">
                                <div class="me-3">
                                    <small class="text-muted">Customer:</small>
                                    <span class="ms-1">${item.customerName}</span>
                                </div>
                                <div class="me-3">
                                    <small class="text-muted">Booking ID:</small>
                                    <span class="ms-1">${item.bookingId}</span>
                                </div>
                                <div class="btn-group ms-auto">
                                    <button class="btn btn-sm btn-outline-primary respond-feedback"
                                            title="Respond"
                                            ${item.responded ? 'disabled' : ''}>
                                        <i class="fas fa-reply"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-info view-details"
                                            title="View Details">
                                        <i class="fas fa-info-circle"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-warning flag-feedback"
                                            title="Flag for Review"
                                            ${item.flagged ? 'disabled' : ''}>
                                        <i class="fas fa-flag"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
            </div>
        `;

        this.addFeedbackEventListeners();
        this.updateMetrics();
    }

    // Utility functions
    formatCategory(category) {
        return category.charAt(0).toUpperCase() + category.slice(1);
    }

    formatDate(date) {
        return new Date(date).toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    getRatingColor(rating) {
        const colors = {
            1: 'danger',
            2: 'warning',
            3: 'info',
            4: 'primary',
            5: 'success'
        };
        return colors[rating] || 'secondary';
    }

    getRatingDistributionData() {
        const distribution = Array(5).fill(0);
        this.feedback.forEach(item => {
            distribution[item.rating - 1]++;
        });

        return {
            labels: Object.values(this.ratings),
            datasets: [{
                label: 'Number of Ratings',
                data: distribution,
                backgroundColor: [
                    '#dc3545',
                    '#ffc107',
                    '#17a2b8',
                    '#007bff',
                    '#28a745'
                ]
            }]
        };
    }

    getCategorySentimentData() {
        const sentiment = {};
        this.categories.forEach(category => {
            const categoryFeedback = Array.from(this.feedback.values())
                .filter(item => item.category === category);
            sentiment[category] = categoryFeedback.length > 0 
                ? categoryFeedback.reduce((sum, item) => sum + item.rating, 0) / categoryFeedback.length
                : 0;
        });

        return {
            labels: this.categories.map(this.formatCategory),
            datasets: [{
                label: 'Average Rating',
                data: Object.values(sentiment),
                backgroundColor: 'rgba(0, 123, 255, 0.2)',
                borderColor: '#007bff',
                pointBackgroundColor: '#007bff'
            }]
        };
    }

    async exportFeedback() {
        try {
            const response = await fetch('/api/staff/feedback/export.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });
            
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `feedback_export_${new Date().toISOString().split('T')[0]}.csv`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } catch (error) {
            console.error('Error exporting feedback:', error);
            this.showError('Failed to export feedback');
        }
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize FeedbackManager when the feedback page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.feedback-manager')) {
        const feedbackManager = new FeedbackManager();
        feedbackManager.initialize();
    }
});
