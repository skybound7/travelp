class TaskManager {
    constructor() {
        this.tasks = [];
        this.currentFilter = 'all';
        this.sortField = 'deadline';
        this.sortOrder = 'asc';
    }

    async initialize() {
        await this.loadTasks();
        this.initializeEventListeners();
        this.initializeKanbanBoard();
    }

    async loadTasks() {
        try {
            const response = await fetch('/api/staff/tasks.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.tasks = data.tasks;
                this.renderTasks();
            }
        } catch (error) {
            console.error('Error loading tasks:', error);
            this.showError('Failed to load tasks');
        }
    }

    initializeEventListeners() {
        // Task filtering
        document.querySelectorAll('.task-filter').forEach(filter => {
            filter.addEventListener('click', (e) => {
                this.currentFilter = e.target.dataset.filter;
                this.renderTasks();
            });
        });

        // Task sorting
        document.querySelectorAll('.task-sort').forEach(sorter => {
            sorter.addEventListener('click', (e) => {
                const field = e.target.dataset.sort;
                if (field === this.sortField) {
                    this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
                } else {
                    this.sortField = field;
                    this.sortOrder = 'asc';
                }
                this.renderTasks();
            });
        });

        // Quick task creation
        document.getElementById('quick-task-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.createQuickTask();
        });
    }

    initializeKanbanBoard() {
        const containers = document.querySelectorAll('.kanban-column');
        
        containers.forEach(container => {
            new Sortable(container, {
                group: 'tasks',
                animation: 150,
                onEnd: (evt) => {
                    const taskId = evt.item.dataset.taskId;
                    const newStatus = evt.to.dataset.status;
                    this.updateTaskStatus(taskId, newStatus);
                }
            });
        });
    }

    async createQuickTask() {
        const input = document.getElementById('quick-task-input');
        const taskText = input.value.trim();
        
        if (!taskText) return;

        try {
            const response = await fetch('/api/staff/tasks/create.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({
                    title: taskText,
                    priority: 'medium',
                    deadline: new Date(Date.now() + 86400000).toISOString() // Tomorrow
                })
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.tasks.push(data.task);
                this.renderTasks();
                input.value = '';
                this.showSuccess('Task created successfully');
            }
        } catch (error) {
            console.error('Error creating task:', error);
            this.showError('Failed to create task');
        }
    }

    async updateTaskStatus(taskId, newStatus) {
        try {
            const response = await fetch(`/api/staff/tasks/${taskId}/status.php`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({ status: newStatus })
            });

            const data = await response.json();
            if (data.status === 'success') {
                const task = this.tasks.find(t => t.id === taskId);
                if (task) {
                    task.status = newStatus;
                    this.showSuccess('Task status updated');
                }
            }
        } catch (error) {
            console.error('Error updating task status:', error);
            this.showError('Failed to update task status');
            this.renderTasks(); // Revert to original state
        }
    }

    renderTasks() {
        const filteredTasks = this.filterTasks();
        const sortedTasks = this.sortTasks(filteredTasks);
        
        // Clear existing tasks
        document.querySelectorAll('.kanban-column').forEach(column => {
            column.innerHTML = '';
        });

        // Render tasks in appropriate columns
        sortedTasks.forEach(task => {
            const column = document.querySelector(`.kanban-column[data-status="${task.status}"]`);
            if (column) {
                column.appendChild(this.createTaskElement(task));
            }
        });

        // Update task counts
        this.updateTaskCounts();
    }

    createTaskElement(task) {
        const taskEl = document.createElement('div');
        taskEl.className = 'task-card';
        taskEl.dataset.taskId = task.id;
        
        taskEl.innerHTML = `
            <div class="task-header">
                <span class="badge bg-${this.getPriorityColor(task.priority)}">${task.priority}</span>
                <div class="task-actions dropdown">
                    <button class="btn btn-sm" data-bs-toggle="dropdown">
                        <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item edit-task" href="#">Edit</a></li>
                        <li><a class="dropdown-item delete-task" href="#">Delete</a></li>
                    </ul>
                </div>
            </div>
            <h6 class="task-title">${task.title}</h6>
            <p class="task-description">${task.description || ''}</p>
            <div class="task-footer">
                <small class="text-muted">
                    <i class="fas fa-clock"></i> ${this.formatDeadline(task.deadline)}
                </small>
                ${task.assignee ? `
                    <small class="text-muted">
                        <i class="fas fa-user"></i> ${task.assignee}
                    </small>
                ` : ''}
            </div>
        `;

        // Add event listeners
        taskEl.querySelector('.edit-task').addEventListener('click', () => {
            this.showEditTaskModal(task);
        });

        taskEl.querySelector('.delete-task').addEventListener('click', () => {
            this.deleteTask(task.id);
        });

        return taskEl;
    }

    filterTasks() {
        return this.tasks.filter(task => {
            switch (this.currentFilter) {
                case 'priority':
                    return task.priority === 'high';
                case 'today':
                    return this.isToday(task.deadline);
                case 'overdue':
                    return new Date(task.deadline) < new Date();
                default:
                    return true;
            }
        });
    }

    sortTasks(tasks) {
        return [...tasks].sort((a, b) => {
            let comparison = 0;
            switch (this.sortField) {
                case 'deadline':
                    comparison = new Date(a.deadline) - new Date(b.deadline);
                    break;
                case 'priority':
                    comparison = this.getPriorityWeight(b.priority) - this.getPriorityWeight(a.priority);
                    break;
                case 'title':
                    comparison = a.title.localeCompare(b.title);
                    break;
            }
            return this.sortOrder === 'asc' ? comparison : -comparison;
        });
    }

    getPriorityWeight(priority) {
        const weights = { low: 1, medium: 2, high: 3 };
        return weights[priority] || 0;
    }

    getPriorityColor(priority) {
        const colors = {
            low: 'success',
            medium: 'warning',
            high: 'danger'
        };
        return colors[priority] || 'secondary';
    }

    formatDeadline(deadline) {
        const date = new Date(deadline);
        if (this.isToday(date)) {
            return `Today ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
        }
        return date.toLocaleDateString();
    }

    isToday(date) {
        const today = new Date();
        date = new Date(date);
        return date.getDate() === today.getDate() &&
               date.getMonth() === today.getMonth() &&
               date.getFullYear() === today.getFullYear();
    }

    updateTaskCounts() {
        const counts = {
            total: this.tasks.length,
            pending: this.tasks.filter(t => t.status === 'pending').length,
            inProgress: this.tasks.filter(t => t.status === 'in-progress').length,
            completed: this.tasks.filter(t => t.status === 'completed').length
        };

        Object.entries(counts).forEach(([key, value]) => {
            const el = document.getElementById(`${key}-count`);
            if (el) el.textContent = value;
        });
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize TaskManager when the tasks page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.task-manager')) {
        const taskManager = new TaskManager();
        taskManager.initialize();
    }
});
