class FleetManager {
    constructor() {
        this.vehicles = [];
        this.maintenanceSchedule = new Map();
        this.activeServices = new Map();
        this.filters = {
            status: 'all',
            type: 'all',
            availability: 'all'
        };
    }

    async initialize() {
        await this.loadVehicles();
        this.initializeEventListeners();
        this.initializeCharts();
        await this.loadMaintenanceSchedule();
        this.initializeServiceTracking();
    }

    async loadVehicles() {
        try {
            const response = await fetch('/api/staff/fleet/vehicles.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.vehicles = data.vehicles;
                this.updateVehiclesList();
                await this.loadVehicleMetrics();
            }
        } catch (error) {
            console.error('Error loading vehicles:', error);
            this.showError('Failed to load vehicles');
        }
    }

    initializeEventListeners() {
        // Vehicle filters
        document.querySelectorAll('.vehicle-filter').forEach(filter => {
            filter.addEventListener('change', (e) => {
                this.filters[e.target.name] = e.target.value;
                this.updateVehiclesList();
            });
        });

        // Add new vehicle
        document.getElementById('add-vehicle-btn')?.addEventListener('click', () => {
            this.showVehicleModal();
        });

        // Schedule maintenance
        document.getElementById('schedule-maintenance-btn')?.addEventListener('click', () => {
            this.showMaintenanceModal();
        });

        // Export fleet report
        document.getElementById('export-fleet-btn')?.addEventListener('click', () => {
            this.exportFleetReport();
        });
    }

    updateVehiclesList() {
        const container = document.getElementById('vehicles-list');
        if (!container) return;

        const filteredVehicles = this.filterVehicles();

        container.innerHTML = `
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Vehicle</th>
                            <th>Status</th>
                            <th>Current Driver</th>
                            <th>Maintenance</th>
                            <th>Performance</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${filteredVehicles.map(vehicle => `
                            <tr data-vehicle-id="${vehicle.id}">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="${vehicle.image}" class="me-2" width="60">
                                        <div>
                                            <div class="fw-bold">${vehicle.model}</div>
                                            <small class="text-muted">${vehicle.plate}</small>
                                            <div class="vehicle-specs">
                                                <span class="badge bg-info">
                                                    <i class="fas fa-users"></i> ${vehicle.capacity}
                                                </span>
                                                <span class="badge bg-secondary">
                                                    <i class="fas fa-suitcase"></i> ${vehicle.luggage}
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-${this.getStatusColor(vehicle.status)}">
                                        ${vehicle.status}
                                    </span>
                                    ${vehicle.currentLocation ? `
                                        <div class="text-muted small">
                                            <i class="fas fa-map-marker-alt"></i> ${vehicle.currentLocation}
                                        </div>
                                    ` : ''}
                                </td>
                                <td>
                                    ${vehicle.currentDriver ? `
                                        <div class="d-flex align-items-center">
                                            <img src="${vehicle.currentDriver.avatar}" 
                                                 class="rounded-circle me-2" width="32">
                                            <div>
                                                <div>${vehicle.currentDriver.name}</div>
                                                <small class="text-muted">Since ${
                                                    this.formatTime(vehicle.currentDriver.assignedAt)
                                                }</small>
                                            </div>
                                        </div>
                                    ` : '<span class="text-muted">Unassigned</span>'}
                                </td>
                                <td>
                                    <div class="maintenance-status">
                                        ${this.getMaintenanceStatus(vehicle)}
                                    </div>
                                    ${vehicle.nextService ? `
                                        <small class="text-muted">
                                            Next: ${this.formatDate(vehicle.nextService)}
                                        </small>
                                    ` : ''}
                                </td>
                                <td>
                                    <div class="vehicle-metrics">
                                        <div class="progress mb-2" style="height: 5px;">
                                            <div class="progress-bar bg-${
                                                this.getHealthColor(vehicle.health)
                                            }" style="width: ${vehicle.health}%"></div>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <small>Health: ${vehicle.health}%</small>
                                            <small>${vehicle.mileage} km</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-outline-primary view-details"
                                                title="View Details">
                                            <i class="fas fa-info-circle"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-success assign-driver"
                                                title="Assign Driver"
                                                ${vehicle.status !== 'AVAILABLE' ? 'disabled' : ''}>
                                            <i class="fas fa-user-plus"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-warning schedule-maintenance"
                                                title="Schedule Maintenance">
                                            <i class="fas fa-tools"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-secondary edit-vehicle"
                                                title="Edit Vehicle">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;

        this.addVehicleEventListeners();
    }

    initializeCharts() {
        // Fleet Status Distribution
        const statusCtx = document.getElementById('fleet-status-chart');
        if (statusCtx) {
            new Chart(statusCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Available', 'In Service', 'Maintenance', 'Out of Service'],
                    datasets: [{
                        data: this.getFleetStatusDistribution(),
                        backgroundColor: ['#2ecc71', '#3498db', '#f1c40f', '#e74c3c']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }

        // Maintenance History
        const maintenanceCtx = document.getElementById('maintenance-history-chart');
        if (maintenanceCtx) {
            new Chart(maintenanceCtx, {
                type: 'bar',
                data: {
                    labels: this.getLast6Months(),
                    datasets: [{
                        label: 'Scheduled',
                        data: this.getMaintenanceHistory('scheduled'),
                        backgroundColor: '#3498db'
                    }, {
                        label: 'Unscheduled',
                        data: this.getMaintenanceHistory('unscheduled'),
                        backgroundColor: '#e74c3c'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1
                            }
                        }
                    }
                }
            });
        }
    }

    showVehicleModal(vehicle = null) {
        const modal = new bootstrap.Modal(document.getElementById('vehicle-modal'));
        const form = document.getElementById('vehicle-form');

        if (vehicle) {
            // Edit mode
            form.elements.model.value = vehicle.model;
            form.elements.plate.value = vehicle.plate;
            form.elements.capacity.value = vehicle.capacity;
            form.elements.luggage.value = vehicle.luggage;
            form.elements.vehicleId.value = vehicle.id;
        } else {
            // Add mode
            form.reset();
            form.elements.vehicleId.value = '';
        }

        modal.show();
    }

    async scheduleMaintenanceService(vehicleId, serviceType, date) {
        try {
            const response = await fetch('/api/staff/fleet/maintenance/schedule.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({
                    vehicleId,
                    serviceType,
                    date
                })
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.showSuccess('Maintenance scheduled successfully');
                await this.loadMaintenanceSchedule();
            }
        } catch (error) {
            console.error('Error scheduling maintenance:', error);
            this.showError('Failed to schedule maintenance');
        }
    }

    async exportFleetReport() {
        try {
            const response = await fetch('/api/staff/fleet/report/export.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `fleet_report_${new Date().toISOString().split('T')[0]}.xlsx`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } catch (error) {
            console.error('Error exporting fleet report:', error);
            this.showError('Failed to export fleet report');
        }
    }

    // Utility functions
    filterVehicles() {
        return this.vehicles.filter(vehicle => {
            if (this.filters.status !== 'all' && vehicle.status !== this.filters.status) return false;
            if (this.filters.type !== 'all' && vehicle.type !== this.filters.type) return false;
            if (this.filters.availability !== 'all' && vehicle.availability !== this.filters.availability) return false;
            return true;
        });
    }

    getStatusColor(status) {
        const colors = {
            AVAILABLE: 'success',
            IN_SERVICE: 'primary',
            MAINTENANCE: 'warning',
            OUT_OF_SERVICE: 'danger'
        };
        return colors[status] || 'secondary';
    }

    getHealthColor(health) {
        if (health >= 80) return 'success';
        if (health >= 60) return 'warning';
        return 'danger';
    }

    getMaintenanceStatus(vehicle) {
        const daysUntilService = this.getDaysUntilService(vehicle.nextService);
        if (daysUntilService <= 0) {
            return `<span class="text-danger">
                <i class="fas fa-exclamation-triangle"></i> Service Overdue
            </span>`;
        }
        if (daysUntilService <= 7) {
            return `<span class="text-warning">
                <i class="fas fa-clock"></i> Service Due Soon
            </span>`;
        }
        return `<span class="text-success">
            <i class="fas fa-check-circle"></i> Service Up to Date
        </span>`;
    }

    getDaysUntilService(nextService) {
        if (!nextService) return 0;
        const today = new Date();
        const serviceDate = new Date(nextService);
        return Math.ceil((serviceDate - today) / (1000 * 60 * 60 * 24));
    }

    formatDate(date) {
        return new Date(date).toLocaleDateString();
    }

    formatTime(timestamp) {
        return new Date(timestamp).toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    getLast6Months() {
        const months = [];
        for (let i = 5; i >= 0; i--) {
            const date = new Date();
            date.setMonth(date.getMonth() - i);
            months.push(date.toLocaleString('default', { month: 'short' }));
        }
        return months;
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize FleetManager when the fleet management page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.fleet-manager')) {
        const fleetManager = new FleetManager();
        fleetManager.initialize();
    }
});
