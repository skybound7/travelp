class AnalyticsManager {
    constructor() {
        this.currentReport = 'overview';
        this.dateRange = {
            start: this.getLastMonthDate(),
            end: new Date().toISOString().split('T')[0]
        };
        this.charts = {};
        this.reportData = {};
    }

    async initialize() {
        this.initializeEventListeners();
        await this.loadReportData();
        this.initializeCharts();
    }

    initializeEventListeners() {
        // Report type selector
        document.querySelectorAll('.report-selector').forEach(selector => {
            selector.addEventListener('click', (e) => {
                e.preventDefault();
                this.switchReport(e.target.dataset.report);
            });
        });

        // Date range picker
        const dateRangePicker = document.getElementById('report-date-range');
        if (dateRangePicker) {
            new DateRangePicker(dateRangePicker, {
                startDate: this.dateRange.start,
                endDate: this.dateRange.end,
                maxDate: new Date(),
                ranges: {
                    'Today': [new Date(), new Date()],
                    'Yesterday': [new Date(Date.now() - 86400000), new Date(Date.now() - 86400000)],
                    'Last 7 Days': [new Date(Date.now() - 6 * 86400000), new Date()],
                    'Last 30 Days': [new Date(Date.now() - 29 * 86400000), new Date()],
                    'This Month': [new Date(new Date().getFullYear(), new Date().getMonth(), 1), new Date()],
                    'Last Month': [
                        new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1),
                        new Date(new Date().getFullYear(), new Date().getMonth(), 0)
                    ]
                }
            });

            dateRangePicker.addEventListener('changeDate', (e) => {
                this.dateRange = {
                    start: e.dates[0].toISOString().split('T')[0],
                    end: e.dates[1].toISOString().split('T')[0]
                };
                this.loadReportData();
            });
        }

        // Export buttons
        document.querySelectorAll('.export-report').forEach(button => {
            button.addEventListener('click', (e) => {
                this.exportReport(e.target.dataset.format);
            });
        });
    }

    async loadReportData() {
        try {
            const response = await fetch('/api/staff/reports/data.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({
                    reportType: this.currentReport,
                    dateRange: this.dateRange
                })
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.reportData = data.data;
                this.updateDashboard();
            }
        } catch (error) {
            console.error('Error loading report data:', error);
            this.showError('Failed to load report data');
        }
    }

    initializeCharts() {
        // Revenue Chart
        this.initializeRevenueChart();
        // Bookings Chart
        this.initializeBookingsChart();
        // Customer Satisfaction Chart
        this.initializeSatisfactionChart();
        // Service Distribution Chart
        this.initializeServiceChart();
    }

    initializeRevenueChart() {
        const ctx = document.getElementById('revenue-chart');
        if (!ctx) return;

        this.charts.revenue = new Chart(ctx, {
            type: 'line',
            data: {
                labels: this.reportData.revenue.labels,
                datasets: [{
                    label: 'Revenue',
                    data: this.reportData.revenue.data,
                    borderColor: '#2ecc71',
                    fill: true,
                    backgroundColor: 'rgba(46, 204, 113, 0.1)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => '£' + value
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: context => '£' + context.parsed.y
                        }
                    }
                }
            }
        });
    }

    initializeBookingsChart() {
        const ctx = document.getElementById('bookings-chart');
        if (!ctx) return;

        this.charts.bookings = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: this.reportData.bookings.labels,
                datasets: [{
                    label: 'Completed',
                    data: this.reportData.bookings.completed,
                    backgroundColor: '#3498db'
                }, {
                    label: 'Cancelled',
                    data: this.reportData.bookings.cancelled,
                    backgroundColor: '#e74c3c'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        stacked: true
                    },
                    x: {
                        stacked: true
                    }
                }
            }
        });
    }

    initializeSatisfactionChart() {
        const ctx = document.getElementById('satisfaction-chart');
        if (!ctx) return;

        this.charts.satisfaction = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Excellent', 'Good', 'Average', 'Poor'],
                datasets: [{
                    data: this.reportData.satisfaction,
                    backgroundColor: [
                        '#2ecc71',
                        '#3498db',
                        '#f1c40f',
                        '#e74c3c'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }

    initializeServiceChart() {
        const ctx = document.getElementById('service-chart');
        if (!ctx) return;

        this.charts.services = new Chart(ctx, {
            type: 'polarArea',
            data: {
                labels: this.reportData.services.labels,
                datasets: [{
                    data: this.reportData.services.data,
                    backgroundColor: [
                        '#3498db',
                        '#2ecc71',
                        '#f1c40f',
                        '#e74c3c',
                        '#9b59b6'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }

    updateDashboard() {
        // Update KPI cards
        this.updateKPICards();
        // Update charts
        this.updateCharts();
        // Update tables
        this.updateTables();
    }

    updateKPICards() {
        const kpis = {
            'total-revenue': {
                value: `£${this.reportData.kpis.totalRevenue}`,
                trend: this.reportData.kpis.revenueTrend
            },
            'total-bookings': {
                value: this.reportData.kpis.totalBookings,
                trend: this.reportData.kpis.bookingsTrend
            },
            'average-rating': {
                value: this.reportData.kpis.averageRating.toFixed(1),
                trend: this.reportData.kpis.ratingTrend
            },
            'conversion-rate': {
                value: `${this.reportData.kpis.conversionRate}%`,
                trend: this.reportData.kpis.conversionTrend
            }
        };

        Object.entries(kpis).forEach(([id, data]) => {
            const card = document.getElementById(id);
            if (card) {
                card.querySelector('.kpi-value').textContent = data.value;
                const trendEl = card.querySelector('.kpi-trend');
                trendEl.innerHTML = `
                    <i class="fas fa-arrow-${data.trend > 0 ? 'up text-success' : 'down text-danger'}"></i>
                    ${Math.abs(data.trend)}%
                `;
            }
        });
    }

    updateCharts() {
        Object.values(this.charts).forEach(chart => {
            chart.update();
        });
    }

    updateTables() {
        // Top Services Table
        const topServicesTable = document.getElementById('top-services-table');
        if (topServicesTable) {
            topServicesTable.querySelector('tbody').innerHTML = this.reportData.topServices
                .map(service => `
                    <tr>
                        <td>${service.name}</td>
                        <td>${service.bookings}</td>
                        <td>£${service.revenue}</td>
                        <td>${service.rating.toFixed(1)}</td>
                    </tr>
                `).join('');
        }

        // Recent Bookings Table
        const recentBookingsTable = document.getElementById('recent-bookings-table');
        if (recentBookingsTable) {
            recentBookingsTable.querySelector('tbody').innerHTML = this.reportData.recentBookings
                .map(booking => `
                    <tr>
                        <td>#${booking.id}</td>
                        <td>${booking.customer}</td>
                        <td>${booking.service}</td>
                        <td>£${booking.amount}</td>
                        <td>
                            <span class="badge bg-${this.getStatusColor(booking.status)}">
                                ${booking.status}
                            </span>
                        </td>
                    </tr>
                `).join('');
        }
    }

    async exportReport(format) {
        try {
            const response = await fetch('/api/staff/reports/export.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({
                    reportType: this.currentReport,
                    dateRange: this.dateRange,
                    format: format
                })
            });

            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `report_${this.currentReport}_${this.dateRange.start}_${this.dateRange.end}.${format}`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } catch (error) {
            console.error('Error exporting report:', error);
            this.showError('Failed to export report');
        }
    }

    // Utility functions
    getLastMonthDate() {
        const date = new Date();
        date.setMonth(date.getMonth() - 1);
        return date.toISOString().split('T')[0];
    }

    getStatusColor(status) {
        const colors = {
            completed: 'success',
            pending: 'warning',
            cancelled: 'danger'
        };
        return colors[status.toLowerCase()] || 'secondary';
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize AnalyticsManager when the analytics page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.analytics-manager')) {
        const analyticsManager = new AnalyticsManager();
        analyticsManager.initialize();
    }
});
