class MaintenanceManager {
    constructor() {
        this.maintenanceSchedule = new Map();
        this.serviceHistory = new Map();
        this.maintenanceTypes = new Set([
            'routine',
            'preventive',
            'repair',
            'inspection',
            'emergency'
        ]);
        this.serviceProviders = new Map();
        this.parts = new Map();
    }

    async initialize() {
        await this.loadMaintenanceData();
        this.initializeEventListeners();
        this.initializeCharts();
        this.setupNotifications();
    }

    async loadMaintenanceData() {
        try {
            const [schedule, history, providers, parts] = await Promise.all([
                this.fetchMaintenanceSchedule(),
                this.fetchServiceHistory(),
                this.fetchServiceProviders(),
                this.fetchParts()
            ]);

            this.maintenanceSchedule = new Map(schedule.map(s => [s.id, s]));
            this.serviceHistory = new Map(history.map(h => [h.id, h]));
            this.serviceProviders = new Map(providers.map(p => [p.id, p]));
            this.parts = new Map(parts.map(p => [p.id, p]));

            this.updateDashboard();
        } catch (error) {
            console.error('Error loading maintenance data:', error);
            this.showError('Failed to load maintenance data');
        }
    }

    async fetchMaintenanceSchedule() {
        const response = await fetch('/api/staff/maintenance/schedule.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        const data = await response.json();
        return data.schedule;
    }

    async fetchServiceHistory() {
        const response = await fetch('/api/staff/maintenance/history.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        const data = await response.json();
        return data.history;
    }

    initializeEventListeners() {
        // Schedule maintenance
        document.getElementById('schedule-maintenance-btn')?.addEventListener('click', () => {
            this.showScheduleModal();
        });

        // Record service
        document.getElementById('record-service-btn')?.addEventListener('click', () => {
            this.showServiceModal();
        });

        // Parts inventory
        document.getElementById('manage-parts-btn')?.addEventListener('click', () => {
            this.showPartsModal();
        });

        // Service provider management
        document.getElementById('manage-providers-btn')?.addEventListener('click', () => {
            this.showProvidersModal();
        });

        // Calendar view toggle
        document.querySelectorAll('.view-toggle')?.forEach(toggle => {
            toggle.addEventListener('click', (e) => {
                this.switchView(e.target.dataset.view);
            });
        });
    }

    updateDashboard() {
        this.updateMaintenanceSchedule();
        this.updateServiceHistory();
        this.updatePartsInventory();
        this.updateMetrics();
    }

    updateMaintenanceSchedule() {
        const container = document.getElementById('maintenance-schedule');
        if (!container) return;

        container.innerHTML = `
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Vehicle</th>
                            <th>Service Type</th>
                            <th>Due Date</th>
                            <th>Provider</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${Array.from(this.maintenanceSchedule.values()).map(schedule => `
                            <tr data-schedule-id="${schedule.id}">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="${schedule.vehicle.image}" 
                                             class="me-2" width="48">
                                        <div>
                                            <div class="fw-bold">${schedule.vehicle.model}</div>
                                            <small class="text-muted">${schedule.vehicle.plate}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-${this.getServiceTypeColor(schedule.type)}">
                                        ${schedule.type}
                                    </span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-calendar me-2"></i>
                                        <div>
                                            <div>${this.formatDate(schedule.dueDate)}</div>
                                            <small class="text-${this.getDueDateColor(schedule.dueDate)}">
                                                ${this.getDueStatus(schedule.dueDate)}
                                            </small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="${schedule.provider.logo}" 
                                             class="rounded-circle me-2" width="32">
                                        <div>
                                            <div>${schedule.provider.name}</div>
                                            <small class="text-muted">${schedule.provider.contact}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-${this.getStatusColor(schedule.status)}">
                                        ${schedule.status}
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-outline-primary edit-schedule"
                                                title="Edit Schedule">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-success complete-service"
                                                title="Mark Complete"
                                                ${schedule.status === 'completed' ? 'disabled' : ''}>
                                            <i class="fas fa-check"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger cancel-service"
                                                title="Cancel Service"
                                                ${schedule.status === 'completed' ? 'disabled' : ''}>
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;

        this.addScheduleEventListeners();
    }

    updatePartsInventory() {
        const container = document.getElementById('parts-inventory');
        if (!container) return;

        container.innerHTML = `
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Part</th>
                            <th>Stock</th>
                            <th>Status</th>
                            <th>Last Order</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${Array.from(this.parts.values()).map(part => `
                            <tr data-part-id="${part.id}">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="${part.image}" class="me-2" width="48">
                                        <div>
                                            <div class="fw-bold">${part.name}</div>
                                            <small class="text-muted">${part.code}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="fw-bold">${part.stock}</div>
                                    <small class="text-muted">Min: ${part.minStock}</small>
                                </td>
                                <td>
                                    <span class="badge bg-${this.getStockStatusColor(part)}">
                                        ${this.getStockStatus(part)}
                                    </span>
                                </td>
                                <td>
                                    <div>${this.formatDate(part.lastOrder)}</div>
                                    <small class="text-muted">Qty: ${part.lastOrderQty}</small>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-outline-primary update-stock"
                                                title="Update Stock">
                                            <i class="fas fa-sync-alt"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-success order-part"
                                                title="Order Part"
                                                ${part.stock > part.minStock ? 'disabled' : ''}>
                                            <i class="fas fa-shopping-cart"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;

        this.addPartsEventListeners();
    }

    async completeService(scheduleId) {
        try {
            const response = await fetch('/api/staff/maintenance/complete.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({ scheduleId })
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.showSuccess('Service marked as completed');
                await this.loadMaintenanceData();
            }
        } catch (error) {
            console.error('Error completing service:', error);
            this.showError('Failed to complete service');
        }
    }

    // Utility functions
    getServiceTypeColor(type) {
        const colors = {
            routine: 'info',
            preventive: 'success',
            repair: 'warning',
            inspection: 'primary',
            emergency: 'danger'
        };
        return colors[type.toLowerCase()] || 'secondary';
    }

    getStatusColor(status) {
        const colors = {
            scheduled: 'info',
            'in-progress': 'warning',
            completed: 'success',
            cancelled: 'danger',
            overdue: 'danger'
        };
        return colors[status.toLowerCase()] || 'secondary';
    }

    getDueDateColor(date) {
        const days = this.getDaysUntil(date);
        if (days < 0) return 'danger';
        if (days <= 7) return 'warning';
        return 'success';
    }

    getDueStatus(date) {
        const days = this.getDaysUntil(date);
        if (days < 0) return 'Overdue';
        if (days === 0) return 'Due today';
        if (days === 1) return 'Due tomorrow';
        return `Due in ${days} days`;
    }

    getDaysUntil(date) {
        const diff = new Date(date) - new Date();
        return Math.ceil(diff / (1000 * 60 * 60 * 24));
    }

    formatDate(date) {
        return new Date(date).toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    }

    getStockStatus(part) {
        if (part.stock <= 0) return 'Out of Stock';
        if (part.stock <= part.minStock) return 'Low Stock';
        return 'In Stock';
    }

    getStockStatusColor(part) {
        if (part.stock <= 0) return 'danger';
        if (part.stock <= part.minStock) return 'warning';
        return 'success';
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize MaintenanceManager when the maintenance page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.maintenance-manager')) {
        const maintenanceManager = new MaintenanceManager();
        maintenanceManager.initialize();
    }
});
