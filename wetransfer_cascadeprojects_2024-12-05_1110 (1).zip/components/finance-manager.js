class FinanceManager {
    constructor() {
        this.transactions = [];
        this.invoices = [];
        this.expenses = [];
        this.dateRange = {
            start: this.getStartOfMonth(),
            end: new Date().toISOString().split('T')[0]
        };
        this.charts = {};
    }

    async initialize() {
        await this.loadFinancialData();
        this.initializeEventListeners();
        this.initializeCharts();
        this.initializePaymentProcessing();
    }

    async loadFinancialData() {
        try {
            const [transactions, invoices, expenses] = await Promise.all([
                this.fetchTransactions(),
                this.fetchInvoices(),
                this.fetchExpenses()
            ]);

            this.transactions = transactions;
            this.invoices = invoices;
            this.expenses = expenses;

            this.updateDashboard();
        } catch (error) {
            console.error('Error loading financial data:', error);
            this.showError('Failed to load financial data');
        }
    }

    async fetchTransactions() {
        const response = await fetch('/api/staff/finance/transactions.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(this.dateRange)
        });
        const data = await response.json();
        return data.transactions;
    }

    async fetchInvoices() {
        const response = await fetch('/api/staff/finance/invoices.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(this.dateRange)
        });
        const data = await response.json();
        return data.invoices;
    }

    async fetchExpenses() {
        const response = await fetch('/api/staff/finance/expenses.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(this.dateRange)
        });
        const data = await response.json();
        return data.expenses;
    }

    initializeEventListeners() {
        // Date range picker
        const dateRangePicker = document.getElementById('finance-date-range');
        if (dateRangePicker) {
            new DateRangePicker(dateRangePicker, {
                startDate: this.dateRange.start,
                endDate: this.dateRange.end,
                maxDate: new Date(),
                ranges: {
                    'Today': [new Date(), new Date()],
                    'Yesterday': [new Date(Date.now() - 86400000), new Date(Date.now() - 86400000)],
                    'Last 7 Days': [new Date(Date.now() - 6 * 86400000), new Date()],
                    'Last 30 Days': [new Date(Date.now() - 29 * 86400000), new Date()],
                    'This Month': [new Date(new Date().getFullYear(), new Date().getMonth(), 1), new Date()],
                    'Last Month': [
                        new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1),
                        new Date(new Date().getFullYear(), new Date().getMonth(), 0)
                    ]
                }
            });

            dateRangePicker.addEventListener('changeDate', (e) => {
                this.dateRange = {
                    start: e.dates[0].toISOString().split('T')[0],
                    end: e.dates[1].toISOString().split('T')[0]
                };
                this.loadFinancialData();
            });
        }

        // Invoice actions
        document.getElementById('create-invoice-btn')?.addEventListener('click', () => {
            this.showInvoiceModal();
        });

        // Expense tracking
        document.getElementById('add-expense-btn')?.addEventListener('click', () => {
            this.showExpenseModal();
        });

        // Report generation
        document.getElementById('generate-report-btn')?.addEventListener('click', () => {
            this.generateFinancialReport();
        });

        // Payment processing
        document.getElementById('process-payment-btn')?.addEventListener('click', () => {
            this.showPaymentModal();
        });
    }

    initializeCharts() {
        // Revenue Chart
        const revenueCtx = document.getElementById('revenue-chart');
        if (revenueCtx) {
            this.charts.revenue = new Chart(revenueCtx, {
                type: 'line',
                data: {
                    labels: this.getDateLabels(),
                    datasets: [{
                        label: 'Revenue',
                        data: this.getRevenueData(),
                        borderColor: '#2ecc71',
                        fill: true,
                        backgroundColor: 'rgba(46, 204, 113, 0.1)'
                    }, {
                        label: 'Expenses',
                        data: this.getExpenseData(),
                        borderColor: '#e74c3c',
                        fill: true,
                        backgroundColor: 'rgba(231, 76, 60, 0.1)'
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: value => '£' + value
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: context => '£' + context.parsed.y
                            }
                        }
                    }
                }
            });
        }

        // Payment Methods Chart
        const paymentMethodsCtx = document.getElementById('payment-methods-chart');
        if (paymentMethodsCtx) {
            this.charts.paymentMethods = new Chart(paymentMethodsCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Credit Card', 'Bank Transfer', 'Cash', 'Other'],
                    datasets: [{
                        data: this.getPaymentMethodsData(),
                        backgroundColor: [
                            '#3498db',
                            '#2ecc71',
                            '#f1c40f',
                            '#95a5a6'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    }
                }
            });
        }
    }

    updateDashboard() {
        this.updateKPIs();
        this.updateTransactionsList();
        this.updateInvoicesList();
        this.updateExpensesList();
        this.updateCharts();
    }

    updateKPIs() {
        const kpis = {
            'total-revenue': {
                value: this.calculateTotalRevenue(),
                trend: this.calculateRevenueTrend()
            },
            'total-expenses': {
                value: this.calculateTotalExpenses(),
                trend: this.calculateExpenseTrend()
            },
            'net-profit': {
                value: this.calculateNetProfit(),
                trend: this.calculateProfitTrend()
            },
            'pending-payments': {
                value: this.calculatePendingPayments(),
                trend: this.calculatePendingTrend()
            }
        };

        Object.entries(kpis).forEach(([id, data]) => {
            const element = document.getElementById(id);
            if (element) {
                element.querySelector('.kpi-value').textContent = this.formatCurrency(data.value);
                element.querySelector('.kpi-trend').innerHTML = this.formatTrend(data.trend);
            }
        });
    }

    updateTransactionsList() {
        const container = document.getElementById('transactions-list');
        if (!container) return;

        container.innerHTML = `
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Transaction ID</th>
                            <th>Date</th>
                            <th>Customer</th>
                            <th>Service</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${this.transactions.map(transaction => `
                            <tr data-transaction-id="${transaction.id}">
                                <td>#${transaction.id}</td>
                                <td>${this.formatDate(transaction.date)}</td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="${transaction.customer.avatar}" 
                                             class="rounded-circle me-2" width="32">
                                        <div>
                                            <div>${transaction.customer.name}</div>
                                            <small class="text-muted">${transaction.customer.email}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>${transaction.service}</td>
                                <td>
                                    <div class="fw-bold ${transaction.type === 'credit' ? 'text-success' : 'text-danger'}">
                                        ${transaction.type === 'credit' ? '+' : '-'}${this.formatCurrency(transaction.amount)}
                                    </div>
                                    <small class="text-muted">${transaction.paymentMethod}</small>
                                </td>
                                <td>
                                    <span class="badge bg-${this.getStatusColor(transaction.status)}">
                                        ${transaction.status}
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-sm btn-outline-primary view-transaction">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-success process-refund"
                                                ${transaction.status !== 'completed' ? 'disabled' : ''}>
                                            <i class="fas fa-undo"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-secondary download-receipt">
                                            <i class="fas fa-download"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;

        this.addTransactionEventListeners();
    }

    async generateFinancialReport() {
        try {
            const response = await fetch('/api/staff/finance/report/generate.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({
                    dateRange: this.dateRange,
                    reportType: 'comprehensive'
                })
            });

            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `financial_report_${this.dateRange.start}_${this.dateRange.end}.pdf`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } catch (error) {
            console.error('Error generating report:', error);
            this.showError('Failed to generate financial report');
        }
    }

    // Utility functions
    formatCurrency(amount) {
        return new Intl.NumberFormat('en-GB', {
            style: 'currency',
            currency: 'GBP'
        }).format(amount);
    }

    formatDate(date) {
        return new Date(date).toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    }

    formatTrend(trend) {
        const direction = trend >= 0 ? 'up' : 'down';
        const color = trend >= 0 ? 'success' : 'danger';
        return `
            <i class="fas fa-arrow-${direction} text-${color}"></i>
            ${Math.abs(trend)}%
        `;
    }

    getStatusColor(status) {
        const colors = {
            completed: 'success',
            pending: 'warning',
            failed: 'danger',
            refunded: 'info'
        };
        return colors[status.toLowerCase()] || 'secondary';
    }

    getStartOfMonth() {
        const date = new Date();
        date.setDate(1);
        return date.toISOString().split('T')[0];
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize FinanceManager when the finance page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.finance-manager')) {
        const financeManager = new FinanceManager();
        financeManager.initialize();
    }
});
