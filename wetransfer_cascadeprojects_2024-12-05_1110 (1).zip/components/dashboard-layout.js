class DashboardLayout {
    constructor() {
        this.currentUser = null;
        this.sidebarCollapsed = false;
        this.activeModule = '';
        this.notifications = [];
        this.modules = [
            {
                id: 'overview',
                name: 'Overview',
                icon: 'fa-home',
                route: '/dashboard'
            },
            {
                id: 'bookings',
                name: 'Bookings',
                icon: 'fa-calendar-check',
                route: '/dashboard/bookings'
            },
            {
                id: 'customers',
                name: 'Customers',
                icon: 'fa-users',
                route: '/dashboard/customers'
            },
            {
                id: 'routes',
                name: 'Routes',
                icon: 'fa-route',
                route: '/dashboard/routes'
            },
            {
                id: 'drivers',
                name: 'Drivers',
                icon: 'fa-id-card',
                route: '/dashboard/drivers'
            },
            {
                id: 'fleet',
                name: 'Fleet',
                icon: 'fa-car',
                route: '/dashboard/fleet'
            },
            {
                id: 'maintenance',
                name: 'Maintenance',
                icon: 'fa-tools',
                route: '/dashboard/maintenance'
            },
            {
                id: 'analytics',
                name: 'Analytics',
                icon: 'fa-chart-line',
                route: '/dashboard/analytics'
            },
            {
                id: 'finance',
                name: 'Finance',
                icon: 'fa-pound-sign',
                route: '/dashboard/finance'
            },
            {
                id: 'staff',
                name: 'Staff',
                icon: 'fa-user-tie',
                route: '/dashboard/staff'
            },
            {
                id: 'messages',
                name: 'Messages',
                icon: 'fa-comments',
                route: '/dashboard/messages'
            },
            {
                id: 'support',
                name: 'Support',
                icon: 'fa-headset',
                route: '/dashboard/support'
            },
            {
                id: 'settings',
                name: 'Settings',
                icon: 'fa-cog',
                route: '/dashboard/settings'
            }
        ];
    }

    async initialize() {
        await this.loadUserData();
        this.initializeLayout();
        this.initializeEventListeners();
        this.setupNotifications();
        this.handleRouting();
    }

    async loadUserData() {
        try {
            const response = await fetch('/api/staff/user/profile.php', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });
            const data = await response.json();
            this.currentUser = data.user;
            this.updateUserInfo();
        } catch (error) {
            console.error('Error loading user data:', error);
            this.showError('Failed to load user data');
        }
    }

    initializeLayout() {
        document.body.innerHTML = `
            <div class="dashboard-container ${this.sidebarCollapsed ? 'sidebar-collapsed' : ''}">
                <nav class="sidebar">
                    <div class="sidebar-header">
                        <div class="brand">
                            <img src="/assets/images/logo.png" alt="Famous Trains" class="logo">
                            <span class="brand-text">Famous Trains</span>
                        </div>
                        <button class="btn btn-link sidebar-toggle">
                            <i class="fas fa-bars"></i>
                        </button>
                    </div>

                    <div class="sidebar-user">
                        <div class="user-avatar">
                            <img src="${this.currentUser?.avatar}" 
                                 alt="${this.currentUser?.name}"
                                 class="rounded-circle">
                            <span class="status-indicator online"></span>
                        </div>
                        <div class="user-info">
                            <div class="user-name">${this.currentUser?.name}</div>
                            <div class="user-role">${this.currentUser?.role}</div>
                        </div>
                    </div>

                    <div class="sidebar-nav">
                        ${this.modules.map(module => `
                            <a href="${module.route}" 
                               class="nav-item ${module.id === this.activeModule ? 'active' : ''}"
                               data-module="${module.id}">
                                <i class="fas ${module.icon}"></i>
                                <span class="nav-text">${module.name}</span>
                                ${module.id === 'messages' && this.notifications.length > 0 ? `
                                    <span class="badge bg-danger">${this.notifications.length}</span>
                                ` : ''}
                            </a>
                        `).join('')}
                    </div>
                </nav>

                <div class="main-content">
                    <header class="top-bar">
                        <div class="d-flex align-items-center">
                            <button class="btn btn-link menu-toggle d-lg-none">
                                <i class="fas fa-bars"></i>
                            </button>
                            <div class="breadcrumb-wrapper">
                                ${this.generateBreadcrumbs()}
                            </div>
                        </div>

                        <div class="top-bar-right">
                            <div class="search-box">
                                <input type="text" 
                                       class="form-control" 
                                       placeholder="Search...">
                                <i class="fas fa-search"></i>
                            </div>

                            <div class="notifications-dropdown dropdown">
                                <button class="btn btn-link position-relative" 
                                        data-bs-toggle="dropdown">
                                    <i class="fas fa-bell"></i>
                                    ${this.notifications.length > 0 ? `
                                        <span class="badge bg-danger notification-badge">
                                            ${this.notifications.length}
                                        </span>
                                    ` : ''}
                                </button>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <div class="dropdown-header">
                                        Notifications
                                        <button class="btn btn-link btn-sm float-end">
                                            Mark all as read
                                        </button>
                                    </div>
                                    ${this.notifications.length > 0 ? `
                                        ${this.notifications.map(notification => `
                                            <a href="${notification.link}" class="dropdown-item">
                                                <div class="notification-icon">
                                                    <i class="fas ${notification.icon}"></i>
                                                </div>
                                                <div class="notification-content">
                                                    <div class="notification-text">
                                                        ${notification.message}
                                                    </div>
                                                    <div class="notification-time">
                                                        ${this.formatTime(notification.timestamp)}
                                                    </div>
                                                </div>
                                            </a>
                                        `).join('')}
                                    ` : `
                                        <div class="dropdown-item text-center text-muted">
                                            No new notifications
                                        </div>
                                    `}
                                </div>
                            </div>

                            <div class="user-dropdown dropdown">
                                <button class="btn btn-link" data-bs-toggle="dropdown">
                                    <img src="${this.currentUser?.avatar}" 
                                         alt="${this.currentUser?.name}"
                                         class="rounded-circle"
                                         width="32"
                                         height="32">
                                </button>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <div class="dropdown-header">
                                        <div class="d-flex align-items-center">
                                            <img src="${this.currentUser?.avatar}" 
                                                 alt="${this.currentUser?.name}"
                                                 class="rounded-circle me-2"
                                                 width="48"
                                                 height="48">
                                            <div>
                                                <div class="fw-bold">${this.currentUser?.name}</div>
                                                <div class="text-muted small">
                                                    ${this.currentUser?.email}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="/dashboard/profile" class="dropdown-item">
                                        <i class="fas fa-user me-2"></i>
                                        Profile
                                    </a>
                                    <a href="/dashboard/settings" class="dropdown-item">
                                        <i class="fas fa-cog me-2"></i>
                                        Settings
                                    </a>
                                    <div class="dropdown-divider"></div>
                                    <a href="#" class="dropdown-item text-danger" id="logout-btn">
                                        <i class="fas fa-sign-out-alt me-2"></i>
                                        Logout
                                    </a>
                                </div>
                            </div>
                        </div>
                    </header>

                    <main class="content">
                        <div id="module-content"></div>
                    </main>
                </div>
            </div>
        `;

        this.initializeBootstrapComponents();
    }

    initializeEventListeners() {
        // Sidebar toggle
        document.querySelector('.sidebar-toggle')?.addEventListener('click', () => {
            this.toggleSidebar();
        });

        // Mobile menu toggle
        document.querySelector('.menu-toggle')?.addEventListener('click', () => {
            document.querySelector('.dashboard-container').classList.toggle('sidebar-mobile-open');
        });

        // Navigation items
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                this.navigateToModule(item.dataset.module);
            });
        });

        // Search
        const searchInput = document.querySelector('.search-box input');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.handleSearch(e.target.value);
            });
        }

        // Logout
        document.getElementById('logout-btn')?.addEventListener('click', (e) => {
            e.preventDefault();
            this.handleLogout();
        });
    }

    generateBreadcrumbs() {
        const module = this.modules.find(m => m.id === this.activeModule);
        if (!module) return '';

        return `
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item">
                        <a href="/dashboard">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">
                        ${module.name}
                    </li>
                </ol>
            </nav>
        `;
    }

    async navigateToModule(moduleId) {
        this.activeModule = moduleId;
        const module = this.modules.find(m => m.id === moduleId);
        
        if (module) {
            history.pushState(null, '', module.route);
            await this.loadModuleContent(moduleId);
            this.updateActiveNavItem();
            this.updateBreadcrumbs();
        }
    }

    async loadModuleContent(moduleId) {
        const contentContainer = document.getElementById('module-content');
        if (!contentContainer) return;

        try {
            const response = await fetch(`/api/staff/modules/${moduleId}.php`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });
            const data = await response.json();
            contentContainer.innerHTML = data.content;
        } catch (error) {
            console.error(`Error loading module ${moduleId}:`, error);
            this.showError(`Failed to load ${moduleId} module`);
        }
    }

    toggleSidebar() {
        this.sidebarCollapsed = !this.sidebarCollapsed;
        document.querySelector('.dashboard-container')
            .classList.toggle('sidebar-collapsed', this.sidebarCollapsed);
    }

    updateActiveNavItem() {
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.toggle('active', item.dataset.module === this.activeModule);
        });
    }

    updateBreadcrumbs() {
        const breadcrumbWrapper = document.querySelector('.breadcrumb-wrapper');
        if (breadcrumbWrapper) {
            breadcrumbWrapper.innerHTML = this.generateBreadcrumbs();
        }
    }

    handleSearch(query) {
        // Implementation of global search functionality
    }

    async handleLogout() {
        try {
            await fetch('/api/staff/auth/logout.php', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });
            localStorage.removeItem('auth_token');
            window.location.href = '/login';
        } catch (error) {
            console.error('Error during logout:', error);
            this.showError('Failed to logout');
        }
    }

    initializeBootstrapComponents() {
        // Initialize all Bootstrap tooltips
        const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        tooltips.forEach(tooltip => {
            new bootstrap.Tooltip(tooltip);
        });

        // Initialize all Bootstrap popovers
        const popovers = document.querySelectorAll('[data-bs-toggle="popover"]');
        popovers.forEach(popover => {
            new bootstrap.Popover(popover);
        });
    }

    formatTime(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        
        if (date.toDateString() === now.toDateString()) {
            return date.toLocaleTimeString('en-GB', {
                hour: '2-digit',
                minute: '2-digit'
            });
        }
        
        if (now.getTime() - date.getTime() < 7 * 24 * 60 * 60 * 1000) {
            return date.toLocaleDateString('en-GB', { weekday: 'short' });
        }
        
        return date.toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'short'
        });
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize DashboardLayout when the page is loaded
document.addEventListener('DOMContentLoaded', () => {
    const dashboardLayout = new DashboardLayout();
    dashboardLayout.initialize();
});
