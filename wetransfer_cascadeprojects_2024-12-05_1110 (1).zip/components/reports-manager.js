class ReportsManager {
    constructor() {
        this.reports = new Map();
        this.templates = new Map();
        this.reportTypes = [
            'financial',
            'operational',
            'performance',
            'customer',
            'inventory',
            'maintenance'
        ];
        this.charts = new Map();
    }

    async initialize() {
        await this.loadReportData();
        this.initializeCharts();
        this.initializeEventListeners();
        this.setupExportHandlers();
    }

    async loadReportData() {
        try {
            const [reports, templates] = await Promise.all([
                this.fetchReports(),
                this.fetchTemplates()
            ]);

            this.reports = new Map(reports.map(report => [report.id, report]));
            this.templates = new Map(templates.map(template => [template.id, template]));

            this.updateReportsView();
        } catch (error) {
            console.error('Error loading report data:', error);
            this.showError('Failed to load report data');
        }
    }

    async fetchReports() {
        const response = await fetch('/api/staff/reports/list.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        return await response.json();
    }

    initializeCharts() {
        // Revenue Chart
        const revenueCtx = document.getElementById('revenue-chart')?.getContext('2d');
        if (revenueCtx) {
            this.charts.set('revenue', new Chart(revenueCtx, {
                type: 'line',
                data: this.getRevenueData(),
                options: this.getChartOptions('Revenue Trends')
            }));
        }

        // Bookings Chart
        const bookingsCtx = document.getElementById('bookings-chart')?.getContext('2d');
        if (bookingsCtx) {
            this.charts.set('bookings', new Chart(bookingsCtx, {
                type: 'bar',
                data: this.getBookingsData(),
                options: this.getChartOptions('Booking Statistics')
            }));
        }

        // Performance Chart
        const performanceCtx = document.getElementById('performance-chart')?.getContext('2d');
        if (performanceCtx) {
            this.charts.set('performance', new Chart(performanceCtx, {
                type: 'radar',
                data: this.getPerformanceData(),
                options: this.getChartOptions('Performance Metrics')
            }));
        }
    }

    initializeEventListeners() {
        // Generate report
        document.getElementById('generate-report-btn')?.addEventListener('click', () => {
            this.showReportModal();
        });

        // Export options
        document.querySelectorAll('.export-option')?.forEach(option => {
            option.addEventListener('click', (e) => {
                this.exportReport(e.target.dataset.format);
            });
        });

        // Date range picker
        const dateRange = document.getElementById('date-range');
        if (dateRange) {
            new DateRangePicker(dateRange, {
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [
                        moment().subtract(1, 'month').startOf('month'),
                        moment().subtract(1, 'month').endOf('month')
                    ]
                },
                alwaysShowCalendars: true,
                startDate: moment().subtract(29, 'days'),
                endDate: moment()
            });
        }

        // Report type filters
        document.querySelectorAll('.report-filter')?.forEach(filter => {
            filter.addEventListener('change', (e) => {
                this.filterReports(e.target.value);
            });
        });
    }

    async generateReport(type, dateRange, filters = {}) {
        try {
            const response = await fetch('/api/staff/reports/generate.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({
                    type,
                    startDate: dateRange[0],
                    endDate: dateRange[1],
                    filters
                })
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.reports.set(data.reportId, data.report);
                this.updateReportsView();
                this.showSuccess('Report generated successfully');
            }
        } catch (error) {
            console.error('Error generating report:', error);
            this.showError('Failed to generate report');
        }
    }

    updateReportsView() {
        this.updateReportsList();
        this.updateReportSummary();
        this.updateCharts();
    }

    updateReportsList() {
        const container = document.getElementById('reports-list');
        if (!container) return;

        container.innerHTML = `
            <div class="list-group">
                ${Array.from(this.reports.values())
                    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
                    .map(report => `
                        <div class="list-group-item" data-report-id="${report.id}">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-1">${report.title}</h6>
                                <small class="text-muted">
                                    ${this.formatDate(report.createdAt)}
                                </small>
                            </div>
                            <p class="mb-1">${report.description}</p>
                            <div class="d-flex align-items-center">
                                <span class="badge bg-${
                                    this.getReportTypeColor(report.type)
                                } me-2">
                                    ${this.formatReportType(report.type)}
                                </span>
                                <div class="btn-group ms-auto">
                                    <button class="btn btn-sm btn-outline-primary view-report"
                                            title="View Report">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-success export-report"
                                            title="Export Report">
                                        <i class="fas fa-download"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-info share-report"
                                            title="Share Report">
                                        <i class="fas fa-share-alt"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
            </div>
        `;

        this.addReportEventListeners();
    }

    updateCharts() {
        // Update Revenue Chart
        const revenueChart = this.charts.get('revenue');
        if (revenueChart) {
            revenueChart.data = this.getRevenueData();
            revenueChart.update();
        }

        // Update Bookings Chart
        const bookingsChart = this.charts.get('bookings');
        if (bookingsChart) {
            bookingsChart.data = this.getBookingsData();
            bookingsChart.update();
        }

        // Update Performance Chart
        const performanceChart = this.charts.get('performance');
        if (performanceChart) {
            performanceChart.data = this.getPerformanceData();
            performanceChart.update();
        }
    }

    async exportReport(reportId, format) {
        try {
            const response = await fetch(`/api/staff/reports/export.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({
                    reportId,
                    format
                })
            });

            if (format === 'pdf') {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `report_${reportId}.pdf`;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
            } else {
                const data = await response.json();
                this.downloadFile(data, format);
            }
        } catch (error) {
            console.error('Error exporting report:', error);
            this.showError('Failed to export report');
        }
    }

    // Utility functions
    getReportTypeColor(type) {
        const colors = {
            financial: 'success',
            operational: 'primary',
            performance: 'info',
            customer: 'warning',
            inventory: 'secondary',
            maintenance: 'danger'
        };
        return colors[type] || 'secondary';
    }

    formatReportType(type) {
        return type.charAt(0).toUpperCase() + type.slice(1);
    }

    formatDate(date) {
        return new Date(date).toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    getChartOptions(title) {
        return {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: title
                },
                legend: {
                    position: 'bottom'
                }
            }
        };
    }

    downloadFile(data, format) {
        const blob = new Blob([data], { type: `application/${format}` });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `report.${format}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize ReportsManager when the reports page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.reports-manager')) {
        const reportsManager = new ReportsManager();
        reportsManager.initialize();
    }
});
