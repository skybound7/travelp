class NotificationManager {
    constructor() {
        this.notifications = new Map();
        this.preferences = new Map();
        this.channels = ['email', 'push', 'sms', 'in-app'];
        this.categories = [
            'booking',
            'maintenance',
            'support',
            'system',
            'security',
            'alerts'
        ];
        this.websocket = null;
    }

    async initialize() {
        await this.loadNotificationData();
        this.initializeEventListeners();
        this.setupWebSocket();
        this.initializeServiceWorker();
    }

    async loadNotificationData() {
        try {
            const [notifications, preferences] = await Promise.all([
                this.fetchNotifications(),
                this.fetchPreferences()
            ]);

            this.notifications = new Map(notifications.map(n => [n.id, n]));
            this.preferences = new Map(preferences);

            this.updateNotificationCenter();
        } catch (error) {
            console.error('Error loading notification data:', error);
            this.showError('Failed to load notifications');
        }
    }

    async fetchNotifications() {
        const response = await fetch('/api/staff/notifications/all.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        const data = await response.json();
        return data.notifications;
    }

    async fetchPreferences() {
        const response = await fetch('/api/staff/notifications/preferences.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        const data = await response.json();
        return data.preferences;
    }

    setupWebSocket() {
        const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        this.websocket = new WebSocket(
            `${wsProtocol}//${window.location.host}/ws/notifications`
        );

        this.websocket.onmessage = (event) => {
            const notification = JSON.parse(event.data);
            this.handleNewNotification(notification);
        };

        this.websocket.onclose = () => {
            setTimeout(() => this.setupWebSocket(), 5000);
        };
    }

    async initializeServiceWorker() {
        if ('serviceWorker' in navigator) {
            try {
                const registration = await navigator.serviceWorker.register(
                    '/service-worker.js'
                );
                console.log('ServiceWorker registered:', registration);
            } catch (error) {
                console.error('ServiceWorker registration failed:', error);
            }
        }
    }

    initializeEventListeners() {
        // Mark as read
        document.getElementById('mark-all-read-btn')?.addEventListener('click', () => {
            this.markAllAsRead();
        });

        // Clear notifications
        document.getElementById('clear-all-btn')?.addEventListener('click', () => {
            this.clearAllNotifications();
        });

        // Preference updates
        document.querySelectorAll('.notification-preference')?.forEach(pref => {
            pref.addEventListener('change', (e) => {
                this.updatePreference(e.target.name, e.target.checked);
            });
        });

        // Category filters
        document.querySelectorAll('.category-filter')?.forEach(filter => {
            filter.addEventListener('click', (e) => {
                this.filterNotifications(e.target.dataset.category);
            });
        });
    }

    updateNotificationCenter() {
        const container = document.getElementById('notification-center');
        if (!container) return;

        const unreadCount = this.getUnreadCount();

        container.innerHTML = `
            <div class="notification-header d-flex justify-content-between align-items-center mb-3">
                <h5 class="mb-0">
                    Notifications 
                    ${unreadCount > 0 ? `
                        <span class="badge bg-danger">${unreadCount}</span>
                    ` : ''}
                </h5>
                <div class="btn-group">
                    <button class="btn btn-sm btn-outline-primary" id="mark-all-read-btn">
                        <i class="fas fa-check-double"></i> Mark All Read
                    </button>
                    <button class="btn btn-sm btn-outline-danger" id="clear-all-btn">
                        <i class="fas fa-trash"></i> Clear All
                    </button>
                </div>
            </div>

            <div class="notification-filters mb-3">
                <div class="btn-group">
                    ${this.categories.map(category => `
                        <button class="btn btn-outline-secondary category-filter"
                                data-category="${category}">
                            ${this.formatCategory(category)}
                        </button>
                    `).join('')}
                </div>
            </div>

            <div class="notification-list">
                ${Array.from(this.notifications.values())
                    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
                    .map(notification => `
                        <div class="notification-item ${notification.read ? '' : 'unread'}"
                             data-notification-id="${notification.id}">
                            <div class="notification-icon">
                                <i class="fas ${this.getNotificationIcon(notification.category)}"></i>
                            </div>
                            <div class="notification-content">
                                <div class="notification-title">
                                    ${notification.title}
                                    ${!notification.read ? `
                                        <span class="badge bg-primary">New</span>
                                    ` : ''}
                                </div>
                                <div class="notification-message">
                                    ${notification.message}
                                </div>
                                <div class="notification-meta">
                                    <small class="text-muted">
                                        <i class="fas fa-clock"></i>
                                        ${this.getTimeAgo(notification.timestamp)}
                                    </small>
                                    <span class="badge bg-${
                                        this.getCategoryColor(notification.category)
                                    }">
                                        ${notification.category}
                                    </span>
                                </div>
                            </div>
                            <div class="notification-actions">
                                <button class="btn btn-sm btn-link mark-read"
                                        ${notification.read ? 'disabled' : ''}>
                                    <i class="fas fa-check"></i>
                                </button>
                                <button class="btn btn-sm btn-link delete-notification">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    `).join('')}
            </div>
        `;

        this.addNotificationEventListeners();
    }

    async handleNewNotification(notification) {
        this.notifications.set(notification.id, notification);
        this.updateNotificationCenter();

        if (this.preferences.get(notification.category)) {
            await this.showPushNotification(notification);
        }
    }

    async showPushNotification(notification) {
        if (!('Notification' in window)) return;

        if (Notification.permission === 'granted') {
            const registration = await navigator.serviceWorker.ready;
            registration.showNotification(notification.title, {
                body: notification.message,
                icon: '/assets/images/notification-icon.png',
                badge: '/assets/images/badge-icon.png',
                data: {
                    notificationId: notification.id,
                    url: notification.url
                }
            });
        }
    }

    async markAllAsRead() {
        try {
            const response = await fetch('/api/staff/notifications/mark-all-read.php', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.notifications.forEach(notification => {
                    notification.read = true;
                });
                this.updateNotificationCenter();
                this.showSuccess('All notifications marked as read');
            }
        } catch (error) {
            console.error('Error marking notifications as read:', error);
            this.showError('Failed to mark notifications as read');
        }
    }

    // Utility functions
    getUnreadCount() {
        return Array.from(this.notifications.values())
            .filter(n => !n.read).length;
    }

    formatCategory(category) {
        return category.charAt(0).toUpperCase() + category.slice(1);
    }

    getNotificationIcon(category) {
        const icons = {
            booking: 'fa-calendar-check',
            maintenance: 'fa-tools',
            support: 'fa-headset',
            system: 'fa-cog',
            security: 'fa-shield-alt',
            alerts: 'fa-exclamation-triangle'
        };
        return icons[category.toLowerCase()] || 'fa-bell';
    }

    getCategoryColor(category) {
        const colors = {
            booking: 'primary',
            maintenance: 'warning',
            support: 'info',
            system: 'secondary',
            security: 'danger',
            alerts: 'dark'
        };
        return colors[category.toLowerCase()] || 'secondary';
    }

    getTimeAgo(timestamp) {
        const seconds = Math.floor((new Date() - new Date(timestamp)) / 1000);
        const intervals = {
            year: 31536000,
            month: 2592000,
            week: 604800,
            day: 86400,
            hour: 3600,
            minute: 60
        };

        for (const [unit, secondsInUnit] of Object.entries(intervals)) {
            const interval = Math.floor(seconds / secondsInUnit);
            if (interval >= 1) {
                return `${interval} ${unit}${interval === 1 ? '' : 's'} ago`;
            }
        }
        return 'Just now';
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize NotificationManager when the page is loaded
document.addEventListener('DOMContentLoaded', () => {
    const notificationManager = new NotificationManager();
    notificationManager.initialize();
});
