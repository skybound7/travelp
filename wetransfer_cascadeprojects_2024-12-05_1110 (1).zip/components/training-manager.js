class TrainingManager {
    constructor() {
        this.trainings = new Map();
        this.certifications = new Map();
        this.staff = new Map();
        this.courses = new Map();
        this.trainingTypes = [
            'onboarding',
            'safety',
            'customer_service',
            'vehicle_operation',
            'first_aid',
            'compliance'
        ];
    }

    async initialize() {
        await this.loadTrainingData();
        this.initializeEventListeners();
        this.setupCharts();
        this.checkCertificationExpiry();
    }

    async loadTrainingData() {
        try {
            const [trainings, certifications, staff, courses] = await Promise.all([
                this.fetchTrainings(),
                this.fetchCertifications(),
                this.fetchStaff(),
                this.fetchCourses()
            ]);

            this.trainings = new Map(trainings.map(t => [t.id, t]));
            this.certifications = new Map(certifications.map(c => [c.id, c]));
            this.staff = new Map(staff.map(s => [s.id, s]));
            this.courses = new Map(courses.map(c => [c.id, c]));

            this.updateTrainingView();
        } catch (error) {
            console.error('Error loading training data:', error);
            this.showError('Failed to load training data');
        }
    }

    async fetchTrainings() {
        const response = await fetch('/api/staff/training/list.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        return await response.json();
    }

    initializeEventListeners() {
        // Schedule training
        document.getElementById('schedule-training-btn')?.addEventListener('click', () => {
            this.showTrainingModal();
        });

        // Add certification
        document.getElementById('add-certification-btn')?.addEventListener('click', () => {
            this.showCertificationModal();
        });

        // Training filters
        document.querySelectorAll('.training-filter')?.forEach(filter => {
            filter.addEventListener('change', (e) => {
                this.filterTrainings(e.target.value);
            });
        });

        // Staff selection
        document.getElementById('staff-select')?.addEventListener('change', (e) => {
            this.loadStaffTrainingHistory(e.target.value);
        });

        // Course selection
        document.getElementById('course-select')?.addEventListener('change', (e) => {
            this.updateCourseDetails(e.target.value);
        });
    }

    updateTrainingView() {
        this.updateTrainingSchedule();
        this.updateCertifications();
        this.updateComplianceStatus();
        this.updateProgressCharts();
    }

    updateTrainingSchedule() {
        const container = document.getElementById('training-schedule');
        if (!container) return;

        container.innerHTML = `
            <div class="list-group">
                ${Array.from(this.trainings.values())
                    .sort((a, b) => new Date(a.startDate) - new Date(b.startDate))
                    .map(training => `
                        <div class="list-group-item" data-training-id="${training.id}">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-1">
                                    ${this.courses.get(training.courseId)?.title}
                                    <span class="badge bg-${
                                        this.getTrainingTypeColor(training.type)
                                    } ms-2">
                                        ${this.formatTrainingType(training.type)}
                                    </span>
                                </h6>
                                <small class="text-muted">
                                    ${this.formatDate(training.startDate)}
                                </small>
                            </div>
                            <p class="mb-1">${training.description}</p>
                            <div class="d-flex align-items-center">
                                <div class="me-3">
                                    <small class="text-muted">Trainer:</small>
                                    <span class="ms-1">
                                        ${this.staff.get(training.trainerId)?.name}
                                    </span>
                                </div>
                                <div class="me-3">
                                    <small class="text-muted">Duration:</small>
                                    <span class="ms-1">${training.duration} hours</span>
                                </div>
                                <div class="me-3">
                                    <small class="text-muted">Location:</small>
                                    <span class="ms-1">${training.location}</span>
                                </div>
                                <div class="btn-group ms-auto">
                                    <button class="btn btn-sm btn-outline-primary edit-training"
                                            title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-success complete-training"
                                            title="Mark Complete"
                                            ${training.status === 'completed' ? 'disabled' : ''}>
                                        <i class="fas fa-check"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-danger cancel-training"
                                            title="Cancel"
                                            ${training.status === 'cancelled' ? 'disabled' : ''}>
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="progress mt-2" style="height: 5px;">
                                <div class="progress-bar bg-${
                                    this.getProgressColor(training.progress)
                                }" 
                                     role="progressbar"
                                     style="width: ${training.progress}%">
                                </div>
                            </div>
                        </div>
                    `).join('')}
            </div>
        `;

        this.addTrainingEventListeners();
    }

    updateCertifications() {
        const container = document.getElementById('certifications-list');
        if (!container) return;

        container.innerHTML = `
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Staff Member</th>
                            <th>Certification</th>
                            <th>Issue Date</th>
                            <th>Expiry Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${Array.from(this.certifications.values())
                            .map(cert => `
                                <tr data-cert-id="${cert.id}">
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <img src="${
                                                this.staff.get(cert.staffId)?.avatar
                                            }" 
                                                 class="rounded-circle me-2" 
                                                 width="32">
                                            ${this.staff.get(cert.staffId)?.name}
                                        </div>
                                    </td>
                                    <td>${cert.name}</td>
                                    <td>${this.formatDate(cert.issueDate)}</td>
                                    <td>
                                        <span class="text-${
                                            this.isExpiringSoon(cert.expiryDate) ? 
                                            'warning' : 'muted'
                                        }">
                                            ${this.formatDate(cert.expiryDate)}
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-${
                                            this.getCertStatusColor(cert)
                                        }">
                                            ${this.getCertStatus(cert)}
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <button class="btn btn-sm btn-outline-primary view-cert"
                                                    title="View Certificate">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn btn-sm btn-outline-success renew-cert"
                                                    title="Renew"
                                                    ${
                                                        !this.isExpiringSoon(cert.expiryDate) ? 
                                                        'disabled' : ''
                                                    }>
                                                <i class="fas fa-sync"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }

    // Utility functions
    formatTrainingType(type) {
        return type.split('_').map(word => 
            word.charAt(0).toUpperCase() + word.slice(1)
        ).join(' ');
    }

    formatDate(date) {
        return new Date(date).toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    }

    getTrainingTypeColor(type) {
        const colors = {
            onboarding: 'primary',
            safety: 'danger',
            customer_service: 'success',
            vehicle_operation: 'warning',
            first_aid: 'info',
            compliance: 'secondary'
        };
        return colors[type] || 'secondary';
    }

    getProgressColor(progress) {
        if (progress >= 80) return 'success';
        if (progress >= 50) return 'warning';
        return 'danger';
    }

    getCertStatusColor(cert) {
        if (new Date(cert.expiryDate) < new Date()) return 'danger';
        if (this.isExpiringSoon(cert.expiryDate)) return 'warning';
        return 'success';
    }

    getCertStatus(cert) {
        if (new Date(cert.expiryDate) < new Date()) return 'Expired';
        if (this.isExpiringSoon(cert.expiryDate)) return 'Expiring Soon';
        return 'Valid';
    }

    isExpiringSoon(date) {
        const expiryDate = new Date(date);
        const today = new Date();
        const daysUntilExpiry = Math.ceil(
            (expiryDate - today) / (1000 * 60 * 60 * 24)
        );
        return daysUntilExpiry <= 30 && daysUntilExpiry > 0;
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize TrainingManager when the training page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.training-manager')) {
        const trainingManager = new TrainingManager();
        trainingManager.initialize();
    }
});
