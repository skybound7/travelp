class MaintenanceScheduler {
    constructor() {
        this.schedule = new Map();
        this.vehicles = new Map();
        this.technicians = new Map();
        this.maintenanceTypes = [
            'routine',
            'preventive',
            'repair',
            'inspection',
            'emergency'
        ];
        this.calendar = null;
    }

    async initialize() {
        await this.loadMaintenanceData();
        this.initializeCalendar();
        this.initializeEventListeners();
        this.setupNotifications();
    }

    async loadMaintenanceData() {
        try {
            const [schedule, vehicles, technicians] = await Promise.all([
                this.fetchSchedule(),
                this.fetchVehicles(),
                this.fetchTechnicians()
            ]);

            this.schedule = new Map(schedule.map(item => [item.id, item]));
            this.vehicles = new Map(vehicles.map(vehicle => [vehicle.id, vehicle]));
            this.technicians = new Map(technicians.map(tech => [tech.id, tech]));

            this.updateMaintenanceView();
        } catch (error) {
            console.error('Error loading maintenance data:', error);
            this.showError('Failed to load maintenance data');
        }
    }

    async fetchSchedule() {
        const response = await fetch('/api/staff/maintenance/schedule.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        return await response.json();
    }

    initializeCalendar() {
        const calendarEl = document.getElementById('maintenance-calendar');
        if (!calendarEl) return;

        this.calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'timeGridWeek',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,listWeek'
            },
            editable: true,
            selectable: true,
            selectMirror: true,
            dayMaxEvents: true,
            weekNumbers: true,
            businessHours: true,
            eventClick: (info) => this.handleEventClick(info),
            select: (info) => this.handleDateSelect(info),
            eventDrop: (info) => this.handleEventDrop(info),
            events: this.getCalendarEvents()
        });

        this.calendar.render();
    }

    initializeEventListeners() {
        // Schedule maintenance
        document.getElementById('schedule-maintenance-btn')?.addEventListener('click', () => {
            this.showScheduleModal();
        });

        // Filter options
        document.querySelectorAll('.maintenance-filter')?.forEach(filter => {
            filter.addEventListener('change', (e) => {
                this.filterMaintenance(e.target.value);
            });
        });

        // Vehicle selection
        document.getElementById('vehicle-select')?.addEventListener('change', (e) => {
            this.loadVehicleHistory(e.target.value);
        });

        // Technician assignment
        document.getElementById('technician-select')?.addEventListener('change', (e) => {
            this.updateTechnicianSchedule(e.target.value);
        });
    }

    async scheduleMaintenance(data) {
        try {
            const response = await fetch('/api/staff/maintenance/schedule.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            if (result.status === 'success') {
                this.schedule.set(result.maintenanceId, result.maintenance);
                this.updateMaintenanceView();
                this.showSuccess('Maintenance scheduled successfully');
            }
        } catch (error) {
            console.error('Error scheduling maintenance:', error);
            this.showError('Failed to schedule maintenance');
        }
    }

    updateMaintenanceView() {
        this.updateScheduleList();
        this.updateVehicleStatus();
        this.updateTechnicianWorkload();
        if (this.calendar) {
            this.calendar.refetchEvents();
        }
    }

    updateScheduleList() {
        const container = document.getElementById('maintenance-schedule');
        if (!container) return;

        container.innerHTML = `
            <div class="list-group">
                ${Array.from(this.schedule.values())
                    .sort((a, b) => new Date(a.scheduledDate) - new Date(b.scheduledDate))
                    .map(item => `
                        <div class="list-group-item" data-maintenance-id="${item.id}">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-1">
                                    ${this.vehicles.get(item.vehicleId)?.name} - 
                                    ${this.formatMaintenanceType(item.type)}
                                </h6>
                                <small class="text-muted">
                                    ${this.formatDate(item.scheduledDate)}
                                </small>
                            </div>
                            <p class="mb-1">${item.description}</p>
                            <div class="d-flex align-items-center">
                                <div class="me-3">
                                    <small class="text-muted">Technician:</small>
                                    <span class="ms-1">
                                        ${this.technicians.get(item.technicianId)?.name}
                                    </span>
                                </div>
                                <div class="me-3">
                                    <small class="text-muted">Duration:</small>
                                    <span class="ms-1">${item.duration} hours</span>
                                </div>
                                <div class="me-3">
                                    <small class="text-muted">Status:</small>
                                    <span class="badge bg-${
                                        this.getStatusColor(item.status)
                                    } ms-1">
                                        ${item.status}
                                    </span>
                                </div>
                                <div class="btn-group ms-auto">
                                    <button class="btn btn-sm btn-outline-primary edit-maintenance"
                                            title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-success complete-maintenance"
                                            title="Mark Complete"
                                            ${item.status === 'completed' ? 'disabled' : ''}>
                                        <i class="fas fa-check"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-danger cancel-maintenance"
                                            title="Cancel"
                                            ${item.status === 'cancelled' ? 'disabled' : ''}>
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
            </div>
        `;

        this.addMaintenanceEventListeners();
    }

    // Utility functions
    formatMaintenanceType(type) {
        return type.charAt(0).toUpperCase() + type.slice(1);
    }

    formatDate(date) {
        return new Date(date).toLocaleDateString('en-GB', {
            weekday: 'short',
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    getStatusColor(status) {
        const colors = {
            scheduled: 'primary',
            in_progress: 'warning',
            completed: 'success',
            cancelled: 'danger',
            overdue: 'dark'
        };
        return colors[status] || 'secondary';
    }

    getCalendarEvents() {
        return Array.from(this.schedule.values()).map(item => ({
            id: item.id,
            title: `${this.vehicles.get(item.vehicleId)?.name} - ${item.type}`,
            start: item.scheduledDate,
            end: this.calculateEndTime(item.scheduledDate, item.duration),
            backgroundColor: this.getStatusColor(item.status),
            borderColor: this.getStatusColor(item.status),
            extendedProps: {
                vehicleId: item.vehicleId,
                technicianId: item.technicianId,
                type: item.type,
                description: item.description
            }
        }));
    }

    calculateEndTime(startDate, duration) {
        const end = new Date(startDate);
        end.setHours(end.getHours() + duration);
        return end;
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize MaintenanceScheduler when the maintenance page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.maintenance-scheduler')) {
        const maintenanceScheduler = new MaintenanceScheduler();
        maintenanceScheduler.initialize();
    }
});
