class BookingManager {
    constructor() {
        this.bookings = [];
        this.currentView = 'list';
        this.filters = {
            status: 'all',
            date: 'all',
            searchQuery: ''
        };
        this.pagination = {
            page: 1,
            perPage: 10,
            total: 0
        };
    }

    async initialize() {
        await this.loadBookings();
        this.initializeEventListeners();
        this.initializeCalendarView();
        this.initializeMap();
    }

    async loadBookings() {
        try {
            const response = await fetch(`/api/staff/bookings.php?${this.getQueryString()}`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.bookings = data.bookings;
                this.pagination.total = data.total;
                this.renderBookings();
            }
        } catch (error) {
            console.error('Error loading bookings:', error);
            this.showError('Failed to load bookings');
        }
    }

    initializeEventListeners() {
        // View toggle
        document.querySelectorAll('.view-toggle').forEach(toggle => {
            toggle.addEventListener('click', (e) => {
                this.currentView = e.target.dataset.view;
                this.renderBookings();
            });
        });

        // Filters
        document.getElementById('booking-status-filter').addEventListener('change', (e) => {
            this.filters.status = e.target.value;
            this.loadBookings();
        });

        document.getElementById('booking-date-filter').addEventListener('change', (e) => {
            this.filters.date = e.target.value;
            this.loadBookings();
        });

        // Search
        document.getElementById('booking-search').addEventListener('input', debounce((e) => {
            this.filters.searchQuery = e.target.value;
            this.loadBookings();
        }, 300));

        // Bulk actions
        document.getElementById('bulk-action-apply').addEventListener('click', () => {
            const action = document.getElementById('bulk-action-select').value;
            const selectedBookings = this.getSelectedBookings();
            this.applyBulkAction(action, selectedBookings);
        });
    }

    initializeCalendarView() {
        const calendarEl = document.getElementById('bookings-calendar');
        if (!calendarEl) return;

        this.calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay'
            },
            events: this.getCalendarEvents(),
            eventClick: (info) => {
                this.showBookingDetails(info.event.id);
            },
            eventDidMount: (info) => {
                // Add tooltips
                new bootstrap.Tooltip(info.el, {
                    title: info.event.title,
                    placement: 'top',
                    trigger: 'hover',
                    container: 'body'
                });
            }
        });

        this.calendar.render();
    }

    initializeMap() {
        const mapEl = document.getElementById('bookings-map');
        if (!mapEl) return;

        this.map = new google.maps.Map(mapEl, {
            zoom: 12,
            center: { lat: 0, lng: 0 } // Default center, will be updated
        });

        this.updateMapMarkers();
    }

    renderBookings() {
        const container = document.getElementById('bookings-container');
        if (!container) return;

        switch (this.currentView) {
            case 'list':
                this.renderListView(container);
                break;
            case 'grid':
                this.renderGridView(container);
                break;
            case 'calendar':
                this.calendar.refetchEvents();
                break;
            case 'map':
                this.updateMapMarkers();
                break;
        }

        this.updatePagination();
        this.updateStats();
    }

    renderListView(container) {
        container.innerHTML = `
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="select-all"></th>
                        <th>Booking ID</th>
                        <th>Customer</th>
                        <th>Service</th>
                        <th>Date & Time</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${this.bookings.map(booking => `
                        <tr data-booking-id="${booking.id}">
                            <td><input type="checkbox" class="booking-select"></td>
                            <td>#${booking.id}</td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <img src="${booking.customer.avatar}" class="rounded-circle me-2" width="32">
                                    <div>
                                        <div>${booking.customer.name}</div>
                                        <small class="text-muted">${booking.customer.email}</small>
                                    </div>
                                </div>
                            </td>
                            <td>${booking.service}</td>
                            <td>
                                <div>${this.formatDate(booking.datetime)}</div>
                                <small class="text-muted">${this.formatTime(booking.datetime)}</small>
                            </td>
                            <td>
                                <span class="badge bg-${this.getStatusColor(booking.status)}">
                                    ${booking.status}
                                </span>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-sm btn-outline-primary view-booking">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-success edit-booking">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-danger delete-booking">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;

        // Add event listeners
        this.addListViewEventListeners();
    }

    renderGridView(container) {
        container.innerHTML = `
            <div class="row">
                ${this.bookings.map(booking => `
                    <div class="col-md-4 col-lg-3 mb-4">
                        <div class="card booking-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start">
                                    <h6 class="card-title">Booking #${booking.id}</h6>
                                    <span class="badge bg-${this.getStatusColor(booking.status)}">
                                        ${booking.status}
                                    </span>
                                </div>
                                <div class="customer-info mb-3">
                                    <img src="${booking.customer.avatar}" class="rounded-circle me-2" width="32">
                                    <span>${booking.customer.name}</span>
                                </div>
                                <div class="booking-details">
                                    <p class="mb-1"><i class="fas fa-car"></i> ${booking.service}</p>
                                    <p class="mb-1"><i class="fas fa-calendar"></i> ${this.formatDate(booking.datetime)}</p>
                                    <p class="mb-1"><i class="fas fa-clock"></i> ${this.formatTime(booking.datetime)}</p>
                                </div>
                                <div class="mt-3">
                                    <button class="btn btn-sm btn-primary view-booking">View Details</button>
                                    <button class="btn btn-sm btn-outline-danger delete-booking">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;

        // Add event listeners
        this.addGridViewEventListeners();
    }

    updateMapMarkers() {
        // Clear existing markers
        if (this.markers) {
            this.markers.forEach(marker => marker.setMap(null));
        }
        this.markers = [];

        // Add markers for each booking
        this.bookings.forEach(booking => {
            const marker = new google.maps.Marker({
                position: booking.location,
                map: this.map,
                title: `Booking #${booking.id}`,
                icon: this.getMarkerIcon(booking.status)
            });

            // Add click listener
            marker.addListener('click', () => {
                this.showBookingDetails(booking.id);
            });

            this.markers.push(marker);
        });

        // Fit bounds to show all markers
        if (this.markers.length > 0) {
            const bounds = new google.maps.LatLngBounds();
            this.markers.forEach(marker => bounds.extend(marker.getPosition()));
            this.map.fitBounds(bounds);
        }
    }

    getCalendarEvents() {
        return this.bookings.map(booking => ({
            id: booking.id,
            title: `${booking.service} - ${booking.customer.name}`,
            start: booking.datetime,
            end: booking.endTime,
            backgroundColor: this.getStatusColor(booking.status),
            borderColor: this.getStatusColor(booking.status)
        }));
    }

    async showBookingDetails(bookingId) {
        try {
            const response = await fetch(`/api/staff/bookings/${bookingId}.php`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                }
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.showBookingModal(data.booking);
            }
        } catch (error) {
            console.error('Error loading booking details:', error);
            this.showError('Failed to load booking details');
        }
    }

    showBookingModal(booking) {
        const modal = new bootstrap.Modal(document.getElementById('booking-modal'));
        const modalBody = document.querySelector('#booking-modal .modal-body');
        
        modalBody.innerHTML = `
            <div class="booking-details">
                <div class="row">
                    <div class="col-md-6">
                        <h5>Customer Information</h5>
                        <p><strong>Name:</strong> ${booking.customer.name}</p>
                        <p><strong>Email:</strong> ${booking.customer.email}</p>
                        <p><strong>Phone:</strong> ${booking.customer.phone}</p>
                    </div>
                    <div class="col-md-6">
                        <h5>Booking Information</h5>
                        <p><strong>Service:</strong> ${booking.service}</p>
                        <p><strong>Date:</strong> ${this.formatDate(booking.datetime)}</p>
                        <p><strong>Time:</strong> ${this.formatTime(booking.datetime)}</p>
                        <p><strong>Status:</strong> 
                            <span class="badge bg-${this.getStatusColor(booking.status)}">
                                ${booking.status}
                            </span>
                        </p>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-12">
                        <h5>Journey Details</h5>
                        <p><strong>Pickup:</strong> ${booking.pickup}</p>
                        <p><strong>Dropoff:</strong> ${booking.dropoff}</p>
                        <p><strong>Distance:</strong> ${booking.distance} km</p>
                        <p><strong>Duration:</strong> ${booking.duration} mins</p>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-12">
                        <h5>Additional Information</h5>
                        <p><strong>Special Requests:</strong> ${booking.specialRequests || 'None'}</p>
                        <p><strong>Notes:</strong> ${booking.notes || 'None'}</p>
                    </div>
                </div>
            </div>
        `;

        modal.show();
    }

    // Utility functions
    formatDate(datetime) {
        return new Date(datetime).toLocaleDateString();
    }

    formatTime(datetime) {
        return new Date(datetime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    getStatusColor(status) {
        const colors = {
            pending: 'warning',
            confirmed: 'success',
            in_progress: 'primary',
            completed: 'info',
            cancelled: 'danger'
        };
        return colors[status] || 'secondary';
    }

    getMarkerIcon(status) {
        // Return appropriate marker icon based on status
        return `markers/${status}.png`;
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize BookingManager when the bookings page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.booking-manager')) {
        const bookingManager = new BookingManager();
        bookingManager.initialize();
    }
});
