class MessagingManager {
    constructor() {
        this.messages = new Map();
        this.conversations = new Map();
        this.staff = new Map();
        this.channels = new Map();
        this.socket = null;
        this.messageTypes = [
            'direct',
            'group',
            'announcement',
            'alert',
            'notification'
        ];
    }

    async initialize() {
        await this.loadMessagingData();
        this.initializeEventListeners();
        this.setupWebSocket();
        this.initializeNotifications();
    }

    async loadMessagingData() {
        try {
            const [messages, conversations, staff, channels] = await Promise.all([
                this.fetchMessages(),
                this.fetchConversations(),
                this.fetchStaff(),
                this.fetchChannels()
            ]);

            this.messages = new Map(messages.map(m => [m.id, m]));
            this.conversations = new Map(conversations.map(c => [c.id, c]));
            this.staff = new Map(staff.map(s => [s.id, s]));
            this.channels = new Map(channels.map(c => [c.id, c]));

            this.updateMessagingView();
        } catch (error) {
            console.error('Error loading messaging data:', error);
            this.showError('Failed to load messaging data');
        }
    }

    async fetchMessages() {
        const response = await fetch('/api/staff/messages/list.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        return await response.json();
    }

    setupWebSocket() {
        const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        this.socket = new WebSocket(
            `${wsProtocol}//${window.location.host}/ws/messages`
        );

        this.socket.onmessage = (event) => {
            const message = JSON.parse(event.data);
            this.handleNewMessage(message);
        };

        this.socket.onclose = () => {
            setTimeout(() => this.setupWebSocket(), 5000);
        };
    }

    initializeEventListeners() {
        // New message
        document.getElementById('new-message-btn')?.addEventListener('click', () => {
            this.showNewMessageModal();
        });

        // New channel
        document.getElementById('new-channel-btn')?.addEventListener('click', () => {
            this.showNewChannelModal();
        });

        // Message search
        document.getElementById('message-search')?.addEventListener('input', (e) => {
            this.searchMessages(e.target.value);
        });

        // Channel selection
        document.querySelectorAll('.channel-item')?.forEach(channel => {
            channel.addEventListener('click', (e) => {
                this.selectChannel(e.target.dataset.channelId);
            });
        });

        // Message input
        document.getElementById('message-input')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
    }

    updateMessagingView() {
        this.updateChannelsList();
        this.updateConversationsList();
        this.updateMessageThread();
        this.updateUnreadCount();
    }

    updateChannelsList() {
        const container = document.getElementById('channels-list');
        if (!container) return;

        container.innerHTML = `
            <div class="channels-header d-flex justify-content-between align-items-center mb-3">
                <h6 class="mb-0">Channels</h6>
                <button class="btn btn-sm btn-primary" id="new-channel-btn">
                    <i class="fas fa-plus"></i>
                </button>
            </div>
            <div class="list-group">
                ${Array.from(this.channels.values()).map(channel => `
                    <div class="list-group-item channel-item ${
                        channel.selected ? 'active' : ''
                    }" 
                         data-channel-id="${channel.id}">
                        <div class="d-flex align-items-center">
                            <div class="channel-icon me-2">
                                <i class="fas ${this.getChannelIcon(channel.type)}"></i>
                            </div>
                            <div class="channel-info flex-grow-1">
                                <div class="channel-name">${channel.name}</div>
                                <small class="text-muted">
                                    ${channel.memberCount} members
                                </small>
                            </div>
                            ${channel.unreadCount > 0 ? `
                                <span class="badge bg-primary rounded-pill">
                                    ${channel.unreadCount}
                                </span>
                            ` : ''}
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    updateConversationsList() {
        const container = document.getElementById('conversations-list');
        if (!container) return;

        container.innerHTML = `
            <div class="conversations-header d-flex justify-content-between align-items-center mb-3">
                <h6 class="mb-0">Direct Messages</h6>
                <button class="btn btn-sm btn-primary" id="new-message-btn">
                    <i class="fas fa-edit"></i>
                </button>
            </div>
            <div class="list-group">
                ${Array.from(this.conversations.values())
                    .sort((a, b) => new Date(b.lastMessageTime) - new Date(a.lastMessageTime))
                    .map(conversation => `
                        <div class="list-group-item conversation-item ${
                            conversation.selected ? 'active' : ''
                        }"
                             data-conversation-id="${conversation.id}">
                            <div class="d-flex align-items-center">
                                <div class="conversation-avatar me-2">
                                    <img src="${
                                        this.staff.get(conversation.participantId)?.avatar
                                    }"
                                         class="rounded-circle"
                                         width="40"
                                         height="40">
                                    <span class="status-indicator ${
                                        this.staff.get(conversation.participantId)?.online
                                            ? 'online'
                                            : 'offline'
                                    }"></span>
                                </div>
                                <div class="conversation-info flex-grow-1">
                                    <div class="conversation-name">
                                        ${this.staff.get(conversation.participantId)?.name}
                                    </div>
                                    <div class="conversation-preview text-muted small">
                                        ${conversation.lastMessage}
                                    </div>
                                </div>
                                <div class="conversation-meta text-end">
                                    <div class="conversation-time small text-muted">
                                        ${this.formatTime(conversation.lastMessageTime)}
                                    </div>
                                    ${conversation.unreadCount > 0 ? `
                                        <span class="badge bg-primary rounded-pill">
                                            ${conversation.unreadCount}
                                        </span>
                                    ` : ''}
                                </div>
                            </div>
                        </div>
                    `).join('')}
            </div>
        `;
    }

    updateMessageThread() {
        const container = document.getElementById('message-thread');
        if (!container) return;

        const selectedConversation = Array.from(this.conversations.values())
            .find(c => c.selected);
        
        if (!selectedConversation) {
            container.innerHTML = `
                <div class="text-center text-muted my-5">
                    <i class="fas fa-comments fa-3x mb-3"></i>
                    <p>Select a conversation to start messaging</p>
                </div>
            `;
            return;
        }

        const messages = Array.from(this.messages.values())
            .filter(m => m.conversationId === selectedConversation.id)
            .sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

        container.innerHTML = `
            <div class="message-thread-header border-bottom p-3">
                <div class="d-flex align-items-center">
                    <div class="thread-avatar me-3">
                        <img src="${
                            this.staff.get(selectedConversation.participantId)?.avatar
                        }"
                             class="rounded-circle"
                             width="48"
                             height="48">
                        <span class="status-indicator ${
                            this.staff.get(selectedConversation.participantId)?.online
                                ? 'online'
                                : 'offline'
                        }"></span>
                    </div>
                    <div class="thread-info">
                        <h6 class="mb-0">
                            ${this.staff.get(selectedConversation.participantId)?.name}
                        </h6>
                        <small class="text-muted">
                            ${
                                this.staff.get(selectedConversation.participantId)?.online
                                    ? 'Online'
                                    : 'Offline'
                            }
                        </small>
                    </div>
                    <div class="thread-actions ms-auto">
                        <div class="btn-group">
                            <button class="btn btn-light" title="Voice Call">
                                <i class="fas fa-phone"></i>
                            </button>
                            <button class="btn btn-light" title="Video Call">
                                <i class="fas fa-video"></i>
                            </button>
                            <button class="btn btn-light" title="More Options">
                                <i class="fas fa-ellipsis-v"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="message-thread-body p-3">
                ${messages.map(message => `
                    <div class="message ${
                        message.senderId === this.getCurrentUserId() ? 'sent' : 'received'
                    } mb-3">
                        <div class="message-content">
                            ${message.content}
                            ${message.attachments?.length ? `
                                <div class="message-attachments mt-2">
                                    ${message.attachments.map(attachment => `
                                        <div class="attachment">
                                            <i class="fas ${
                                                this.getAttachmentIcon(attachment.type)
                                            }"></i>
                                            <span>${attachment.name}</span>
                                        </div>
                                    `).join('')}
                                </div>
                            ` : ''}
                        </div>
                        <div class="message-meta">
                            <small class="text-muted">
                                ${this.formatTime(message.timestamp)}
                                ${message.read ? `
                                    <i class="fas fa-check-double text-primary ms-1"></i>
                                ` : `
                                    <i class="fas fa-check ms-1"></i>
                                `}
                            </small>
                        </div>
                    </div>
                `).join('')}
            </div>

            <div class="message-thread-footer border-top p-3">
                <div class="input-group">
                    <button class="btn btn-light" title="Attach File">
                        <i class="fas fa-paperclip"></i>
                    </button>
                    <textarea class="form-control" 
                              id="message-input"
                              placeholder="Type a message..."
                              rows="1"></textarea>
                    <button class="btn btn-primary" id="send-message-btn">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </div>
            </div>
        `;

        // Scroll to bottom of message thread
        const threadBody = container.querySelector('.message-thread-body');
        threadBody.scrollTop = threadBody.scrollHeight;
    }

    // Utility functions
    getChannelIcon(type) {
        const icons = {
            team: 'fa-users',
            announcement: 'fa-bullhorn',
            project: 'fa-project-diagram',
            general: 'fa-hashtag'
        };
        return icons[type] || 'fa-hashtag';
    }

    getAttachmentIcon(type) {
        const icons = {
            image: 'fa-image',
            document: 'fa-file-alt',
            pdf: 'fa-file-pdf',
            spreadsheet: 'fa-file-excel'
        };
        return icons[type] || 'fa-file';
    }

    formatTime(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        
        if (date.toDateString() === now.toDateString()) {
            return date.toLocaleTimeString('en-GB', {
                hour: '2-digit',
                minute: '2-digit'
            });
        }
        
        if (now.getTime() - date.getTime() < 7 * 24 * 60 * 60 * 1000) {
            return date.toLocaleDateString('en-GB', { weekday: 'short' });
        }
        
        return date.toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'short'
        });
    }

    getCurrentUserId() {
        return localStorage.getItem('user_id');
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize MessagingManager when the messaging page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.messaging-manager')) {
        const messagingManager = new MessagingManager();
        messagingManager.initialize();
    }
});
