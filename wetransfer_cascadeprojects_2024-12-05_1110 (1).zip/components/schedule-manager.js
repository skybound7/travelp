class ScheduleManager {
    constructor() {
        this.calendar = null;
        this.shifts = new Map();
        this.staff = new Map();
        this.preferences = new Map();
        this.shiftTypes = [
            'morning',
            'afternoon',
            'evening',
            'night',
            'on_call'
        ];
    }

    async initialize() {
        await this.loadScheduleData();
        this.initializeCalendar();
        this.initializeEventListeners();
        this.setupDragAndDrop();
    }

    async loadScheduleData() {
        try {
            const [shifts, staff, preferences] = await Promise.all([
                this.fetchShifts(),
                this.fetchStaff(),
                this.fetchPreferences()
            ]);

            this.shifts = new Map(shifts.map(shift => [shift.id, shift]));
            this.staff = new Map(staff.map(member => [member.id, member]));
            this.preferences = new Map(preferences);

            this.updateScheduleView();
        } catch (error) {
            console.error('Error loading schedule data:', error);
            this.showError('Failed to load schedule data');
        }
    }

    async fetchShifts() {
        const response = await fetch('/api/staff/schedule/shifts.php', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            }
        });
        return await response.json();
    }

    initializeCalendar() {
        const calendarEl = document.getElementById('schedule-calendar');
        if (!calendarEl) return;

        this.calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'timeGridWeek',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
            },
            slotMinTime: '06:00:00',
            slotMaxTime: '23:00:00',
            slotDuration: '01:00:00',
            editable: true,
            selectable: true,
            selectMirror: true,
            dayMaxEvents: true,
            weekNumbers: true,
            nowIndicator: true,
            businessHours: {
                daysOfWeek: [0, 1, 2, 3, 4, 5, 6],
                startTime: '06:00',
                endTime: '23:00',
            },
            select: (info) => {
                this.handleDateSelect(info);
            },
            eventClick: (info) => {
                this.handleEventClick(info);
            },
            eventDrop: (info) => {
                this.handleEventDrop(info);
            },
            eventResize: (info) => {
                this.handleEventResize(info);
            },
            events: this.getCalendarEvents()
        });

        this.calendar.render();
    }

    getCalendarEvents() {
        return Array.from(this.shifts.values()).map(shift => ({
            id: shift.id,
            title: this.formatShiftTitle(shift),
            start: shift.startTime,
            end: shift.endTime,
            backgroundColor: this.getShiftColor(shift.type),
            borderColor: this.getShiftColor(shift.type),
            textColor: '#ffffff',
            extendedProps: {
                staffId: shift.staffId,
                type: shift.type,
                notes: shift.notes
            }
        }));
    }

    initializeEventListeners() {
        // Add shift
        document.getElementById('add-shift-btn')?.addEventListener('click', () => {
            this.showShiftModal();
        });

        // Staff availability
        document.getElementById('availability-btn')?.addEventListener('click', () => {
            this.showAvailabilityModal();
        });

        // View options
        document.querySelectorAll('.view-option')?.forEach(option => {
            option.addEventListener('click', (e) => {
                this.calendar.changeView(e.target.dataset.view);
            });
        });

        // Filter shifts
        document.querySelectorAll('.shift-filter')?.forEach(filter => {
            filter.addEventListener('change', (e) => {
                this.filterShifts(e.target.value);
            });
        });
    }

    setupDragAndDrop() {
        const staffList = document.getElementById('staff-list');
        if (!staffList) return;

        new Draggable(staffList, {
            itemSelector: '.staff-item',
            eventData: (eventEl) => {
                const staffId = eventEl.dataset.staffId;
                const staffMember = this.staff.get(staffId);
                return {
                    title: staffMember.name,
                    duration: '04:00',
                    extendedProps: {
                        staffId: staffId
                    }
                };
            }
        });
    }

    async handleDateSelect(info) {
        const staffId = prompt('Enter staff ID:');
        if (!staffId) return;

        try {
            const response = await fetch('/api/staff/schedule/shifts.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({
                    staffId,
                    startTime: info.startStr,
                    endTime: info.endStr,
                    type: 'morning'
                })
            });

            const data = await response.json();
            if (data.status === 'success') {
                this.calendar.addEvent({
                    id: data.shiftId,
                    title: this.staff.get(staffId).name,
                    start: info.startStr,
                    end: info.endStr,
                    backgroundColor: this.getShiftColor('morning'),
                    extendedProps: {
                        staffId
                    }
                });
            }
        } catch (error) {
            console.error('Error creating shift:', error);
            this.showError('Failed to create shift');
        }
    }

    async handleEventDrop(info) {
        try {
            await fetch('/api/staff/schedule/shifts.php', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: JSON.stringify({
                    shiftId: info.event.id,
                    startTime: info.event.startStr,
                    endTime: info.event.endStr
                })
            });
        } catch (error) {
            console.error('Error updating shift:', error);
            info.revert();
            this.showError('Failed to update shift');
        }
    }

    updateScheduleView() {
        this.updateStaffList();
        this.updateShiftSummary();
        this.updateConflicts();
        if (this.calendar) {
            this.calendar.refetchEvents();
        }
    }

    updateStaffList() {
        const container = document.getElementById('staff-list');
        if (!container) return;

        container.innerHTML = `
            <div class="list-group">
                ${Array.from(this.staff.values()).map(member => `
                    <div class="list-group-item staff-item" 
                         data-staff-id="${member.id}">
                        <div class="d-flex align-items-center">
                            <img src="${member.avatar}" 
                                 class="rounded-circle me-2" 
                                 width="32">
                            <div>
                                <div class="fw-bold">${member.name}</div>
                                <small class="text-muted">
                                    ${member.role}
                                </small>
                            </div>
                            <div class="ms-auto">
                                <span class="badge bg-${
                                    member.available ? 'success' : 'danger'
                                }">
                                    ${member.available ? 'Available' : 'Busy'}
                                </span>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    // Utility functions
    formatShiftTitle(shift) {
        const staff = this.staff.get(shift.staffId);
        return `${staff.name} - ${this.formatShiftType(shift.type)}`;
    }

    formatShiftType(type) {
        return type.charAt(0).toUpperCase() + type.slice(1).replace('_', ' ');
    }

    getShiftColor(type) {
        const colors = {
            morning: '#4CAF50',
            afternoon: '#2196F3',
            evening: '#9C27B0',
            night: '#607D8B',
            on_call: '#FF9800'
        };
        return colors[type] || '#9E9E9E';
    }

    showSuccess(message) {
        // Implementation of success toast
    }

    showError(message) {
        // Implementation of error toast
    }
}

// Initialize ScheduleManager when the schedule page is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.schedule-manager')) {
        const scheduleManager = new ScheduleManager();
        scheduleManager.initialize();
    }
});
